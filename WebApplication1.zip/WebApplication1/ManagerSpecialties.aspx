﻿<%@ Page Title="مدیریت کارشناسان"
    Language="C#"
    MasterPageFile="~/Site.Master"
    AutoEventWireup="true"
    CodeBehind="ManagerSpecialties.aspx.cs"
    Inherits="WebApplication1.ManagerSpecialties" %>

<asp:Content ID="Content1"
    ContentPlaceHolderID="TitleContent"
    runat="server">
    مدیریت کارشناسان
</asp:Content>

<asp:Content ID="Content2"
    ContentPlaceHolderID="HeadContent"
    runat="server">

<style type="text/css">

    .mk-page {
        width: 100%;
        direction: rtl;
        font-family: "Vazirmatn","B Nazanin","B Zar",Tahoma,Arial,sans-serif;
    }

    .mk-intro {
        padding: 20px 22px;
        margin-bottom: 18px;
        background: linear-gradient(135deg,#f8fbff,#ffffff);
        border: 1px solid #e7edf5;
        border-radius: 14px;
        box-shadow: 0 4px 18px rgba(35,48,66,.04);
    }

    .mk-title {
        margin: 0 0 6px;
        color: #273142;
        font-size: 19px;
        font-weight: 700;
    }

    .mk-desc {
        margin: 0;
        color: #7b8493;
        font-size: 12px;
        line-height: 1.9;
    }

    .mk-tabs {
        background: #fff;
        border: 1px solid #e6ebf2;
        border-radius: 14px;
        box-shadow: 0 4px 18px rgba(35,48,66,.05);
        overflow: hidden;
    }

    .mk-tab-buttons {
        display: flex;
        align-items: stretch;
        background: #f8fafc;
        border-bottom: 1px solid #e6ebf2;
        overflow-x: auto;
    }

    .mk-tab-button {
        position: relative;
        border: 0;
        background: transparent;
        color: #687386;
        padding: 15px 22px;
        font-family: inherit;
        font-size: 13px;
        font-weight: 600;
        cursor: pointer;
        white-space: nowrap;
    }

    .mk-tab-button:hover {
        background: #f1f5f9;
        color: #334155;
    }

    .mk-tab-button.active {
        background: #fff;
        color: #2f80ed;
        font-weight: 700;
    }

    .mk-tab-button.active:after {
        content: "";
        position: absolute;
        right: 0;
        left: 0;
        bottom: -1px;
        height: 3px;
        background: #2f80ed;
        border-radius: 3px 3px 0 0;
    }

    .mk-tab-icon {
        margin-left: 7px;
    }

    .mk-tab-content {
        display: none;
        padding: 20px;
    }

    .mk-tab-content.active {
        display: block;
    }

    .mk-card {
        background: #fff;
        border: 1px solid #e6ebf2;
        border-radius: 14px;
        box-shadow: 0 4px 18px rgba(35,48,66,.05);
        overflow: hidden;
        margin-bottom: 18px;
    }

    .mk-card:last-child {
        margin-bottom: 0;
    }

    .mk-card-head {
        display: flex;
        align-items: center;
        gap: 11px;
        min-height: 64px;
        padding: 0 20px;
        border-bottom: 1px solid #edf0f4;
    }

    .mk-icon {
        width: 36px;
        height: 36px;
        min-width: 36px;
        border-radius: 9px;
        background: #edf4ff;
        color: #2f80ed;
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: 700;
        font-size: 16px;
    }

    .mk-card-head h3 {
        margin: 0;
        color: #273142;
        font-size: 15px;
    }

    .mk-card-head p {
        margin: 4px 0 0;
        color: #929baa;
        font-size: 11px;
    }

    .mk-body {
        padding: 20px;
    }

    .mk-grid-two {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 16px;
    }

    .mk-group {
        margin-bottom: 15px;
    }

    .mk-label {
        display: block;
        margin-bottom: 7px;
        color: #687386;
        font-size: 12px;
        font-weight: 600;
    }

    .mk-input,
    .mk-select {
        width: 100%;
        min-height: 42px;
        box-sizing: border-box;
        padding: 9px 12px;
        border: 1px solid #dce2ea;
        border-radius: 9px;
        background: #fff;
        color: #3f4a5a;
        font-family: inherit;
        font-size: 12px;
        outline: none;
    }

    .mk-input:focus,
    .mk-select:focus {
        border-color: #8bb8f3;
        box-shadow: 0 0 0 3px rgba(47,128,237,.08);
    }

    .mk-hint {
        margin-top: 5px;
        color: #9aa3b1;
        font-size: 10px;
        line-height: 1.8;
    }

    .mk-specialties-box {
        background: #f8fafc;
        border: 1px solid #e3e8ef;
        border-radius: 10px;
        padding: 12px;
        min-height: 80px;
    }

    .mk-specialty-item {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 10px;
        padding: 10px 11px;
        background: #fff;
        border: 1px solid #edf0f4;
        border-radius: 8px;
        margin-bottom: 7px;
    }

    .mk-specialty-item:last-child {
        margin-bottom: 0;
    }

    .mk-specialty-name {
        color: #354052;
        font-size: 11px;
        font-weight: 600;
    }

    .mk-specialty-desc {
        margin-top: 3px;
        color: #929baa;
        font-size: 9px;
    }

    .mk-remove {
        min-width: 48px;
        min-height: 29px;
        border: 1px solid #f3d3d6;
        border-radius: 7px;
        background: #fff1f2;
        color: #d64550;
        font-family: inherit;
        font-size: 10px;
        cursor: pointer;
    }

    .mk-remove:hover {
        background: #ffe5e7;
    }

    .mk-empty {
        display: block;
        padding: 20px;
        text-align: center;
        color: #929baa;
        font-size: 10px;
    }

    .mk-add-specialty {
        display: flex;
        gap: 8px;
        margin-top: 11px;
    }

    .mk-add-specialty .mk-select {
        flex: 1;
    }

    .mk-btn {
        min-height: 40px;
        border: 0;
        border-radius: 9px;
        padding: 8px 16px;
        font-family: inherit;
        font-size: 11px;
        font-weight: 600;
        cursor: pointer;
    }

    .mk-btn-primary {
        background: #2f80ed;
        color: #fff;
    }

    .mk-btn-primary:hover {
        background: #216fda;
    }

    .mk-btn-success {
        background: #28a56a;
        color: #fff;
    }

    .mk-btn-success:hover {
        background: #218c59;
    }

    .mk-btn-secondary {
        background: #f0f2f5;
        color: #596273;
    }

    .mk-btn-secondary:hover {
        background: #e5e8ec;
    }

    .mk-btn-danger {
        background: #fff1f2;
        color: #d64550;
        border: 1px solid #f3d3d6;
    }

    .mk-actions {
        display: flex;
        gap: 8px;
        margin-top: 18px;
        padding-top: 16px;
        border-top: 1px solid #edf0f4;
    }

    .mk-message {
        display: block;
        margin-top: 14px;
        padding: 10px 12px;
        border-radius: 8px;
        font-size: 11px;
        line-height: 1.9;
    }

    .mk-success {
        background: #eaf8f0;
        color: #238653;
    }

    .mk-error {
        background: #fff0f1;
        color: #c83b46;
    }

    .mk-info {
        background: #edf4ff;
        color: #3573c9;
    }

    .mk-status-row {
        display: flex;
        align-items: center;
        gap: 8px;
        margin-top: 7px;
    }

    .mk-status-label {
        color: #596273;
        font-size: 11px;
    }

    .mk-table-wrap {
        overflow-x: auto;
        -webkit-overflow-scrolling: touch;
        border: 1px solid #edf0f4;
        border-radius: 10px;
    }

    .mk-grid-table {
        width: 100%;
        min-width: 900px;
        border-collapse: collapse;
    }

    .mk-grid-table th {
        padding: 12px 13px;
        background: #f8f9fb;
        color: #687386;
        font-size: 11px;
        text-align: right;
        white-space: nowrap;
        border-bottom: 1px solid #e8ebf0;
    }

    .mk-grid-table td {
        padding: 11px 13px;
        color: #4d5869;
        font-size: 11px;
        line-height: 1.8;
        border-bottom: 1px solid #eef1f4;
        vertical-align: middle;
    }

    .mk-grid-table tr:last-child td {
        border-bottom: 0;
    }

    .mk-grid-table tr:hover td {
        background: #fafbfd;
    }

    .mk-user-name {
        font-weight: 700;
        color: #354052;
    }

    .mk-pill {
        display: inline-block;
        margin: 2px 3px 2px 0;
        padding: 4px 8px;
        border-radius: 12px;
        background: #edf4ff;
        color: #3573c9;
        font-size: 9px;
    }

    .mk-no-specialty {
        color: #929baa;
        font-size: 9px;
    }

    .mk-grid-btn {
        display: inline-block;
        margin-left: 4px;
        margin-bottom: 3px;
        padding: 6px 9px;
        border-radius: 7px;
        font-family: inherit;
        font-size: 9px;
        cursor: pointer;
        text-decoration: none;
    }

    .mk-edit-btn {
        background: #edf4ff;
        color: #2f70c8;
        border: 1px solid #d7e7ff;
    }

    .mk-on {
        background: #eaf8f0;
        color: #238653;
        border: 1px solid #d2efdf;
    }

    .mk-off {
        background: #f1f2f4;
        color: #777f8c;
        border: 1px solid #e0e2e6;
    }

    .mk-search {
        margin-bottom: 15px;
    }

    .mk-selected {
        display: block;
        margin-bottom: 15px;
        padding: 10px 12px;
        background: #f7f9fc;
        color: #455165;
        border-radius: 9px;
        font-size: 11px;
    }

    .mk-selected strong {
        color: #2f80ed;
    }

    .mk-specialty-tools {
        display: flex;
        align-items: flex-end;
        justify-content: space-between;
        gap: 12px;
        margin-bottom: 16px;
        flex-wrap: wrap;
    }

    .mk-specialty-search {
        flex: 1;
        min-width: 250px;
    }

    .mk-specialty-new {
        flex-shrink: 0;
    }

    .mk-specialty-edit {
        background: #f8fafc;
        border: 1px solid #e4e9ef;
        border-radius: 11px;
        padding: 16px;
        margin-bottom: 17px;
    }

    .mk-specialty-edit-title {
        color: #354052;
        font-size: 13px;
        font-weight: 700;
        margin-bottom: 14px;
    }

    .mk-count {
        display: inline-block;
        min-width: 25px;
        padding: 3px 7px;
        border-radius: 12px;
        background: #f1f5f9;
        color: #64748b;
        text-align: center;
        font-size: 9px;
    }

    .mk-specialty-description {
        color: #7b8493;
        font-size: 10px;
        line-height: 1.8;
    }

    @media(max-width:700px) {

        .mk-grid-two {
            grid-template-columns: 1fr;
        }

        .mk-body {
            padding: 14px;
        }

        .mk-tab-content {
            padding: 14px;
        }

        .mk-card-head {
            padding: 0 14px;
        }

        .mk-add-specialty {
            flex-direction: column;
        }

        .mk-actions {
            flex-wrap: wrap;
        }

        .mk-actions .mk-btn {
            flex: 1;
        }

        .mk-specialty-tools {
            flex-direction: column;
            align-items: stretch;
        }

        .mk-specialty-search {
            width: 100%;
            min-width: 0;
        }

        .mk-specialty-new .mk-btn {
            width: 100%;
        }

        .mk-tab-button {
            padding: 13px 16px;
        }
    }

</style>

</asp:Content>

<asp:Content ID="Content3"
    ContentPlaceHolderID="PageHeader"
    runat="server">

    مدیریت کارشناسان

</asp:Content>

<asp:Content ID="Content4"
    ContentPlaceHolderID="MainContent"
    runat="server">

<div class="mk-page">

    <div class="mk-intro">

        <h2 class="mk-title">
            مدیریت کارشناسان و تخصص‌ها
        </h2>

        <p class="mk-desc">
            در این بخش می‌توانید اطلاعات کارشناسان، واحد سازمانی، وضعیت فعالیت و تخصص‌های آنان
            را مدیریت کنید و همچنین عناوین تخصص‌های قابل استفاده در سامانه را تعریف یا ویرایش نمایید.
        </p>

    </div>


    <div class="mk-tabs">

        <div class="mk-tab-buttons">

            <button type="button"
                id="btnTabSpecialists"
                class="mk-tab-button active"
                onclick="showManagerTab('tabSpecialists');">

                <span class="mk-tab-icon">👨‍💻</span>
                مدیریت کارشناسان

            </button>


            <button type="button"
                id="btnTabSpecialtyTitles"
                class="mk-tab-button"
                onclick="showManagerTab('tabSpecialtyTitles');">

                <span class="mk-tab-icon">⚙</span>
                مدیریت عناوین تخصص‌ها

            </button>

        </div>


        <div id="tabSpecialists"
            class="mk-tab-content active">


            <asp:Panel ID="pnlEdit"
                runat="server"
                Visible="false">

                <div class="mk-card">

                    <div class="mk-card-head">

                        <div class="mk-icon">
                            ✎
                        </div>

                        <div>

                            <h3>
                                ویرایش اطلاعات کارشناس
                            </h3>

                            <p>
                                اطلاعات کارشناس انتخاب‌شده را ویرایش کنید.
                            </p>

                        </div>

                    </div>


                    <div class="mk-body">

                        <asp:Label
                            ID="lblEditSpecialist"
                            runat="server"
                            CssClass="mk-selected">
                        </asp:Label>


                        <div class="mk-grid-two">

                            <div class="mk-group">

                                <label class="mk-label">
                                    نام و نام خانوادگی
                                </label>

                                <asp:TextBox
                                    ID="txtEditFullName"
                                    runat="server"
                                    CssClass="mk-input"
                                    MaxLength="150">
                                </asp:TextBox>

                            </div>


                            <div class="mk-group">

                                <label class="mk-label">
                                    نام کاربری
                                </label>

                                <asp:TextBox
                                    ID="txtEditUserName"
                                    runat="server"
                                    CssClass="mk-input"
                                    MaxLength="256"
                                    autocomplete="off">
                                </asp:TextBox>

                            </div>

                        </div>


                        <div class="mk-grid-two">

                            <div class="mk-group">

                                <label class="mk-label">
                                    واحد سازمانی
                                </label>

                                <asp:DropDownList
                                    ID="ddlEditDepartment"
                                    runat="server"
                                    CssClass="mk-select">
                                </asp:DropDownList>

                            </div>


                            <div class="mk-group">

                                <label class="mk-label">
                                    وضعیت کارشناس
                                </label>

                                <div class="mk-status-row">

                                    <asp:CheckBox
                                        ID="chkEditActive"
                                        runat="server"
                                        Checked="true" />

                                    <span class="mk-status-label">
                                        کارشناس فعال باشد
                                    </span>

                                </div>

                            </div>

                        </div>


                        <div class="mk-grid-two">

                            <div class="mk-group">

                                <label class="mk-label">
                                    رمز عبور جدید
                                </label>

                                <asp:TextBox
                                    ID="txtEditPassword"
                                    runat="server"
                                    TextMode="Password"
                                    CssClass="mk-input"
                                    MaxLength="100"
                                    autocomplete="new-password">
                                </asp:TextBox>

                                <div class="mk-hint">
                                    در صورت عدم نیاز به تغییر رمز، این کادر را خالی بگذارید.
                                </div>

                            </div>


                            <div class="mk-group">

                                <label class="mk-label">
                                    تکرار رمز عبور جدید
                                </label>

                                <asp:TextBox
                                    ID="txtEditConfirmPassword"
                                    runat="server"
                                    TextMode="Password"
                                    CssClass="mk-input"
                                    MaxLength="100"
                                    autocomplete="new-password">
                                </asp:TextBox>

                            </div>

                        </div>


                        <div class="mk-group">

                            <label class="mk-label">
                                تخصص‌های کارشناس
                            </label>

                            <div class="mk-specialties-box">

                                <asp:Repeater
                                    ID="rptEditSpecialties"
                                    runat="server"
                                    OnItemCommand="rptEditSpecialties_ItemCommand">

                                    <ItemTemplate>

                                        <div class="mk-specialty-item">

                                            <div>

                                                <div class="mk-specialty-name">
                                                    <%# Eval("SpecialtyName") %>
                                                </div>

                                                <div class="mk-specialty-desc">
                                                    <%# Eval("Description") %>
                                                </div>

                                            </div>


                                            <asp:Button
                                                ID="btnRemoveSpecialty"
                                                runat="server"
                                                Text="حذف"
                                                CssClass="mk-remove"
                                                CommandName="RemoveSpecialty"
                                                CommandArgument='<%# Eval("SpecialtyId") %>' />

                                        </div>

                                    </ItemTemplate>

                                </asp:Repeater>


                                <asp:Label
                                    ID="lblNoSpecialty"
                                    runat="server"
                                    CssClass="mk-empty"
                                    Visible="false">

                                    هنوز تخصصی برای این کارشناس انتخاب نشده است.

                                </asp:Label>


                                <div class="mk-add-specialty">

                                    <asp:DropDownList
                                        ID="ddlAddSpecialty"
                                        runat="server"
                                        CssClass="mk-select">
                                    </asp:DropDownList>


                                    <asp:Button
                                        ID="btnAddSpecialty"
                                        runat="server"
                                        Text="＋ افزودن تخصص"
                                        CssClass="mk-btn mk-btn-primary"
                                        OnClick="btnAddSpecialty_Click" />

                                </div>

                            </div>

                        </div>


                        <div class="mk-actions">

                            <asp:Button
                                ID="btnSaveChanges"
                                runat="server"
                                Text="✓ ثبت اطلاعات"
                                CssClass="mk-btn mk-btn-success"
                                OnClick="btnSaveChanges_Click" />


                            <asp:Button
                                ID="btnCancelEdit"
                                runat="server"
                                Text="انصراف"
                                CssClass="mk-btn mk-btn-secondary"
                                OnClick="btnCancelEdit_Click" />

                        </div>


                        <asp:Label
                            ID="lblMessage"
                            runat="server"
                            Visible="false"
                            CssClass="mk-message">
                        </asp:Label>

                    </div>

                </div>

            </asp:Panel>


            <div class="mk-card">

                <div class="mk-card-head">

                    <div class="mk-icon">
                        ≡
                    </div>

                    <div>

                        <h3>
                            فهرست کارشناسان
                        </h3>

                        <p>
                            برای ویرایش اطلاعات یک کارشناس، گزینه ویرایش را انتخاب کنید.
                        </p>

                    </div>

                </div>


                <div class="mk-body">


                    <div class="mk-search">

                        <label class="mk-label">
                            جستجوی کارشناس
                        </label>

                        <asp:TextBox
                            ID="txtSearch"
                            runat="server"
                            CssClass="mk-input"
                            placeholder="نام، نام کاربری یا واحد سازمانی..."
                            AutoPostBack="true"
                            OnTextChanged="txtSearch_TextChanged">
                        </asp:TextBox>

                    </div>


                    <div class="mk-table-wrap">

                        <asp:GridView
                            ID="gvSpecialists"
                            runat="server"
                            AutoGenerateColumns="False"
                            CssClass="mk-grid-table"
                            GridLines="None"
                            OnRowCommand="gvSpecialists_RowCommand">

                            <Columns>

                                <asp:BoundField
                                    DataField="FullName"
                                    HeaderText="نام کارشناس" />


                                <asp:BoundField
                                    DataField="UserName"
                                    HeaderText="نام کاربری" />


                                <asp:BoundField
                                    DataField="DepartmentName"
                                    HeaderText="واحد" />


                                <asp:TemplateField
                                    HeaderText="تخصص‌ها">

                                    <ItemTemplate>

                                        <asp:Repeater
                                            ID="rptGridSpecialties"
                                            runat="server"
                                            DataSource='<%# Eval("SpecialtyRows") %>'>

                                            <ItemTemplate>

                                                <span class="mk-pill">
                                                    <%# Eval("SpecialtyName") %>
                                                </span>

                                            </ItemTemplate>

                                        </asp:Repeater>


                                        <asp:Label
                                            ID="lblNoGridSpecialty"
                                            runat="server"
                                            CssClass="mk-no-specialty"
                                            Text="بدون تخصص"
                                            Visible='<%# Convert.ToString(Eval("Specialties")).Length == 0 %>' />

                                    </ItemTemplate>

                                </asp:TemplateField>


                                <asp:TemplateField
                                    HeaderText="وضعیت">

                                    <ItemTemplate>

                                        <span class='<%# Convert.ToBoolean(Eval("IsActive")) ? "mk-grid-btn mk-on" : "mk-grid-btn mk-off" %>'>

                                            <%# Convert.ToBoolean(Eval("IsActive")) ? "فعال" : "غیرفعال" %>

                                        </span>

                                    </ItemTemplate>

                                </asp:TemplateField>


                                <asp:TemplateField
                                    HeaderText="عملیات">

                                    <ItemTemplate>

                                        <asp:LinkButton
                                            ID="btnEdit"
                                            runat="server"
                                            Text="✏ ویرایش"
                                            CssClass="mk-grid-btn mk-edit-btn"
                                            CommandName="EditSpecialist"
                                            CommandArgument='<%# Eval("UserId") %>' />


                                        <asp:LinkButton
                                            ID="btnToggle"
                                            runat="server"
                                            Text='<%# Convert.ToBoolean(Eval("IsActive")) ? "غیرفعال کردن" : "فعال کردن" %>'
                                            CssClass='<%# Convert.ToBoolean(Eval("IsActive")) ? "mk-grid-btn mk-off" : "mk-grid-btn mk-on" %>'
                                            CommandName="ToggleActive"
                                            CommandArgument='<%# Eval("UserId") %>' />

                                    </ItemTemplate>

                                </asp:TemplateField>

                            </Columns>

                        </asp:GridView>

                    </div>

                </div>

            </div>

        </div>


        <div id="tabSpecialtyTitles"
            class="mk-tab-content">


            <div class="mk-card">

                <div class="mk-card-head">

                    <div class="mk-icon">
                        ⚙
                    </div>

                    <div>

                        <h3>
                            مدیریت عناوین تخصص‌ها
                        </h3>

                        <p>
                            افزودن، ویرایش و فعال یا غیرفعال کردن عناوین تخصص‌های کارشناسان.
                        </p>

                    </div>

                </div>


                <div class="mk-body">


                    <asp:Label
                        ID="lblSpecialtyTitleMessage"
                        runat="server"
                        Visible="false"
                        CssClass="mk-message">
                    </asp:Label>


                    <div class="mk-specialty-tools">

                        <div class="mk-specialty-search">

                            <label class="mk-label">
                                جستجوی تخصص
                            </label>

                            <asp:TextBox
                                ID="txtSpecialtyTitleSearch"
                                runat="server"
                                CssClass="mk-input"
                                placeholder="عنوان تخصص یا توضیحات..."
                                AutoPostBack="true"
                                OnTextChanged="txtSpecialtyTitleSearch_TextChanged">
                            </asp:TextBox>

                        </div>


                        <div class="mk-specialty-new">

                            <asp:Button
                                ID="btnNewSpecialtyTitle"
                                runat="server"
                                Text="＋ تخصص جدید"
                                CssClass="mk-btn mk-btn-primary"
                                CausesValidation="false"
                                OnClick="btnNewSpecialtyTitle_Click" />

                        </div>

                    </div>


                    <asp:Panel
                        ID="pnlSpecialtyTitleEdit"
                        runat="server"
                        Visible="false"
                        CssClass="mk-specialty-edit">

                        <div class="mk-specialty-edit-title">

                            <asp:Label
                                ID="lblSpecialtyTitleEditTitle"
                                runat="server"
                                Text="افزودن تخصص جدید">
                            </asp:Label>

                        </div>


                        <asp:HiddenField
                            ID="hfSpecialtyTitleEditId"
                            runat="server"
                            Value="0" />


                        <div class="mk-grid-two">

                            <div class="mk-group">

                                <label class="mk-label">
                                    عنوان تخصص
                                </label>

                                <asp:TextBox
                                    ID="txtSpecialtyTitleName"
                                    runat="server"
                                    CssClass="mk-input"
                                    MaxLength="100">
                                </asp:TextBox>

                            </div>


                            <div class="mk-group">

                                <label class="mk-label">
                                    وضعیت
                                </label>

                                <div class="mk-status-row">

                                    <asp:CheckBox
                                        ID="chkSpecialtyTitleActive"
                                        runat="server"
                                        Checked="true" />

                                    <span class="mk-status-label">
                                        تخصص فعال باشد
                                    </span>

                                </div>

                            </div>

                        </div>


                        <div class="mk-group">

                            <label class="mk-label">
                                توضیحات تخصص
                            </label>

                            <asp:TextBox
                                ID="txtSpecialtyTitleDescription"
                                runat="server"
                                CssClass="mk-input"
                                TextMode="MultiLine"
                                MaxLength="500"
                                style="min-height:90px;resize:vertical;">
                            </asp:TextBox>

                        </div>


                        <div class="mk-actions">

                            <asp:Button
                                ID="btnSaveSpecialtyTitle"
                                runat="server"
                                Text="✓ ثبت تخصص"
                                CssClass="mk-btn mk-btn-success"
                                OnClick="btnSaveSpecialtyTitle_Click" />


                            <asp:Button
                                ID="btnCancelSpecialtyTitle"
                                runat="server"
                                Text="انصراف"
                                CssClass="mk-btn mk-btn-secondary"
                                CausesValidation="false"
                                OnClick="btnCancelSpecialtyTitle_Click" />

                        </div>

                    </asp:Panel>


                    <div class="mk-table-wrap">

                        <asp:GridView
                            ID="gvSpecialtyTitles"
                            runat="server"
                            AutoGenerateColumns="False"
                            CssClass="mk-grid-table"
                            GridLines="None"
                            EmptyDataText="هنوز عنوان تخصصی ثبت نشده است."
                            OnRowCommand="gvSpecialtyTitles_RowCommand">

                            <Columns>

                                <asp:BoundField
                                    DataField="SpecialtyName"
                                    HeaderText="عنوان تخصص" />


                                <asp:TemplateField
                                    HeaderText="توضیحات">

                                    <ItemTemplate>

                                        <div class="mk-specialty-description">
                                            <%# Eval("Description") %>
                                        </div>

                                    </ItemTemplate>

                                </asp:TemplateField>


                                <asp:TemplateField
                                    HeaderText="تعداد کارشناسان">

                                    <ItemTemplate>

                                        <span class="mk-count">
                                            <%# Eval("SpecialistCount") %>
                                        </span>

                                    </ItemTemplate>

                                </asp:TemplateField>


                                <asp:TemplateField
                                    HeaderText="وضعیت">

                                    <ItemTemplate>

                                        <span class='<%# Convert.ToBoolean(Eval("IsActive")) ? "mk-grid-btn mk-on" : "mk-grid-btn mk-off" %>'>

                                            <%# Convert.ToBoolean(Eval("IsActive")) ? "فعال" : "غیرفعال" %>

                                        </span>

                                    </ItemTemplate>

                                </asp:TemplateField>


                                <asp:TemplateField
                                    HeaderText="عملیات">

                                    <ItemTemplate>

                                        <asp:LinkButton
                                            ID="btnEditSpecialtyTitle"
                                            runat="server"
                                            Text="✏ ویرایش"
                                            CssClass="mk-grid-btn mk-edit-btn"
                                            CommandName="EditSpecialtyTitle"
                                            CommandArgument='<%# Eval("SpecialtyId") %>'
                                            CausesValidation="false" />


                                        <asp:LinkButton
                                            ID="btnToggleSpecialtyTitle"
                                            runat="server"
                                            Text='<%# Convert.ToBoolean(Eval("IsActive")) ? "غیرفعال کردن" : "فعال کردن" %>'
                                            CssClass='<%# Convert.ToBoolean(Eval("IsActive")) ? "mk-grid-btn mk-off" : "mk-grid-btn mk-on" %>'
                                            CommandName="ToggleSpecialtyTitle"
                                            CommandArgument='<%# Eval("SpecialtyId") %>'
                                            CausesValidation="false" />

                                    </ItemTemplate>

                                </asp:TemplateField>

                            </Columns>

                        </asp:GridView>

                    </div>

                </div>

            </div>

        </div>

    </div>

</div>


<asp:HiddenField
    ID="hfManagerActiveTab"
    runat="server"
    Value="tabSpecialists" />


<script type="text/javascript">

    function showManagerTab(tabId) {

        var tabs =
            document.getElementsByClassName("mk-tab-content");

        for (var i = 0; i < tabs.length; i++) {
            tabs[i].classList.remove("active");
        }


        var buttons =
            document.getElementsByClassName("mk-tab-button");

        for (var j = 0; j < buttons.length; j++) {
            buttons[j].classList.remove("active");
        }


        var selected =
            document.getElementById(tabId);

        if (selected) {
            selected.classList.add("active");
        }


        if (tabId === "tabSpecialists") {

            var btn1 =
                document.getElementById("btnTabSpecialists");

            if (btn1) {
                btn1.classList.add("active");
            }

        }
        else if (tabId === "tabSpecialtyTitles") {

            var btn2 =
                document.getElementById("btnTabSpecialtyTitles");

            if (btn2) {
                btn2.classList.add("active");
            }

        }


        var hidden =
            document.getElementById(
                '<%= hfManagerActiveTab.ClientID %>'
            );

        if (hidden) {
            hidden.value = tabId;
        }

    }


    document.addEventListener(
        "DOMContentLoaded",
        function () {

            var hidden =
                document.getElementById(
                    '<%= hfManagerActiveTab.ClientID %>'
                );

            var activeTab =
                "tabSpecialists";

            if (hidden && hidden.value) {
                activeTab = hidden.value;
            }

            showManagerTab(activeTab);

        }
    );

</script>

</asp:Content>