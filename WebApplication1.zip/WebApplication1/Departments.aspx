﻿<%@ Page Title="واحدهای سازمانی"
    Language="C#"
    MasterPageFile="~/Site.Master"
    AutoEventWireup="true"
    CodeBehind="Departments.aspx.cs"
    Inherits="WebApplication1.Departments" %>

<asp:Content ID="Content1"
    ContentPlaceHolderID="TitleContent"
    runat="server">

    مدیریت واحدهای سازمانی

</asp:Content>


<asp:Content ID="Content2"
    ContentPlaceHolderID="HeadContent"
    runat="server">

    <style type="text/css">

        .department-container {
            width: 100%;
            max-width: 1100px;
            margin: 0 auto;
        }

        .department-card {
            background: #ffffff;
            border-radius: 10px;
            padding: 22px;
            box-shadow: 0 2px 10px rgba(0,0,0,.06);
            margin-bottom: 20px;
        }

        .section-title {
            font-size: 16px;
            font-weight: bold;
            color: #333;
            margin-bottom: 18px;
            padding-bottom: 12px;
            border-bottom: 1px solid #eeeeee;
        }

        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 18px;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-label {
            display: block;
            margin-bottom: 7px;
            font-size: 13px;
            color: #555555;
        }

        .required {
            color: #c62828;
        }

        .form-control {
            width: 100%;
            box-sizing: border-box;
            padding: 10px 12px;
            border: 1px solid #d6dbe1;
            border-radius: 6px;
            background: #ffffff;
            font-family: Tahoma, Arial;
            font-size: 13px;
        }

        .form-control:focus {
            border-color: #1976d2;
            outline: none;
        }

        textarea.form-control {
            resize: vertical;
            min-height: 80px;
        }

        .checkbox-row {
            display: flex;
            align-items: center;
            min-height: 40px;
        }

        .checkbox-row label {
            margin-right: 7px;
            color: #555555;
            font-size: 13px;
        }

        .button-row {
            margin-top: 8px;
        }

        .btn {
            display: inline-block;
            border: none;
            border-radius: 6px;
            padding: 10px 20px;
            font-family: Tahoma, Arial;
            font-size: 13px;
            cursor: pointer;
            text-decoration: none;
        }

        .btn-primary {
            background: #1976d2;
            color: #ffffff;
        }

        .btn-primary:hover {
            background: #1565c0;
        }

        .btn-secondary {
            background: #eceff1;
            color: #333333;
            margin-right: 8px;
        }

        .btn-secondary:hover {
            background: #dfe3e6;
        }

        .btn-edit {
            background: #fff3e0;
            color: #ef6c00;
            border: 1px solid #ffe0b2;
            padding: 6px 12px;
        }

        .btn-edit:hover {
            background: #ffe0b2;
        }

        .btn-toggle {
            padding: 6px 12px;
            border-radius: 5px;
            font-family: Tahoma, Arial;
            font-size: 12px;
            cursor: pointer;
        }

        .btn-disable {
            background: #ffebee;
            color: #c62828;
            border: 1px solid #ffcdd2;
        }

        .btn-enable {
            background: #e8f5e9;
            color: #2e7d32;
            border: 1px solid #c8e6c9;
        }

        .message {
            display: block;
            margin-bottom: 18px;
            padding: 11px 13px;
            border-radius: 6px;
            font-size: 13px;
        }

        .success {
            background: #e8f5e9;
            color: #2e7d32;
        }

        .error {
            background: #ffebee;
            color: #c62828;
        }

        .table-wrapper {
            overflow-x: auto;
        }

        .department-table {
            width: 100%;
            border-collapse: collapse;
            font-size: 13px;
        }

        .department-table th {
            background: #f5f7fa;
            color: #444444;
            font-weight: bold;
            padding: 12px 10px;
            border-bottom: 2px solid #e0e4e8;
            text-align: right;
            white-space: nowrap;
        }

        .department-table td {
            padding: 11px 10px;
            border-bottom: 1px solid #eeeeee;
            color: #555555;
            vertical-align: middle;
        }

        .department-table tr:hover td {
            background: #fafafa;
        }

        .status-active {
            display: inline-block;
            padding: 4px 9px;
            border-radius: 15px;
            background: #e8f5e9;
            color: #2e7d32;
            font-size: 11px;
        }

        .status-inactive {
            display: inline-block;
            padding: 4px 9px;
            border-radius: 15px;
            background: #ffebee;
            color: #c62828;
            font-size: 11px;
        }

        .empty-message {
            padding: 30px;
            text-align: center;
            color: #888888;
            font-size: 13px;
        }

        .count-label {
            display: block;
            margin-bottom: 15px;
            color: #777777;
            font-size: 12px;
        }

        @media (max-width: 700px) {

            .form-row {
                grid-template-columns: 1fr;
            }

            .department-card {
                padding: 16px;
            }

        }

    </style>

</asp:Content>


<asp:Content ID="Content3"
    ContentPlaceHolderID="PageHeader"
    runat="server">

    مدیریت واحدهای سازمانی

</asp:Content>


<asp:Content ID="Content4"
    ContentPlaceHolderID="MainContent"
    runat="server">

    <div class="department-container">


        <!-- پیام -->

        <asp:Label
            ID="lblMessage"
            runat="server"
            Visible="false">
        </asp:Label>


        <!-- فرم افزودن / ویرایش -->

        <div class="department-card">

            <div class="section-title">

                <asp:Label
                    ID="lblFormTitle"
                    runat="server"
                    Text="افزودن واحد سازمانی">
                </asp:Label>

            </div>


            <div class="form-row">

                <div class="form-group">

                    <label class="form-label">

                        نام واحد سازمانی

                        <span class="required">*</span>

                    </label>

                    <asp:TextBox
                        ID="txtDepartmentName"
                        runat="server"
                        CssClass="form-control"
                        MaxLength="100">
                    </asp:TextBox>

                </div>


                <div class="form-group">

                    <label class="form-label">

                        وضعیت

                    </label>

                    <div class="checkbox-row">

                        <asp:CheckBox
                            ID="chkIsActive"
                            runat="server"
                            Checked="true" />

                        <label>

                            واحد فعال باشد

                        </label>

                    </div>

                </div>

            </div>


            <div class="form-group">

                <label class="form-label">

                    توضیحات

                </label>

                <asp:TextBox
                    ID="txtDescription"
                    runat="server"
                    CssClass="form-control"
                    TextMode="MultiLine"
                    MaxLength="500">
                </asp:TextBox>

            </div>


            <div class="button-row">

                <asp:Button
                    ID="btnSave"
                    runat="server"
                    Text="افزودن واحد"
                    CssClass="btn btn-primary"
                    OnClick="btnSave_Click" />


                <asp:Button
                    ID="btnCancel"
                    runat="server"
                    Text="انصراف"
                    CssClass="btn btn-secondary"
                    Visible="false"
                    OnClick="btnCancel_Click" />

            </div>

        </div>


        <!-- لیست واحدها -->

        <div class="department-card">

            <div class="section-title">

                واحدهای سازمانی

            </div>


            <asp:Label
                ID="lblDepartmentCount"
                runat="server"
                CssClass="count-label">
            </asp:Label>


            <div class="table-wrapper">

                <asp:GridView
                    ID="gvDepartments"
                    runat="server"
                    AutoGenerateColumns="false"
                    CssClass="department-table"
                    GridLines="None"
                    EmptyDataText="هنوز هیچ واحد سازمانی ثبت نشده است.">

                    <Columns>


                        <asp:BoundField
                            DataField="DepartmentName"
                            HeaderText="نام واحد سازمانی" />


                        <asp:BoundField
                            DataField="Description"
                            HeaderText="توضیحات" />


                        <asp:BoundField
                            DataField="UserCount"
                            HeaderText="تعداد کاربران" />


                        <asp:TemplateField
                            HeaderText="وضعیت">

                            <ItemTemplate>

                                <span
                                    class='<%# Eval("StatusCss") %>'>

                                    <%# Eval("StatusText") %>

                                </span>

                            </ItemTemplate>

                        </asp:TemplateField>


                        <asp:BoundField
                            DataField="CreatedAtText"
                            HeaderText="تاریخ ایجاد" />


                        <asp:TemplateField
                            HeaderText="عملیات">

                            <ItemTemplate>

                                <asp:Button
                                    ID="btnEdit"
                                    runat="server"
                                    Text="ویرایش"
                                    CssClass="btn btn-edit"
                                    CommandName="EditDepartment"
                                    CommandArgument='<%# Eval("DepartmentId") %>'
                                    OnCommand="Department_Command" />


                                <asp:Button
                                    ID="btnToggle"
                                    runat="server"
                                    Text='<%# Eval("ToggleText") %>'
                                    CssClass='<%# Eval("ToggleCss") %>'
                                    CommandName="ToggleDepartment"
                                    CommandArgument='<%# Eval("DepartmentId") %>'
                                    OnCommand="Department_Command" />

                            </ItemTemplate>

                        </asp:TemplateField>

                    </Columns>

                </asp:GridView>

            </div>

        </div>

    </div>

</asp:Content>