﻿using System;
using System.Linq;
using System.Web.UI;
using System.Web.UI.WebControls;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;
using WebApplication1.Models;

namespace WebApplication1
{
    public partial class EditUser : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            // فقط کاربران واردشده
            if (!Request.IsAuthenticated)
            {
                Response.Redirect("~/Login.aspx");
                return;
            }

            // فقط Manager
            if (!User.IsInRole("Manager"))
            {
                Response.Redirect("~/UserDashboard.aspx");
                return;
            }

            if (!IsPostBack)
            {
                LoadDepartments();
                LoadSpecialties();
                LoadUser();
            }
        }


        // =====================================================
        // بارگذاری واحدهای سازمانی
        // =====================================================
        private void LoadDepartments()
        {
            using (var db = new ApplicationDbContext())
            {
                var departments = db.Departments
                    .Where(d => d.IsActive)
                    .OrderBy(d => d.DepartmentName)
                    .ToList();

                ddlDepartment.Items.Clear();

                ddlDepartment.Items.Add(
                    new ListItem("انتخاب واحد", "")
                );

                foreach (var department in departments)
                {
                    ddlDepartment.Items.Add(
                        new ListItem(
                            department.DepartmentName,
                            department.DepartmentId.ToString()
                        )
                    );
                }
            }
        }


        // =====================================================
        // بارگذاری تخصص‌ها
        // =====================================================
        private void LoadSpecialties()
        {
            using (var db = new ApplicationDbContext())
            {
                var specialties = db.Specialties
                    .Where(s => s.IsActive)
                    .OrderBy(s => s.SpecialtyName)
                    .ToList();

                cblSpecialties.Items.Clear();

                foreach (var specialty in specialties)
                {
                    cblSpecialties.Items.Add(
                        new ListItem(
                            specialty.SpecialtyName,
                            specialty.SpecialtyId.ToString()
                        )
                    );
                }
            }
        }


        // =====================================================
        // بارگذاری اطلاعات کاربر
        // =====================================================
        private void LoadUser()
        {
            string userId = Request.QueryString["id"];

            if (string.IsNullOrEmpty(userId))
            {
                ShowError("شناسه کاربر مشخص نشده است.");
                return;
            }

            using (var db = new ApplicationDbContext())
            {
                var userManager =
                    new UserManager<ApplicationUser>(
                        new UserStore<ApplicationUser>(db)
                    );

                var user = userManager.FindById(userId);

                if (user == null)
                {
                    ShowError("کاربر موردنظر پیدا نشد.");
                    return;
                }

                // -------------------------------------------------
                // نام کاربری
                // -------------------------------------------------
                txtUserName.Text = user.UserName;


                // -------------------------------------------------
                // اطلاعات پروفایل
                // -------------------------------------------------
                var profile = db.UserProfiles
                    .FirstOrDefault(
                        p => p.UserId == user.Id
                    );

                if (profile != null)
                {
                    txtFullName.Text = profile.FullName;

                    if (profile.DepartmentId > 0)
                    {
                        string departmentValue =
                            profile.DepartmentId.ToString();

                        if (ddlDepartment.Items.FindByValue(
                            departmentValue) != null)
                        {
                            ddlDepartment.SelectedValue =
                                departmentValue;
                        }
                    }

                    chkIsActive.Checked =
                        profile.IsActive;
                }


                // -------------------------------------------------
                // Role
                // -------------------------------------------------
                var roles =
                    userManager.GetRoles(user.Id);

                if (roles != null &&
                    roles.Count > 0)
                {
                    string role = roles[0];

                    if (ddlRole.Items.FindByValue(role) != null)
                    {
                        ddlRole.SelectedValue = role;
                    }
                }


                // -------------------------------------------------
                // تخصص‌های کاربر
                // -------------------------------------------------
                LoadUserSpecialties(
                    db,
                    user.Id
                );


                // -------------------------------------------------
                // نمایش تخصص‌ها
                // -------------------------------------------------
                UpdateSpecialtyVisibility();
            }
        }


        // =====================================================
        // بارگذاری تخصص‌های فعلی کاربر
        // =====================================================
        private void LoadUserSpecialties(
            ApplicationDbContext db,
            string userId)
        {
            var userSpecialties =
                db.SpecialistSpecialties
                    .Where(x => x.UserId == userId)
                    .Select(x => x.SpecialtyId)
                    .ToList();

            foreach (ListItem item in cblSpecialties.Items)
            {
                int specialtyId;

                if (int.TryParse(
                    item.Value,
                    out specialtyId))
                {
                    item.Selected =
                        userSpecialties.Contains(
                            specialtyId
                        );
                }
            }
        }


        // =====================================================
        // تغییر Role
        // =====================================================
        protected void ddlRole_SelectedIndexChanged(
            object sender,
            EventArgs e)
        {
            UpdateSpecialtyVisibility();
        }


        // =====================================================
        // نمایش / عدم نمایش تخصص‌ها
        // =====================================================
        private void UpdateSpecialtyVisibility()
        {
            pnlSpecialties.Visible =
                ddlRole.SelectedValue == "Specialist";
        }


        // =====================================================
        // ذخیره تغییرات
        // =====================================================
        protected void btnSave_Click(
            object sender,
            EventArgs e)
        {
            lblMessage.Text = "";
            lblMessage.Visible = false;


            string userId =
                Request.QueryString["id"];


            if (string.IsNullOrEmpty(userId))
            {
                ShowError(
                    "شناسه کاربر مشخص نشده است."
                );

                return;
            }


            string fullName =
                txtFullName.Text.Trim();


            string role =
                ddlRole.SelectedValue;


            // -------------------------------------------------
            // اعتبارسنجی نام
            // -------------------------------------------------
            if (string.IsNullOrEmpty(fullName))
            {
                ShowError(
                    "لطفاً نام و نام خانوادگی را وارد کنید."
                );

                return;
            }


            // -------------------------------------------------
            // اعتبارسنجی واحد
            // -------------------------------------------------
            if (string.IsNullOrEmpty(
                ddlDepartment.SelectedValue))
            {
                ShowError(
                    "لطفاً واحد سازمانی را انتخاب کنید."
                );

                return;
            }


            int departmentId;

            if (!int.TryParse(
                ddlDepartment.SelectedValue,
                out departmentId))
            {
                ShowError(
                    "واحد سازمانی انتخاب‌شده معتبر نیست."
                );

                return;
            }


            // -------------------------------------------------
            // اعتبارسنجی Role
            // -------------------------------------------------
            if (role != "User" &&
                role != "Specialist" &&
                role != "Manager")
            {
                ShowError(
                    "نقش انتخاب‌شده معتبر نیست."
                );

                return;
            }


            using (var db = new ApplicationDbContext())
            {
                // -------------------------------------------------
                // بررسی واحد سازمانی
                // -------------------------------------------------
                var department =
                    db.Departments.FirstOrDefault(
                        d =>
                            d.DepartmentId == departmentId &&
                            d.IsActive
                    );

                if (department == null)
                {
                    ShowError(
                        "واحد سازمانی انتخاب‌شده معتبر یا غیرفعال است."
                    );

                    return;
                }


                // -------------------------------------------------
                // UserManager
                // -------------------------------------------------
                var userManager =
                    new UserManager<ApplicationUser>(
                        new UserStore<ApplicationUser>(db)
                    );


                // -------------------------------------------------
                // پیدا کردن کاربر
                // -------------------------------------------------
                var user =
                    userManager.FindById(userId);

                if (user == null)
                {
                    ShowError(
                        "کاربر موردنظر پیدا نشد."
                    );

                    return;
                }


                // -------------------------------------------------
                // تغییر رمز عبور
                // -------------------------------------------------
                string password =
                    txtPassword.Text;

                string confirmPassword =
                    txtConfirmPassword.Text;


                if (!string.IsNullOrEmpty(password))
                {
                    if (password != confirmPassword)
                    {
                        ShowError(
                            "رمز عبور و تکرار آن یکسان نیستند."
                        );

                        return;
                    }


                    if (password.Length < 6)
                    {
                        ShowError(
                            "رمز عبور باید حداقل ۶ کاراکتر باشد."
                        );

                        return;
                    }


                    // ساخت Hash جدید
                    user.PasswordHash =
                        userManager.PasswordHasher
                            .HashPassword(password);
                }


                // -------------------------------------------------
                // Role های فعلی
                // -------------------------------------------------
                var currentRoles =
                    userManager.GetRoles(user.Id);


                // -------------------------------------------------
                // حذف Role های قبلی
                // -------------------------------------------------
                if (currentRoles != null)
                {
                    foreach (
                        string currentRole
                        in currentRoles.ToList())
                    {
                        IdentityResult removeResult =
                            userManager.RemoveFromRole(
                                user.Id,
                                currentRole
                            );


                        if (!removeResult.Succeeded)
                        {
                            ShowError(
                                string.Join(
                                    " ",
                                    removeResult.Errors
                                )
                            );

                            return;
                        }
                    }
                }


                // -------------------------------------------------
                // RoleManager
                // -------------------------------------------------
                var roleManager =
                    new RoleManager<IdentityRole>(
                        new RoleStore<IdentityRole>(db)
                    );


                // -------------------------------------------------
                // ایجاد Role در صورت نبودن
                // -------------------------------------------------
                if (!roleManager.RoleExists(role))
                {
                    IdentityResult roleResult =
                        roleManager.Create(
                            new IdentityRole(role)
                        );


                    if (!roleResult.Succeeded)
                    {
                        ShowError(
                            string.Join(
                                " ",
                                roleResult.Errors
                            )
                        );

                        return;
                    }
                }


                // -------------------------------------------------
                // اختصاص Role جدید
                // -------------------------------------------------
                IdentityResult addRoleResult =
                    userManager.AddToRole(
                        user.Id,
                        role
                    );


                if (!addRoleResult.Succeeded)
                {
                    ShowError(
                        string.Join(
                            " ",
                            addRoleResult.Errors
                        )
                    );

                    return;
                }


                // -------------------------------------------------
                // UserProfile
                // -------------------------------------------------
                var profile =
                    db.UserProfiles.FirstOrDefault(
                        p => p.UserId == user.Id
                    );


                if (profile == null)
                {
                    profile =
                        new UserProfile
                        {
                            UserId = user.Id,
                            FullName = fullName,
                            DepartmentId = departmentId,
                            IsActive = chkIsActive.Checked,
                            CreatedAt = DateTime.Now
                        };

                    db.UserProfiles.Add(profile);
                }
                else
                {
                    profile.FullName =
                        fullName;

                    profile.DepartmentId =
                        departmentId;

                    profile.IsActive =
                        chkIsActive.Checked;
                }


                // -------------------------------------------------
                // حذف تخصص‌های قبلی
                // -------------------------------------------------
                var oldSpecialties =
                    db.SpecialistSpecialties
                        .Where(
                            x => x.UserId == user.Id
                        )
                        .ToList();


                foreach (
                    var oldSpecialty
                    in oldSpecialties)
                {
                    db.SpecialistSpecialties.Remove(
                        oldSpecialty
                    );
                }


                // -------------------------------------------------
                // ثبت تخصص‌های جدید
                // فقط برای Specialist
                // -------------------------------------------------
                if (role == "Specialist")
                {
                    foreach (
                        ListItem item
                        in cblSpecialties.Items)
                    {
                        if (!item.Selected)
                            continue;


                        int specialtyId;

                        if (!int.TryParse(
                            item.Value,
                            out specialtyId))
                        {
                            continue;
                        }


                        var specialty =
                            db.Specialties.FirstOrDefault(
                                s =>
                                    s.SpecialtyId ==
                                    specialtyId &&
                                    s.IsActive
                            );


                        if (specialty == null)
                            continue;


                        var specialistSpecialty =
                            new SpecialistSpecialty
                            {
                                UserId = user.Id,
                                SpecialtyId = specialtyId
                            };


                        db.SpecialistSpecialties.Add(
                            specialistSpecialty
                        );
                    }
                }


                // -------------------------------------------------
                // ذخیره نهایی
                // -------------------------------------------------
                db.SaveChanges();


                // -------------------------------------------------
                // پیام موفقیت
                // -------------------------------------------------
                ShowSuccess(
                    "اطلاعات کاربر «" +
                    fullName +
                    "» با موفقیت ویرایش شد."
                );
            }
        }


        // =====================================================
        // حذف کاربر
        // =====================================================
        protected void btnDelete_Click(
            object sender,
            EventArgs e)
        {
            string userId =
                Request.QueryString["id"];


            if (string.IsNullOrEmpty(userId))
            {
                ShowError(
                    "شناسه کاربر مشخص نشده است."
                );

                return;
            }


            using (var db = new ApplicationDbContext())
            {
                // -------------------------------------------------
                // UserManager
                // -------------------------------------------------
                var userManager =
                    new UserManager<ApplicationUser>(
                        new UserStore<ApplicationUser>(db)
                    );


                // -------------------------------------------------
                // پیدا کردن کاربر
                // -------------------------------------------------
                var user =
                    userManager.FindById(userId);


                if (user == null)
                {
                    ShowError(
                        "کاربر موردنظر پیدا نشد."
                    );

                    return;
                }


                // -------------------------------------------------
                // جلوگیری از حذف خود کاربر جاری
                // -------------------------------------------------
                if (user.Id ==
                    User.Identity.GetUserId())
                {
                    ShowError(
                        "شما نمی‌توانید حساب کاربری خودتان را حذف کنید."
                    );

                    return;
                }


                // -------------------------------------------------
                // حذف تخصص‌های کاربر
                // -------------------------------------------------
                var specialties =
                    db.SpecialistSpecialties
                        .Where(
                            x => x.UserId == user.Id
                        )
                        .ToList();


                foreach (
                    var specialty
                    in specialties)
                {
                    db.SpecialistSpecialties.Remove(
                        specialty
                    );
                }


                // -------------------------------------------------
                // حذف UserProfile
                // -------------------------------------------------
                var profile =
                    db.UserProfiles.FirstOrDefault(
                        p => p.UserId == user.Id
                    );


                if (profile != null)
                {
                    db.UserProfiles.Remove(
                        profile
                    );
                }


                // -------------------------------------------------
                // حذف کاربر از Identity
                // -------------------------------------------------
                var userStore =
                    new UserStore<ApplicationUser>(db);


                userStore.DeleteAsync(user).Wait();


                // -------------------------------------------------
                // ذخیره تغییرات
                // -------------------------------------------------
                db.SaveChanges();
            }


            // -------------------------------------------------
            // بازگشت به مدیریت کاربران
            // -------------------------------------------------
            Response.Redirect(
                "~/ManageUsers.aspx"
            );
        }


        // =====================================================
        // پیام موفقیت
        // =====================================================
        private void ShowSuccess(
            string message)
        {
            lblMessage.Text =
                message;

            lblMessage.CssClass =
                "message success";

            lblMessage.Visible =
                true;
        }


        // =====================================================
        // پیام خطا
        // =====================================================
        private void ShowError(
            string message)
        {
            lblMessage.Text =
                message;

            lblMessage.CssClass =
                "message error";

            lblMessage.Visible =
                true;
        }
    }
}