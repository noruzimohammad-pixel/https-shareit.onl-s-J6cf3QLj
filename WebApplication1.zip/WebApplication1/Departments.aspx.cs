﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.UI.WebControls;
using WebApplication1.Models;

namespace WebApplication1
{
    public partial class Departments : System.Web.UI.Page
    {
        private int EditingDepartmentId
        {
            get
            {
                if (ViewState["EditingDepartmentId"] == null)
                    return 0;

                return Convert.ToInt32(
                    ViewState["EditingDepartmentId"]);
            }

            set
            {
                ViewState["EditingDepartmentId"] = value;
            }
        }


        protected void Page_Load(
            object sender,
            EventArgs e)
        {
            if (!Request.IsAuthenticated)
            {
                Response.Redirect("~/Login.aspx");
                return;
            }


            if (!User.IsInRole("Manager"))
            {
                Response.Redirect("~/UserDashboard.aspx");
                return;
            }


            if (!IsPostBack)
            {
                ClearForm();
                LoadDepartments();
            }
        }


        private void LoadDepartments()
        {
            using (var db =
                new ApplicationDbContext())
            {
                var departments =
                    db.Departments
                        .OrderBy(d => d.DepartmentName)
                        .ToList();


                var result =
                    new List<DepartmentListItem>();


                foreach (var department
                    in departments)
                {
                    int userCount =
                        db.UserProfiles.Count(
                            p =>
                                p.DepartmentId ==
                                department.DepartmentId);


                    string statusText;
                    string statusCss;
                    string toggleText;
                    string toggleCss;


                    if (department.IsActive)
                    {
                        statusText = "فعال";

                        statusCss =
                            "status-active";

                        toggleText =
                            "غیرفعال کردن";

                        toggleCss =
                            "btn btn-toggle btn-disable";
                    }
                    else
                    {
                        statusText = "غیرفعال";

                        statusCss =
                            "status-inactive";

                        toggleText =
                            "فعال کردن";

                        toggleCss =
                            "btn btn-toggle btn-enable";
                    }


                    result.Add(
                        new DepartmentListItem
                        {
                            DepartmentId =
                                department.DepartmentId,

                            DepartmentName =
                                department.DepartmentName,

                            Description =
                                department.Description,

                            UserCount =
                                userCount,

                            StatusText =
                                statusText,

                            StatusCss =
                                statusCss,

                            ToggleText =
                                toggleText,

                            ToggleCss =
                                toggleCss,

                            CreatedAtText =
                                department.CreatedAt
                                    .ToString("yyyy/MM/dd HH:mm")
                        });
                }


                gvDepartments.DataSource =
                    result;

                gvDepartments.DataBind();


                lblDepartmentCount.Text =
                    "تعداد واحدهای سازمانی: " +
                    result.Count.ToString();
            }
        }


        protected void btnSave_Click(
            object sender,
            EventArgs e)
        {
            lblMessage.Visible = false;
            lblMessage.Text = "";


            string departmentName =
                txtDepartmentName.Text.Trim();


            string description =
                txtDescription.Text.Trim();


            if (string.IsNullOrEmpty(
                departmentName))
            {
                ShowError(
                    "لطفاً نام واحد سازمانی را وارد کنید.");

                return;
            }


            using (var db =
                new ApplicationDbContext())
            {
                // حالت ویرایش
                if (EditingDepartmentId > 0)
                {
                    var department =
                        db.Departments.FirstOrDefault(
                            d =>
                                d.DepartmentId ==
                                EditingDepartmentId);


                    if (department == null)
                    {
                        ShowError(
                            "واحد سازمانی مورد نظر پیدا نشد.");

                        ClearForm();

                        LoadDepartments();

                        return;
                    }


                    bool duplicate =
                        db.Departments.Any(
                            d =>
                                d.DepartmentId !=
                                    EditingDepartmentId
                                &&
                                d.DepartmentName ==
                                    departmentName);


                    if (duplicate)
                    {
                        ShowError(
                            "واحدی با این نام قبلاً ثبت شده است.");

                        return;
                    }


                    department.DepartmentName =
                        departmentName;

                    department.Description =
                        string.IsNullOrEmpty(description)
                            ? null
                            : description;

                    department.IsActive =
                        chkIsActive.Checked;


                    db.SaveChanges();


                    ShowSuccess(
                        "واحد سازمانی با موفقیت ویرایش شد.");


                    ClearForm();

                    LoadDepartments();

                    return;
                }


                // حالت افزودن
                bool exists =
                    db.Departments.Any(
                        d =>
                            d.DepartmentName ==
                            departmentName);


                if (exists)
                {
                    ShowError(
                        "واحدی با این نام قبلاً ثبت شده است.");

                    return;
                }


                var newDepartment =
                    new Department
                    {
                        DepartmentName =
                            departmentName,

                        Description =
                            string.IsNullOrEmpty(description)
                                ? null
                                : description,

                        IsActive =
                            chkIsActive.Checked,

                        CreatedAt =
                            DateTime.Now
                    };


                db.Departments.Add(
                    newDepartment);


                db.SaveChanges();


                ShowSuccess(
                    "واحد سازمانی با موفقیت ایجاد شد.");


                ClearForm();

                LoadDepartments();
            }
        }


        protected void Department_Command(
            object sender,
            CommandEventArgs e)
        {
            int departmentId;


            if (!int.TryParse(
                Convert.ToString(
                    e.CommandArgument),
                out departmentId))
            {
                ShowError(
                    "شناسه واحد سازمانی معتبر نیست.");

                return;
            }


            if (e.CommandName ==
                "EditDepartment")
            {
                EditDepartment(
                    departmentId);

                return;
            }


            if (e.CommandName ==
                "ToggleDepartment")
            {
                ToggleDepartment(
                    departmentId);

                return;
            }
        }


        private void EditDepartment(
            int departmentId)
        {
            using (var db =
                new ApplicationDbContext())
            {
                var department =
                    db.Departments.FirstOrDefault(
                        d =>
                            d.DepartmentId ==
                            departmentId);


                if (department == null)
                {
                    ShowError(
                        "واحد سازمانی مورد نظر پیدا نشد.");

                    return;
                }


                EditingDepartmentId =
                    department.DepartmentId;


                txtDepartmentName.Text =
                    department.DepartmentName;


                txtDescription.Text =
                    department.Description;


                chkIsActive.Checked =
                    department.IsActive;


                lblFormTitle.Text =
                    "ویرایش واحد سازمانی";


                btnSave.Text =
                    "ذخیره تغییرات";


                btnCancel.Visible =
                    true;


                txtDepartmentName.Focus();
            }
        }


        private void ToggleDepartment(
            int departmentId)
        {
            using (var db =
                new ApplicationDbContext())
            {
                var department =
                    db.Departments.FirstOrDefault(
                        d =>
                            d.DepartmentId ==
                            departmentId);


                if (department == null)
                {
                    ShowError(
                        "واحد سازمانی مورد نظر پیدا نشد.");

                    return;
                }


                department.IsActive =
                    !department.IsActive;


                db.SaveChanges();


                if (department.IsActive)
                {
                    ShowSuccess(
                        "واحد سازمانی فعال شد.");
                }
                else
                {
                    ShowSuccess(
                        "واحد سازمانی غیرفعال شد.");
                }


                LoadDepartments();
            }
        }


        protected void btnCancel_Click(
            object sender,
            EventArgs e)
        {
            ClearForm();

            LoadDepartments();
        }


        private void ClearForm()
        {
            EditingDepartmentId = 0;


            txtDepartmentName.Text = "";

            txtDescription.Text = "";

            chkIsActive.Checked = true;


            lblFormTitle.Text =
                "افزودن واحد سازمانی";


            btnSave.Text =
                "افزودن واحد";


            btnCancel.Visible =
                false;
        }


        private void ShowSuccess(
            string message)
        {
            lblMessage.Text =
                message;


            lblMessage.CssClass =
                "message success";


            lblMessage.Visible =
                true;
        }


        private void ShowError(
            string message)
        {
            lblMessage.Text =
                message;


            lblMessage.CssClass =
                "message error";


            lblMessage.Visible =
                true;
        }


        private class DepartmentListItem
        {
            public int DepartmentId
            {
                get;
                set;
            }


            public string DepartmentName
            {
                get;
                set;
            }


            public string Description
            {
                get;
                set;
            }


            public int UserCount
            {
                get;
                set;
            }


            public string StatusText
            {
                get;
                set;
            }


            public string StatusCss
            {
                get;
                set;
            }


            public string ToggleText
            {
                get;
                set;
            }


            public string ToggleCss
            {
                get;
                set;
            }


            public string CreatedAtText
            {
                get;
                set;
            }
        }
    }
}