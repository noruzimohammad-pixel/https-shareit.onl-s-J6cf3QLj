﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;
using WebApplication1.Models;

namespace WebApplication1
{
    public partial class Reports : System.Web.UI.Page
    {
        private const int PageSize = 10;

        private string ActiveReport
        {
            get
            {
                if (ViewState["ActiveReport"] == null)
                    return "Requester";

                return ViewState["ActiveReport"].ToString();
            }
            set
            {
                ViewState["ActiveReport"] = value;
            }
        }

        protected void Page_Load(
            object sender,
            EventArgs e)
        {
            // Force UTF-8 response so Persian text is decoded correctly by the browser.
            Response.ContentEncoding = Encoding.UTF8;
            Response.Charset = "utf-8";
            Response.ContentType = "text/html";

            if (!Request.IsAuthenticated)
            {
                Response.Redirect("~/Login.aspx");
                return;
            }

            if (!User.IsInRole("Manager"))
            {
                Response.Redirect("~/Login.aspx");
                return;
            }

            if (!IsPostBack)
            {
                ActiveReport = "Requester";

                LoadDepartments();
                LoadSpecialists();

                LoadReport();

                SetActiveTab();
            }
        }


        // =====================================================
        // واحدها
        // =====================================================

        private void LoadDepartments()
        {
            using (var db =
                new ApplicationDbContext())
            {
                var departments =
                    db.Departments
                    .Where(d => d.IsActive)
                    .OrderBy(d =>
                        d.DepartmentName)
                    .ToList();

                ddlDepartment.Items.Clear();

                ddlDepartment.Items.Add(
                    new ListItem(
                        "همه واحدها",
                        ""));

                foreach (var department
                    in departments)
                {
                    ddlDepartment.Items.Add(
                        new ListItem(
                            department.DepartmentName,
                            department.DepartmentId.ToString()));
                }
            }
        }


        // =====================================================
        // کارشناسان
        // =====================================================

        private void LoadSpecialists()
        {
            using (var db =
                new ApplicationDbContext())
            {
                var specialistRole =
                    db.Roles.FirstOrDefault(
                        r => r.Name == "Specialist");

                ddlSpecialist.Items.Clear();

                ddlSpecialist.Items.Add(
                    new ListItem(
                        "همه کارشناسان",
                        ""));

                if (specialistRole == null)
                    return;

                var specialistIds =
                    db.Set<
                        Microsoft.AspNet.Identity.EntityFramework.IdentityUserRole>()
                    .Where(ur =>
                        ur.RoleId ==
                        specialistRole.Id)
                    .Select(ur =>
                        ur.UserId)
                    .ToList();

                var specialists =
                    db.Users
                    .Where(u =>
                        specialistIds.Contains(
                            u.Id))
                    .Select(u => new
                    {
                        u.Id,
                        u.UserName
                    })
                    .OrderBy(u =>
                        u.UserName)
                    .ToList();

                foreach (var specialist
                    in specialists)
                {
                    string name =
                        GetUserDisplayName(
                            db,
                            specialist.Id,
                            specialist.UserName);

                    ddlSpecialist.Items.Add(
                        new ListItem(
                            name,
                            specialist.Id));
                }
            }
        }


        // =====================================================
        // نام کاربر
        // =====================================================

        private string GetUserDisplayName(
            ApplicationDbContext db,
            string userId,
            string userName)
        {
            var profile =
                db.UserProfiles
                .FirstOrDefault(
                    p => p.UserId == userId);

            if (profile != null &&
                !string.IsNullOrEmpty(
                    profile.FullName))
            {
                return profile.FullName;
            }

            return userName;
        }


        // =====================================================
        // دکمه نمایش گزارش
        // =====================================================

        protected void btnGenerateReport_Click(
            object sender,
            EventArgs e)
        {
            ResetAllReportPages();

            LoadReport();

            SetActiveTab();
        }


        // =====================================================
        // حذف فیلترهای اصلی
        // =====================================================

        protected void btnClearFilters_Click(
            object sender,
            EventArgs e)
        {
            txtFromDate.Text = "";
            txtToDate.Text = "";

            ddlDepartment.SelectedIndex = 0;
            ddlSpecialist.SelectedIndex = 0;
            ddlCategory.SelectedIndex = 0;
            ddlPriority.SelectedIndex = 0;
            ddlStatus.SelectedIndex = 0;

            txtRequesterSearch.Text = "";
            txtDepartmentSearch.Text = "";
            txtCategorySearch.Text = "";
            txtServiceCategorySearch.Text = "";
            txtServiceTopicSearch.Text = "";
            txtStatusSearch.Text = "";
            txtSpecialistSearch.Text = "";

            ResetAllReportPages();

            LoadReport();

            SetActiveTab();
        }


        // =====================================================
        // تب گزارش
        // =====================================================

        protected void ReportTab_Click(
            object sender,
            EventArgs e)
        {
            LinkButton button =
                sender as LinkButton;

            if (button == null)
                return;

            ActiveReport =
                button.CommandArgument;

            ResetAllReportPages();

            LoadReport();

            SetActiveTab();
        }


        // =====================================================
        // تنظیم تب فعال
        // =====================================================

        private void SetActiveTab()
        {
            pnlRequester.Visible =
                ActiveReport == "Requester";

            pnlDepartment.Visible =
                ActiveReport == "Department";

            pnlCategory.Visible =
                ActiveReport == "Category";

            pnlStatus.Visible =
                ActiveReport == "Status";

            pnlSpecialist.Visible =
                ActiveReport == "Specialist";

            pnlPriority.Visible =
                ActiveReport == "Priority";

            pnlTiming.Visible =
                ActiveReport == "Timing";

            pnlAging.Visible =
                ActiveReport == "Aging";

            pnlReturned.Visible =
                ActiveReport == "Returned";

            pnlActions.Visible =
                ActiveReport == "Actions";

            pnlTrend.Visible =
                ActiveReport == "Trend";

            pnlUnassigned.Visible =
                ActiveReport == "Unassigned";


            btnRequesterTab.CssClass =
                ActiveReport == "Requester"
                    ? "report-tab report-tab-active"
                    : "report-tab";

            btnDepartmentTab.CssClass =
                ActiveReport == "Department"
                    ? "report-tab report-tab-active"
                    : "report-tab";

            btnCategoryTab.CssClass =
                ActiveReport == "Category"
                    ? "report-tab report-tab-active"
                    : "report-tab";

            btnStatusTab.CssClass =
                ActiveReport == "Status"
                    ? "report-tab report-tab-active"
                    : "report-tab";

            btnSpecialistTab.CssClass =
                ActiveReport == "Specialist"
                    ? "report-tab report-tab-active"
                    : "report-tab";

            btnPriorityTab.CssClass =
                ActiveReport == "Priority"
                    ? "report-tab report-tab-active"
                    : "report-tab";

            btnTimingTab.CssClass =
                ActiveReport == "Timing"
                    ? "report-tab report-tab-active"
                    : "report-tab";

            btnAgingTab.CssClass =
                ActiveReport == "Aging"
                    ? "report-tab report-tab-active"
                    : "report-tab";

            btnReturnedTab.CssClass =
                ActiveReport == "Returned"
                    ? "report-tab report-tab-active"
                    : "report-tab";

            btnActionsTab.CssClass =
                ActiveReport == "Actions"
                    ? "report-tab report-tab-active"
                    : "report-tab";

            btnTrendTab.CssClass =
                ActiveReport == "Trend"
                    ? "report-tab report-tab-active"
                    : "report-tab";

            btnUnassignedTab.CssClass =
                ActiveReport == "Unassigned"
                    ? "report-tab report-tab-active"
                    : "report-tab";
        }


        // =====================================================
        // بارگذاری گزارش اصلی
        // =====================================================

        private void LoadReport()
        {
            DateTime? fromDate =
                ParsePersianDate(
                    txtFromDate.Text);

            DateTime? toDate =
                ParsePersianDate(
                    txtToDate.Text);

            string departmentValue =
                ddlDepartment.SelectedValue;

            string specialistValue =
                ddlSpecialist.SelectedValue;

            string categoryValue =
                ddlCategory.SelectedValue;

            string priorityValue =
                ddlPriority.SelectedValue;

            string statusValue =
                ddlStatus.SelectedValue;


            using (var db =
                new ApplicationDbContext())
            {
                var query =
                    db.Tickets.AsQueryable();


                // ---------------------------------------------
                // تاریخ
                // ---------------------------------------------

                if (fromDate.HasValue)
                {
                    DateTime startDate =
                        fromDate.Value.Date;

                    query =
                        query.Where(
                            t => t.CreatedAt >=
                                 startDate);
                }


                if (toDate.HasValue)
                {
                    DateTime endDate =
                        toDate.Value.Date.AddDays(1);

                    query =
                        query.Where(
                            t => t.CreatedAt <
                                 endDate);
                }


                // ---------------------------------------------
                // واحد
                // ---------------------------------------------

                if (!string.IsNullOrEmpty(
                    departmentValue))
                {
                    int departmentId;

                    if (int.TryParse(
                        departmentValue,
                        out departmentId))
                    {
                        query =
                            query.Where(
                                t => t.DepartmentId ==
                                     departmentId);
                    }
                }


                // ---------------------------------------------
                // کارشناس
                // ---------------------------------------------

                if (!string.IsNullOrEmpty(
                    specialistValue))
                {
                    query =
                        query.Where(
                            t => t.AssignedTo ==
                                 specialistValue);
                }


                // ---------------------------------------------
                // دسته‌بندی
                // ---------------------------------------------

                if (!string.IsNullOrEmpty(
                    categoryValue))
                {
                    query =
                        query.Where(
                            t => t.Category ==
                                 categoryValue);
                }


                // ---------------------------------------------
                // اولویت
                // ---------------------------------------------

                if (!string.IsNullOrEmpty(
                    priorityValue))
                {
                    query =
                        query.Where(
                            t => t.Priority ==
                                 priorityValue);
                }


                // ---------------------------------------------
                // وضعیت
                // ---------------------------------------------

                if (!string.IsNullOrEmpty(
                    statusValue))
                {
                    query =
                        query.Where(
                            t => t.Status ==
                                 statusValue);
                }


                var tickets =
                    query.ToList();


                // =================================================
                // کارت‌های آماری
                // =================================================

                lblTotalCount.Text =
                    tickets.Count.ToString();

                lblNewCount.Text =
                    tickets.Count(
                        t => t.Status ==
                             "New")
                    .ToString();

                lblInProgressCount.Text =
                    tickets.Count(
                        t => t.Status ==
                             "InProgress")
                    .ToString();

                lblWaitingCount.Text =
                    tickets.Count(
                        t => t.Status ==
                             "WaitingConfirmation")
                    .ToString();

                lblClosedCount.Text =
                    tickets.Count(
                        t => t.Status ==
                             "Closed")
                    .ToString();


                var ticketIds =
                    tickets
                    .Select(t =>
                        t.TicketId)
                    .ToList();


                var rejectedTicketIds =
                    db.TicketConfirmations
                    .Where(c =>
                        ticketIds.Contains(
                            c.TicketId) &&
                        c.ConfirmationStatus ==
                            "Rejected")
                    .Select(c =>
                        c.TicketId)
                    .Distinct()
                    .ToList();


                lblRejectedCount.Text =
                    rejectedTicketIds.Count.ToString();


                // =================================================
                // گزارش‌ها
                // =================================================

                LoadRequesterReport(
                    db,
                    tickets,
                    rejectedTicketIds);

                LoadDepartmentReport(
                    db,
                    tickets);

                LoadCategoryReport(
                    tickets);

                LoadServiceReports(
                    tickets);

                LoadStatusReport(
                    tickets);

                LoadSpecialistReport(
                    db,
                    tickets);

                LoadPriorityReport(
                    tickets);

                LoadTimingReport(
                    tickets);

                LoadAgingReport(
                    tickets);

                LoadReturnedReport(
                    db,
                    tickets);

                LoadActionsReport(
                    db,
                    tickets);

                LoadTrendReport(
                    tickets);

                LoadUnassignedReport(
                    db,
                    tickets);


                SetActiveTab();
            }
        }


        // =====================================================
        // درخواست‌کنندگان
        // =====================================================

        private void LoadRequesterReport(
            ApplicationDbContext db,
            List<Ticket> tickets,
            List<int> rejectedTicketIds)
        {
            var requesterIds =
                tickets
                .Where(t =>
                    !string.IsNullOrEmpty(
                        t.UserId))
                .Select(t =>
                    t.UserId)
                .Distinct()
                .ToList();


            var users =
                db.Users
                .Where(u =>
                    requesterIds.Contains(
                        u.Id))
                .ToList();


            var profiles =
                db.UserProfiles
                .Where(p =>
                    requesterIds.Contains(
                        p.UserId))
                .ToList();


            var departmentIds =
                tickets
                .Where(t =>
                    t.DepartmentId.HasValue)
                .Select(t =>
                    t.DepartmentId.Value)
                .Distinct()
                .ToList();


            var departments =
                db.Departments
                .Where(d =>
                    departmentIds.Contains(
                        d.DepartmentId))
                .ToDictionary(
                    d => d.DepartmentId,
                    d => d.DepartmentName);


            var report =
                tickets
                .Where(t =>
                    !string.IsNullOrEmpty(
                        t.UserId))
                .GroupBy(t =>
                    t.UserId)
                .Select(g =>
                {
                    string userId =
                        g.Key;


                    var profile =
                        profiles.FirstOrDefault(
                            p =>
                                p.UserId ==
                                userId);


                    var user =
                        users.FirstOrDefault(
                            u =>
                                u.Id ==
                                userId);


                    string requesterName =
                        "-";


                    if (profile != null &&
                        !string.IsNullOrEmpty(
                            profile.FullName))
                    {
                        requesterName =
                            profile.FullName;
                    }
                    else if (user != null)
                    {
                        requesterName =
                            user.UserName;
                    }


                    string userName =
                        user != null
                            ? user.UserName
                            : "-";


                    var departmentGroup =
                        g.Where(t =>
                            t.DepartmentId.HasValue)
                         .GroupBy(t =>
                            t.DepartmentId.Value)
                         .OrderByDescending(
                            x => x.Count())
                         .FirstOrDefault();


                    string departmentName =
                        "بدون واحد";


                    if (departmentGroup != null &&
                        departments.ContainsKey(
                            departmentGroup.Key))
                    {
                        departmentName =
                            departments[
                                departmentGroup.Key];
                    }


                    int rejectedCount =
                        g.Count(t =>
                            rejectedTicketIds.Contains(
                                t.TicketId));


                    return new RequesterReportItem
                    {
                        RequesterName =
                            requesterName,

                        UserName =
                            userName,

                        DepartmentName =
                            departmentName,

                        TotalCount =
                            g.Count(),

                        NewCount =
                            g.Count(t =>
                                t.Status ==
                                "New"),

                        InProgressCount =
                            g.Count(t =>
                                t.Status ==
                                "InProgress"),

                        WaitingCount =
                            g.Count(t =>
                                t.Status ==
                                "WaitingConfirmation"),

                        ClosedCount =
                            g.Count(t =>
                                t.Status ==
                                "Closed"),

                        RejectedCount =
                            rejectedCount
                    };
                })
                .OrderByDescending(
                    x => x.TotalCount)
                .ThenBy(
                    x => x.RequesterName)
                .ToList();


            string search =
                txtRequesterSearch.Text
                .Trim();


            if (!string.IsNullOrEmpty(search))
            {
                report =
                    report
                    .Where(x =>
                        ContainsText(
                            x.RequesterName,
                            search) ||
                        ContainsText(
                            x.UserName,
                            search))
                    .ToList();
            }


            lblRequesterResultCount.Text =
                "تعداد درخواست‌کنندگان: " +
                report.Count.ToString();


            gvRequesterReport.DataSource =
                report;

            gvRequesterReport.DataBind();
        }


        // =====================================================
        // واحدها
        // =====================================================

        private void LoadDepartmentReport(
            ApplicationDbContext db,
            List<Ticket> tickets)
        {
            var departmentIds =
                tickets
                .Where(t =>
                    t.DepartmentId.HasValue)
                .Select(t =>
                    t.DepartmentId.Value)
                .Distinct()
                .ToList();


            var departments =
                db.Departments
                .Where(d =>
                    departmentIds.Contains(
                        d.DepartmentId))
                .ToDictionary(
                    d => d.DepartmentId,
                    d => d.DepartmentName);


            var report =
                tickets
                .GroupBy(t =>
                    t.DepartmentId)
                .Select(g => new DepartmentReportItem
                {
                    DepartmentName =
                        g.Key.HasValue &&
                        departments.ContainsKey(
                            g.Key.Value)
                            ?
                            departments[
                                g.Key.Value]
                            :
                            "بدون واحد",

                    Count =
                        g.Count()
                })
                .OrderByDescending(
                    x => x.Count)
                .ToList();


            string search =
                txtDepartmentSearch.Text
                .Trim();


            if (!string.IsNullOrEmpty(search))
            {
                report =
                    report
                    .Where(x =>
                        ContainsText(
                            x.DepartmentName,
                            search))
                    .ToList();
            }


            lblDepartmentResultCount.Text =
                "تعداد واحدها: " +
                report.Count.ToString();


            gvDepartmentReport.DataSource =
                report;

            gvDepartmentReport.DataBind();
        }


        // =====================================================
        // دسته‌بندی
        // =====================================================

        private void LoadCategoryReport(
            List<Ticket> tickets)
        {
            var report =
                tickets
                .GroupBy(t =>
                    string.IsNullOrEmpty(
                        t.Category)
                        ?
                        "سایر"
                        :
                        t.Category)
                .Select(g => new CategoryReportItem
                {
                    Category =
                        GetCategoryText(
                            g.Key),

                    Count =
                        g.Count()
                })
                .OrderByDescending(
                    x => x.Count)
                .ToList();


            string search =
                txtCategorySearch.Text
                .Trim();


            if (!string.IsNullOrEmpty(search))
            {
                report =
                    report
                    .Where(x =>
                        ContainsText(
                            x.Category,
                            search))
                    .ToList();
            }


            lblCategoryResultCount.Text =
                "تعداد دسته‌ها: " +
                report.Count.ToString();


            gvCategoryReport.DataSource =
                report;

            gvCategoryReport.DataBind();
        }


        // =====================================================
        // گزارش خدمات
        // =====================================================

        private void LoadServiceReports(
            List<Ticket> tickets)
        {
            string connectionString =
                ConfigurationManager
                .ConnectionStrings["DefaultConnection"]
                .ConnectionString;

            var categoryNames =
                new Dictionary<int, string>();

            var topicMap =
                new Dictionary<int, ServiceTopicReportItem>();

            using (var connection =
                new SqlConnection(connectionString))
            {
                connection.Open();

                using (var command =
                    new SqlCommand(
                        "SELECT ServiceCategoryId, CategoryName FROM ServiceCategories",
                        connection))
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        categoryNames[reader.GetInt32(0)] =
                            reader.IsDBNull(1)
                                ? "-"
                                : reader.GetString(1);
                    }
                }

                using (var command =
                    new SqlCommand(
                        "SELECT ServiceTopicId, ServiceCategoryId, TopicName FROM ServiceTopics",
                        connection))
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        int topicId = reader.GetInt32(0);
                        int categoryId = reader.GetInt32(1);

                        topicMap[topicId] =
                            new ServiceTopicReportItem
                            {
                                ServiceTopicId = topicId,
                                ServiceCategoryId = categoryId,
                                ServiceCategoryName =
                                    categoryNames.ContainsKey(categoryId)
                                        ? categoryNames[categoryId]
                                        : "-",
                                ServiceTopicName =
                                    reader.IsDBNull(2)
                                        ? "-"
                                        : reader.GetString(2)
                            };
                    }
                }
            }

            var categoryReport =
                tickets
                .Where(t =>
                    t.ServiceTopicId.HasValue &&
                    topicMap.ContainsKey(t.ServiceTopicId.Value))
                .GroupBy(t =>
                    topicMap[t.ServiceTopicId.Value].ServiceCategoryId)
                .Select(g => new ServiceCategoryReportItem
                {
                    ServiceCategoryName =
                        categoryNames.ContainsKey(g.Key)
                            ? categoryNames[g.Key]
                            : "-",
                    Count = g.Count()
                })
                .OrderByDescending(x => x.Count)
                .ThenBy(x => x.ServiceCategoryName)
                .ToList();

            string categorySearch =
                txtServiceCategorySearch.Text.Trim();

            if (!string.IsNullOrEmpty(categorySearch))
            {
                categoryReport = categoryReport
                    .Where(x => ContainsText(
                        x.ServiceCategoryName,
                        categorySearch))
                    .ToList();
            }

            lblServiceCategoryResultCount.Text =
                "تعداد حوزه‌ها: " + categoryReport.Count.ToString();

            gvServiceCategoryReport.DataSource = categoryReport;
            gvServiceCategoryReport.DataBind();

            var topicReport =
                tickets
                .Where(t =>
                    t.ServiceTopicId.HasValue &&
                    topicMap.ContainsKey(t.ServiceTopicId.Value))
                .GroupBy(t => t.ServiceTopicId.Value)
                .Select(g =>
                {
                    ServiceTopicReportItem topic =
                        topicMap[g.Key];

                    return new ServiceTopicReportItem
                    {
                        ServiceTopicId = topic.ServiceTopicId,
                        ServiceCategoryId = topic.ServiceCategoryId,
                        ServiceCategoryName = topic.ServiceCategoryName,
                        ServiceTopicName = topic.ServiceTopicName,
                        Count = g.Count()
                    };
                })
                .OrderByDescending(x => x.Count)
                .ThenBy(x => x.ServiceCategoryName)
                .ThenBy(x => x.ServiceTopicName)
                .ToList();

            string topicSearch =
                txtServiceTopicSearch.Text.Trim();

            if (!string.IsNullOrEmpty(topicSearch))
            {
                topicReport = topicReport
                    .Where(x =>
                        ContainsText(x.ServiceCategoryName, topicSearch) ||
                        ContainsText(x.ServiceTopicName, topicSearch))
                    .ToList();
            }

            lblServiceTopicResultCount.Text =
                "تعداد موضوع‌ها: " + topicReport.Count.ToString();

            gvServiceTopicReport.DataSource = topicReport;
            gvServiceTopicReport.DataBind();

            int mismatchCount =
                tickets.Count(t =>
                    t.ServiceTopicId.HasValue &&
                    topicMap.ContainsKey(t.ServiceTopicId.Value) &&
                    !string.IsNullOrWhiteSpace(t.Category) &&
                    !string.Equals(
                        NormalizeText(t.Category),
                        NormalizeText(topicMap[t.ServiceTopicId.Value].ServiceCategoryName),
                        StringComparison.OrdinalIgnoreCase));

            lblServiceMismatchCount.Text =
                mismatchCount.ToString();
        }


        private string NormalizeText(string value)
        {
            if (string.IsNullOrEmpty(value))
                return "";

            return value.Trim()
                .Replace("ي", "ی")
                .Replace("ى", "ی")
                .Replace("ك", "ک")
                .Replace("ۀ", "ه")
                .Replace("ة", "ه")
                .Replace("‌", "")
                .Replace(" ", "");
        }



        // =====================================================
        // اولویت‌ها
        // =====================================================

        private void LoadPriorityReport(
            List<Ticket> tickets)
        {
            int total = tickets.Count;

            var report = tickets
                .GroupBy(t => string.IsNullOrEmpty(t.Priority) ? "Normal" : t.Priority)
                .Select(g => new PriorityReportItem
                {
                    Priority = GetPriorityText(g.Key),
                    Count = g.Count(),
                    Percent = total == 0 ? "0%" : (g.Count() * 100.0 / total).ToString("0.0") + "%"
                })
                .OrderByDescending(x => x.Count)
                .ThenBy(x => x.Priority)
                .ToList();

            lblPriorityResultCount.Text = "تعداد اولویت‌ها: " + report.Count.ToString();
            gvPriorityReport.DataSource = report;
            gvPriorityReport.DataBind();
        }


        // =====================================================
        // زمان رسیدگی
        // =====================================================

        private void LoadTimingReport(
            List<Ticket> tickets)
        {
            var assignmentHours = tickets
                .Where(t => t.AssignedAt.HasValue)
                .Select(t => (t.AssignedAt.Value - t.CreatedAt).TotalHours)
                .Where(x => x >= 0)
                .ToList();

            var resolutionHours = tickets
                .Where(t => t.ResolvedAt.HasValue)
                .Select(t => (t.ResolvedAt.Value - t.CreatedAt).TotalHours)
                .Where(x => x >= 0)
                .ToList();

            var closureHours = tickets
                .Where(t => t.ClosedAt.HasValue)
                .Select(t => (t.ClosedAt.Value - t.CreatedAt).TotalHours)
                .Where(x => x >= 0)
                .ToList();

            lblAvgAssignmentHours.Text = FormatHours(assignmentHours.Count == 0 ? 0 : assignmentHours.Average());
            lblAvgResolutionHours.Text = FormatHours(resolutionHours.Count == 0 ? 0 : resolutionHours.Average());
            lblAvgClosureHours.Text = FormatHours(closureHours.Count == 0 ? 0 : closureHours.Average());
            lblMaxResolutionHours.Text = resolutionHours.Count == 0 ? "-" : FormatHours(resolutionHours.Max());

            var report = new List<TimingReportItem>
            {
                new TimingReportItem { Metric = "میانگین زمان تا تخصیص", Value = assignmentHours.Count == 0 ? "-" : FormatHours(assignmentHours.Average()), Count = assignmentHours.Count },
                new TimingReportItem { Metric = "میانگین زمان تا حل", Value = resolutionHours.Count == 0 ? "-" : FormatHours(resolutionHours.Average()), Count = resolutionHours.Count },
                new TimingReportItem { Metric = "میانگین زمان تا خاتمه", Value = closureHours.Count == 0 ? "-" : FormatHours(closureHours.Average()), Count = closureHours.Count },
                new TimingReportItem { Metric = "طولانی‌ترین زمان حل", Value = resolutionHours.Count == 0 ? "-" : FormatHours(resolutionHours.Max()), Count = resolutionHours.Count }
            };

            lblTimingResultCount.Text = "تعداد درخواست‌ها: " + tickets.Count.ToString();
            gvTimingReport.DataSource = report;
            gvTimingReport.DataBind();
        }

        private string FormatHours(double hours)
        {
            if (hours < 24)
                return hours.ToString("0.0") + " ساعت";

            return (hours / 24.0).ToString("0.0") + " روز";
        }


        // =====================================================
        // عمر درخواست‌های باز
        // =====================================================

        private void LoadAgingReport(
            List<Ticket> tickets)
        {
            DateTime now = DateTime.Now;

            var openTickets = tickets
                .Where(t => !string.Equals(t.Status, "Closed", StringComparison.OrdinalIgnoreCase))
                .ToList();

            var buckets = new List<AgingReportItem>
            {
                CreateAgingItem("تا ۳ روز", openTickets.Where(t => (now - t.CreatedAt).TotalDays <= 3)),
                CreateAgingItem("۴ تا ۷ روز", openTickets.Where(t => (now - t.CreatedAt).TotalDays > 3 && (now - t.CreatedAt).TotalDays <= 7)),
                CreateAgingItem("۸ تا ۱۴ روز", openTickets.Where(t => (now - t.CreatedAt).TotalDays > 7 && (now - t.CreatedAt).TotalDays <= 14)),
                CreateAgingItem("بیش از ۱۴ روز", openTickets.Where(t => (now - t.CreatedAt).TotalDays > 14))
            };

            lblAgingResultCount.Text = "درخواست‌های باز: " + openTickets.Count.ToString();
            gvAgingReport.DataSource = buckets;
            gvAgingReport.DataBind();
        }

        private AgingReportItem CreateAgingItem(string bucket, IEnumerable<Ticket> source)
        {
            var list = source.ToList();
            return new AgingReportItem
            {
                Bucket = bucket,
                Count = list.Count,
                OldestDate = list.Count == 0 ? "-" : list.Min(t => t.CreatedAt).ToString("yyyy/MM/dd HH:mm")
            };
        }


        // =====================================================
        // درخواست‌های برگشتی
        // =====================================================

        private void LoadReturnedReport(
            ApplicationDbContext db,
            List<Ticket> tickets)
        {
            var ids = tickets.Select(t => t.TicketId).ToList();

            var histories = ids.Count == 0
                ? new List<TicketHistory>()
                : db.TicketHistory
                    .Where(h => ids.Contains(h.TicketId) && h.NewStatus == "New")
                    .ToList();

            var returned = histories
                .Where(h => h.OldStatus == "Assigned" || h.OldStatus == "InProgress")
                .ToList();

            var report = new List<ReturnedReportItem>
            {
                new ReturnedReportItem
                {
                    Type = "تعداد دفعات برگشت",
                    Count = returned.Count,
                    LastDate = returned.Count == 0 ? "-" : returned.Max(x => x.HistoryDate).ToString("yyyy/MM/dd HH:mm")
                },
                new ReturnedReportItem
                {
                    Type = "تعداد درخواست‌های دارای برگشت",
                    Count = returned.Select(x => x.TicketId).Distinct().Count(),
                    LastDate = returned.Count == 0 ? "-" : returned.Max(x => x.HistoryDate).ToString("yyyy/MM/dd HH:mm")
                }
            };

            lblReturnedResultCount.Text = "درخواست‌های برگشتی: " + returned.Select(x => x.TicketId).Distinct().Count().ToString();
            gvReturnedReport.DataSource = report;
            gvReturnedReport.DataBind();
        }


        // =====================================================
        // اقدامات کارشناسان
        // =====================================================

        private void LoadActionsReport(
            ApplicationDbContext db,
            List<Ticket> tickets)
        {
            var ids = tickets.Select(t => t.TicketId).ToList();
            var actions = ids.Count == 0
                ? new List<TicketAction>()
                : db.TicketActions.Where(a => ids.Contains(a.TicketId)).ToList();

            var userIds = actions.Select(a => a.UserId).Where(x => !string.IsNullOrEmpty(x)).Distinct().ToList();
            var users = db.Users.Where(u => userIds.Contains(u.Id)).ToList();
            var profiles = db.UserProfiles.Where(p => userIds.Contains(p.UserId)).ToList();

            var report = actions
                .GroupBy(a => a.UserId)
                .Select(g => new ActionReportItem
                {
                    SpecialistName = GetSpecialistName(g.Key, users, profiles),
                    TicketCount = g.Select(x => x.TicketId).Distinct().Count(),
                    ActionCount = g.Count(),
                    AverageActions = g.Select(x => x.TicketId).Distinct().Count() == 0 ? "0" : (g.Count() * 1.0 / g.Select(x => x.TicketId).Distinct().Count()).ToString("0.0"),
                    LastActionDate = g.Max(x => x.ActionDate).ToString("yyyy/MM/dd HH:mm")
                })
                .OrderByDescending(x => x.ActionCount)
                .ThenBy(x => x.SpecialistName)
                .ToList();

            lblActionsResultCount.Text = "تعداد کارشناسان دارای اقدام: " + report.Count.ToString();
            gvActionsReport.DataSource = report;
            gvActionsReport.DataBind();
        }


        // =====================================================
        // روند ماهانه
        // =====================================================

        private void LoadTrendReport(
            List<Ticket> tickets)
        {
            var pc = new PersianCalendar();

            var report = tickets
                .GroupBy(t => new { Year = pc.GetYear(t.CreatedAt), Month = pc.GetMonth(t.CreatedAt) })
                .Select(g => new TrendReportItem
                {
                    Month = g.Key.Year.ToString() + "/" + g.Key.Month.ToString("00"),
                    TotalCount = g.Count(),
                    ClosedCount = g.Count(t => t.Status == "Closed"),
                    WaitingCount = g.Count(t => t.Status == "WaitingConfirmation"),
                    NewCount = g.Count(t => t.Status == "New")
                })
                .OrderBy(x => x.Month)
                .ToList();

            lblTrendResultCount.Text = "تعداد ماه‌های دارای داده: " + report.Count.ToString();
            gvTrendReport.DataSource = report;
            gvTrendReport.DataBind();
        }


        // =====================================================
        // بدون تخصیص
        // =====================================================

        private void LoadUnassignedReport(
            ApplicationDbContext db,
            List<Ticket> tickets)
        {
            var departments = db.Departments.ToDictionary(d => d.DepartmentId, d => d.DepartmentName);

            var open = tickets
                .Where(t => t.Status == "New" && string.IsNullOrEmpty(t.AssignedTo))
                .ToList();

            var report = open
                .GroupBy(t => t.DepartmentId)
                .Select(g => new UnassignedReportItem
                {
                    DepartmentName = g.Key.HasValue && departments.ContainsKey(g.Key.Value) ? departments[g.Key.Value] : "بدون واحد",
                    Count = g.Count(),
                    OldestDate = g.Min(t => t.CreatedAt).ToString("yyyy/MM/dd HH:mm")
                })
                .OrderByDescending(x => x.Count)
                .ThenBy(x => x.DepartmentName)
                .ToList();

            lblUnassignedResultCount.Text = "کل درخواست‌های بدون تخصیص: " + open.Count.ToString();
            gvUnassignedReport.DataSource = report;
            gvUnassignedReport.DataBind();
        }


        // =====================================================
        // وضعیت
        // =====================================================

        private void LoadStatusReport(
            List<Ticket> tickets)
        {
            var report =
                tickets
                .GroupBy(t =>
                    t.Status)
                .Select(g => new StatusReportItem
                {
                    Status =
                        GetStatusText(
                            g.Key),

                    Count =
                        g.Count()
                })
                .OrderByDescending(
                    x => x.Count)
                .ToList();


            string search =
                txtStatusSearch.Text
                .Trim();


            if (!string.IsNullOrEmpty(search))
            {
                report =
                    report
                    .Where(x =>
                        ContainsText(
                            x.Status,
                            search))
                    .ToList();
            }


            lblStatusResultCount.Text =
                "تعداد وضعیت‌ها: " +
                report.Count.ToString();


            gvStatusReport.DataSource =
                report;

            gvStatusReport.DataBind();
        }


        // =====================================================
        // کارشناسان
        // =====================================================

        private void LoadSpecialistReport(
            ApplicationDbContext db,
            List<Ticket> tickets)
        {
            var specialistIds =
                tickets
                .Where(t =>
                    !string.IsNullOrEmpty(
                        t.AssignedTo))
                .Select(t =>
                    t.AssignedTo)
                .Distinct()
                .ToList();


            var users =
                db.Users
                .Where(u =>
                    specialistIds.Contains(
                        u.Id))
                .ToList();


            var profiles =
                db.UserProfiles
                .Where(p =>
                    specialistIds.Contains(
                        p.UserId))
                .ToList();


            var report =
                tickets
                .Where(t =>
                    !string.IsNullOrEmpty(
                        t.AssignedTo))
                .GroupBy(t =>
                    t.AssignedTo)
                .Select(g =>
                {
                    string name =
                        GetSpecialistName(
                            g.Key,
                            users,
                            profiles);


                    return new SpecialistReportItem
                    {
                        SpecialistName =
                            name,

                        AssignedCount =
                            g.Count(),

                        InProgressCount =
                            g.Count(t =>
                                t.Status ==
                                "InProgress"),

                        WaitingCount =
                            g.Count(t =>
                                t.Status ==
                                "WaitingConfirmation"),

                        ClosedCount =
                            g.Count(t =>
                                t.Status ==
                                "Closed")
                    };
                })
                .OrderByDescending(
                    x => x.ClosedCount)
                .ThenBy(
                    x => x.SpecialistName)
                .ToList();


            string search =
                txtSpecialistSearch.Text
                .Trim();


            if (!string.IsNullOrEmpty(search))
            {
                report =
                    report
                    .Where(x =>
                        ContainsText(
                            x.SpecialistName,
                            search))
                    .ToList();
            }


            lblSpecialistResultCount.Text =
                "تعداد کارشناسان: " +
                report.Count.ToString();


            gvSpecialistReport.DataSource =
                report;

            gvSpecialistReport.DataBind();
        }


        // =====================================================
        // جستجوی درخواست‌کننده
        // =====================================================

        protected void btnRequesterSearch_Click(
            object sender,
            EventArgs e)
        {
            ActiveReport = "Requester";

            gvRequesterReport.PageIndex = 0;

            LoadReport();

            SetActiveTab();
        }


        protected void btnRequesterClearSearch_Click(
            object sender,
            EventArgs e)
        {
            txtRequesterSearch.Text = "";

            ActiveReport = "Requester";

            gvRequesterReport.PageIndex = 0;

            LoadReport();

            SetActiveTab();
        }


        // =====================================================
        // جستجوی واحد
        // =====================================================

        protected void btnDepartmentSearch_Click(
            object sender,
            EventArgs e)
        {
            ActiveReport = "Department";

            gvDepartmentReport.PageIndex = 0;

            LoadReport();

            SetActiveTab();
        }


        protected void btnDepartmentClearSearch_Click(
            object sender,
            EventArgs e)
        {
            txtDepartmentSearch.Text = "";

            ActiveReport = "Department";

            gvDepartmentReport.PageIndex = 0;

            LoadReport();

            SetActiveTab();
        }


        // =====================================================
        // جستجوی دسته‌بندی
        // =====================================================

        protected void btnCategorySearch_Click(
            object sender,
            EventArgs e)
        {
            ActiveReport = "Category";

            gvCategoryReport.PageIndex = 0;

            LoadReport();

            SetActiveTab();
        }


        protected void btnCategoryClearSearch_Click(
            object sender,
            EventArgs e)
        {
            txtCategorySearch.Text = "";

            ActiveReport = "Category";

            gvCategoryReport.PageIndex = 0;

            LoadReport();

            SetActiveTab();
        }


        // =====================================================
        // جستجوی حوزه خدمات
        // =====================================================

        protected void btnServiceCategorySearch_Click(
            object sender,
            EventArgs e)
        {
            ActiveReport = "Category";

            gvServiceCategoryReport.PageIndex = 0;

            LoadReport();

            SetActiveTab();
        }


        protected void btnServiceCategoryClearSearch_Click(
            object sender,
            EventArgs e)
        {
            txtServiceCategorySearch.Text = "";

            ActiveReport = "Category";

            gvServiceCategoryReport.PageIndex = 0;

            LoadReport();

            SetActiveTab();
        }


        // =====================================================
        // جستجوی موضوع خدمات
        // =====================================================

        protected void btnServiceTopicSearch_Click(
            object sender,
            EventArgs e)
        {
            ActiveReport = "Category";

            gvServiceTopicReport.PageIndex = 0;

            LoadReport();

            SetActiveTab();
        }


        protected void btnServiceTopicClearSearch_Click(
            object sender,
            EventArgs e)
        {
            txtServiceTopicSearch.Text = "";

            ActiveReport = "Category";

            gvServiceTopicReport.PageIndex = 0;

            LoadReport();

            SetActiveTab();
        }


        // =====================================================
        // جستجوی وضعیت
        // =====================================================

        protected void btnStatusSearch_Click(
            object sender,
            EventArgs e)
        {
            ActiveReport = "Status";

            gvStatusReport.PageIndex = 0;

            LoadReport();

            SetActiveTab();
        }


        protected void btnStatusClearSearch_Click(
            object sender,
            EventArgs e)
        {
            txtStatusSearch.Text = "";

            ActiveReport = "Status";

            gvStatusReport.PageIndex = 0;

            LoadReport();

            SetActiveTab();
        }


        // =====================================================
        // جستجوی کارشناس
        // =====================================================

        protected void btnSpecialistSearch_Click(
            object sender,
            EventArgs e)
        {
            ActiveReport = "Specialist";

            gvSpecialistReport.PageIndex = 0;

            LoadReport();

            SetActiveTab();
        }


        protected void btnSpecialistClearSearch_Click(
            object sender,
            EventArgs e)
        {
            txtSpecialistSearch.Text = "";

            ActiveReport = "Specialist";

            gvSpecialistReport.PageIndex = 0;

            LoadReport();

            SetActiveTab();
        }



        // =====================================================
        // صفحه‌بندی اقدامات کارشناسان
        // =====================================================

        protected void gvActionsReport_PageIndexChanging(
            object sender,
            GridViewPageEventArgs e)
        {
            gvActionsReport.PageIndex = e.NewPageIndex;
            ActiveReport = "Actions";
            LoadReport();
            SetActiveTab();
        }


        // =====================================================
        // صفحه‌بندی درخواست‌کنندگان
        // =====================================================

        protected void gvRequesterReport_PageIndexChanging(
            object sender,
            GridViewPageEventArgs e)
        {
            gvRequesterReport.PageIndex =
                e.NewPageIndex;

            ActiveReport = "Requester";

            LoadReport();

            SetActiveTab();
        }


        // =====================================================
        // صفحه‌بندی واحدها
        // =====================================================

        protected void gvDepartmentReport_PageIndexChanging(
            object sender,
            GridViewPageEventArgs e)
        {
            gvDepartmentReport.PageIndex =
                e.NewPageIndex;

            ActiveReport = "Department";

            LoadReport();

            SetActiveTab();
        }


        // =====================================================
        // صفحه‌بندی دسته‌بندی
        // =====================================================

        protected void gvCategoryReport_PageIndexChanging(
            object sender,
            GridViewPageEventArgs e)
        {
            gvCategoryReport.PageIndex =
                e.NewPageIndex;

            ActiveReport = "Category";

            LoadReport();

            SetActiveTab();
        }


        // =====================================================
        // صفحه‌بندی حوزه خدمات
        // =====================================================

        protected void gvServiceCategoryReport_PageIndexChanging(
            object sender,
            GridViewPageEventArgs e)
        {
            gvServiceCategoryReport.PageIndex =
                e.NewPageIndex;

            ActiveReport = "Category";

            LoadReport();

            SetActiveTab();
        }


        // =====================================================
        // صفحه‌بندی موضوع خدمات
        // =====================================================

        protected void gvServiceTopicReport_PageIndexChanging(
            object sender,
            GridViewPageEventArgs e)
        {
            gvServiceTopicReport.PageIndex =
                e.NewPageIndex;

            ActiveReport = "Category";

            LoadReport();

            SetActiveTab();
        }


        // =====================================================
        // صفحه‌بندی وضعیت
        // =====================================================

        protected void gvStatusReport_PageIndexChanging(
            object sender,
            GridViewPageEventArgs e)
        {
            gvStatusReport.PageIndex =
                e.NewPageIndex;

            ActiveReport = "Status";

            LoadReport();

            SetActiveTab();
        }


        // =====================================================
        // صفحه‌بندی کارشناسان
        // =====================================================

        protected void gvSpecialistReport_PageIndexChanging(
            object sender,
            GridViewPageEventArgs e)
        {
            gvSpecialistReport.PageIndex =
                e.NewPageIndex;

            ActiveReport = "Specialist";

            LoadReport();

            SetActiveTab();
        }


        // =====================================================
        // ریست صفحه‌بندی
        // =====================================================

        private void ResetAllReportPages()
        {
            gvRequesterReport.PageIndex = 0;
            gvDepartmentReport.PageIndex = 0;
            gvCategoryReport.PageIndex = 0;
            gvServiceCategoryReport.PageIndex = 0;
            gvServiceTopicReport.PageIndex = 0;
            gvStatusReport.PageIndex = 0;
            gvSpecialistReport.PageIndex = 0;
            gvActionsReport.PageIndex = 0;
        }


        // =====================================================
        // نام کارشناس
        // =====================================================

        private string GetSpecialistName(
            string userId,
            List<ApplicationUser> users,
            List<UserProfile> profiles)
        {
            var profile =
                profiles.FirstOrDefault(
                    p => p.UserId == userId);

            if (profile != null &&
                !string.IsNullOrEmpty(
                    profile.FullName))
            {
                return profile.FullName;
            }


            var user =
                users.FirstOrDefault(
                    u => u.Id == userId);


            if (user != null &&
                !string.IsNullOrEmpty(
                    user.UserName))
            {
                return user.UserName;
            }


            return "-";
        }


        // =====================================================
        // جستجوی فارسی / انگلیسی
        // =====================================================

        private bool ContainsText(
            string source,
            string search)
        {
            if (string.IsNullOrEmpty(source) ||
                string.IsNullOrEmpty(search))
            {
                return false;
            }

            return source.IndexOf(
                search,
                StringComparison
                    .CurrentCultureIgnoreCase) >= 0;
        }


        // =====================================================
        // تبدیل تاریخ شمسی
        // =====================================================

        private DateTime? ParsePersianDate(
            string value)
        {
            if (string.IsNullOrWhiteSpace(value))
                return null;


            value =
                value.Trim()
                .Replace("-", "/")
                .Replace(".", "/");


            string[] parts =
                value.Split('/');


            if (parts.Length != 3)
                return null;


            int year;
            int month;
            int day;


            if (!int.TryParse(
                parts[0],
                out year))
            {
                return null;
            }


            if (!int.TryParse(
                parts[1],
                out month))
            {
                return null;
            }


            if (!int.TryParse(
                parts[2],
                out day))
            {
                return null;
            }


            try
            {
                PersianCalendar pc =
                    new PersianCalendar();


                return pc.ToDateTime(
                    year,
                    month,
                    day,
                    0,
                    0,
                    0,
                    0);
            }
            catch
            {
                return null;
            }
        }


        // =====================================================
        // متن دسته‌بندی
        // =====================================================

        private string GetCategoryText(
            string category)
        {
            switch (category)
            {
                case "نرم‌افزار":
                    return "نرم‌افزار";

                case "سخت‌افزار":
                    return "سخت‌افزار";

                case "شبکه":
                    return "شبکه";

                case "امنیت":
                    return "امنیت";

                case "سایر":
                    return "سایر";

                default:
                    return category;
            }
        }



        // =====================================================
        // متن اولویت
        // =====================================================

        private string GetPriorityText(string priority)
        {
            switch (priority)
            {
                case "Low":
                    return "کم";
                case "Normal":
                    return "عادی";
                case "High":
                    return "زیاد";
                case "Critical":
                    return "بحرانی";
                default:
                    return string.IsNullOrEmpty(priority) ? "عادی" : priority;
            }
        }


        // =====================================================
        // متن وضعیت
        // =====================================================

        private string GetStatusText(
            string status)
        {
            switch (status)
            {
                case "New":
                    return "جدید";

                case "Assigned":
                    return "ارجاع شده";

                case "InProgress":
                    return "در حال انجام";

                case "WaitingConfirmation":
                    return "منتظر تأیید کاربر";

                case "Closed":
                    return "خاتمه یافته";

                default:
                    return status;
            }
        }


        // =====================================================
        // کلاس‌های گزارش
        // =====================================================

        private class RequesterReportItem
        {
            public string RequesterName { get; set; }

            public string UserName { get; set; }

            public string DepartmentName { get; set; }

            public int TotalCount { get; set; }

            public int NewCount { get; set; }

            public int InProgressCount { get; set; }

            public int WaitingCount { get; set; }

            public int ClosedCount { get; set; }

            public int RejectedCount { get; set; }
        }


        private class DepartmentReportItem
        {
            public string DepartmentName { get; set; }

            public int Count { get; set; }
        }


        private class CategoryReportItem
        {
            public string Category { get; set; }

            public int Count { get; set; }
        }


        private class ServiceCategoryReportItem
        {
            public string ServiceCategoryName { get; set; }
            public int Count { get; set; }
        }


        private class ServiceTopicReportItem
        {
            public int ServiceTopicId { get; set; }
            public int ServiceCategoryId { get; set; }
            public string ServiceCategoryName { get; set; }
            public string ServiceTopicName { get; set; }
            public int Count { get; set; }
        }



        private class PriorityReportItem
        {
            public string Priority { get; set; }
            public int Count { get; set; }
            public string Percent { get; set; }
        }

        private class TimingReportItem
        {
            public string Metric { get; set; }
            public string Value { get; set; }
            public int Count { get; set; }
        }

        private class AgingReportItem
        {
            public string Bucket { get; set; }
            public int Count { get; set; }
            public string OldestDate { get; set; }
        }

        private class ReturnedReportItem
        {
            public string Type { get; set; }
            public int Count { get; set; }
            public string LastDate { get; set; }
        }

        private class ActionReportItem
        {
            public string SpecialistName { get; set; }
            public int TicketCount { get; set; }
            public int ActionCount { get; set; }
            public string AverageActions { get; set; }
            public string LastActionDate { get; set; }
        }

        private class TrendReportItem
        {
            public string Month { get; set; }
            public int TotalCount { get; set; }
            public int ClosedCount { get; set; }
            public int WaitingCount { get; set; }
            public int NewCount { get; set; }
        }

        private class UnassignedReportItem
        {
            public string DepartmentName { get; set; }
            public int Count { get; set; }
            public string OldestDate { get; set; }
        }


        private class StatusReportItem
        {
            public string Status { get; set; }

            public int Count { get; set; }
        }


        private class SpecialistReportItem
        {
            public string SpecialistName { get; set; }

            public int AssignedCount { get; set; }

            public int InProgressCount { get; set; }

            public int WaitingCount { get; set; }

            public int ClosedCount { get; set; }
        }
    }
}