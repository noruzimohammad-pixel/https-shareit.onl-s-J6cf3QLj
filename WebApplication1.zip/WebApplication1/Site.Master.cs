﻿using System;
using System.Linq;
using System.Web;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;
using WebApplication1.Models;

namespace WebApplication1
{
    public partial class SiteMaster : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Context == null ||
                Context.User == null ||
                !Context.User.Identity.IsAuthenticated)
            {
                Response.Redirect("Login.aspx");
                return;
            }

            if (!IsPostBack)
            {
                LoadUserInformation();
                LoadMenu();
            }
            SetSpecialistSubmenuActive();
        }

        private void SetSpecialistSubmenuActive()
        {
            string currentPage =
                System.IO.Path.GetFileName(
                    Request.Url.AbsolutePath);

            if (currentPage != "SpecialistDashboard.aspx")
                return;

            string status =
                Request.QueryString["status"];

            if (string.IsNullOrEmpty(status))
                status = "All";


            lnkSpecialistAll.CssClass = "";
            lnkSpecialistAssigned.CssClass = "";
            lnkSpecialistInProgress.CssClass = "";
            lnkSpecialistWaiting.CssClass = "";
            lnkSpecialistClosed.CssClass = "";


            switch (status)
            {
                case "Assigned":

                    lnkSpecialistAssigned.CssClass =
                        "active";

                    break;


                case "InProgress":

                    lnkSpecialistInProgress.CssClass =
                        "active";

                    break;


                case "WaitingConfirmation":

                    lnkSpecialistWaiting.CssClass =
                        "active";

                    break;


                case "Closed":

                    lnkSpecialistClosed.CssClass =
                        "active";

                    break;


                default:

                    lnkSpecialistAll.CssClass =
                        "active";

                    break;
            }
        }
        private void LoadUserInformation()
        {
            string userId = Context.User.Identity.GetUserId();

            if (string.IsNullOrEmpty(userId))
                return;

            using (var db = new ApplicationDbContext())
            {
                var userManager = new UserManager<ApplicationUser>(
                    new UserStore<ApplicationUser>(db));

                var user = userManager.FindById(userId);

                if (user == null)
                    return;

                string fullName = user.UserName;

                var profile = db.UserProfiles.FirstOrDefault(
                    p => p.UserId == userId);

                if (profile != null &&
                    !string.IsNullOrEmpty(profile.FullName))
                {
                    fullName = profile.FullName;
                }

                lblUserName.Text = fullName;

                string roleText = "کاربر";

                if (userManager.IsInRole(userId, "Manager"))
                {
                    roleText = "مدیر سامانه";
                }
                else if (userManager.IsInRole(userId, "Specialist"))
                {
                    roleText = "کارشناس فناوری اطلاعات";
                }

                lblUserRole.Text = roleText;

                if (!string.IsNullOrEmpty(fullName))
                {
                    lblUserAvatar.Text =
                        fullName.Substring(0, 1).ToUpper();
                }
            }
        }

        private void LoadMenu()
        {
            string userId = Context.User.Identity.GetUserId();

            if (string.IsNullOrEmpty(userId))
                return;

            using (var db = new ApplicationDbContext())
            {
                var userManager = new UserManager<ApplicationUser>(
                    new UserStore<ApplicationUser>(db));

                bool isManager =
                    userManager.IsInRole(userId, "Manager");

                bool isSpecialist =
                    userManager.IsInRole(userId, "Specialist");

                phManagerMenu.Visible = isManager;

                phSpecialistMenu.Visible =
                    !isManager && isSpecialist;

                phUserMenu.Visible =
                    !isManager && !isSpecialist;
            }
        }

        protected void btnLogout_Click(object sender, EventArgs e)
        {
            HttpContextWrapper httpContext =
                new HttpContextWrapper(Context);

            var authenticationManager =
                httpContext.GetOwinContext().Authentication;

            authenticationManager.SignOut(
                DefaultAuthenticationTypes.ApplicationCookie);

            Response.Redirect("Login.aspx");
        }
    }
}