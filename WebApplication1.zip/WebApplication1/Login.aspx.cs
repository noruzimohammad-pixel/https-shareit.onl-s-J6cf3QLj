﻿using System;
using System.Web;
using Microsoft.AspNet.Identity;
using Microsoft.Owin.Security;
using WebApplication1.Models;

namespace WebApplication1
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            // فقط هنگام ورود اولیه به صفحه، پیام را مخفی کن
            if (!IsPostBack)
            {
                lblMessage.Visible = false;
                lblMessage.Text = "";
            }
        }


        // =========================================
        // نمایش پیام خطا
        // =========================================

        private void ShowError(string message)
        {
            lblMessage.Visible = true;
            lblMessage.CssClass = "message message-error";
            lblMessage.Text = message;
        }


        // =========================================
        // نمایش پیام هشدار
        // =========================================

        private void ShowWarning(string message)
        {
            lblMessage.Visible = true;
            lblMessage.CssClass = "message message-warning";
            lblMessage.Text = message;
        }


        // =========================================
        // نمایش پیام موفقیت
        // =========================================

        private void ShowSuccess(string message)
        {
            lblMessage.Visible = true;
            lblMessage.CssClass = "message message-success";
            lblMessage.Text = message;
        }


        // =========================================
        // ورود به سامانه
        // =========================================

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            string userName = txtUserName.Text.Trim();
            string password = txtPassword.Text;


            // -----------------------------------------
            // بررسی خالی نبودن اطلاعات
            // -----------------------------------------

            if (string.IsNullOrEmpty(userName) ||
                string.IsNullOrEmpty(password))
            {
                ShowWarning("لطفاً نام کاربری و رمز عبور را وارد کنید.");
                return;
            }


            using (var context = new ApplicationDbContext())
            {
                var userManager =
                    new Microsoft.AspNet.Identity.UserManager<ApplicationUser>(
                        new Microsoft.AspNet.Identity.EntityFramework.UserStore<ApplicationUser>(context));


                // -----------------------------------------
                // بررسی نام کاربری و رمز عبور
                // -----------------------------------------

                var user = userManager.Find(userName, password);


                if (user == null)
                {
                    ShowError("نام کاربری یا رمز عبور صحیح نیست.");
                    return;
                }


                // -----------------------------------------
                // ایجاد Identity
                // -----------------------------------------

                var identity = userManager.CreateIdentity(
                    user,
                    DefaultAuthenticationTypes.ApplicationCookie);


                // -----------------------------------------
                // ورود کاربر
                // -----------------------------------------

                var httpContext =
                    new HttpContextWrapper(Context);

                var authenticationManager =
                    httpContext.GetOwinContext().Authentication;


                authenticationManager.SignIn(
                    new Microsoft.Owin.Security.AuthenticationProperties
                    {
                        IsPersistent = false
                    },
                    identity);


                // -----------------------------------------
                // هدایت بر اساس نقش
                // -----------------------------------------

                if (userManager.IsInRole(user.Id, "Manager"))
                {
                    Response.Redirect("~/ManagerDashboard.aspx");
                }
                else if (userManager.IsInRole(user.Id, "Specialist"))
                {
                    Response.Redirect("~/SpecialistDashboard.aspx");
                }
                else
                {
                    Response.Redirect("~/UserDashboard.aspx");
                }
            }
        }
    }
}
