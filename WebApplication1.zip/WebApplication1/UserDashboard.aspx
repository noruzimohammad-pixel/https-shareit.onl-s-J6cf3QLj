﻿<%@ Page Title="داشبورد کاربر"
    Language="C#"
    MasterPageFile="~/Site.Master"
    AutoEventWireup="true"
    CodeBehind="UserDashboard.aspx.cs"
    Inherits="WebApplication1.UserDashboard" %>

<asp:Content ID="Content1"
    ContentPlaceHolderID="MainContent"
    runat="server">

    <style type="text/css">

        * {
            font-family: "vazirmatn", "B Nazanin", Tahoma, Arial;
        }

        .user-dashboard {
            direction: rtl;
            padding: 24px 26px;
        }


        /* =========================================
           Header
           ========================================= */

        .dashboard-header {
            margin-bottom: 22px;
        }

        .dashboard-title {
            margin: 0;
            font-size: 24px;
            font-weight: 700;
            color: #1f2937;
        }

        .dashboard-subtitle {
            margin-top: 7px;
            color: #6b7280;
            font-size: 14px;
        }


        /* =========================================
           Statistics
           ========================================= */

        .user-stats {
            display: grid;
            grid-template-columns: repeat(5, 1fr);
            gap: 14px;
            margin-bottom: 22px;
        }

        .user-stat-card {
            background: #ffffff;
            border-radius: 14px;
            padding: 20px 18px;
            box-shadow: 0 3px 14px rgba(0, 0, 0, 0.06);
            border: 1px solid #eef1f5;
            text-align: right;
        }

        .user-stat-title {
            color: #777f8c;
            font-size: 13px;
            margin-bottom: 10px;
        }

        .user-stat-number {
            color: #293548;
            font-size: 28px;
            font-weight: 700;
        }


        /* =========================================
           Main card
           ========================================= */

        .user-card {
            background: #ffffff;
            border-radius: 15px;
            padding: 20px;
            box-shadow: 0 3px 15px rgba(0, 0, 0, 0.06);
            border: 1px solid #eef1f5;
        }

        .user-card-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 18px;
        }

        .user-card-title {
            margin: 0;
            font-size: 17px;
            font-weight: 700;
            color: #293548;
        }


        /* =========================================
           New ticket button
           ========================================= */

        .btn-new-ticket {
            display: inline-block;
            padding: 9px 16px;
            border-radius: 7px;
            background: #4f46e5;
            color: #ffffff !important;
            text-decoration: none !important;
            font-size: 13px;
            font-weight: 600;
            border: none;
        }

        .btn-new-ticket:hover {
            background: #4338ca;
        }


        /* =========================================
           Table
           ========================================= */

        .ticket-table {
            width: 100%;
            border-collapse: collapse;
            direction: rtl;
            font-size: 13px;
        }

        .ticket-table th {
            background: #f7f8fa;
            color: #374151;
            font-weight: 700;
            padding: 11px 9px;
            border: 1px solid #e5e7eb;
            white-space: nowrap;
            text-align: center;
        }

        .ticket-table td {
            padding: 10px 9px;
            border: 1px solid #e5e7eb;
            color: #374151;
            text-align: center;
            vertical-align: middle;
        }

        .ticket-table tr:hover td {
            background: #fafbfc;
        }


        /* =========================================
           Request title
           ========================================= */

        .ticket-link {
            color: #245b89 !important;
            text-decoration: none !important;
            font-weight: 600;
        }

        .ticket-link:hover {
            color: #1d4b70 !important;
            text-decoration: underline !important;
        }


        .ticket-id {
            font-weight: 600;
            color: #4b5563;
        }


        /* =========================================
           View button
           ========================================= */

        .ticket-view-button {
            display: inline-block;
            min-width: 58px;
            padding: 6px 12px;
            background: #eef3f8;
            color: #2c5f8a !important;
            border: 1px solid #d5e0ea;
            border-radius: 5px;
            text-decoration: none !important;
            font-size: 12px;
            font-weight: 600;
            white-space: nowrap;
            text-align: center;
            box-sizing: border-box;
        }

        .ticket-view-button:hover {
            background: #2c5f8a;
            color: #ffffff !important;
            border-color: #2c5f8a;
            text-decoration: none !important;
        }


        /* =========================================
           Empty message
           ========================================= */

        .ticket-empty {
            padding: 30px;
            text-align: center;
            color: #8a93a1;
        }


        /* =========================================
           Paging
           ========================================= */

        .ticket-table .pager {
            background: #ffffff;
            text-align: center;
        }

        .ticket-table .pager td {
            padding: 16px 8px;
            border: none;
            background: #ffffff;
        }

        .ticket-table .pager a,
        .ticket-table .pager span {
            display: inline-block;
            min-width: 34px;
            padding: 7px 10px;
            margin: 0 3px;
            border-radius: 6px;
            border: 1px solid #d9e0e7;
            text-decoration: none;
            font-size: 12px;
            font-weight: 600;
            box-sizing: border-box;
        }

        .ticket-table .pager a {
            background: #ffffff;
            color: #2c5f8a;
        }

        .ticket-table .pager a:hover {
            background: #eef3f8;
            border-color: #b9c9d8;
        }

        .ticket-table .pager span {
            background: #2c5f8a;
            color: #ffffff;
            border-color: #2c5f8a;
        }


        /* =========================================
           Waiting confirmation alert
           ========================================= */

        .waiting-alert {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 15px;
            margin-bottom: 18px;
            padding: 14px 18px;
            background: #fff8e6;
            border: 1px solid #f2d58a;
            border-right: 4px solid #e5a900;
            border-radius: 10px;
            color: #6b5200;
        }

        .waiting-alert-content {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .waiting-alert-icon {
            width: 34px;
            height: 34px;
            border-radius: 50%;
            background: #f5c542;
            color: #ffffff;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 18px;
            font-weight: bold;
            flex-shrink: 0;
        }

        .waiting-alert-title {
            font-size: 14px;
            font-weight: 700;
            margin-bottom: 3px;
        }

        .waiting-alert-text {
            font-size: 12px;
            color: #806a20;
        }

        .btn-alert-view {
            display: inline-block;
            padding: 7px 14px;
            background: #e5a900;
            color: #ffffff !important;
            border-radius: 6px;
            text-decoration: none !important;
            font-size: 12px;
            font-weight: 600;
            white-space: nowrap;
        }

        .btn-alert-view:hover {
            background: #c99100;
            color: #ffffff !important;
        }


        /* =========================================
           Responsive
           ========================================= */

        @media screen and (max-width: 1100px) {

            .user-stats {
                grid-template-columns: repeat(3, 1fr);
            }

        }


        @media screen and (max-width: 700px) {

            .user-dashboard {
                padding: 15px;
            }

            .user-stats {
                grid-template-columns: repeat(2, 1fr);
            }

            .user-card {
                overflow-x: auto;
            }

            .ticket-table {
                min-width: 850px;
            }

            .user-card-header {
                flex-direction: column;
                align-items: flex-start;
                gap: 12px;
            }

            .waiting-alert {
                flex-direction: column;
                align-items: stretch;
            }

            .btn-alert-view {
                text-align: center;
            }

        }

    </style>


    <div class="user-dashboard">


        <!-- =========================================
             Header
             ========================================= -->

        <div class="dashboard-header">

            <h1 class="dashboard-title">
                داشبورد کاربر
            </h1>

            <div class="dashboard-subtitle">
                پیگیری درخواست‌های پشتیبانی فناوری اطلاعات
            </div>

        </div>


        <!-- =========================================
             Statistics
             ========================================= -->

        <div class="user-stats">


            <div class="user-stat-card">

                <div class="user-stat-title">
                    کل درخواست‌ها
                </div>

                <div class="user-stat-number">

                    <asp:Label
                        ID="lblTotalCount"
                        runat="server"
                        Text="0" />

                </div>

            </div>


            <div class="user-stat-card">

                <div class="user-stat-title">
                    جدید
                </div>

                <div class="user-stat-number">

                    <asp:Label
                        ID="lblNewCount"
                        runat="server"
                        Text="0" />

                </div>

            </div>


            <div class="user-stat-card">

                <div class="user-stat-title">
                    در حال رسیدگی
                </div>

                <div class="user-stat-number">

                    <asp:Label
                        ID="lblInProgressCount"
                        runat="server"
                        Text="0" />

                </div>

            </div>


            <div class="user-stat-card">

                <div class="user-stat-title">
                    منتظر تأیید
                </div>

                <div class="user-stat-number">

                    <asp:Label
                        ID="lblWaitingCount"
                        runat="server"
                        Text="0" />

                </div>

            </div>


            <div class="user-stat-card">

                <div class="user-stat-title">
                    خاتمه‌یافته
                </div>

                <div class="user-stat-number">

                    <asp:Label
                        ID="lblClosedCount"
                        runat="server"
                        Text="0" />

                </div>

            </div>


        </div>


        <!-- =========================================
             Waiting confirmation alert
             ========================================= -->

        <asp:Panel
            ID="pnlWaitingAlert"
            runat="server"
            CssClass="waiting-alert"
            Visible="false">


            <div class="waiting-alert-content">


                <div class="waiting-alert-icon">
                    !
                </div>


                <div>

                    <div class="waiting-alert-title">
                        درخواست منتظر تأیید شماست
                    </div>

                    <div class="waiting-alert-text">

                        <asp:Label
                            ID="lblWaitingAlert"
                            runat="server" />

                    </div>

                </div>


            </div>


            <asp:HyperLink
                ID="lnkWaitingTickets"
                runat="server"
                NavigateUrl="~/UserTickets.aspx"
                CssClass="btn-alert-view">

                مشاهده درخواست‌ها

            </asp:HyperLink>


        </asp:Panel>


        <!-- =========================================
             My Tickets
             ========================================= -->

        <div class="user-card">


            <div class="user-card-header">

                <h2 class="user-card-title">
                    درخواست‌های من
                </h2>


                <asp:HyperLink
                    ID="lnkCreateTicket"
                    runat="server"
                    NavigateUrl="~/CreateTicket.aspx"
                    CssClass="btn-new-ticket">

                    + ثبت درخواست جدید

                </asp:HyperLink>


            </div>


            <asp:GridView
                ID="gvTickets"
                runat="server"
                AutoGenerateColumns="False"
                CssClass="ticket-table"
                GridLines="Both"
                EmptyDataText="درخواستی برای نمایش وجود ندارد."
                AllowPaging="true"
                PageSize="10"
                OnPageIndexChanging="gvTickets_PageIndexChanging">

                <PagerSettings
                    Mode="NumericFirstLast"
                    FirstPageText="اولین"
                    LastPageText="آخرین"
                    PreviousPageText="قبلی"
                    NextPageText="بعدی"
                    Position="Bottom" />

                <PagerStyle
                    CssClass="pager"
                    HorizontalAlign="Center" />


                <Columns>


                    <asp:BoundField
                        DataField="TicketId"
                        HeaderText="شماره درخواست"
                        ItemStyle-CssClass="ticket-id" />


                    <asp:TemplateField
                        HeaderText="عنوان درخواست">

                        <ItemTemplate>

                            <asp:HyperLink
                                ID="lnkSubject"
                                runat="server"
                                Text='<%# Eval("Subject") %>'
                                NavigateUrl='<%# "UserTicketDetails.aspx?id=" + Eval("TicketId") %>'
                                CssClass="ticket-link">

                            </asp:HyperLink>

                        </ItemTemplate>

                    </asp:TemplateField>


                    <asp:BoundField
                        DataField="Category"
                        HeaderText="دسته‌بندی" />


                    <asp:BoundField
                        DataField="PriorityText"
                        HeaderText="اولویت" />


                    <asp:BoundField
                        DataField="StatusText"
                        HeaderText="وضعیت" />


                    <asp:BoundField
                        DataField="CreatedAtText"
                        HeaderText="تاریخ ثبت" />


                    <asp:TemplateField
                        HeaderText="مشاهده">

                        <ItemTemplate>

                            <asp:HyperLink
                                ID="lnkView"
                                runat="server"
                                Text="مشاهده"
                                NavigateUrl='<%# "UserTicketDetails.aspx?id=" + Eval("TicketId") %>'
                                CssClass="ticket-view-button">

                            </asp:HyperLink>

                        </ItemTemplate>

                        <ItemStyle
                            HorizontalAlign="Center" />

                    </asp:TemplateField>


                </Columns>

            </asp:GridView>


        </div>


    </div>

</asp:Content>