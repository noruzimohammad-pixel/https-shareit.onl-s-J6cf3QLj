﻿<%@ Page Title="مدیریت موضوعات خدمات"
    Language="C#"
    MasterPageFile="~/Site.Master"
    AutoEventWireup="true"
    CodeBehind="ServiceTopics.aspx.cs"
    Inherits="WebApplication1.ServiceTopics" %>

<asp:Content ID="Content1"
    ContentPlaceHolderID="TitleContent"
    runat="server">
    مدیریت موضوعات خدمات
</asp:Content>

<asp:Content ID="Content2"
    ContentPlaceHolderID="HeadContent"
    runat="server">

    <style type="text/css">

        .service-topic-page {
            direction: rtl;
            font-family: Vazirmatn, Tahoma, Arial, sans-serif;
        }

        .service-topic-intro {
            background: linear-gradient(135deg, #1976d2, #1565c0);
            color: #fff;
            border-radius: 16px;
            padding: 22px 24px;
            margin-bottom: 20px;
            box-shadow: 0 8px 25px rgba(25,118,210,.15);
        }

        .service-topic-intro h2 {
            margin: 0 0 7px 0;
            font-size: 21px;
            font-weight: 700;
        }

        .service-topic-intro p {
            margin: 0;
            font-size: 13px;
            opacity: .9;
            line-height: 1.9;
        }

        .topic-layout {
            display: grid;
            grid-template-columns: minmax(250px, 330px) minmax(0, 1fr);
            gap: 20px;
            align-items: start;
        }

        .topic-card {
            background: #fff;
            border-radius: 14px;
            box-shadow: 0 3px 16px rgba(0,0,0,.06);
            overflow: hidden;
        }

        .topic-card-header {
            padding: 18px 20px;
            border-bottom: 1px solid #edf0f3;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 12px;
        }

        .topic-card-title {
            margin: 0;
            font-size: 16px;
            font-weight: 700;
            color: #263238;
        }

        .topic-card-subtitle {
            margin: 5px 0 0 0;
            color: #8a949e;
            font-size: 11px;
        }

        .topic-card-body {
            padding: 20px;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-label {
            display: block;
            margin-bottom: 7px;
            font-size: 12px;
            color: #455a64;
            font-weight: 600;
        }

        .form-control {
            width: 100%;
            box-sizing: border-box;
            border: 1px solid #dce2e7;
            border-radius: 8px;
            padding: 10px 12px;
            min-height: 42px;
            font-family: Vazirmatn, Tahoma, Arial, sans-serif;
            font-size: 13px;
            color: #263238;
            background: #fff;
            outline: none;
            transition: all .2s ease;
        }

        textarea.form-control {
            min-height: 95px;
            resize: vertical;
        }

        select.form-control {
            cursor: pointer;
        }

        .form-control:focus {
            border-color: #1976d2;
            box-shadow: 0 0 0 3px rgba(25,118,210,.08);
        }

        .form-check {
            display: flex;
            align-items: center;
            gap: 8px;
            margin-top: 4px;
            color: #455a64;
            font-size: 12px;
        }

        .form-check input {
            width: 17px;
            height: 17px;
        }

        .button-row {
            display: flex;
            gap: 8px;
            flex-wrap: wrap;
            margin-top: 18px;
        }

        .btn-service {
            border: 0;
            border-radius: 8px;
            padding: 10px 16px;
            min-height: 40px;
            font-family: Vazirmatn, Tahoma, Arial, sans-serif;
            font-size: 12px;
            cursor: pointer;
            transition: all .2s ease;
        }

        .btn-service:hover {
            transform: translateY(-1px);
        }

        .btn-primary-service {
            background: #1976d2;
            color: #fff;
        }

        .btn-primary-service:hover {
            background: #1565c0;
        }

        .btn-secondary-service {
            background: #eef1f4;
            color: #455a64;
        }

        .btn-secondary-service:hover {
            background: #e2e6ea;
        }

        .btn-status-service {
            background: #fff8e1;
            color: #ef6c00;
        }

        .category-box {
            background: #f8fafc;
            border: 1px solid #e7ebef;
            border-radius: 10px;
            padding: 15px;
        }

        .category-box-title {
            font-size: 12px;
            color: #78909c;
            margin-bottom: 7px;
        }

        .category-box-name {
            font-size: 15px;
            font-weight: 700;
            color: #1976d2;
        }

        .category-box-description {
            margin-top: 5px;
            font-size: 11px;
            color: #8a949e;
            line-height: 1.8;
        }

        .edit-box {
            background: #f8fafc;
            border: 1px solid #e7ebef;
            border-radius: 10px;
            padding: 15px;
            margin-bottom: 18px;
        }

        .edit-box-title {
            font-size: 13px;
            font-weight: 700;
            color: #37474f;
            margin-bottom: 13px;
        }

        .message-service {
            display: block;
            margin-bottom: 15px;
            padding: 10px 12px;
            border-radius: 8px;
            font-size: 12px;
            line-height: 1.8;
        }

        .message-success {
            background: #e8f5e9;
            color: #2e7d32;
        }

        .message-error {
            background: #ffebee;
            color: #c62828;
        }

        .message-info {
            background: #e3f2fd;
            color: #1565c0;
        }

        .topic-list {
            display: flex;
            flex-direction: column;
        }

        .topic-item {
            padding: 15px 0;
            border-bottom: 1px solid #edf0f3;
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 15px;
        }

        .topic-item:last-child {
            border-bottom: none;
        }

        .topic-item:hover {
            background: #fafbfd;
        }

        .topic-info {
            min-width: 0;
        }

        .topic-name {
            font-size: 13px;
            color: #263238;
            font-weight: 600;
        }

        .topic-description {
            color: #8a949e;
            font-size: 11px;
            margin-top: 4px;
            line-height: 1.7;
        }

        .topic-meta {
            margin-top: 8px;
            display: flex;
            align-items: center;
            gap: 7px;
            flex-wrap: wrap;
        }

        .badge-service {
            display: inline-flex;
            align-items: center;
            padding: 3px 8px;
            border-radius: 20px;
            font-size: 10px;
            white-space: nowrap;
        }

        .badge-active {
            background: #e8f5e9;
            color: #2e7d32;
        }

        .badge-inactive {
            background: #f5f5f5;
            color: #757575;
        }

        .badge-order {
            background: #eef1f4;
            color: #546e7a;
        }

        .topic-actions {
            display: flex;
            align-items: center;
            gap: 6px;
            flex-shrink: 0;
        }

        .mini-btn {
            border: 0;
            border-radius: 6px;
            padding: 6px 10px;
            font-family: Vazirmatn, Tahoma, Arial, sans-serif;
            font-size: 10px;
            cursor: pointer;
        }

        .mini-edit {
            background: #e3f2fd;
            color: #1565c0;
        }

        .mini-status {
            background: #fff8e1;
            color: #ef6c00;
        }

        .topic-empty {
            padding: 45px 15px;
            text-align: center;
            color: #9aa3aa;
            font-size: 12px;
        }

        .category-list {
            display: flex;
            flex-direction: column;
        }

        .category-item {
            border-bottom: 1px solid #edf0f3;
            padding: 13px 12px;
            cursor: pointer;
            transition: all .2s ease;
            text-decoration: none !important;
            display: block;
        }

        .category-item:last-child {
            border-bottom: none;
        }

        .category-item:hover {
            background: #f8fafc;
        }

        .category-item-selected {
            background: #eef6ff;
            border-right: 4px solid #1976d2;
            padding-right: 8px;
        }

        .category-name {
            font-size: 12px;
            font-weight: 700;
            color: #263238;
        }

        .category-description {
            color: #8a949e;
            font-size: 10px;
            line-height: 1.7;
            margin-top: 3px;
        }

        .category-meta {
            margin-top: 7px;
            display: flex;
            gap: 6px;
            flex-wrap: wrap;
        }

        .search-box {
            margin-bottom: 15px;
        }

        .search-box .form-control {
            min-height: 40px;
        }

        .no-category {
            padding: 40px 15px;
            text-align: center;
            color: #9aa3aa;
            font-size: 12px;
            line-height: 2;
        }

        @media (max-width: 900px) {

            .topic-layout {
                grid-template-columns: 1fr;
            }

            .topic-card-body {
                padding: 16px;
            }

            .service-topic-intro {
                padding: 18px;
            }

            .service-topic-intro h2 {
                font-size: 18px;
            }
        }

        @media (max-width: 600px) {

            .topic-card-header {
                padding: 15px;
                align-items: flex-start;
            }

            .topic-card-body {
                padding: 13px;
            }

            .topic-item {
                flex-direction: column;
                align-items: flex-start;
            }

            .topic-actions {
                width: 100%;
            }

            .topic-actions .mini-btn {
                flex: 1;
            }

            .button-row {
                flex-direction: column;
            }

            .btn-service {
                width: 100%;
            }

            .service-topic-intro {
                border-radius: 10px;
            }
        }

    </style>

</asp:Content>

<asp:Content ID="Content3"
    ContentPlaceHolderID="PageHeader"
    runat="server">

    مدیریت موضوعات خدمات

</asp:Content>

<asp:Content ID="Content4"
    ContentPlaceHolderID="MainContent"
    runat="server">

    <div class="service-topic-page">

        <div class="service-topic-intro">

            <h2>
                مدیریت موضوعات خدمات فناوری اطلاعات
            </h2>

            <p>
                در این بخش موضوعات تخصصی هر حوزه خدمات را تعریف و مدیریت می‌کنید.
                موضوع انتخاب‌شده توسط کارشناس در زمان تشخیص مشکل، به درخواست متصل خواهد شد.
            </p>

        </div>

        <asp:Label
            ID="lblMessage"
            runat="server"
            Visible="false"
            CssClass="message-service">
        </asp:Label>

        <div class="topic-layout">

            <!-- ستون حوزه‌ها -->

            <div class="topic-card">

                <div class="topic-card-header">

                    <div>
                        <h3 class="topic-card-title">
                            حوزه‌های خدمات
                        </h3>

                        <p class="topic-card-subtitle">
                            برای مشاهده موضوعات انتخاب کنید
                        </p>
                    </div>

                </div>

                <div class="topic-card-body">

                    <div class="search-box">

                        <asp:TextBox
                            ID="txtCategorySearch"
                            runat="server"
                            CssClass="form-control"
                            MaxLength="100"
                            AutoPostBack="true"
                            OnTextChanged="txtCategorySearch_TextChanged"
                            placeholder="جستجوی حوزه...">
                        </asp:TextBox>

                    </div>

                    <div class="category-list">

                        <asp:Repeater
                            ID="rptCategories"
                            runat="server"
                            OnItemCommand="rptCategories_ItemCommand">

                            <ItemTemplate>

                                <asp:LinkButton
                                    ID="btnSelectCategory"
                                    runat="server"
                                    CommandName="SelectCategory"
                                    CommandArgument='<%# Eval("ServiceCategoryId") %>'
                                    CausesValidation="false"
                                    CssClass='<%# GetCategoryCss(Eval("ServiceCategoryId")) %>'>

                                    <div class="category-name">
                                        <%# Eval("CategoryName") %>
                                    </div>

                                    <div class="category-description">
                                        <%# Eval("Description") %>
                                    </div>

                                    <div class="category-meta">

                                        <span class='<%# GetActiveBadgeCss(Eval("IsActive")) %>'>
                                            <%# GetActiveText(Eval("IsActive")) %>
                                        </span>

                                        <span class="badge-service badge-order">
                                            <%# Eval("TopicCount") %> موضوع
                                        </span>

                                    </div>

                                </asp:LinkButton>

                            </ItemTemplate>

                        </asp:Repeater>

                        <asp:Label
                            ID="lblNoCategories"
                            runat="server"
                            Visible="false"
                            CssClass="topic-empty">

                            حوزه‌ای برای نمایش وجود ندارد.

                        </asp:Label>

                    </div>

                </div>

            </div>


            <!-- ستون موضوعات -->

            <div class="topic-card">

                <div class="topic-card-header">

                    <div>

                        <h3 class="topic-card-title">
                            موضوعات حوزه
                        </h3>

                        <p class="topic-card-subtitle">
                            موضوعات قابل انتخاب برای درخواست‌های این حوزه
                        </p>

                    </div>

                    <asp:Button
                        ID="btnNewTopic"
                        runat="server"
                        Text="+ موضوع جدید"
                        CssClass="btn-service btn-primary-service"
                        CausesValidation="false"
                        OnClick="btnNewTopic_Click" />

                </div>

                <div class="topic-card-body">

                    <asp:Panel
                        ID="pnlSelectedCategory"
                        runat="server"
                        Visible="false">

                        <div class="category-box">

                            <div class="category-box-title">
                                حوزه انتخاب‌شده
                            </div>

                            <asp:Label
                                ID="lblSelectedCategoryName"
                                runat="server"
                                CssClass="category-box-name">
                            </asp:Label>

                            <asp:Label
                                ID="lblSelectedCategoryDescription"
                                runat="server"
                                CssClass="category-box-description">
                            </asp:Label>

                        </div>

                    </asp:Panel>


                    <asp:Panel
                        ID="pnlTopicEdit"
                        runat="server"
                        Visible="false"
                        CssClass="edit-box">

                        <div class="edit-box-title">

                            <asp:Label
                                ID="lblTopicEditTitle"
                                runat="server"
                                Text="افزودن موضوع جدید">
                            </asp:Label>

                        </div>

                        <div class="form-group">

                            <label class="form-label">
                                حوزه خدمت
                            </label>

                            <asp:DropDownList
                                ID="ddlTopicCategory"
                                runat="server"
                                CssClass="form-control">
                            </asp:DropDownList>

                        </div>

                        <div class="form-group">

                            <label class="form-label">
                                نام موضوع
                            </label>

                            <asp:TextBox
                                ID="txtTopicName"
                                runat="server"
                                CssClass="form-control"
                                MaxLength="150">
                            </asp:TextBox>

                        </div>

                        <div class="form-group">

                            <label class="form-label">
                                توضیحات
                            </label>

                            <asp:TextBox
                                ID="txtTopicDescription"
                                runat="server"
                                CssClass="form-control"
                                TextMode="MultiLine"
                                MaxLength="500">
                            </asp:TextBox>

                        </div>

                        <div class="form-group">

                            <label class="form-label">
                                ترتیب نمایش
                            </label>

                            <asp:TextBox
                                ID="txtDisplayOrder"
                                runat="server"
                                CssClass="form-control"
                                MaxLength="5"
                                Text="0">
                            </asp:TextBox>

                        </div>

                        <div class="form-check">

                            <asp:CheckBox
                                ID="chkTopicActive"
                                runat="server"
                                Checked="true" />

                            <span>
                                موضوع فعال باشد
                            </span>

                        </div>

                        <div class="button-row">

                            <asp:Button
                                ID="btnSaveTopic"
                                runat="server"
                                Text="ثبت اطلاعات"
                                CssClass="btn-service btn-primary-service"
                                OnClick="btnSaveTopic_Click" />

                            <asp:Button
                                ID="btnCancelTopic"
                                runat="server"
                                Text="انصراف"
                                CssClass="btn-service btn-secondary-service"
                                CausesValidation="false"
                                OnClick="btnCancelTopic_Click" />

                        </div>

                    </asp:Panel>


                    <asp:Panel
                        ID="pnlNoCategorySelected"
                        runat="server"
                        Visible="true">

                        <div class="no-category">
                            ابتدا یک حوزه از فهرست سمت راست انتخاب کنید.
                        </div>

                    </asp:Panel>


                    <div class="topic-list">

                        <asp:Repeater
                            ID="rptTopics"
                            runat="server"
                            OnItemCommand="rptTopics_ItemCommand">

                            <ItemTemplate>

                                <div class="topic-item">

                                    <div class="topic-info">

                                        <div class="topic-name">
                                            <%# Eval("TopicName") %>
                                        </div>

                                        <div class="topic-description">
                                            <%# Eval("Description") %>
                                        </div>

                                        <div class="topic-meta">

                                            <span class='<%# GetActiveBadgeCss(Eval("IsActive")) %>'>
                                                <%# GetActiveText(Eval("IsActive")) %>
                                            </span>

                                            <span class="badge-service badge-order">
                                                ترتیب: <%# Eval("DisplayOrder") %>
                                            </span>

                                        </div>

                                    </div>

                                    <div class="topic-actions">

                                        <asp:Button
                                            ID="btnEditTopic"
                                            runat="server"
                                            Text="ویرایش"
                                            CssClass="mini-btn mini-edit"
                                            CommandName="EditTopic"
                                            CommandArgument='<%# Eval("ServiceTopicId") %>'
                                            CausesValidation="false" />

                                        <asp:Button
                                            ID="btnToggleTopic"
                                            runat="server"
                                            Text='<%# GetToggleText(Eval("IsActive")) %>'
                                            CssClass="mini-btn mini-status"
                                            CommandName="ToggleTopic"
                                            CommandArgument='<%# Eval("ServiceTopicId") %>'
                                            CausesValidation="false" />

                                    </div>

                                </div>

                            </ItemTemplate>

                        </asp:Repeater>

                    </div>

                    <asp:Label
                        ID="lblNoTopics"
                        runat="server"
                        Visible="false"
                        CssClass="topic-empty">

                        برای این حوزه هنوز موضوعی ثبت نشده است.

                    </asp:Label>

                </div>

            </div>

        </div>

    </div>

</asp:Content>