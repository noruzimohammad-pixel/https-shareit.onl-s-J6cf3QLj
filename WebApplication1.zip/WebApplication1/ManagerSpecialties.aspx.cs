﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.UI.WebControls;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;
using WebApplication1.Models;

namespace WebApplication1
{
    public partial class ManagerSpecialties : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Request.IsAuthenticated)
            {
                Response.Redirect("~/Login.aspx");
                return;
            }

            if (!User.IsInRole("Manager"))
            {
                Response.Redirect("~/UserDashboard.aspx");
                return;
            }

            if (!IsPostBack)
            {
                LoadDepartments();
                LoadSpecialties();
                LoadSpecialtyTitles();
                LoadSpecialistsGrid();

                pnlEdit.Visible = false;
            }
        }


        // =========================================================
        // بارگذاری واحدها
        // =========================================================

        private void LoadDepartments()
        {
            using (var db = new ApplicationDbContext())
            {
                var list = db.Departments
                    .Where(x => x.IsActive)
                    .OrderBy(x => x.DepartmentName)
                    .ToList();

                ddlEditDepartment.Items.Clear();

                ddlEditDepartment.Items.Add(
                    new ListItem(
                        "انتخاب واحد سازمانی",
                        ""));

                foreach (var item in list)
                {
                    ddlEditDepartment.Items.Add(
                        new ListItem(
                            item.DepartmentName,
                            item.DepartmentId.ToString()));
                }
            }
        }


        // =========================================================
        // مدیریت عناوین تخصص‌ها
        // =========================================================

        private void LoadSpecialtyTitles()
        {
            string search =
                (txtSpecialtyTitleSearch.Text ?? "").Trim();

            using (var db = new ApplicationDbContext())
            {
                var query = db.Specialties.AsQueryable();

                if (!string.IsNullOrEmpty(search))
                {
                    query = query.Where(x =>
                        x.SpecialtyName.Contains(search) ||
                        x.Description.Contains(search));
                }

                var rows = query
                    .OrderBy(x => x.SpecialtyName)
                    .Select(x => new
                    {
                        x.SpecialtyId,
                        x.SpecialtyName,
                        x.Description,
                        x.IsActive,
                        SpecialistCount = db.SpecialistSpecialties.Count(ss =>
                            ss.SpecialtyId == x.SpecialtyId)
                    })
                    .ToList();

                gvSpecialtyTitles.DataSource = rows;
                gvSpecialtyTitles.DataBind();
            }
        }

        protected void txtSpecialtyTitleSearch_TextChanged(
            object sender,
            EventArgs e)
        {
            LoadSpecialtyTitles();
        }

        protected void btnNewSpecialtyTitle_Click(
            object sender,
            EventArgs e)
        {
            ClearSpecialtyTitleForm();
            pnlSpecialtyTitleEdit.Visible = true;
            btnSaveSpecialtyTitle.Text = "✓ ثبت تخصص";
            ShowSpecialtyInfo("عنوان تخصص جدید را وارد کنید.");
        }

        protected void btnCancelSpecialtyTitle_Click(
            object sender,
            EventArgs e)
        {
            ClearSpecialtyTitleForm();
            pnlSpecialtyTitleEdit.Visible = false;
            lblSpecialtyTitleMessage.Visible = false;
        }

        protected void gvSpecialtyTitles_RowCommand(
            object sender,
            GridViewCommandEventArgs e)
        {
            int specialtyId;

            if (!int.TryParse(
                Convert.ToString(e.CommandArgument),
                out specialtyId))
                return;

            if (e.CommandName == "EditSpecialtyTitle")
            {
                EditSpecialtyTitle(specialtyId);
            }
            else if (e.CommandName == "ToggleSpecialtyTitle")
            {
                ToggleSpecialtyTitle(specialtyId);
            }
        }

        private void EditSpecialtyTitle(int specialtyId)
        {
            using (var db = new ApplicationDbContext())
            {
                var specialty = db.Specialties.FirstOrDefault(
                    x => x.SpecialtyId == specialtyId);

                if (specialty == null)
                {
                    ShowSpecialtyError("تخصص موردنظر پیدا نشد.");
                    return;
                }

                hfSpecialtyTitleEditId.Value =
                    specialty.SpecialtyId.ToString();

                txtSpecialtyTitleName.Text =
                    specialty.SpecialtyName;

                txtSpecialtyTitleDescription.Text =
                    specialty.Description ?? "";

                chkSpecialtyTitleActive.Checked =
                    specialty.IsActive;

                pnlSpecialtyTitleEdit.Visible = true;
                btnSaveSpecialtyTitle.Text = "✓ ذخیره ویرایش";
                ShowSpecialtyInfo(
                    "تخصص انتخاب‌شده برای ویرایش آماده است.");
            }
        }

        private void ToggleSpecialtyTitle(int specialtyId)
        {
            using (var db = new ApplicationDbContext())
            {
                var specialty = db.Specialties.FirstOrDefault(
                    x => x.SpecialtyId == specialtyId);

                if (specialty == null)
                {
                    ShowSpecialtyError("تخصص موردنظر پیدا نشد.");
                    return;
                }

                specialty.IsActive = !specialty.IsActive;
                db.SaveChanges();

                ShowSpecialtySuccess(
                    specialty.IsActive
                        ? "تخصص فعال شد."
                        : "تخصص غیرفعال شد.");

                LoadSpecialtyTitles();
                LoadSpecialties();
            }
        }

        protected void btnSaveSpecialtyTitle_Click(
            object sender,
            EventArgs e)
        {
            string name =
                (txtSpecialtyTitleName.Text ?? "").Trim();

            string description =
                (txtSpecialtyTitleDescription.Text ?? "").Trim();

            int editId = 0;
            int.TryParse(
                hfSpecialtyTitleEditId.Value,
                out editId);

            if (string.IsNullOrEmpty(name))
            {
                ShowSpecialtyError(
                    "لطفاً عنوان تخصص را وارد کنید.");
                return;
            }

            if (name.Length > 100)
            {
                ShowSpecialtyError(
                    "عنوان تخصص نمی‌تواند بیشتر از 100 کاراکتر باشد.");
                return;
            }

            if (description.Length > 500)
            {
                ShowSpecialtyError(
                    "توضیحات نمی‌تواند بیشتر از 500 کاراکتر باشد.");
                return;
            }

            using (var db = new ApplicationDbContext())
            {
                bool duplicate = db.Specialties.Any(
                    x => x.SpecialtyName == name &&
                         x.SpecialtyId != editId);

                if (duplicate)
                {
                    ShowSpecialtyError(
                        "تخصصی با این عنوان قبلاً ثبت شده است.");
                    return;
                }

                if (editId > 0)
                {
                    var specialty = db.Specialties.FirstOrDefault(
                        x => x.SpecialtyId == editId);

                    if (specialty == null)
                    {
                        ShowSpecialtyError(
                            "تخصص موردنظر برای ویرایش پیدا نشد.");
                        return;
                    }

                    specialty.SpecialtyName = name;
                    specialty.Description =
                        string.IsNullOrEmpty(description)
                            ? null
                            : description;
                    specialty.IsActive =
                        chkSpecialtyTitleActive.Checked;

                    db.SaveChanges();

                    ShowSpecialtySuccess(
                        "اطلاعات تخصص با موفقیت ویرایش شد.");
                }
                else
                {
                    db.Specialties.Add(
                        new Specialty
                        {
                            SpecialtyName = name,
                            Description =
                                string.IsNullOrEmpty(description)
                                    ? null
                                    : description,
                            IsActive =
                                chkSpecialtyTitleActive.Checked
                        });

                    db.SaveChanges();

                    ShowSpecialtySuccess(
                        "تخصص جدید با موفقیت ثبت شد.");
                }
            }

            ClearSpecialtyTitleForm();
            pnlSpecialtyTitleEdit.Visible = false;
            LoadSpecialtyTitles();
            LoadSpecialties();
        }

        private void ClearSpecialtyTitleForm()
        {
            hfSpecialtyTitleEditId.Value = "0";
            txtSpecialtyTitleName.Text = "";
            txtSpecialtyTitleDescription.Text = "";
            chkSpecialtyTitleActive.Checked = true;
            btnSaveSpecialtyTitle.Text = "✓ ثبت تخصص";
        }

        private void ShowSpecialtySuccess(string message)
        {
            lblSpecialtyTitleMessage.Text = message;
            lblSpecialtyTitleMessage.CssClass =
                "mk-message mk-success";
            lblSpecialtyTitleMessage.Visible = true;
        }

        private void ShowSpecialtyError(string message)
        {
            lblSpecialtyTitleMessage.Text = message;
            lblSpecialtyTitleMessage.CssClass =
                "mk-message mk-error";
            lblSpecialtyTitleMessage.Visible = true;
        }

        private void ShowSpecialtyInfo(string message)
        {
            lblSpecialtyTitleMessage.Text = message;
            lblSpecialtyTitleMessage.CssClass =
                "mk-message mk-info";
            lblSpecialtyTitleMessage.Visible = true;
        }


        // =========================================================
        // بارگذاری تخصص‌ها
        // =========================================================

        private void LoadSpecialties()
        {
            using (var db = new ApplicationDbContext())
            {
                var list = db.Specialties
                    .Where(x => x.IsActive)
                    .OrderBy(x => x.SpecialtyName)
                    .ToList();

                ddlAddSpecialty.Items.Clear();

                ddlAddSpecialty.Items.Add(
                    new ListItem(
                        "انتخاب تخصص برای افزودن",
                        ""));

                foreach (var item in list)
                {
                    ddlAddSpecialty.Items.Add(
                        new ListItem(
                            item.SpecialtyName,
                            item.SpecialtyId.ToString()));
                }
            }
        }


        // =========================================================
        // جستجوی کارشناسان
        // =========================================================

        protected void txtSearch_TextChanged(
            object sender,
            EventArgs e)
        {
            LoadSpecialistsGrid();
        }


        // =========================================================
        // دریافت شناسه کاربران دارای نقش Specialist
        // =========================================================

        private List<string> GetSpecialistIds(
            ApplicationDbContext db)
        {
            var role =
                db.Roles.FirstOrDefault(
                    x => x.Name == "Specialist");

            if (role == null)
                return new List<string>();

            return db.Set<IdentityUserRole>()
                .Where(x => x.RoleId == role.Id)
                .Select(x => x.UserId)
                .ToList();
        }


        // =========================================================
        // بارگذاری جدول کارشناسان
        // =========================================================

        private void LoadSpecialistsGrid()
        {
            using (var db = new ApplicationDbContext())
            {
                var ids = GetSpecialistIds(db);

                string search =
                    (txtSearch.Text ?? "").Trim();


                var query =
                    from u in db.Users

                    join p in db.UserProfiles
                        on u.Id equals p.UserId

                    join d0 in db.Departments
                        on p.DepartmentId
                        equals d0.DepartmentId
                        into dj

                    from d in dj.DefaultIfEmpty()

                    where ids.Contains(u.Id)

                    select new
                    {
                        UserId = u.Id,

                        FullName = p.FullName,

                        UserName = u.UserName,

                        DepartmentName =
                            d != null
                                ? d.DepartmentName
                                : "",

                        IsActive = p.IsActive
                    };


                if (!string.IsNullOrEmpty(search))
                {
                    query = query.Where(x =>
                        x.FullName.Contains(search) ||
                        x.UserName.Contains(search) ||
                        x.DepartmentName.Contains(search));
                }


                var baseList =
                    query
                    .OrderBy(x => x.FullName)
                    .ToList();


                var rows =
                    baseList.Select(x => new
                    {
                        x.UserId,
                        x.FullName,
                        x.UserName,
                        x.DepartmentName,
                        x.IsActive,

                        SpecialtyRows =
                            (
                                from ss in db.SpecialistSpecialties

                                join s in db.Specialties
                                    on ss.SpecialtyId
                                    equals s.SpecialtyId

                                where ss.UserId == x.UserId

                                orderby s.SpecialtyName

                                select new
                                {
                                    s.SpecialtyId,
                                    s.SpecialtyName
                                }
                            ).ToList(),

                        Specialties =
                            string.Join(
                                "، ",
                                (
                                    from ss in db.SpecialistSpecialties

                                    join s in db.Specialties
                                        on ss.SpecialtyId
                                        equals s.SpecialtyId

                                    where ss.UserId == x.UserId

                                    orderby s.SpecialtyName

                                    select s.SpecialtyName
                                ).ToList())
                    })
                    .ToList();


                gvSpecialists.DataSource = rows;

                gvSpecialists.DataBind();
            }
        }


        // =========================================================
        // کلیک روی عملیات جدول
        // =========================================================

        protected void gvSpecialists_RowCommand(
            object sender,
            GridViewCommandEventArgs e)
        {
            string userId =
                Convert.ToString(e.CommandArgument);


            if (e.CommandName == "EditSpecialist")
            {
                LoadSpecialistForEdit(userId);
            }
            else if (e.CommandName == "ToggleActive")
            {
                ToggleSpecialistStatus(userId);
            }
        }


        // =========================================================
        // بارگذاری اطلاعات کارشناس برای ویرایش
        // =========================================================

        private void LoadSpecialistForEdit(
            string userId)
        {
            if (string.IsNullOrEmpty(userId))
                return;


            using (var db = new ApplicationDbContext())
            {
                var role =
                    db.Roles.FirstOrDefault(
                        x => x.Name == "Specialist");


                if (role == null)
                {
                    ShowError(
                        "نقش کارشناس در سامانه پیدا نشد.");

                    return;
                }


                bool isSpecialist =
                    db.Set<IdentityUserRole>()
                        .Any(x =>
                            x.UserId == userId &&
                            x.RoleId == role.Id);


                if (!isSpecialist)
                {
                    ShowError(
                        "کاربر انتخاب‌شده کارشناس نیست.");

                    return;
                }


                var user =
                    db.Users.FirstOrDefault(
                        x => x.Id == userId);


                var profile =
                    db.UserProfiles.FirstOrDefault(
                        x => x.UserId == userId);


                if (user == null || profile == null)
                {
                    ShowError(
                        "اطلاعات کارشناس پیدا نشد.");

                    return;
                }


                pnlEdit.Visible = true;


                ViewState["EditUserId"] =
                    userId;


                lblEditSpecialist.Text =
                    "<strong>کارشناس انتخاب‌شده:</strong> " +
                    Server.HtmlEncode(profile.FullName);


                txtEditFullName.Text =
                    profile.FullName;


                txtEditUserName.Text =
                    user.UserName;


                if (ddlEditDepartment.Items.FindByValue(
                    profile.DepartmentId.ToString()) != null)
                {
                    ddlEditDepartment.SelectedValue =
                        profile.DepartmentId.ToString();
                }


                chkEditActive.Checked =
                    profile.IsActive;


                txtEditPassword.Text = "";

                txtEditConfirmPassword.Text = "";


                // بارگذاری تخصص‌های فعلی
                var specialtyIds =
                    db.SpecialistSpecialties
                        .Where(x => x.UserId == userId)
                        .Select(x => x.SpecialtyId)
                        .ToList();


                SetPendingSpecialties(
                    specialtyIds);


                BindEditSpecialties();


                lblMessage.Visible = false;
            }
        }


        // =========================================================
        // نگهداری تخصص‌های در حال ویرایش
        // =========================================================

        private List<int> GetPendingSpecialties()
        {
            string value =
                Convert.ToString(
                    ViewState["PendingSpecialties"]);


            if (string.IsNullOrEmpty(value))
                return new List<int>();


            return value
                .Split(',')
                .Where(x => !string.IsNullOrEmpty(x))
                .Select(x =>
                {
                    int id;

                    return int.TryParse(x, out id)
                        ? id
                        : 0;
                })
                .Where(x => x > 0)
                .Distinct()
                .ToList();
        }


        private void SetPendingSpecialties(
            List<int> ids)
        {
            ViewState["PendingSpecialties"] =
                string.Join(
                    ",",
                    ids.Distinct());
        }


        // =========================================================
        // نمایش تخصص‌های فعلی
        // =========================================================

        private void BindEditSpecialties()
        {
            List<int> ids =
                GetPendingSpecialties();


            using (var db = new ApplicationDbContext())
            {
                var list =
                    db.Specialties
                        .Where(x =>
                            ids.Contains(x.SpecialtyId))
                        .OrderBy(x => x.SpecialtyName)
                        .Select(x => new
                        {
                            x.SpecialtyId,
                            x.SpecialtyName,
                            x.Description
                        })
                        .ToList();


                rptEditSpecialties.DataSource =
                    list;

                rptEditSpecialties.DataBind();


                lblNoSpecialty.Visible =
                    list.Count == 0;
            }
        }


        // =========================================================
        // افزودن تخصص
        // =========================================================

        protected void btnAddSpecialty_Click(
            object sender,
            EventArgs e)
        {
            int specialtyId;


            if (!int.TryParse(
                ddlAddSpecialty.SelectedValue,
                out specialtyId))
            {
                ShowError(
                    "لطفاً تخصص موردنظر را انتخاب کنید.");

                return;
            }


            List<int> ids =
                GetPendingSpecialties();


            if (ids.Contains(specialtyId))
            {
                ShowError(
                    "این تخصص قبلاً برای کارشناس انتخاب شده است.");

                return;
            }


            using (var db = new ApplicationDbContext())
            {
                bool exists =
                    db.Specialties.Any(x =>
                        x.SpecialtyId == specialtyId &&
                        x.IsActive);


                if (!exists)
                {
                    ShowError(
                        "تخصص انتخاب‌شده معتبر نیست.");

                    return;
                }
            }


            ids.Add(specialtyId);


            SetPendingSpecialties(ids);


            BindEditSpecialties();


            ddlAddSpecialty.SelectedIndex = 0;


            ShowInfo(
                "تخصص به فهرست تخصیص‌یافته اضافه شد. برای ثبت نهایی، «ثبت اطلاعات» را بزنید.");
        }


        // =========================================================
        // حذف تخصص از فهرست
        // =========================================================

        protected void rptEditSpecialties_ItemCommand(
            object source,
            RepeaterCommandEventArgs e)
        {
            if (e.CommandName != "RemoveSpecialty")
                return;


            int specialtyId;


            if (!int.TryParse(
                Convert.ToString(e.CommandArgument),
                out specialtyId))
                return;


            List<int> ids =
                GetPendingSpecialties();


            if (ids.Contains(specialtyId))
            {
                ids.Remove(specialtyId);
            }


            SetPendingSpecialties(ids);


            BindEditSpecialties();


            ShowInfo(
                "تخصص از فهرست تخصیص‌یافته حذف شد. برای ثبت نهایی، «ثبت اطلاعات» را بزنید.");
        }


        // =========================================================
        // ثبت نهایی اطلاعات
        // =========================================================

        protected void btnSaveChanges_Click(
            object sender,
            EventArgs e)
        {
            lblMessage.Visible = false;


            string userId =
                Convert.ToString(
                    ViewState["EditUserId"]);


            if (string.IsNullOrEmpty(userId))
            {
                ShowError(
                    "کارشناس برای ویرایش انتخاب نشده است.");

                return;
            }


            string fullName =
                txtEditFullName.Text.Trim();


            string userName =
                txtEditUserName.Text.Trim();


            string password =
                txtEditPassword.Text;


            string confirmPassword =
                txtEditConfirmPassword.Text;


            int departmentId;


            // نام
            if (string.IsNullOrEmpty(fullName))
            {
                ShowError(
                    "لطفاً نام و نام خانوادگی را وارد کنید.");

                return;
            }


            // نام کاربری
            if (string.IsNullOrEmpty(userName))
            {
                ShowError(
                    "لطفاً نام کاربری را وارد کنید.");

                return;
            }


            // واحد
            if (!int.TryParse(
                ddlEditDepartment.SelectedValue,
                out departmentId))
            {
                ShowError(
                    "لطفاً واحد سازمانی را انتخاب کنید.");

                return;
            }


            // رمز عبور
            if (!string.IsNullOrEmpty(password))
            {
                if (password.Length < 6)
                {
                    ShowError(
                        "رمز عبور باید حداقل 6 کاراکتر باشد.");

                    return;
                }


                if (password != confirmPassword)
                {
                    ShowError(
                        "رمز عبور جدید و تکرار آن یکسان نیستند.");

                    return;
                }
            }


            using (var db =
                new ApplicationDbContext())
            {
                var user =
                    db.Users.FirstOrDefault(
                        x => x.Id == userId);


                var profile =
                    db.UserProfiles.FirstOrDefault(
                        x => x.UserId == userId);


                if (user == null || profile == null)
                {
                    ShowError(
                        "اطلاعات کارشناس پیدا نشد.");

                    return;
                }


                // بررسی واحد
                var department =
                    db.Departments.FirstOrDefault(
                        x =>
                            x.DepartmentId == departmentId &&
                            x.IsActive);


                if (department == null)
                {
                    ShowError(
                        "واحد سازمانی انتخاب‌شده معتبر نیست.");

                    return;
                }


                // بررسی تکراری نبودن نام کاربری
                bool duplicateUserName =
                    db.Users.Any(
                        x =>
                            x.UserName == userName &&
                            x.Id != userId);


                if (duplicateUserName)
                {
                    ShowError(
                        "این نام کاربری قبلاً در سامانه ثبت شده است.");

                    return;
                }


                // UserManager
                var userManager =
                    new UserManager<ApplicationUser>(
                        new UserStore<ApplicationUser>(db));


                // تغییر اطلاعات حساب
                user.UserName =
                    userName;


                // تغییر رمز
                if (!string.IsNullOrEmpty(password))
                {
                    user.PasswordHash =
                        userManager.PasswordHasher
                            .HashPassword(password);
                }


                // تغییر پروفایل
                profile.FullName =
                    fullName;


                profile.DepartmentId =
                    departmentId;


                profile.IsActive =
                    chkEditActive.Checked;


                // =================================================
                // ثبت تخصص‌ها
                // =================================================

                List<int> specialtyIds =
                    GetPendingSpecialties();


                // فقط تخصص‌های معتبر و فعال
                specialtyIds =
                    db.Specialties
                        .Where(x =>
                            specialtyIds.Contains(
                                x.SpecialtyId) &&
                            x.IsActive)
                        .Select(x => x.SpecialtyId)
                        .ToList();


                // حذف تخصص‌های قبلی
                var oldSpecialties =
                    db.SpecialistSpecialties
                        .Where(x =>
                            x.UserId == userId)
                        .ToList();


                foreach (var item in oldSpecialties)
                {
                    db.SpecialistSpecialties.Remove(item);
                }


                // افزودن تخصص‌های جدید
                foreach (int specialtyId
                    in specialtyIds)
                {
                    db.SpecialistSpecialties.Add(
                        new SpecialistSpecialty
                        {
                            UserId = userId,
                            SpecialtyId = specialtyId
                        });
                }


                // ذخیره همه تغییرات
                db.SaveChanges();


                ShowSuccess(
                    "اطلاعات کارشناس با موفقیت ثبت شد.");


                LoadSpecialistsGrid();


                // فرم ویرایش را باز نگه می‌داریم
                // تا مدیر نتیجه را ببیند

                LoadSpecialistForEdit(userId);
            }
        }


        // =========================================================
        // انصراف از ویرایش
        // =========================================================

        protected void btnCancelEdit_Click(
            object sender,
            EventArgs e)
        {
            CancelEdit();
        }


        private void CancelEdit()
        {
            pnlEdit.Visible = false;


            ViewState.Remove(
                "EditUserId");


            ViewState.Remove(
                "PendingSpecialties");


            txtEditFullName.Text = "";

            txtEditUserName.Text = "";

            txtEditPassword.Text = "";

            txtEditConfirmPassword.Text = "";


            lblEditSpecialist.Text = "";

            lblMessage.Visible = false;
        }


        // =========================================================
        // فعال / غیرفعال کردن
        // =========================================================

        private void ToggleSpecialistStatus(
            string userId)
        {
            if (string.IsNullOrEmpty(userId))
                return;


            using (var db =
                new ApplicationDbContext())
            {
                var profile =
                    db.UserProfiles.FirstOrDefault(
                        x => x.UserId == userId);


                if (profile == null)
                {
                    ShowError(
                        "پروفایل کارشناس پیدا نشد.");

                    return;
                }


                profile.IsActive =
                    !profile.IsActive;


                db.SaveChanges();


                ShowSuccess(
                    profile.IsActive
                        ? "کارشناس فعال شد."
                        : "کارشناس غیرفعال شد.");
            }


            LoadSpecialistsGrid();
        }


        // =========================================================
        // پیام موفقیت
        // =========================================================

        private void ShowSuccess(
            string message)
        {
            lblMessage.Text =
                message;

            lblMessage.CssClass =
                "mk-message mk-success";

            lblMessage.Visible =
                true;
        }


        // =========================================================
        // پیام خطا
        // =========================================================

        private void ShowError(
            string message)
        {
            lblMessage.Text =
                message;

            lblMessage.CssClass =
                "mk-message mk-error";

            lblMessage.Visible =
                true;
        }


        // =========================================================
        // پیام اطلاعاتی
        // =========================================================

        private void ShowInfo(
            string message)
        {
            lblMessage.Text =
                message;

            lblMessage.CssClass =
                "mk-message mk-info";

            lblMessage.Visible =
                true;
        }


        protected string GetToggleConfirmScript(object value)
        {
            bool isActive = Convert.ToBoolean(value);

            if (isActive)
            {
                return "return confirm('آیا از غیرفعال کردن این تخصص اطمینان دارید؟');";
            }

            return "return true;";
        }
    }
}