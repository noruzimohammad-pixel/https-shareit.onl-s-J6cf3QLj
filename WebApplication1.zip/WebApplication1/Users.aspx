﻿<%@ Page Title="مدیریت کاربران"
    Language="C#"
    MasterPageFile="~/Site.Master"
    AutoEventWireup="true"
    CodeBehind="Users.aspx.cs"
    Inherits="WebApplication1.Users" %>

<asp:Content ID="Content1"
    ContentPlaceHolderID="TitleContent"
    runat="server">

    مدیریت کاربران

</asp:Content>


<asp:Content ID="Content2"
    ContentPlaceHolderID="HeadContent"
    runat="server">

    <style type="text/css">

        .users-container {
            width: 100%;
            max-width: 1250px;
            margin: 0 auto;
        }

        .users-card {
            background: #ffffff;
            border-radius: 10px;
            padding: 22px;
            box-shadow: 0 2px 10px rgba(0,0,0,.06);
        }

        .top-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 18px;
            gap: 15px;
        }

        .page-description {
            color: #777777;
            font-size: 12px;
        }

        .btn {
            display: inline-block;
            border: none;
            border-radius: 6px;
            padding: 10px 18px;
            font-family: Tahoma, Arial;
            font-size: 13px;
            cursor: pointer;
            text-decoration: none;
        }

        .btn-primary {
            background: #1976d2;
            color: #ffffff;
        }

        .btn-primary:hover {
            background: #1565c0;
        }

        .message {
            display: block;
            margin-bottom: 18px;
            padding: 11px 13px;
            border-radius: 6px;
            font-size: 13px;
        }

        .success {
            background: #e8f5e9;
            color: #2e7d32;
        }

        .error {
            background: #ffebee;
            color: #c62828;
        }

        .count-label {
            display: block;
            margin-bottom: 15px;
            color: #777777;
            font-size: 12px;
        }

        .table-wrapper {
            overflow-x: auto;
        }

        .users-table {
            width: 100%;
            border-collapse: collapse;
            font-size: 12px;
        }

        .users-table th {
            background: #f5f7fa;
            color: #444444;
            font-weight: bold;
            padding: 12px 9px;
            border-bottom: 2px solid #e0e4e8;
            text-align: right;
            white-space: nowrap;
        }

        .users-table td {
            padding: 11px 9px;
            border-bottom: 1px solid #eeeeee;
            color: #555555;
            vertical-align: middle;
        }

        .users-table tr:hover td {
            background: #fafafa;
        }

        .role-badge {
            display: inline-block;
            padding: 4px 8px;
            border-radius: 12px;
            background: #e3f2fd;
            color: #1565c0;
            font-size: 11px;
            white-space: nowrap;
        }

        .category-badge {
            display: inline-block;
            padding: 4px 8px;
            border-radius: 12px;
            background: #f3e5f5;
            color: #6a1b9a;
            font-size: 11px;
            white-space: nowrap;
        }

        .status-active {
            display: inline-block;
            padding: 4px 8px;
            border-radius: 12px;
            background: #e8f5e9;
            color: #2e7d32;
            font-size: 11px;
        }

        .status-inactive {
            display: inline-block;
            padding: 4px 8px;
            border-radius: 12px;
            background: #ffebee;
            color: #c62828;
            font-size: 11px;
        }

        .specialties {
            line-height: 1.8;
            color: #666666;
        }

        .no-specialty {
            color: #aaaaaa;
        }

        .btn-edit {
            background: #fff3e0;
            color: #ef6c00;
            border: 1px solid #ffe0b2;
            padding: 6px 10px;
            border-radius: 5px;
            font-family: Tahoma, Arial;
            font-size: 11px;
            text-decoration: none;
            white-space: nowrap;
        }

        .btn-edit:hover {
            background: #ffe0b2;
        }

        .btn-toggle {
            padding: 6px 10px;
            border-radius: 5px;
            font-family: Tahoma, Arial;
            font-size: 11px;
            cursor: pointer;
            white-space: nowrap;
        }

        .btn-disable {
            background: #ffebee;
            color: #c62828;
            border: 1px solid #ffcdd2;
        }

        .btn-enable {
            background: #e8f5e9;
            color: #2e7d32;
            border: 1px solid #c8e6c9;
        }

        .empty-message {
            padding: 30px;
            text-align: center;
            color: #888888;
        }

        @media (max-width: 800px) {

            .top-bar {
                flex-direction: column;
                align-items: stretch;
            }

        }

    </style>

</asp:Content>


<asp:Content ID="Content3"
    ContentPlaceHolderID="PageHeader"
    runat="server">

    مدیریت کاربران

</asp:Content>


<asp:Content ID="Content4"
    ContentPlaceHolderID="MainContent"
    runat="server">

    <div class="users-container">


        <asp:Label
            ID="lblMessage"
            runat="server"
            Visible="false">
        </asp:Label>


        <div class="users-card">


            <div class="top-bar">

                <div>

                    <div class="page-description">

                        مدیریت کاربران، نقش‌ها، واحدهای سازمانی و تخصص کارشناسان

                    </div>

                </div>


                <div>

                    <asp:HyperLink
                        ID="lnkCreateUser"
                        runat="server"
                        NavigateUrl="~/CreateUser.aspx"
                        CssClass="btn btn-primary">

                        + ایجاد کاربر جدید

                    </asp:HyperLink>

                </div>

            </div>


            <asp:Label
                ID="lblUserCount"
                runat="server"
                CssClass="count-label">
            </asp:Label>


            <div class="table-wrapper">


                <asp:GridView
                    ID="gvUsers"
                    runat="server"
                    AutoGenerateColumns="false"
                    CssClass="users-table"
                    GridLines="None"
                    EmptyDataText="هیچ کاربری ثبت نشده است.">


                    <Columns>


                        <asp:BoundField
                            DataField="UserName"
                            HeaderText="نام کاربری" />


                        <asp:BoundField
                            DataField="FullName"
                            HeaderText="نام و نام خانوادگی" />


                        <asp:BoundField
                            DataField="DepartmentName"
                            HeaderText="واحد سازمانی" />


                        <asp:TemplateField
                            HeaderText="دسته کاربری">

                            <ItemTemplate>

                                <span class="category-badge">

                                    <%# Eval("UserCategoryText") %>

                                </span>

                            </ItemTemplate>

                        </asp:TemplateField>


                        <asp:TemplateField
                            HeaderText="نقش">

                            <ItemTemplate>

                                <span class="role-badge">

                                    <%# Eval("RoleName") %>

                                </span>

                            </ItemTemplate>

                        </asp:TemplateField>


                        <asp:TemplateField
                            HeaderText="تخصص‌ها">

                            <ItemTemplate>

                                <span class="specialties">

                                    <%# Eval("Specialties") %>

                                </span>

                            </ItemTemplate>

                        </asp:TemplateField>


                        <asp:TemplateField
                            HeaderText="وضعیت">

                            <ItemTemplate>

                                <span class='<%# Eval("StatusCss") %>'>

                                    <%# Eval("StatusText") %>

                                </span>

                            </ItemTemplate>

                        </asp:TemplateField>


                        <asp:BoundField
                            DataField="CreatedAtText"
                            HeaderText="تاریخ ایجاد" />


                        <asp:TemplateField
                            HeaderText="عملیات">

                            <ItemTemplate>

                                <asp:HyperLink
                                    ID="lnkEdit"
                                    runat="server"
                                    NavigateUrl='<%# "~/EditUser.aspx?id=" + Eval("UserId") %>'
                                    CssClass="btn-edit">

                                    ویرایش

                                </asp:HyperLink>


                                <asp:Button
                                    ID="btnToggleActive"
                                    runat="server"
                                    Text='<%# Eval("ToggleText") %>'
                                    CssClass='<%# Eval("ToggleCss") %>'
                                    CommandArgument='<%# Eval("UserId") %>'
                                    OnCommand="btnToggleActive_Command" />

                            </ItemTemplate>

                        </asp:TemplateField>


                    </Columns>

                </asp:GridView>


            </div>


        </div>

    </div>

</asp:Content>