﻿<%@ Page Title="ویرایش کاربر"
    Language="C#"
    MasterPageFile="~/Site.Master"
    AutoEventWireup="true"
    CodeBehind="EditUser.aspx.cs"
    Inherits="WebApplication1.EditUser" %>

<asp:Content ID="Content1"
    ContentPlaceHolderID="TitleContent"
    runat="server">

    ویرایش کاربر

</asp:Content>

<asp:Content ID="Content2"
    ContentPlaceHolderID="HeadContent"
    runat="server">

    <style type="text/css">

        .edit-user-container {
            max-width: 850px;
            margin: 0 auto;
        }

        .form-card {
            background: #ffffff;
            border-radius: 10px;
            padding: 25px;
            box-shadow: 0 2px 10px rgba(0,0,0,.06);
        }

        .section-title {
            font-size: 16px;
            font-weight: bold;
            color: #333333;
            padding-bottom: 12px;
            margin-bottom: 20px;
            border-bottom: 1px solid #eeeeee;
        }

        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 18px;
        }

        .form-group {
            margin-bottom: 18px;
        }

        .form-label {
            display: block;
            margin-bottom: 7px;
            color: #555555;
            font-size: 13px;
        }

        .required {
            color: #c62828;
        }

        .form-control {
            width: 100%;
            box-sizing: border-box;
            padding: 10px 12px;
            border: 1px solid #d5d9df;
            border-radius: 6px;
            font-family: Tahoma, Arial;
            font-size: 13px;
            background: #ffffff;
        }

        .form-control:focus {
            border-color: #1976d2;
            outline: none;
        }

        .readonly-control {
            background: #f5f5f5;
            color: #777777;
        }

        .checkbox-row {
            display: flex;
            align-items: center;
            min-height: 40px;
        }

        .checkbox-row label {
            margin-right: 7px;
            color: #555555;
            font-size: 13px;
        }

        .category-info {
            background: #f5f5f5;
            border-right: 3px solid #1976d2;
            padding: 10px 12px;
            margin-top: 8px;
            border-radius: 5px;
            color: #666666;
            font-size: 12px;
            line-height: 1.8;
        }

        .specialties-box {
            background: #f7f9fb;
            border: 1px solid #e1e5e9;
            border-radius: 7px;
            padding: 15px;
            margin-bottom: 20px;
        }

        .specialties-description {
            color: #777777;
            font-size: 12px;
            line-height: 1.8;
            margin-bottom: 14px;
        }

        .specialty-item {
            display: inline-block;
            margin-left: 20px;
            margin-bottom: 10px;
            font-size: 13px;
        }

        .specialty-item input {
            margin-left: 5px;
        }

        .password-info {
            background: #fff8e1;
            border-right: 3px solid #ffb300;
            padding: 10px 12px;
            border-radius: 5px;
            margin-bottom: 18px;
            color: #795548;
            font-size: 12px;
            line-height: 1.8;
        }

        .buttons {
            margin-top: 25px;
            padding-top: 20px;
            border-top: 1px solid #eeeeee;
        }

        .btn {
            border: none;
            border-radius: 6px;
            padding: 11px 22px;
            font-family: Tahoma, Arial;
            font-size: 13px;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
        }

        .btn-primary {
            background: #1976d2;
            color: #ffffff;
        }

        .btn-primary:hover {
            background: #1565c0;
        }

        .btn-secondary {
            background: #eceff1;
            color: #333333;
            margin-right: 8px;
        }

        .btn-secondary:hover {
            background: #dfe3e6;
        }

        .message {
            display: block;
            margin-top: 18px;
            padding: 10px 12px;
            border-radius: 6px;
            font-size: 13px;
        }

        .success {
            background: #e8f5e9;
            color: #2e7d32;
        }

        .error {
            background: #ffebee;
            color: #c62828;
        }

        @media (max-width: 700px) {

            .form-row {
                grid-template-columns: 1fr;
            }

            .form-card {
                padding: 18px;
            }

        }

    </style>

</asp:Content>

<asp:Content ID="Content3"
    ContentPlaceHolderID="PageHeader"
    runat="server">

    ویرایش کاربر

</asp:Content>

<asp:Content ID="Content4"
    ContentPlaceHolderID="MainContent"
    runat="server">

    <div class="edit-user-container">

        <div class="form-card">

            <div class="section-title">

                اطلاعات کاربر

            </div>


            <asp:Label
                ID="lblMessage"
                runat="server"
                Visible="false">
            </asp:Label>


            <div class="form-row">

                <div class="form-group">

                    <label class="form-label">

                        نام کاربری

                    </label>

                    <asp:TextBox
                        ID="txtUserName"
                        runat="server"
                        CssClass="form-control readonly-control"
                        ReadOnly="true">
                    </asp:TextBox>

                </div>


                <div class="form-group">

                    <label class="form-label">

                        نام و نام خانوادگی

                        <span class="required">*</span>

                    </label>

                    <asp:TextBox
                        ID="txtFullName"
                        runat="server"
                        CssClass="form-control"
                        MaxLength="150">
                    </asp:TextBox>

                </div>

            </div>


            <div class="form-row">

                <div class="form-group">

                    <label class="form-label">

                        واحد سازمانی

                        <span class="required">*</span>

                    </label>

                    <asp:DropDownList
                        ID="ddlDepartment"
                        runat="server"
                        CssClass="form-control">
                    </asp:DropDownList>

                </div>


                <div class="form-group">

                    <label class="form-label">

                        نقش کاربر

                        <span class="required">*</span>

                    </label>

                    <asp:DropDownList
                        ID="ddlRole"
                        runat="server"
                        CssClass="form-control"
                        AutoPostBack="true"
                        OnSelectedIndexChanged="ddlRole_SelectedIndexChanged">

                        <asp:ListItem
                            Text="کاربر"
                            Value="User">
                        </asp:ListItem>

                        <asp:ListItem
                            Text="کارشناس"
                            Value="Specialist">
                        </asp:ListItem>

                        <asp:ListItem
                            Text="مدیر"
                            Value="Manager">
                        </asp:ListItem>

                    </asp:DropDownList>


                    <div class="category-info">

                        دسته کاربری به صورت خودکار از روی نقش تعیین می‌شود.

                        <br />

                        کاربر ← کاربر عمومی

                        <br />

                        کارشناس و مدیر ← خدمات پشتیبانی فناوری اطلاعات

                    </div>

                </div>

            </div>


            <div class="form-group">

                <label class="form-label">

                    وضعیت حساب

                </label>

                <div class="checkbox-row">

                    <asp:CheckBox
                        ID="chkIsActive"
                        runat="server" />

                    <label>

                        کاربر فعال باشد

                    </label>

                </div>

            </div>


            <asp:Panel
                ID="pnlSpecialties"
                runat="server"
                Visible="false">

                <div class="section-title">

                    تخصص‌های اجرایی کارشناس

                </div>


                <div class="specialties-box">

                    <div class="specialties-description">

                        یک یا چند تخصص را برای این کارشناس انتخاب کنید.
                        این تخصص‌ها در زمان ارجاع درخواست‌ها استفاده خواهند شد.

                    </div>


                    <asp:CheckBoxList
                        ID="cblSpecialties"
                        runat="server"
                        RepeatDirection="Horizontal"
                        RepeatLayout="Flow"
                        CssClass="specialty-item">

                    </asp:CheckBoxList>

                </div>

            </asp:Panel>


            <div class="section-title">

                تغییر رمز عبور

            </div>


            <div class="password-info">

                اگر قصد تغییر رمز عبور را ندارید، این دو فیلد را خالی بگذارید.

            </div>


            <div class="form-row">

                <div class="form-group">

                    <label class="form-label">

                        رمز عبور جدید

                    </label>

                    <asp:TextBox
                        ID="txtPassword"
                        runat="server"
                        TextMode="Password"
                        CssClass="form-control"
                        MaxLength="100">
                    </asp:TextBox>

                </div>


                <div class="form-group">

                    <label class="form-label">

                        تکرار رمز عبور جدید

                    </label>

                    <asp:TextBox
                        ID="txtConfirmPassword"
                        runat="server"
                        TextMode="Password"
                        CssClass="form-control"
                        MaxLength="100">
                    </asp:TextBox>

                </div>

            </div>


            <div class="buttons">

                <asp:Button
                    ID="btnSave"
                    runat="server"
                    Text="ذخیره تغییرات"
                    CssClass="btn btn-primary"
                    OnClick="btnSave_Click" />


                <asp:HyperLink
                    ID="lnkBack"
                    runat="server"
                    NavigateUrl="~/Users.aspx"
                    CssClass="btn btn-secondary">

                    بازگشت

                </asp:HyperLink>

            </div>

        </div>

    </div>

</asp:Content>