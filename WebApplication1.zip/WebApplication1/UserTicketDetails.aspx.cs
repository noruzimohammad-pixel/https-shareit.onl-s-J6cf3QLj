﻿using System;
using System.Linq;
using System.Web.UI;
using WebApplication1.Models;
using Microsoft.AspNet.Identity;

namespace WebApplication1
{
    public partial class UserTicketDetails : System.Web.UI.Page
    {
        private int TicketId
        {
            get
            {
                int id;

                if (int.TryParse(Request.QueryString["id"], out id))
                    return id;

                return 0;
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Request.IsAuthenticated)
            {
                Response.Redirect("~/Login.aspx");
                return;
            }

            if (User.IsInRole("Manager") || User.IsInRole("Specialist"))
            {
                Response.Redirect("~/Login.aspx");
                return;
            }

            if (TicketId <= 0)
            {
                Response.Redirect("~/UserTickets.aspx");
                return;
            }

            if (!IsPostBack)
            {
                LoadTicket();
                LoadActions();
                LoadHistory();
            }
        }

        private void LoadTicket()
        {
            string currentUserId = User.Identity.GetUserId();

            using (var db = new ApplicationDbContext())
            {
                var ticket = db.Tickets
                    .FirstOrDefault(t =>
                        t.TicketId == TicketId &&
                        t.UserId == currentUserId);

                if (ticket == null)
                {
                    Response.Redirect("~/UserTickets.aspx");
                    return;
                }

                lblTicketId.Text = ticket.TicketId.ToString();
                lblSubject.Text = ticket.Subject;
                lblDescription.Text = ticket.Description;
                lblCategory.Text = GetCategoryText(ticket.Category);
                lblPriority.Text = GetPriorityText(ticket.Priority);
                lblStatus.Text = GetStatusText(ticket.Status);
                lblCreatedAt.Text = ticket.CreatedAt.ToString("yyyy/MM/dd HH:mm");

                pnlConfirmation.Visible =
                    ticket.Status == "WaitingConfirmation";
            }
        }

        protected void btnConfirm_Click(object sender, EventArgs e)
        {
            string currentUserId = User.Identity.GetUserId();

            using (var db = new ApplicationDbContext())
            {
                var ticket = db.Tickets
                    .FirstOrDefault(t =>
                        t.TicketId == TicketId &&
                        t.UserId == currentUserId);

                if (ticket == null)
                {
                    ShowError("درخواست پیدا نشد.");
                    return;
                }

                if (ticket.Status != "WaitingConfirmation")
                {
                    ShowError("این درخواست در انتظار تأیید نیست.");
                    return;
                }

                string comment = txtConfirmationComment.Text.Trim();

                // ثبت تأیید کاربر
                var confirmation = new TicketConfirmation
                {
                    TicketId = ticket.TicketId,
                    UserId = currentUserId,
                    ConfirmationStatus = "Confirmed",
                    Comment = comment,
                    ConfirmationDate = DateTime.Now,
                    AutoConfirmed = false,
                    CreatedAt = DateTime.Now
                };

                db.TicketConfirmations.Add(confirmation);

                // بستن درخواست
                string oldStatus = ticket.Status;

                ticket.UserConfirmed = true;
                ticket.AutoClosed = false;
                ticket.Status = "Closed";
                ticket.ClosedAt = DateTime.Now;

                var history = new TicketHistory
                {
                    TicketId = ticket.TicketId,
                    UserId = currentUserId,
                    OldStatus = oldStatus,
                    NewStatus = "Closed",
                    Description = string.IsNullOrEmpty(comment)
                        ? "کاربر انجام درخواست را تأیید کرد و درخواست خاتمه یافت."
                        : "کاربر انجام درخواست را تأیید کرد. توضیحات: " + comment,
                    HistoryDate = DateTime.Now
                };

                db.TicketHistory.Add(history);

                db.SaveChanges();
            }

            ShowSuccess("درخواست با موفقیت تأیید و خاتمه یافت.");

            txtConfirmationComment.Text = "";

            LoadTicket();
            LoadActions();
            LoadHistory();
        }

        protected void btnReject_Click(object sender, EventArgs e)
        {
            string currentUserId = User.Identity.GetUserId();

            using (var db = new ApplicationDbContext())
            {
                var ticket = db.Tickets
                    .FirstOrDefault(t =>
                        t.TicketId == TicketId &&
                        t.UserId == currentUserId);

                if (ticket == null)
                {
                    ShowError("درخواست پیدا نشد.");
                    return;
                }

                if (ticket.Status != "WaitingConfirmation")
                {
                    ShowError("این درخواست در انتظار تأیید نیست.");
                    return;
                }

                string comment = txtConfirmationComment.Text.Trim();

                if (string.IsNullOrEmpty(comment))
                {
                    ShowError("لطفاً توضیح دهید مشکل چه بخشی هنوز برطرف نشده است.");
                    return;
                }

                // ثبت عدم تأیید
                var confirmation = new TicketConfirmation
                {
                    TicketId = ticket.TicketId,
                    UserId = currentUserId,
                    ConfirmationStatus = "Rejected",
                    Comment = comment,
                    ConfirmationDate = DateTime.Now,
                    AutoConfirmed = false,
                    CreatedAt = DateTime.Now
                };

                db.TicketConfirmations.Add(confirmation);

                // بازگشت به متخصص
                string oldStatus = ticket.Status;

                ticket.UserConfirmed = false;
                ticket.AutoClosed = false;
                ticket.Status = "InProgress";
                ticket.ConfirmationRequestedAt = null;
                ticket.ClosedAt = null;

                var history = new TicketHistory
                {
                    TicketId = ticket.TicketId,
                    UserId = currentUserId,
                    OldStatus = oldStatus,
                    NewStatus = "InProgress",
                    Description = "کاربر درخواست را تأیید نکرد و اعلام کرد مشکل همچنان وجود دارد. توضیحات: " + comment,
                    HistoryDate = DateTime.Now
                };

                db.TicketHistory.Add(history);

                db.SaveChanges();
            }

            ShowSuccess("عدم رفع مشکل ثبت شد و درخواست مجدداً برای رسیدگی به متخصص ارجاع شد.");

            txtConfirmationComment.Text = "";

            LoadTicket();
            LoadActions();
            LoadHistory();
        }

        private void LoadActions()
        {
            using (var db = new ApplicationDbContext())
            {
                var actions = db.TicketActions
                    .Where(a => a.TicketId == TicketId)
                    .OrderByDescending(a => a.ActionDate)
                    .ToList()
                    .Select(a => new
                    {
                        a.ActionId,
                        ActionDate = a.ActionDate.ToString("yyyy/MM/dd HH:mm"),
                        UserName = GetUserDisplayName(db, a.UserId),
                        a.ActionText
                    })
                    .ToList();

                gvActions.DataSource = actions;
                gvActions.DataBind();
            }
        }

        private void LoadHistory()
        {
            using (var db = new ApplicationDbContext())
            {
                var history = db.TicketHistory
                    .Where(h => h.TicketId == TicketId)
                    .OrderByDescending(h => h.HistoryDate)
                    .ToList()
                    .Select(h => new
                    {
                        h.HistoryId,
                        HistoryDate = h.HistoryDate.ToString("yyyy/MM/dd HH:mm"),
                        UserName = GetUserDisplayName(db, h.UserId),
                        OldStatus = GetStatusText(h.OldStatus),
                        NewStatus = GetStatusText(h.NewStatus),
                        h.Description
                    })
                    .ToList();

                gvHistory.DataSource = history;
                gvHistory.DataBind();
            }
        }

        private string GetUserDisplayName(ApplicationDbContext db, string userId)
        {
            var profile = db.UserProfiles
                .FirstOrDefault(p => p.UserId == userId);

            if (profile != null && !string.IsNullOrEmpty(profile.FullName))
                return profile.FullName;

            var user = db.Users
                .FirstOrDefault(u => u.Id == userId);

            if (user != null && !string.IsNullOrEmpty(user.UserName))
                return user.UserName;

            return "نامشخص";
        }

        private void ShowSuccess(string message)
        {
            lblMessage.Text = message;
            lblMessage.ForeColor = System.Drawing.Color.Green;
            lblMessage.BackColor = System.Drawing.Color.Honeydew;
            lblMessage.Visible = true;
        }

        private void ShowError(string message)
        {
            lblMessage.Text = message;
            lblMessage.ForeColor = System.Drawing.Color.DarkRed;
            lblMessage.BackColor = System.Drawing.Color.MistyRose;
            lblMessage.Visible = true;
        }

        private string GetCategoryText(string category)
        {
            switch (category)
            {
                case "نرم‌افزار":
                    return "نرم‌افزار";

                case "سخت‌افزار":
                    return "سخت‌افزار";

                case "شبکه":
                    return "شبکه";

                case "امنیت":
                    return "امنیت";

                case "سایر":
                    return "سایر";

                default:
                    return category;
            }
        }

        private string GetPriorityText(string priority)
        {
            switch (priority)
            {
                case "Low":
                    return "کم";

                case "Normal":
                    return "عادی";

                case "High":
                    return "زیاد";

                case "Critical":
                    return "بحرانی";

                default:
                    return priority;
            }
        }

        private string GetStatusText(string status)
        {
            switch (status)
            {
                case "New":
                    return "جدید";

                case "Assigned":
                    return "ارجاع شده";

                case "InProgress":
                    return "در حال انجام";

                case "WaitingConfirmation":
                    return "منتظر تأیید کاربر";

                case "Closed":
                    return "خاتمه یافته";

                default:
                    return string.IsNullOrEmpty(status)
                        ? "-"
                        : status;
            }
        }
    }
}