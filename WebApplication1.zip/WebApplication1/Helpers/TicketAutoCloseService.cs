﻿using System;
using System.Linq;
using WebApplication1.Models;

namespace WebApplication1.Helpers
{
    public static class TicketAutoCloseService
    {
        public static int ProcessAutoClose()
        {
            int closedCount = 0;

            using (var db = new ApplicationDbContext())
            {
                DateTime limitDate = DateTime.Now.AddDays(-3);

                var tickets = db.Tickets
                    .Where(t =>
                        t.Status == "WaitingConfirmation" &&
                        !t.UserConfirmed &&
                        t.ConfirmationRequestedAt.HasValue &&
                        t.ConfirmationRequestedAt.Value <= limitDate)
                    .ToList();

                foreach (var ticket in tickets)
                {
                    string oldStatus = ticket.Status;

                    ticket.Status = "Closed";
                    ticket.ClosedAt = DateTime.Now;
                    ticket.UserConfirmed = false;
                    ticket.AutoClosed = true;

                    var confirmation = new TicketConfirmation
                    {
                        TicketId = ticket.TicketId,
                        UserId = ticket.UserId,
                        ConfirmationStatus = "AutoConfirmed",
                        Comment = "کاربر طی ۳ روز پس از درخواست تأیید، پاسخی ثبت نکرد.",
                        ConfirmationDate = DateTime.Now,
                        AutoConfirmed = true,
                        CreatedAt = DateTime.Now
                    };

                    db.TicketConfirmations.Add(confirmation);

                    var history = new TicketHistory
                    {
                        TicketId = ticket.TicketId,
                        UserId = ticket.UserId,
                        OldStatus = oldStatus,
                        NewStatus = "Closed",
                        Description = "درخواست به دلیل عدم پاسخ کاربر طی ۳ روز به‌صورت خودکار خاتمه یافت.",
                        HistoryDate = DateTime.Now
                    };

                    db.TicketHistory.Add(history);

                    closedCount++;
                }

                if (closedCount > 0)
                    db.SaveChanges();
            }

            return closedCount;
        }
    }
}