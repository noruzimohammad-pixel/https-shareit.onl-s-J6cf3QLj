﻿<%@ Page Title="داشبورد مدیریت" Language="C#" MasterPageFile="~/Site.Master"
    AutoEventWireup="true" CodeBehind="ManagerDashboard.aspx.cs"
    Inherits="WebApplication1.ManagerDashboard" %>

<asp:Content ID="Content1" ContentPlaceHolderID="TitleContent" runat="server">
    داشبورد مدیریت
</asp:Content>

<asp:Content ID="Content2" ContentPlaceHolderID="PageHeader" runat="server">
    داشبورد مدیریت
</asp:Content>

<asp:Content ID="Content3" ContentPlaceHolderID="MainContent" runat="server">

<style type="text/css">

.manager-attention-card {
    background: #fff;
    border: 1px solid #e8ebf0;
    border-radius: 12px;
    box-shadow: 0 3px 12px rgba(28,39,56,.04);
    margin-bottom: 24px;
    overflow: hidden;
}

.manager-attention-header {
    min-height: 54px;
    padding: 0 18px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    border-bottom: 1px solid #edf0f4;
}

.manager-attention-header h3 {
    margin: 0;
    font-size: 14px;
    color: #273142;
}

.manager-attention-header span {
    color: #929baa;
    font-size: 10px;
}

.manager-attention-body {
    padding: 12px;
}

.manager-attention-grid {
    display: grid;
    grid-template-columns: repeat(6, minmax(0, 1fr));
    gap: 10px;
}

.manager-attention-item {
    display: flex;
    align-items: center;
    min-height: 58px;
    padding: 0 9px;
    border: 1px solid #edf0f4;
    border-radius: 9px;
    background: #fafbfd;
    text-decoration: none;
    transition: all .2s ease;
    min-width: 0;
}

.manager-attention-item:hover {
    background: #f5f8fc;
    border-color: #dfe5ed;
    text-decoration: none;
}

.manager-attention-icon {
    width: 32px;
    height: 32px;
    min-width: 32px;
    border-radius: 8px;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-left: 8px;
    font-size: 14px;
    font-weight: bold;
}

.attention-blue {
    background: #eaf2ff;
    color: #2f80ed;
}

.attention-orange {
    background: #fff3df;
    color: #d6810c;
}

.attention-purple {
    background: #f0eaff;
    color: #7655d6;
}

.attention-green {
    background: #e8f8ef;
    color: #239653;
}

.manager-attention-info {
    display: flex;
    flex-direction: column;
    gap: 2px;
    min-width: 0;
}

.manager-attention-number {
    font-size: 17px;
    line-height: 1;
    font-weight: bold;
    color: #273142;
}

.manager-attention-label {
    font-size: 9px;
    color: #7d8797;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

.manager-attention-sub {
    margin-top: 2px;
    font-size: 8px;
    color: #929baa;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

.manager-table-card {
    background: #fff;
    border: 1px solid #e8ebf0;
    border-radius: 12px;
    overflow: hidden;
    box-shadow: 0 3px 12px rgba(28,39,56,.04);
    margin-bottom: 24px;
}

.manager-table-header {
    min-height: 58px;
    padding: 0 20px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    border-bottom: 1px solid #edf0f4;
}

.manager-table-header h3 {
    margin: 0;
    font-size: 14px;
    color: #273142;
}

.manager-table-wrapper {
    width: 100%;
    overflow-x: auto;
}

.manager-table {
    width: 100%;
    min-width: 1050px;
    border-collapse: collapse;
}

.manager-table th {
    background: #f8f9fb;
    color: #687386;
    font-size: 11px;
    font-weight: bold;
    padding: 13px 12px;
    text-align: right;
    border-bottom: 1px solid #e7eaf0;
    white-space: nowrap;
}

.manager-table td {
    padding: 13px 12px;
    font-size: 11px;
    color: #465164;
    border-bottom: 1px solid #eef0f3;
    vertical-align: middle;
}

.manager-table tr:last-child td {
    border-bottom: 0;
}

.manager-table tr:hover td {
    background: #fafbfd;
}

.manager-priority,
.manager-status {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    min-height: 25px;
    padding: 0 9px;
    border-radius: 20px;
    font-size: 10px;
    font-weight: bold;
    white-space: nowrap;
}

.priority-low {
    background: #eef7f1;
    color: #4c956c;
}

.priority-normal {
    background: #eef1f5;
    color: #697586;
}

.priority-high {
    background: #fff3df;
    color: #d6810c;
}

.priority-critical {
    background: #fdebec;
    color: #c83b46;
}

.manager-status-new {
    background: #eef1f5;
    color: #697586;
}

.manager-status-assigned {
    background: #eaf2ff;
    color: #2f80ed;
}

.manager-status-progress {
    background: #fff3df;
    color: #d6810c;
}

.manager-status-waiting {
    background: #f0eaff;
    color: #7655d6;
}

.manager-status-closed {
    background: #e8f8ef;
    color: #239653;
}

.manager-empty {
    padding: 35px 20px;
    text-align: center;
    color: #929baa;
    font-size: 12px;
}

@media screen and (max-width: 1200px) {
    .manager-attention-grid {
        grid-template-columns: repeat(3, minmax(0, 1fr));
    }
}

@media screen and (max-width: 800px) {
    .manager-attention-grid {
        grid-template-columns: repeat(2, minmax(0, 1fr));
    }

    .manager-attention-header,
    .manager-table-header {
        padding: 0 14px;
    }
}

@media screen and (max-width: 480px) {
    .manager-attention-grid {
        grid-template-columns: 1fr;
    }

    .manager-attention-body {
        padding: 10px;
    }

    .manager-attention-item {
        min-height: 54px;
    }
}

</style>

<div class="page-header">

    <div>
        <h2>خوش آمدید</h2>
        <p>نمای کلی وضعیت درخواست‌های پشتیبانی فناوری اطلاعات</p>
    </div>

    <a href="CreateTicket.aspx" class="btn btn-primary">
        ＋ ثبت درخواست جدید
    </a>

</div>


<div class="manager-attention-card">

    <div class="manager-attention-header">

        <h3>وضعیت درخواست‌ها</h3>

        <span>نمای کلی کارتابل</span>

    </div>

    <div class="manager-attention-body">

        <div class="manager-attention-grid">


            <a href="Tickets.aspx?status=New"
               class="manager-attention-item">

                <div class="manager-attention-icon attention-blue">◷</div>

                <div class="manager-attention-info">

                    <span class="manager-attention-number">
                        <asp:Label ID="lblNewCount" runat="server" Text="0" />
                    </span>

                    <span class="manager-attention-label">
                        درخواست جدید
                    </span>

                </div>

            </a>


            <a href="Tickets.aspx?status=Assigned"
               class="manager-attention-item">

                <div class="manager-attention-icon attention-orange">↗</div>

                <div class="manager-attention-info">

                    <span class="manager-attention-number">
                        <asp:Label ID="lblAssignedSubCount" runat="server" Text="0" />
                    </span>

                    <span class="manager-attention-label">
                        ارجاع شده
                    </span>

                </div>

            </a>


            <a href="Tickets.aspx?status=InProgress"
               class="manager-attention-item">

                <div class="manager-attention-icon attention-orange">⚙</div>

                <div class="manager-attention-info">

                    <span class="manager-attention-number">
                        <asp:Label ID="lblProcessingSubCount" runat="server" Text="0" />
                    </span>

                    <span class="manager-attention-label">
                        در حال رسیدگی
                    </span>

                </div>

            </a>


            <a href="Tickets.aspx?status=WaitingConfirmation"
               class="manager-attention-item">

                <div class="manager-attention-icon attention-purple">?</div>

                <div class="manager-attention-info">

                    <span class="manager-attention-number">
                        <asp:Label ID="lblWaitingCount" runat="server" Text="0" />
                    </span>

                    <span class="manager-attention-label">
                        منتظر تأیید کاربر
                    </span>

                </div>

            </a>


            <a href="Tickets.aspx"
               class="manager-attention-item">

                <div class="manager-attention-icon attention-orange">⚡</div>

                <div class="manager-attention-info">

                    <span class="manager-attention-number">
                        <asp:Label ID="lblInProgressCount" runat="server" Text="0" />
                    </span>

                    <span class="manager-attention-label">
                        مجموع در حال پیگیری
                    </span>

                    <span class="manager-attention-sub">
                        ارجاع شده + در حال رسیدگی
                    </span>

                </div>

            </a>


            <a href="Tickets.aspx?status=Closed"
               class="manager-attention-item">

                <div class="manager-attention-icon attention-green">✓</div>

                <div class="manager-attention-info">

                    <span class="manager-attention-number">
                        <asp:Label ID="lblClosedCount" runat="server" Text="0" />
                    </span>

                    <span class="manager-attention-label">
                        خاتمه یافته
                    </span>

                </div>

            </a>


        </div>

    </div>

</div>


<div class="manager-table-card">

    <div class="manager-table-header">

        <h3>آخرین درخواست‌ها</h3>

        <a href="Tickets.aspx"
           class="btn btn-secondary btn-small">
            مشاهده همه
        </a>

    </div>

    <div class="manager-table-wrapper">

        <asp:GridView
            ID="gvRecentTickets"
            runat="server"
            AutoGenerateColumns="false"
            CssClass="manager-table"
            GridLines="None"
            EmptyDataText="درخواستی ثبت نشده است.">

            <Columns>

                <asp:HyperLinkField
                    DataNavigateUrlFields="TicketId"
                    DataNavigateUrlFormatString="TicketDetails.aspx?id={0}"
                    DataTextField="TicketId"
                    HeaderText="شماره" />

                <asp:BoundField
                    DataField="Subject"
                    HeaderText="موضوع" />

                <asp:BoundField
                    DataField="RequesterName"
                    HeaderText="درخواست‌کننده" />

                <asp:BoundField
                    DataField="DepartmentName"
                    HeaderText="واحد" />

                <asp:BoundField
                    DataField="Category"
                    HeaderText="دسته‌بندی" />

                <asp:TemplateField HeaderText="اولویت">

                    <ItemTemplate>

                        <span class='<%# GetPriorityCssClass(Eval("PriorityValue").ToString()) %>'>
                            <%# Eval("Priority") %>
                        </span>

                    </ItemTemplate>

                </asp:TemplateField>

                <asp:TemplateField HeaderText="وضعیت">

                    <ItemTemplate>

                        <span class='<%# GetStatusCssClass(Eval("StatusValue").ToString()) %>'>
                            <%# Eval("Status") %>
                        </span>

                    </ItemTemplate>

                </asp:TemplateField>

                <asp:BoundField
                    DataField="CreatedAt"
                    HeaderText="تاریخ ثبت"
                    DataFormatString="{0:yyyy/MM/dd HH:mm}" />

            </Columns>

            <EmptyDataRowStyle CssClass="manager-empty" />

        </asp:GridView>

    </div>

</div>


<div class="manager-table-card">

    <div class="manager-table-header">

        <h3>آخرین درخواست‌های خاتمه‌یافته</h3>

        <a href="Tickets.aspx?status=Closed"
           class="btn btn-secondary btn-small">
            مشاهده همه
        </a>

    </div>

    <div class="manager-table-wrapper">

        <asp:GridView
            ID="gvClosedTickets"
            runat="server"
            AutoGenerateColumns="false"
            CssClass="manager-table"
            GridLines="None"
            EmptyDataText="هنوز درخواست خاتمه‌یافته‌ای وجود ندارد.">

            <Columns>

                <asp:HyperLinkField
                    DataNavigateUrlFields="TicketId"
                    DataNavigateUrlFormatString="TicketDetails.aspx?id={0}"
                    DataTextField="TicketId"
                    HeaderText="شماره" />

                <asp:BoundField
                    DataField="Subject"
                    HeaderText="موضوع" />

                <asp:BoundField
                    DataField="RequesterName"
                    HeaderText="درخواست‌کننده" />

                <asp:BoundField
                    DataField="DepartmentName"
                    HeaderText="واحد" />

                <asp:BoundField
                    DataField="Category"
                    HeaderText="دسته‌بندی" />

                <asp:TemplateField HeaderText="اولویت">

                    <ItemTemplate>

                        <span class='<%# GetPriorityCssClass(Eval("PriorityValue").ToString()) %>'>
                            <%# Eval("Priority") %>
                        </span>

                    </ItemTemplate>

                </asp:TemplateField>

                <asp:BoundField
                    DataField="ClosedAt"
                    HeaderText="تاریخ خاتمه"
                    DataFormatString="{0:yyyy/MM/dd HH:mm}" />

            </Columns>

            <EmptyDataRowStyle CssClass="manager-empty" />

        </asp:GridView>

    </div>

</div>

</asp:Content>
