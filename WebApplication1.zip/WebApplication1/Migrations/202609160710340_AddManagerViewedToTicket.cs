namespace WebApplication1.Migrations
{
    using System.Data.Entity.Migrations;

    public partial class AddManagerViewedToTicket : DbMigration
    {
        public override void Up()
        {
            AddColumn(
                "dbo.Tickets",
                "ManagerViewed",
                c => c.Boolean(nullable: false));

            AddColumn(
                "dbo.Tickets",
                "ManagerViewedAt",
                c => c.DateTime());
        }

        public override void Down()
        {
            DropColumn(
                "dbo.Tickets",
                "ManagerViewedAt");

            DropColumn(
                "dbo.Tickets",
                "ManagerViewed");
        }
    }
}