﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="Default.aspx.cs" Inherits="WebApplication1.Default" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml" lang="fa" dir="rtl">
<head runat="server">
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <title>سامانه خدمات فناوری اطلاعات</title>

    <style type="text/css">

        @font-face {
            font-family: 'Vazirmatn';
            src: url('Content/fonts/Vazirmatn[wght].woff2') format('woff2');
            font-weight: 100 900;
            font-style: normal;
            font-display: swap;
        }

        * {
            box-sizing: border-box;
        }

        html,
        body {
            margin: 0;
            padding: 0;
            min-height: 100%;
        }

        body {
            direction: rtl;
            font-family: 'Vazirmatn', Tahoma, Arial, sans-serif !important;
            background: #f4f7f9;
            color: #25313c;
        }

        button,
        input,
        select,
        textarea,
        a,
        div,
        span,
        p,
        h1,
        h2,
        h3 {
            font-family: 'Vazirmatn', Tahoma, Arial, sans-serif !important;
        }

        a {
            text-decoration: none;
        }

        .page {
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        /* =========================
           HEADER
           ========================= */

        .top-header {
            height: 76px;
            background: #ffffff;
            border-bottom: 1px solid #e6ebef;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 7%;
        }

        .brand {
            display: flex;
            align-items: center;
        }

        .brand-logo {
            width: 46px;
            height: 46px;
            border-radius: 11px;
            background: #176b78;
            color: #ffffff;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 14px;
            font-weight: 800;
            margin-left: 12px;
            box-shadow: 0 5px 14px rgba(23, 107, 120, .18);
        }

        .brand-text {
            display: flex;
            flex-direction: column;
        }

        .brand-title {
            font-size: 15px;
            font-weight: 800;
            color: #1f2e38;
            margin-bottom: 3px;
        }

        .brand-subtitle {
            font-size: 10px;
            color: #8997a1;
        }

        .system-status {
            display: flex;
            align-items: center;
            color: #64747e;
            font-size: 10px;
        }

        .status-dot {
            width: 8px;
            height: 8px;
            border-radius: 50%;
            background: #27ae60;
            margin-left: 7px;
            box-shadow: 0 0 0 4px rgba(39, 174, 96, .10);
        }

        /* =========================
           MAIN
           ========================= */

        .main {
            width: 100%;
            max-width: 1180px;
            margin: 0 auto;
            padding: 52px 25px 40px;
            flex: 1;
        }

        .main-card {
            background: #ffffff;
            border: 1px solid #e4eaee;
            border-radius: 18px;
            overflow: hidden;
            box-shadow: 0 12px 35px rgba(35, 52, 63, .06);
            display: grid;
            grid-template-columns: 1.45fr .75fr;
            min-height: 390px;
        }

        /* =========================
           WELCOME
           ========================= */

        .welcome {
            padding: 55px 55px 45px;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }

        .welcome-label {
            display: inline-flex;
            align-items: center;
            width: fit-content;
            background: #edf7f8;
            color: #176b78;
            border-radius: 20px;
            padding: 6px 12px;
            font-size: 10px;
            font-weight: 700;
            margin-bottom: 20px;
        }

        .welcome-label span {
            width: 6px;
            height: 6px;
            border-radius: 50%;
            background: #176b78;
            margin-left: 6px;
        }

        .welcome h1 {
            margin: 0;
            color: #1d2c36;
            font-size: 29px;
            line-height: 1.8;
            font-weight: 800;
        }

        .welcome h1 strong {
            color: #176b78;
            font-weight: 800;
        }

        .welcome-description {
            max-width: 620px;
            margin: 14px 0 0;
            color: #73818b;
            font-size: 13px;
            line-height: 2.2;
        }

        .welcome-divider {
            width: 55px;
            height: 3px;
            background: #176b78;
            border-radius: 5px;
            margin: 23px 0;
        }

        .organization {
            color: #5e6d77;
            font-size: 11px;
            line-height: 1.9;
        }

        /* =========================
           LOGIN PANEL
           ========================= */

        .login-panel {
            background: #f7fafb;
            border-right: 1px solid #e7edef;
            padding: 45px 35px;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }

        .login-icon {
            width: 56px;
            height: 56px;
            border-radius: 14px;
            background: #e8f4f5;
            color: #176b78;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 23px;
            margin-bottom: 18px;
        }

        .login-panel h2 {
            margin: 0 0 8px;
            color: #25343e;
            font-size: 19px;
            font-weight: 800;
        }

        .login-panel p {
            margin: 0 0 24px;
            color: #84919a;
            font-size: 11px;
            line-height: 1.9;
        }

        .login-button {
            width: 100%;
            height: 45px;
            border: 0;
            border-radius: 8px;
            background: #176b78;
            color: #ffffff;
            cursor: pointer;
            font-size: 12px;
            font-weight: 700;
            transition: all .2s ease;
        }

        .login-button:hover {
            background: #125966;
            box-shadow: 0 7px 18px rgba(23, 107, 120, .17);
        }

        .login-note {
            margin-top: 15px !important;
            margin-bottom: 0 !important;
            text-align: center;
            font-size: 9px !important;
            color: #9ba6ad !important;
        }

        /* =========================
           SERVICES
           ========================= */

        .services {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 15px;
            margin-top: 20px;
        }

        .service {
            background: #ffffff;
            border: 1px solid #e5ebee;
            border-radius: 12px;
            padding: 19px 18px;
            display: flex;
            align-items: center;
            min-height: 82px;
            transition: all .2s ease;
        }

        .service:hover {
            border-color: #cbdfe2;
            transform: translateY(-2px);
            box-shadow: 0 7px 20px rgba(35, 52, 63, .05);
        }

        .service-icon {
            width: 40px;
            height: 40px;
            border-radius: 10px;
            background: #edf7f8;
            color: #176b78;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 17px;
            margin-left: 12px;
            flex-shrink: 0;
        }

        .service-text strong {
            display: block;
            color: #35444e;
            font-size: 11px;
            margin-bottom: 4px;
        }

        .service-text span {
            display: block;
            color: #8b979f;
            font-size: 9px;
            line-height: 1.7;
        }

        /* =========================
           FOOTER
           ========================= */

        .footer {
            min-height: 58px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #98a3aa;
            font-size: 9px;
            text-align: center;
            padding: 15px;
        }

        /* =========================
           RESPONSIVE
           ========================= */

        @media screen and (max-width: 850px) {

            .top-header {
                padding: 0 25px;
            }

            .main {
                padding-top: 30px;
            }

            .main-card {
                grid-template-columns: 1fr;
            }

            .login-panel {
                border-right: 0;
                border-top: 1px solid #e7edef;
            }

            .welcome {
                padding: 40px 35px;
            }

            .login-panel {
                padding: 35px;
            }
        }

        @media screen and (max-width: 600px) {

            .top-header {
                height: 68px;
                padding: 0 15px;
            }

            .brand-title {
                font-size: 13px;
            }

            .brand-subtitle {
                font-size: 8px;
            }

            .system-status {
                display: none;
            }

            .main {
                padding: 20px 12px;
            }

            .main-card {
                border-radius: 13px;
            }

            .welcome {
                padding: 32px 23px;
            }

            .welcome h1 {
                font-size: 22px;
            }

            .welcome-description {
                font-size: 11px;
            }

            .login-panel {
                padding: 28px 23px;
            }

            .services {
                grid-template-columns: 1fr;
            }
        }

    </style>
</head>

<body>

    <form id="form1" runat="server">

        <div class="page">

            <!-- HEADER -->
            <header class="top-header">

                <div class="brand">

                    <div class="brand-logo">
                        IT
                    </div>

                    <div class="brand-text">

                        <div class="brand-title">
                            سامانه خدمات فناوری اطلاعات
                        </div>

                        <div class="brand-subtitle">
                            مدیریت و پیگیری درخواست‌های فناوری اطلاعات
                        </div>

                    </div>

                </div>

                <div class="system-status">
                    <span class="status-dot"></span>
                    سامانه فعال است
                </div>

            </header>


            <!-- MAIN -->
            <main class="main">

                <section class="main-card">

                    <!-- WELCOME -->
                    <div class="welcome">

                        <div class="welcome-label">
                            <span></span>
                            پرتال خدمات فناوری اطلاعات
                        </div>

                        <h1>
                            به <strong>سامانه خدمات فناوری اطلاعات</strong>
                            خوش آمدید
                        </h1>

                        <p class="welcome-description">
                            در این سامانه می‌توانید درخواست‌ها و مشکلات فناوری اطلاعات
                            را ثبت کرده، وضعیت رسیدگی به آن‌ها را پیگیری نموده و
                            نتیجه انجام خدمات را مشاهده و تأیید کنید.
                        </p>

                        <div class="welcome-divider"></div>

                        <div class="organization">
                            سامانه داخلی خدمات فناوری اطلاعات
                        </div>

                    </div>


                    <!-- LOGIN -->
                    <div class="login-panel">

                        <div class="login-icon">
                            ↪
                        </div>

                        <h2>
                            ورود به سامانه
                        </h2>

                        <p>
                            برای ثبت و پیگیری درخواست‌های خود وارد حساب کاربری شوید.
                        </p>

                        <asp:Button
                            ID="btnLogin"
                            runat="server"
                            Text="ورود به سامانه"
                            CssClass="login-button"
                            PostBackUrl="~/Login.aspx" />

                        <p class="login-note">
                            دسترسی بر اساس سطح کاربری شما تعیین می‌شود.
                        </p>

                    </div>

                </section>


                <!-- SERVICES -->
                <section class="services">

                    <div class="service">

                        <div class="service-icon">
                            +
                        </div>

                        <div class="service-text">

                            <strong>
                                ثبت درخواست
                            </strong>

                            <span>
                                ثبت سریع مشکل یا درخواست جدید
                            </span>

                        </div>

                    </div>


                    <div class="service">

                        <div class="service-icon">
                            ✓
                        </div>

                        <div class="service-text">

                            <strong>
                                پیگیری درخواست
                            </strong>

                            <span>
                                مشاهده وضعیت و روند رسیدگی
                            </span>

                        </div>

                    </div>


                    <div class="service">

                        <div class="service-icon">
                            ★
                        </div>

                        <div class="service-text">

                            <strong>
                                تأیید خدمت
                            </strong>

                            <span>
                                تأیید نتیجه انجام درخواست
                            </span>

                        </div>

                    </div>

                </section>

            </main>


            <!-- FOOTER -->
            <footer class="footer">
                سامانه خدمات فناوری اطلاعات
            </footer>

        </div>

    </form>

</body>
</html>