﻿<%@ Page Title="کارتابل درخواست‌ها"
    Language="C#"
    MasterPageFile="~/Site.Master"
    AutoEventWireup="true"
    CodeBehind="SpecialistTickets.aspx.cs"
    Inherits="WebApplication1.SpecialistTickets" %>

<asp:Content ID="Content1"
    ContentPlaceHolderID="TitleContent"
    runat="server">
    کارتابل درخواست‌ها
</asp:Content>

<asp:Content ID="Content2"
    ContentPlaceHolderID="HeadContent"
    runat="server">

    <style>

        .specialist-stats {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 18px;
            margin-bottom: 24px;
        }

        .specialist-stat {
            background: #ffffff;
            border-radius: 14px;
            padding: 20px 22px;
            box-shadow: 0 3px 15px rgba(0,0,0,.06);
            border: 1px solid #eef0f4;
        }

        .specialist-stat-title {
            font-size: 13px;
            color: #777;
            margin-bottom: 10px;
        }

        .specialist-stat-number {
            font-size: 28px;
            font-weight: 700;
            color: #222;
        }

        .specialist-card {
            background: #ffffff;
            border-radius: 14px;
            padding: 24px;
            box-shadow: 0 3px 15px rgba(0,0,0,.06);
            border: 1px solid #eef0f4;
        }

        .specialist-card-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 20px;
        }

        .specialist-card-header h3 {
            margin: 0;
            font-size: 18px;
            color: #222;
        }

        .specialist-card-header span {
            font-size: 13px;
            color: #777;
        }

        .ticket-table {
            width: 100%;
            border-collapse: collapse;
        }

        .ticket-table th {
            background: #f7f8fb;
            color: #555;
            font-size: 13px;
            font-weight: 600;
            padding: 13px 12px;
            border-bottom: 1px solid #e7eaf0;
            text-align: right;
        }

        .ticket-table td {
            padding: 14px 12px;
            border-bottom: 1px solid #edf0f5;
            color: #444;
            font-size: 13px;
            vertical-align: middle;
        }

        .ticket-table tr:hover td {
            background: #fafbfc;
        }

        .ticket-link {
            color: #4f46e5;
            text-decoration: none;
            font-weight: 600;
        }

        .ticket-link:hover {
            text-decoration: underline;
        }

        .priority {
            display: inline-block;
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 11px;
            font-weight: 600;
        }

        .priority-low {
            background: #f1f5f9;
            color: #64748b;
        }

        .priority-normal {
            background: #eef2ff;
            color: #4f46e5;
        }

        .priority-high {
            background: #fff7ed;
            color: #c2410c;
        }

        .priority-critical {
            background: #fef2f2;
            color: #dc2626;
        }

        .status {
            display: inline-block;
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 11px;
            font-weight: 600;
        }

        .status-assigned {
            background: #eff6ff;
            color: #2563eb;
        }

        .status-progress {
            background: #fefce8;
            color: #a16207;
        }

        .status-resolved {
            background: #f0fdf4;
            color: #16a34a;
        }

        .status-waiting {
            background: #fff7ed;
            color: #ea580c;
        }

        .empty-message {
            text-align: center;
            padding: 40px 20px;
            color: #888;
            font-size: 14px;
        }

        @media (max-width: 900px) {

            .specialist-stats {
                grid-template-columns: repeat(2, 1fr);
            }

            .specialist-card {
                overflow-x: auto;
            }

            .ticket-table {
                min-width: 800px;
            }
        }

        @media (max-width: 600px) {

            .specialist-stats {
                grid-template-columns: 1fr;
            }
        }

    </style>

</asp:Content>

<asp:Content ID="Content3"
    ContentPlaceHolderID="PageHeader"
    runat="server">

    <div class="page-title">
        <h1>کارتابل درخواست‌ها</h1>
        <p>درخواست‌های ارجاع‌شده به شما</p>
    </div>

</asp:Content>

<asp:Content ID="Content4"
    ContentPlaceHolderID="MainContent"
    runat="server">

    <!-- آمار کارشناس -->

    <div class="specialist-stats">

        <div class="specialist-stat">

            <div class="specialist-stat-title">
                کل درخواست‌های ارجاع‌شده
            </div>

            <asp:Label
                ID="lblTotalCount"
                runat="server"
                CssClass="specialist-stat-number"
                Text="0">
            </asp:Label>

        </div>


        <div class="specialist-stat">

            <div class="specialist-stat-title">
                ارجاع‌شده
            </div>

            <asp:Label
                ID="lblAssignedCount"
                runat="server"
                CssClass="specialist-stat-number"
                Text="0">
            </asp:Label>

        </div>


        <div class="specialist-stat">

            <div class="specialist-stat-title">
                در حال رسیدگی
            </div>

            <asp:Label
                ID="lblInProgressCount"
                runat="server"
                CssClass="specialist-stat-number"
                Text="0">
            </asp:Label>

        </div>


        <div class="specialist-stat">

            <div class="specialist-stat-title">
                منتظر تأیید کاربر
            </div>

            <asp:Label
                ID="lblWaitingCount"
                runat="server"
                CssClass="specialist-stat-number"
                Text="0">
            </asp:Label>

        </div>

    </div>


    <!-- کارتابل -->

    <div class="specialist-card">

        <div class="specialist-card-header">

            <h3>
                درخواست‌های ارجاع‌شده به من
            </h3>

            <span>
                فهرست درخواست‌های قابل رسیدگی
            </span>

        </div>


        <asp:GridView
            ID="gvTickets"
            runat="server"
            AutoGenerateColumns="False"
            CssClass="ticket-table"
            GridLines="None"
            EmptyDataText="در حال حاضر هیچ درخواست ارجاع‌شده‌ای برای شما وجود ندارد.">

            <Columns>

                <asp:BoundField
                    DataField="TicketId"
                    HeaderText="شماره" />


                <asp:TemplateField
                    HeaderText="عنوان">

                    <ItemTemplate>

                        <asp:HyperLink
                            ID="lnkTicket"
                            runat="server"
                            Text='<%# Eval("Subject") %>'
                            NavigateUrl='<%# "SpecialistTicketDetails.aspx?id=" + Eval("TicketId") %>'
                            CssClass="ticket-link">
                        </asp:HyperLink>

                    </ItemTemplate>

                </asp:TemplateField>


                <asp:BoundField
                    DataField="RequesterName"
                    HeaderText="درخواست‌کننده" />


                <asp:BoundField
                    DataField="Category"
                    HeaderText="دسته‌بندی" />


                <asp:TemplateField
                    HeaderText="اولویت">

                    <ItemTemplate>

                        <span class='<%# Eval("PriorityCss") %>'>
                            <%# Eval("PriorityText") %>
                        </span>

                    </ItemTemplate>

                </asp:TemplateField>


                <asp:TemplateField
                    HeaderText="وضعیت">

                    <ItemTemplate>

                        <span class='<%# Eval("StatusCss") %>'>
                            <%# Eval("StatusText") %>
                        </span>

                    </ItemTemplate>

                </asp:TemplateField>


                <asp:BoundField
                    DataField="AssignedAtText"
                    HeaderText="تاریخ ارجاع" />

            </Columns>

        </asp:GridView>

    </div>

</asp:Content>