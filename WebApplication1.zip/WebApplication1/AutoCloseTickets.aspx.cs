﻿using System;
using System.Linq;
using WebApplication1.Models;

namespace WebApplication1
{
    public partial class AutoCloseTickets :
        System.Web.UI.Page
    {
        protected void Page_Load(
            object sender,
            EventArgs e)
        {
            /*
             * این صفحه فقط باید از روی همان
             * سرور اجرا شود.
             *
             * در محیط توسعه می‌توان از localhost
             * و در محیط IIS نیز از خود سرور اجرا کرد.
             */
            if (!Request.IsLocal)
            {
                Response.StatusCode = 403;

                Response.Write(
                    "Access denied.");

                Response.End();

                return;
            }


            ProcessAutoClose();
        }


        private void ProcessAutoClose()
        {
            int processedCount = 0;

            DateTime now =
                DateTime.Now;


            /*
             * تیکت‌هایی که منتظر تأیید کاربر هستند.
             */
            using (var db =
                new ApplicationDbContext())
            {
                var waitingTickets =
                    db.Tickets
                        .Where(
                            t =>
                                t.Status ==
                                "WaitingConfirmation")
                        .ToList();


                foreach (var ticket in
                    waitingTickets)
                {
                    /*
                     * آخرین تاریخچه‌ای که وضعیت تیکت
                     * را به WaitingConfirmation تغییر داده
                     * پیدا می‌شود.
                     */
                    var waitingHistory =
                        db.TicketHistory
                            .Where(
                                h =>
                                    h.TicketId ==
                                    ticket.TicketId &&

                                    h.NewStatus ==
                                    "WaitingConfirmation")
                            .OrderByDescending(
                                h =>
                                    h.HistoryDate)
                            .FirstOrDefault();


                    /*
                     * اگر تاریخچه مربوط به ورود به
                     * وضعیت انتظار وجود نداشته باشد،
                     * برای اطمینان کاری انجام نمی‌دهیم.
                     */
                    if (waitingHistory == null)
                        continue;


                    /*
                     * سه روز از زمان ارسال برای تأیید
                     * گذشته است؟
                     */
                    DateTime autoCloseDate =
                        waitingHistory.HistoryDate
                            .AddDays(3);


                    if (now < autoCloseDate)
                        continue;


                    /*
                     * قبل از تغییر وضعیت،
                     * دوباره وضعیت را بررسی می‌کنیم.
                     */
                    if (ticket.Status !=
                        "WaitingConfirmation")
                    {
                        continue;
                    }


                    /*
                     * تأیید خودکار
                     */
                    ticket.Status =
                        "Closed";


                    ticket.UserConfirmed =
                        true;


                    ticket.AutoClosed =
                        true;


                    /*
                     * ثبت TicketConfirmation
                     */
                    var confirmation =
                        new TicketConfirmation
                        {
                            TicketId =
                                ticket.TicketId,

                            /*
                             * در تأیید خودکار،
                             * UserId درخواست‌کننده است.
                             */
                            UserId =
                                ticket.UserId,

                            ConfirmationStatus =
                                "Confirmed",

                            Comment =
                                "تأیید به صورت خودکار پس از گذشت ۳ روز انجام شد.",

                            ConfirmationDate =
                                now,

                            AutoConfirmed =
                                true,

                            CreatedAt =
                                now
                        };


                    db.TicketConfirmations.Add(
                        confirmation);


                    /*
                     * ثبت تاریخچه
                     */
                    var history =
                        new TicketHistory
                        {
                            TicketId =
                                ticket.TicketId,

                            /*
                             * چون این عملیات توسط سیستم
                             * انجام شده است، UserId را
                             * خالی می‌گذاریم.
                             */
                            UserId =
                                null,

                            OldStatus =
                                "WaitingConfirmation",

                            NewStatus =
                                "Closed",

                            Description =
                                "به دلیل عدم تأیید درخواست‌کننده طی ۳ روز، درخواست به صورت خودکار تأیید و خاتمه یافت.",

                            HistoryDate =
                                now
                        };


                    db.TicketHistory.Add(
                        history);


                    processedCount++;
                }


                if (processedCount > 0)
                {
                    db.SaveChanges();
                }
            }


            lblResult.Text =
                "Auto Close completed. " +
                "Processed tickets: " +
                processedCount.ToString();
        }
    }
}