﻿using System;
using System.Linq;
using System.Web.UI;
using Microsoft.AspNet.Identity;
using WebApplication1.Models;

namespace WebApplication1
{
    public partial class UserDashboard : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Request.IsAuthenticated)
            {
                Response.Redirect("~/Login.aspx");
                return;
            }

            if (User.IsInRole("Manager") || User.IsInRole("Specialist"))
            {
                Response.Redirect("~/Login.aspx");
                return;
            }

            if (!IsPostBack)
            {
                LoadDashboard();
            }
        }


        private void LoadDashboard()
        {
            string currentUserId =
                User.Identity.GetUserId();

            if (string.IsNullOrEmpty(currentUserId))
                return;


            using (var db =
                new ApplicationDbContext())
            {

                // ---------------------------------
                // آمار درخواست‌ها
                // ---------------------------------

                lblTotalCount.Text =
                    db.Tickets
                        .Count(t =>
                            t.UserId == currentUserId)
                        .ToString();


                lblNewCount.Text =
                    db.Tickets
                        .Count(t =>
                            t.UserId == currentUserId &&
                            t.Status == "New")
                        .ToString();


                lblInProgressCount.Text =
                    db.Tickets
                        .Count(t =>
                            t.UserId == currentUserId &&
                            (t.Status == "Assigned" ||
                             t.Status == "InProgress"))
                        .ToString();


                // ---------------------------------
                // درخواست‌های منتظر تأیید
                // ---------------------------------

                int waitingCount =
                    db.Tickets
                        .Count(t =>
                            t.UserId == currentUserId &&
                            t.Status ==
                                "WaitingConfirmation");


                lblWaitingCount.Text =
                    waitingCount.ToString();


                // ---------------------------------
                // نمایش هشدار منتظر تأیید
                // ---------------------------------

                if (waitingCount > 0)
                {
                    pnlWaitingAlert.Visible = true;


                    if (waitingCount == 1)
                    {
                        lblWaitingAlert.Text =
                            "یک درخواست منتظر تأیید شماست. " +
                            "لطفاً نتیجه رسیدگی را بررسی و تأیید یا رد کنید.";
                    }
                    else
                    {
                        lblWaitingAlert.Text =
                            "تعداد " +
                            waitingCount +
                            " درخواست منتظر تأیید شماست. " +
                            "لطفاً نتیجه رسیدگی را بررسی و تأیید یا رد کنید.";
                    }
                }
                else
                {
                    pnlWaitingAlert.Visible = false;
                    lblWaitingAlert.Text = "";
                }


                // ---------------------------------
                // درخواست‌های خاتمه‌یافته
                // ---------------------------------

                lblClosedCount.Text =
                    db.Tickets
                        .Count(t =>
                            t.UserId == currentUserId &&
                            t.Status == "Closed")
                        .ToString();
            }


            // ---------------------------------
            // بارگذاری درخواست‌ها
            // ---------------------------------

            LoadTickets();
        }


        private void LoadTickets()
        {
            string currentUserId =
                User.Identity.GetUserId();

            if (string.IsNullOrEmpty(currentUserId))
                return;


            using (var db =
                new ApplicationDbContext())
            {

                var tickets =
                    db.Tickets

                        .Where(t =>
                            t.UserId == currentUserId)

                        .OrderByDescending(t =>
                            t.Status ==
                            "WaitingConfirmation")

                        .ThenByDescending(t =>
                            t.CreatedAt)

                        .Select(t => new
                        {
                            t.TicketId,
                            t.Subject,
                            t.Category,
                            t.Priority,
                            t.Status,
                            t.CreatedAt
                        })

                        .ToList()

                        .Select(t => new
                        {
                            t.TicketId,
                            t.Subject,

                            Category =
                                GetCategoryText(
                                    t.Category),

                            PriorityText =
                                GetPriorityText(
                                    t.Priority),

                            StatusText =
                                GetStatusText(
                                    t.Status),

                            CreatedAtText =
                                t.CreatedAt
                                    .ToString(
                                        "yyyy/MM/dd HH:mm")
                        })

                        .ToList();


                gvTickets.DataSource =
                    tickets;

                gvTickets.DataBind();
            }
        }


        // =========================================
        // تغییر صفحه GridView
        // =========================================

        protected void gvTickets_PageIndexChanging(
            object sender,
            System.Web.UI.WebControls.GridViewPageEventArgs e)
        {
            gvTickets.PageIndex = e.NewPageIndex;

            LoadTickets();
        }


        // =========================================
        // متن دسته‌بندی
        // =========================================

        private string GetCategoryText(
            string category)
        {
            switch (category)
            {
                case "نرم‌افزار":
                    return "نرم‌افزار";

                case "سخت‌افزار":
                    return "سخت‌افزار";

                case "شبکه":
                    return "شبکه";

                case "امنیت":
                    return "امنیت";

                case "سایر":
                    return "سایر";

                default:
                    return category;
            }
        }


        // =========================================
        // متن اولویت
        // =========================================

        private string GetPriorityText(
            string priority)
        {
            switch (priority)
            {
                case "Low":
                    return "کم";

                case "Normal":
                    return "عادی";

                case "High":
                    return "زیاد";

                case "Critical":
                    return "بحرانی";

                default:
                    return priority;
            }
        }


        // =========================================
        // متن وضعیت
        // =========================================

        private string GetStatusText(
            string status)
        {
            switch (status)
            {
                case "New":
                    return "جدید";

                case "Assigned":
                    return "ارجاع شده";

                case "InProgress":
                    return "در حال رسیدگی";

                case "WaitingConfirmation":
                    return "منتظر تأیید کاربر";

                case "Closed":
                    return "خاتمه یافته";

                default:
                    return status;
            }
        }
    }
}