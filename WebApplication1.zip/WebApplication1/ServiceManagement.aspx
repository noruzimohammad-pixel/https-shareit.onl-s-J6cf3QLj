﻿<%@ Page Title="مدیریت ساختار خدمات"
    Language="C#"
    MasterPageFile="~/Site.Master"
    AutoEventWireup="true"
    CodeBehind="ServiceManagement.aspx.cs"
    Inherits="WebApplication1.ServiceManagement" %>

<asp:Content ID="Content1" ContentPlaceHolderID="HeadContent" runat="server">

<style type="text/css">

    .service-page {
        direction: rtl;
        font-family: Vazirmatn, Tahoma, Arial, sans-serif;
        padding: 20px;
        color: #354052;
    }

    .service-intro {
        background: linear-gradient(135deg, #f7faff, #ffffff);
        border: 1px solid #e4eaf2;
        border-radius: 14px;
        padding: 18px 20px;
        margin-bottom: 18px;
        box-shadow: 0 3px 12px rgba(35, 55, 80, .04);
    }

    .service-title {
        margin: 0 0 7px 0;
        font-size: 19px;
        font-weight: 800;
        color: #293548;
    }

    .service-desc {
        margin: 0;
        color: #788395;
        font-size: 11px;
        line-height: 2;
    }

    .service-layout {
        display: grid;
        grid-template-columns: 360px minmax(0, 1fr);
        gap: 18px;
        align-items: start;
    }

    .service-card {
        background: #fff;
        border: 1px solid #e4e8ee;
        border-radius: 14px;
        overflow: hidden;
        box-shadow: 0 4px 16px rgba(31, 45, 65, .045);
    }

    .service-card-header {
        min-height: 62px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 10px;
        padding: 0 18px;
        border-bottom: 1px solid #edf0f4;
        background: #fbfcfe;
    }

    .service-card-title {
        margin: 0;
        font-size: 13px;
        font-weight: 800;
        color: #354052;
    }

    .service-card-subtitle {
        font-size: 9px;
        color: #929baa;
        margin-top: 4px;
    }

    .service-card-body {
        padding: 16px;
    }

    .service-btn {
        border: 0;
        border-radius: 8px;
        padding: 8px 13px;
        font-family: inherit;
        font-size: 10px;
        cursor: pointer;
        transition: all .15s ease;
    }

    .service-btn:hover {
        transform: translateY(-1px);
    }

    .service-btn-primary {
        background: #3978c9;
        color: #fff;
    }

    .service-btn-primary:hover {
        background: #2f69b5;
    }

    .service-btn-secondary {
        background: #f1f4f8;
        color: #596579;
        border: 1px solid #e1e5eb;
    }

    .service-btn-success {
        background: #eaf8f0;
        color: #238653;
        border: 1px solid #d2efdf;
    }

    .service-btn-warning {
        background: #fff7e8;
        color: #b57913;
        border: 1px solid #f2dfb7;
    }

    .service-btn-danger {
        background: #fff0f0;
        color: #bd4b4b;
        border: 1px solid #f0d4d4;
    }

    .service-search {
        margin-bottom: 13px;
    }

    .service-input,
    .service-textarea,
    .service-select {
        width: 100%;
        box-sizing: border-box;
        border: 1px solid #dfe4eb;
        border-radius: 8px;
        background: #fff;
        color: #3d4758;
        padding: 9px 11px;
        font-family: inherit;
        font-size: 10px;
        outline: none;
    }

    .service-input:focus,
    .service-textarea:focus,
    .service-select:focus {
        border-color: #77a8df;
        box-shadow: 0 0 0 3px rgba(57, 120, 201, .08);
    }

    .service-textarea {
        min-height: 80px;
        resize: vertical;
        line-height: 1.9;
    }

    .category-list {
        display: flex;
        flex-direction: column;
        gap: 7px;
        max-height: 570px;
        overflow-y: auto;
    }

    .category-item {
        border: 1px solid #e7ebf0;
        border-radius: 10px;
        background: #fff;
        padding: 11px 12px;
        cursor: pointer;
        transition: all .15s ease;
    }

    .category-item:hover {
        border-color: #bdd4ee;
        background: #fafcff;
    }

    .category-item-selected {
        border-color: #8db6e5;
        background: #f2f7fd;
        box-shadow: inset -3px 0 0 #3978c9;
    }

    .category-main {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 10px;
    }

    .category-name {
        font-size: 11px;
        font-weight: 800;
        color: #354052;
    }

    .category-count {
        font-size: 8px;
        color: #738095;
        background: #f1f4f8;
        border-radius: 12px;
        padding: 4px 7px;
        white-space: nowrap;
    }

    .category-description {
        margin-top: 6px;
        color: #8993a2;
        font-size: 9px;
        line-height: 1.8;
    }

    .category-footer {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 8px;
        margin-top: 8px;
    }

    .badge {
        display: inline-block;
        padding: 3px 8px;
        border-radius: 12px;
        font-size: 8px;
        white-space: nowrap;
    }

    .badge-active {
        color: #21824e;
        background: #eaf8f0;
    }

    .badge-inactive {
        color: #7d8592;
        background: #f0f1f3;
    }

    .category-actions {
        display: flex;
        gap: 5px;
    }

    .mini-btn {
        border: 0;
        border-radius: 6px;
        padding: 4px 7px;
        font-family: inherit;
        font-size: 8px;
        cursor: pointer;
    }

    .mini-edit {
        color: #3472bd;
        background: #edf5ff;
        border: 1px solid #d7e7fb;
    }

    .mini-toggle {
        color: #5e6877;
        background: #f4f5f7;
        border: 1px solid #e3e5e8;
    }

    .selected-category {
        border: 1px solid #dce8f6;
        background: #f7faff;
        border-radius: 10px;
        padding: 13px 15px;
        margin-bottom: 15px;
    }

    .selected-category-name {
        font-size: 14px;
        font-weight: 800;
        color: #2f3d52;
    }

    .selected-category-description {
        margin-top: 5px;
        font-size: 9px;
        color: #7d8796;
        line-height: 1.9;
    }

    .topic-list {
        display: flex;
        flex-direction: column;
        gap: 8px;
        margin-top: 12px;
    }

    .topic-item {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 12px;
        padding: 12px 13px;
        border: 1px solid #e7ebf0;
        border-radius: 10px;
        background: #fff;
    }

    .topic-item:hover {
        background: #fcfdff;
        border-color: #d9e3ef;
    }

    .topic-main {
        min-width: 0;
    }

    .topic-name {
        font-size: 11px;
        font-weight: 700;
        color: #3c4759;
    }

    .topic-description {
        margin-top: 4px;
        color: #8b94a1;
        font-size: 9px;
        line-height: 1.8;
    }

    .topic-meta {
        margin-top: 6px;
        display: flex;
        gap: 5px;
        align-items: center;
        flex-wrap: wrap;
    }

    .topic-order {
        display: inline-block;
        padding: 3px 7px;
        border-radius: 10px;
        background: #f3f5f8;
        color: #7b8492;
        font-size: 8px;
    }

    .topic-actions {
        display: flex;
        gap: 5px;
        flex-shrink: 0;
    }

    .form-panel {
        margin-top: 16px;
        padding: 15px;
        border: 1px solid #e3e8ee;
        border-radius: 10px;
        background: #fafbfd;
    }

    .form-title {
        margin: 0 0 13px 0;
        font-size: 12px;
        font-weight: 800;
        color: #354052;
    }

    .form-grid {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 12px;
    }

    .form-group {
        margin-bottom: 0;
    }

    .form-group-full {
        grid-column: 1 / -1;
    }

    .form-label {
        display: block;
        margin-bottom: 6px;
        font-size: 9px;
        font-weight: 700;
        color: #697587;
    }

    .check-row {
        display: flex;
        align-items: center;
        gap: 7px;
        min-height: 38px;
    }

    .check-row label {
        font-size: 10px;
        color: #596577;
    }

    .form-actions {
        display: flex;
        justify-content: flex-start;
        gap: 7px;
        margin-top: 14px;
    }

    .empty-box {
        text-align: center;
        padding: 35px 15px;
        border: 1px dashed #dce2e9;
        border-radius: 10px;
        color: #929baa;
        font-size: 10px;
        background: #fcfdfe;
    }

    .message {
        display: block;
        border-radius: 8px;
        padding: 9px 11px;
        margin-bottom: 12px;
        font-size: 9px;
        line-height: 1.8;
    }

    .message-success {
        background: #eaf8f0;
        color: #237b4d;
        border: 1px solid #d2efdf;
    }

    .message-error {
        background: #fff0f0;
        color: #b84b4b;
        border: 1px solid #f0d5d5;
    }

    .message-warning {
        background: #fff7e8;
        color: #a87417;
        border: 1px solid #f0dfbc;
    }

    @media (max-width: 900px) {

        .service-layout {
            grid-template-columns: 1fr;
        }

        .category-list {
            max-height: 350px;
        }

    }

    @media (max-width: 600px) {

        .service-page {
            padding: 12px;
        }

        .form-grid {
            grid-template-columns: 1fr;
        }

        .form-group-full {
            grid-column: auto;
        }

        .service-card-header {
            padding: 0 13px;
        }

        .service-card-body {
            padding: 12px;
        }

        .topic-item {
            align-items: flex-start;
            flex-direction: column;
        }

        .topic-actions {
            width: 100%;
        }

    }

</style>

</asp:Content>


<asp:Content ID="Content2" ContentPlaceHolderID="PageHeader" runat="server">
    مدیریت ساختار خدمات
</asp:Content>


<asp:Content ID="Content3" ContentPlaceHolderID="MainContent" runat="server">

<div class="service-page">

    <div class="service-intro">

        <h2 class="service-title">
            مدیریت ساختار خدمات
        </h2>

        <p class="service-desc">
            در این بخش حوزه‌های خدمات فناوری اطلاعات و موضوعات مربوط به هر حوزه را مدیریت کنید.
            ابتدا یک حوزه را انتخاب کنید و سپس موضوعات همان حوزه را مشاهده یا ویرایش نمایید.
        </p>

    </div>


    <asp:Label
        ID="lblMessage"
        runat="server"
        Visible="false">
    </asp:Label>


    <div class="service-layout">


        <!-- حوزه‌های خدمات -->

        <div class="service-card">

            <div class="service-card-header">

                <div>

                    <h3 class="service-card-title">
                        حوزه‌های خدمات
                    </h3>

                    <div class="service-card-subtitle">
                        ساختار اصلی خدمات فناوری اطلاعات
                    </div>

                </div>

                <asp:Button
                    ID="btnNewCategory"
                    runat="server"
                    Text="+ افزودن حوزه"
                    CssClass="service-btn service-btn-primary"
                    OnClick="btnNewCategory_Click" />

            </div>


            <div class="service-card-body">

                <div class="service-search">

                    <asp:TextBox
                        ID="txtCategorySearch"
                        runat="server"
                        CssClass="service-input"
                        AutoPostBack="true"
                        OnTextChanged="txtCategorySearch_TextChanged"
                        placeholder="جستجوی حوزه...">
                    </asp:TextBox>

                </div>


                <asp:Repeater
                    ID="rptCategories"
                    runat="server"
                    OnItemCommand="rptCategories_ItemCommand">

                    <HeaderTemplate>

                        <div class="category-list">

                    </HeaderTemplate>


                    <ItemTemplate>

                        <div class='<%# GetCategoryCss(Convert.ToInt32(Eval("ServiceCategoryId"))) %>'>

                            <asp:LinkButton
                                ID="btnSelectCategory"
                                runat="server"
                                CommandName="SelectCategory"
                                CommandArgument='<%# Eval("ServiceCategoryId") %>'
                                CausesValidation="false"
                                Style="display:block;text-decoration:none;color:inherit;">

                                <div class="category-main">

                                    <span class="category-name">
                                        <%# Eval("CategoryName") %>
                                    </span>

                                    <span class="category-count">
                                        <%# Eval("TopicCount") %> موضوع
                                    </span>

                                </div>

                                <div class="category-description">
                                    <%# Eval("Description") %>
                                </div>

                            </asp:LinkButton>


                            <div class="category-footer">

                                <span class='<%# GetActiveBadgeCss(Convert.ToBoolean(Eval("IsActive"))) %>'>
                                    <%# GetActiveText(Convert.ToBoolean(Eval("IsActive"))) %>
                                </span>


                                <div class="category-actions">

                                    <asp:LinkButton
                                        ID="btnEditCategory"
                                        runat="server"
                                        CommandName="EditCategory"
                                        CommandArgument='<%# Eval("ServiceCategoryId") %>'
                                        CausesValidation="false"
                                        CssClass="mini-btn mini-edit">
                                        ویرایش
                                    </asp:LinkButton>


                                    <asp:LinkButton
                                        ID="btnToggleCategory"
                                        runat="server"
                                        CommandName="ToggleCategory"
                                        CommandArgument='<%# Eval("ServiceCategoryId") %>'
                                        CausesValidation="false"
                                        CssClass="mini-btn mini-toggle">
                                        <%# GetToggleText(Convert.ToBoolean(Eval("IsActive"))) %>
                                    </asp:LinkButton>

                                </div>

                            </div>

                        </div>

                    </ItemTemplate>


                    <FooterTemplate>

                        </div>

                    </FooterTemplate>

                </asp:Repeater>


                <asp:Panel
                    ID="pnlCategoryEmpty"
                    runat="server"
                    Visible="false">

                    <div class="empty-box">
                        حوزه‌ای برای نمایش وجود ندارد.
                    </div>

                </asp:Panel>


                <!-- فرم حوزه -->

                <asp:Panel
                    ID="pnlCategoryEdit"
                    runat="server"
                    Visible="false"
                    CssClass="form-panel">

                    <h4 class="form-title">
                        <asp:Label
                            ID="lblCategoryEditTitle"
                            runat="server">
                        </asp:Label>
                    </h4>


                    <div class="form-grid">

                        <div class="form-group form-group-full">

                            <label class="form-label">
                                نام حوزه
                            </label>

                            <asp:TextBox
                                ID="txtCategoryName"
                                runat="server"
                                CssClass="service-input"
                                MaxLength="100">
                            </asp:TextBox>

                        </div>


                        <div class="form-group form-group-full">

                            <label class="form-label">
                                توضیحات
                            </label>

                            <asp:TextBox
                                ID="txtCategoryDescription"
                                runat="server"
                                CssClass="service-textarea"
                                TextMode="MultiLine"
                                MaxLength="500">
                            </asp:TextBox>

                        </div>


                        <div class="form-group">

                            <div class="check-row">

                                <asp:CheckBox
                                    ID="chkCategoryActive"
                                    runat="server"
                                    Checked="true" />

                                <label for="<%= chkCategoryActive.ClientID %>">
                                    حوزه فعال باشد
                                </label>

                            </div>

                        </div>

                    </div>


                    <div class="form-actions">

                        <asp:Button
                            ID="btnSaveCategory"
                            runat="server"
                            Text="ثبت اطلاعات"
                            CssClass="service-btn service-btn-primary"
                            OnClick="btnSaveCategory_Click" />

                        <asp:Button
                            ID="btnCancelCategory"
                            runat="server"
                            Text="انصراف"
                            CssClass="service-btn service-btn-secondary"
                            CausesValidation="false"
                            OnClick="btnCancelCategory_Click" />

                    </div>

                </asp:Panel>

            </div>

        </div>


        <!-- موضوعات -->

        <div class="service-card">

            <div class="service-card-header">

                <div>

                    <h3 class="service-card-title">
                        موضوعات خدمت
                    </h3>

                    <div class="service-card-subtitle">
                        موضوعات قابل انتخاب برای حوزه انتخاب‌شده
                    </div>

                </div>


                <asp:Button
                    ID="btnNewTopic"
                    runat="server"
                    Text="+ افزودن موضوع"
                    CssClass="service-btn service-btn-primary"
                    CausesValidation="false"
                    OnClick="btnNewTopic_Click" />

            </div>


            <div class="service-card-body">


                <asp:Panel
                    ID="pnlSelectedCategory"
                    runat="server"
                    Visible="false"
                    CssClass="selected-category">

                    <div class="selected-category-name">

                        <asp:Label
                            ID="lblSelectedCategoryName"
                            runat="server">
                        </asp:Label>

                    </div>


                    <div class="selected-category-description">

                        <asp:Label
                            ID="lblSelectedCategoryDescription"
                            runat="server">
                        </asp:Label>

                    </div>

                </asp:Panel>


                <asp:Panel
                    ID="pnlNoCategory"
                    runat="server">

                    <div class="empty-box">
                        برای مشاهده موضوعات، ابتدا یک حوزه از فهرست سمت راست انتخاب کنید.
                    </div>

                </asp:Panel>


                <asp:Panel
                    ID="pnlTopics"
                    runat="server"
                    Visible="false">


                    <asp:Repeater
                        ID="rptTopics"
                        runat="server"
                        OnItemCommand="rptTopics_ItemCommand">

                        <HeaderTemplate>

                            <div class="topic-list">

                        </HeaderTemplate>


                        <ItemTemplate>

                            <div class="topic-item">

                                <div class="topic-main">

                                    <div class="topic-name">
                                        <%# Eval("TopicName") %>
                                    </div>


                                    <div class="topic-description">
                                        <%# Eval("Description") %>
                                    </div>


                                    <div class="topic-meta">

                                        <span class="topic-order">
                                            ترتیب: <%# Eval("DisplayOrder") %>
                                        </span>


                                        <span class='<%# GetActiveBadgeCss(Convert.ToBoolean(Eval("IsActive"))) %>'>
                                            <%# GetActiveText(Convert.ToBoolean(Eval("IsActive"))) %>
                                        </span>

                                    </div>

                                </div>


                                <div class="topic-actions">

                                    <asp:LinkButton
                                        ID="btnEditTopic"
                                        runat="server"
                                        CommandName="EditTopic"
                                        CommandArgument='<%# Eval("ServiceTopicId") %>'
                                        CausesValidation="false"
                                        CssClass="mini-btn mini-edit">
                                        ویرایش
                                    </asp:LinkButton>


                                    <asp:LinkButton
                                        ID="btnToggleTopic"
                                        runat="server"
                                        CommandName="ToggleTopic"
                                        CommandArgument='<%# Eval("ServiceTopicId") %>'
                                        CausesValidation="false"
                                        CssClass="mini-btn mini-toggle">
                                        <%# GetToggleText(Convert.ToBoolean(Eval("IsActive"))) %>
                                    </asp:LinkButton>

                                </div>

                            </div>

                        </ItemTemplate>


                        <FooterTemplate>

                            </div>

                        </FooterTemplate>

                    </asp:Repeater>


                    <asp:Panel
                        ID="pnlTopicEmpty"
                        runat="server"
                        Visible="false">

                        <div class="empty-box">
                            برای این حوزه هنوز موضوعی ثبت نشده است.
                        </div>

                    </asp:Panel>


                </asp:Panel>


                <!-- فرم موضوع -->

                <asp:Panel
                    ID="pnlTopicEdit"
                    runat="server"
                    Visible="false"
                    CssClass="form-panel">

                    <h4 class="form-title">
                        <asp:Label
                            ID="lblTopicEditTitle"
                            runat="server">
                        </asp:Label>
                    </h4>


                    <div class="form-grid">


                        <div class="form-group">

                            <label class="form-label">
                                حوزه خدمت
                            </label>

                            <asp:DropDownList
                                ID="ddlTopicCategory"
                                runat="server"
                                CssClass="service-select">
                            </asp:DropDownList>

                        </div>


                        <div class="form-group">

                            <label class="form-label">
                                ترتیب نمایش
                            </label>

                            <asp:TextBox
                                ID="txtDisplayOrder"
                                runat="server"
                                CssClass="service-input"
                                Text="1">
                            </asp:TextBox>

                        </div>


                        <div class="form-group form-group-full">

                            <label class="form-label">
                                نام موضوع
                            </label>

                            <asp:TextBox
                                ID="txtTopicName"
                                runat="server"
                                CssClass="service-input"
                                MaxLength="150">
                            </asp:TextBox>

                        </div>


                        <div class="form-group form-group-full">

                            <label class="form-label">
                                توضیحات
                            </label>

                            <asp:TextBox
                                ID="txtTopicDescription"
                                runat="server"
                                CssClass="service-textarea"
                                TextMode="MultiLine"
                                MaxLength="500">
                            </asp:TextBox>

                        </div>


                        <div class="form-group">

                            <div class="check-row">

                                <asp:CheckBox
                                    ID="chkTopicActive"
                                    runat="server"
                                    Checked="true" />

                                <label for="<%= chkTopicActive.ClientID %>">
                                    موضوع فعال باشد
                                </label>

                            </div>

                        </div>

                    </div>


                    <div class="form-actions">

                        <asp:Button
                            ID="btnSaveTopic"
                            runat="server"
                            Text="ثبت اطلاعات"
                            CssClass="service-btn service-btn-primary"
                            OnClick="btnSaveTopic_Click" />

                        <asp:Button
                            ID="btnCancelTopic"
                            runat="server"
                            Text="انصراف"
                            CssClass="service-btn service-btn-secondary"
                            CausesValidation="false"
                            OnClick="btnCancelTopic_Click" />

                    </div>

                </asp:Panel>


            </div>

        </div>

    </div>

</div>

</asp:Content>