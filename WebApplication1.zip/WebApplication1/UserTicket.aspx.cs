﻿using System;
using System.Linq;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;
using WebApplication1.Models;

namespace WebApplication1
{
    public partial class UserTicket : System.Web.UI.Page
    {
        private int TicketId
        {
            get
            {
                int id;

                if (int.TryParse(
                    Request.QueryString["id"],
                    out id))
                {
                    return id;
                }

                return 0;
            }
        }


        protected void Page_Load(
            object sender,
            EventArgs e)
        {
            if (!Request.IsAuthenticated)
            {
                Response.Redirect("~/Login.aspx");
                return;
            }


            string userId =
                User.Identity.GetUserId();


            if (string.IsNullOrEmpty(userId))
            {
                Response.Redirect("~/Login.aspx");
                return;
            }


            /*
             * مدیر و کارشناس نباید از این صفحه
             * به عنوان درخواست‌کننده استفاده کنند.
             */
            using (var db =
                new ApplicationDbContext())
            {
                var userManager =
                    new UserManager<ApplicationUser>(
                        new UserStore<ApplicationUser>(db));


                if (userManager.IsInRole(
                        userId,
                        "Manager") ||
                    userManager.IsInRole(
                        userId,
                        "Specialist"))
                {
                    Response.Redirect(
                        "~/Login.aspx");

                    return;
                }
            }


            if (TicketId == 0)
            {
                Response.Redirect(
                    "~/UserDashboard.aspx");

                return;
            }


            if (!IsPostBack)
            {
                LoadTicket();
                LoadActions();
            }
        }


        private void LoadTicket()
        {
            string userId =
                User.Identity.GetUserId();


            using (var db =
                new ApplicationDbContext())
            {
                var ticket =
                    db.Tickets.FirstOrDefault(
                        t =>
                            t.TicketId == TicketId &&
                            t.UserId == userId);


                /*
                 * کاربر فقط درخواست‌های خودش
                 * را می‌تواند مشاهده کند.
                 */
                if (ticket == null)
                {
                    Response.Redirect(
                        "~/UserDashboard.aspx");

                    return;
                }


                lblTicketId.Text =
                    ticket.TicketId.ToString();

                lblSubject.Text =
                    ticket.Subject;

                lblDescription.Text =
                    ticket.Description;

                lblCategory.Text =
                    ticket.Category;

                lblPriority.Text =
                    GetPriorityText(
                        ticket.Priority);

                lblStatus.Text =
                    GetStatusText(
                        ticket.Status);

                lblCreatedAt.Text =
                    ticket.CreatedAt.ToString(
                        "yyyy/MM/dd HH:mm");


                /*
                 * فقط زمانی که تیکت منتظر تأیید
                 * است، بخش تأیید نمایش داده شود.
                 */
                pnlConfirmation.Visible =
                    ticket.Status ==
                    "WaitingConfirmation";
            }
        }


        private void LoadActions()
        {
            string userId =
                User.Identity.GetUserId();


            using (var db =
                new ApplicationDbContext())
            {
                var actions =
                    db.TicketActions
                        .Where(
                            a =>
                                a.TicketId == TicketId &&
                                a.Ticket.UserId == userId)
                        .OrderBy(
                            a => a.ActionDate)
                        .ToList()
                        .Select(
                            a => new
                            {
                                a.ActionText,

                                ActionDateText =
                                    a.ActionDate.ToString(
                                        "yyyy/MM/dd HH:mm"),

                                UserName =
                                    GetUserDisplayName(
                                        db,
                                        a.UserId)
                            })
                        .ToList();


                rptActions.DataSource =
                    actions;

                rptActions.DataBind();


                lblNoActions.Visible =
                    actions.Count == 0;
            }
        }


        private string GetUserDisplayName(
            ApplicationDbContext db,
            string userId)
        {
            var profile =
                db.UserProfiles.FirstOrDefault(
                    p => p.UserId == userId);


            if (profile != null &&
                !string.IsNullOrEmpty(
                    profile.FullName))
            {
                return profile.FullName;
            }


            var user =
                db.Users.FirstOrDefault(
                    u => u.Id == userId);


            if (user != null)
                return user.UserName;


            return "کاربر سامانه";
        }


        /*
         * ==========================================
         * تأیید نهایی درخواست توسط درخواست‌کننده
         *
         * WaitingConfirmation -> Closed
         * ==========================================
         */
        protected void btnConfirm_Click(
            object sender,
            EventArgs e)
        {
            string userId =
                User.Identity.GetUserId();


            using (var db =
                new ApplicationDbContext())
            {
                var ticket =
                    db.Tickets.FirstOrDefault(
                        t =>
                            t.TicketId == TicketId &&
                            t.UserId == userId);


                if (ticket == null)
                {
                    ShowError(
                        "درخواست موردنظر پیدا نشد.");

                    return;
                }


                if (ticket.Status !=
                    "WaitingConfirmation")
                {
                    ShowError(
                        "این درخواست در حال حاضر منتظر تأیید نیست.");

                    return;
                }


                var existingConfirmation =
                    db.TicketConfirmations
                        .FirstOrDefault(
                            c =>
                                c.TicketId ==
                                ticket.TicketId &&
                                c.UserId ==
                                userId &&
                                c.ConfirmationStatus ==
                                "Confirmed");


                if (existingConfirmation != null)
                {
                    ShowError(
                        "این درخواست قبلاً تأیید شده است.");

                    return;
                }


                DateTime now =
                    DateTime.Now;


                string confirmationComment =
                    txtConfirmationComment.Text.Trim();


                /*
                 * ثبت تأیید کاربر
                 */
                var confirmation =
                    new TicketConfirmation
                    {
                        TicketId =
                            ticket.TicketId,

                        UserId =
                            userId,

                        ConfirmationStatus =
                            "Confirmed",

                        Comment =
                            confirmationComment,

                        ConfirmationDate =
                            now,

                        AutoConfirmed =
                            false,

                        CreatedAt =
                            now
                    };


                db.TicketConfirmations.Add(
                    confirmation);


                /*
                 * تغییر وضعیت
                 */
                string oldStatus =
                    ticket.Status;


                ticket.Status =
                    "Closed";

                ticket.UserConfirmed =
                    true;

                ticket.AutoClosed =
                    false;


                /*
                 * ثبت تاریخچه
                 */
                string historyDescription;


                if (string.IsNullOrEmpty(
                    confirmationComment))
                {
                    historyDescription =
                        "درخواست توسط درخواست‌کننده تأیید و خاتمه یافت.";
                }
                else
                {
                    historyDescription =
                        "درخواست توسط درخواست‌کننده تأیید و خاتمه یافت. " +
                        "نظر درخواست‌کننده: " +
                        confirmationComment;
                }


                var history =
                    new TicketHistory
                    {
                        TicketId =
                            ticket.TicketId,

                        UserId =
                            userId,

                        OldStatus =
                            oldStatus,

                        NewStatus =
                            "Closed",

                        Description =
                            historyDescription,

                        HistoryDate =
                            now
                    };


                db.TicketHistory.Add(
                    history);


                db.SaveChanges();


                txtConfirmationComment.Text =
                    "";


                ShowSuccess(
                    "درخواست با موفقیت تأیید و خاتمه یافت.");


                LoadTicket();
                LoadActions();
            }
        }


        /*
         * ==========================================
         * عدم تأیید نتیجه رسیدگی
         *
         * WaitingConfirmation -> InProgress
         * ==========================================
         */
        protected void btnReject_Click(
         object sender,
         EventArgs e)
        {
            string userId =
                User.Identity.GetUserId();

            using (var db =
                new ApplicationDbContext())
            {
                /*
                 * فقط درخواست متعلق به همین کاربر
                 * قابل تغییر است.
                 */
                var ticket =
                    db.Tickets.FirstOrDefault(
                        t =>
                            t.TicketId == TicketId &&
                            t.UserId == userId);

                if (ticket == null)
                {
                    ShowError(
                        "درخواست موردنظر پیدا نشد.");

                    return;
                }


                /*
                 * فقط درخواست منتظر تأیید
                 * قابل عدم تأیید است.
                 */
                if (ticket.Status !=
                    "WaitingConfirmation")
                {
                    ShowError(
                        "این درخواست در حال حاضر منتظر تأیید نیست.");

                    return;
                }


                /*
                 * توضیح عدم تأیید الزامی است.
                 */
                string rejectComment =
                    txtConfirmationComment.Text.Trim();

                if (string.IsNullOrEmpty(rejectComment))
                {
                    ShowError(
                        "برای عدم تأیید نتیجه رسیدگی، لطفاً توضیح دهید چه بخشی از مشکل برطرف نشده است.");

                    return;
                }


                DateTime now =
                    DateTime.Now;


                /*
                 * ثبت سابقه عدم تأیید
                 */
                var confirmation =
                    new TicketConfirmation
                    {
                        TicketId =
                            ticket.TicketId,

                        UserId =
                            userId,

                        ConfirmationStatus =
                            "Rejected",

                        Comment =
                            rejectComment,

                        ConfirmationDate =
                            now,

                        AutoConfirmed =
                            false,

                        CreatedAt =
                            now
                    };


                db.TicketConfirmations.Add(
                    confirmation);


                /*
                 * وضعیت قبلی
                 */
                string oldStatus =
                    ticket.Status;


                /*
                 * برگشت درخواست به کارشناس
                 */
                ticket.Status =
                    "RejectedByUser";


                /*
                 * درخواست دیگر تأیید نشده است.
                 */
                ticket.UserConfirmed =
                    false;


                /*
                 * ثبت تاریخچه
                 */
                var history =
                    new TicketHistory
                    {
                        TicketId =
                            ticket.TicketId,

                        UserId =
                            userId,

                        OldStatus =
                            oldStatus,

                        NewStatus =
                            "RejectedByUser",

                        Description =
                            "نتیجه رسیدگی توسط درخواست‌کننده تأیید نشد. " +
                            "توضیح درخواست‌کننده: " +
                            rejectComment,

                        HistoryDate =
                            now
                    };


                db.TicketHistory.Add(
                    history);


                db.SaveChanges();


                txtConfirmationComment.Text =
                    "";


                ShowSuccess(
                    "درخواست برای ادامه رسیدگی به کارشناس بازگردانده شد.");


                LoadTicket();
                LoadActions();
            }
        }

        private void ShowError(
            string message)
        {
            lblMessage.Text =
                message;


            lblMessage.CssClass =
                "message error";


            lblMessage.Visible =
                true;
        }


        private void ShowSuccess(
            string message)
        {
            lblMessage.Text =
                message;


            lblMessage.CssClass =
                "message success";


            lblMessage.Visible =
                true;
        }


        private string GetPriorityText(
            string priority)
        {
            switch (priority)
            {
                case "Low":
                    return "کم";

                case "Normal":
                    return "عادی";

                case "High":
                    return "زیاد";

                case "Critical":
                    return "بحرانی";

                default:
                    return priority;
            }
        }


        private string GetStatusText(
            string status)
        {
            switch (status)
            {
                case "New":
                    return "جدید";

                case "Assigned":
                    return "ارجاع شده";

                case "InProgress":
                    return "در حال رسیدگی";

                case "Resolved":
                    return "حل شده";

                case "WaitingConfirmation":
                    return "منتظر تأیید";

                case "Closed":
                    return "خاتمه یافته";
                case "RejectedByUser":
                    return "برگشتی از کاربر";
                default:
                    return status;
            }
        }
    }
}