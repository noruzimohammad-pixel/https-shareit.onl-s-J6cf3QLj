﻿<%@ Page Title="ایجاد کاربر جدید"
    Language="C#"
    MasterPageFile="~/Site.Master"
    AutoEventWireup="true"
    CodeBehind="CreateUser.aspx.cs"
    Inherits="WebApplication1.CreateUser" %>

<asp:Content ID="Content1"
    ContentPlaceHolderID="TitleContent"
    runat="server">

    مدیریت کاربران

</asp:Content>


<asp:Content ID="Content2"
    ContentPlaceHolderID="HeadContent"
    runat="server">

    <style type="text/css">

        .user-page {
            width: 100%;
            font-family: "Vazirmatn","B Nazanin","B Zar",Tahoma,Arial,sans-serif;
        }

        .user-card {
            background: #fff;
            border: 1px solid #e6ebf2;
            border-radius: 14px;
            box-shadow: 0 4px 18px rgba(35,48,66,.05);
            overflow: hidden;
            margin-bottom: 18px;
        }

        .user-card-head {
            display: flex;
            align-items: center;
            gap: 11px;
            min-height: 62px;
            padding: 0 20px;
            border-bottom: 1px solid #edf0f4;
        }

        .user-icon {
            width: 36px;
            height: 36px;
            min-width: 36px;
            border-radius: 9px;
            background: #edf4ff;
            color: #2f80ed;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 17px;
        }

        .user-card-head h3 {
            margin: 0;
            color: #273142;
            font-size: 15px;
        }

        .user-card-head p {
            margin: 3px 0 0;
            color: #929baa;
            font-size: 9px;
        }

        .user-card-body {
            padding: 20px;
        }

        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 18px;
        }

        .form-group {
            margin-bottom: 17px;
        }

        .form-label {
            display: block;
            margin-bottom: 7px;
            color: #687386;
            font-size: 11px;
            font-weight: 600;
        }

        .required {
            color: #d64550;
        }

        .form-control {
            width: 100%;
            min-height: 42px;
            box-sizing: border-box;
            padding: 8px 11px;
            border: 1px solid #dce2ea;
            border-radius: 9px;
            background: #fff;
            color: #3f4a5a;
            font-family: inherit;
            font-size: 11px;
            outline: none;
        }

        .form-control:focus {
            border-color: #8bb8f3;
            box-shadow: 0 0 0 3px rgba(47,128,237,.08);
        }

        .checkbox-row {
            min-height: 42px;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .checkbox-row label {
            color: #4d5869;
            font-size: 11px;
        }

        .buttons {
            display: flex;
            gap: 8px;
            margin-top: 8px;
            padding-top: 18px;
            border-top: 1px solid #edf0f4;
        }

        .btn {
            min-height: 40px;
            border: 0;
            border-radius: 9px;
            padding: 8px 17px;
            font-family: inherit;
            font-size: 10px;
            font-weight: 600;
            cursor: pointer;
            text-decoration: none;
        }

        .btn-primary {
            background: #2f80ed;
            color: #fff;
        }

        .btn-primary:hover {
            background: #216fda;
        }

        .btn-secondary {
            background: #f0f2f5;
            color: #596273;
        }

        .btn-secondary:hover {
            background: #e5e8ec;
        }

        .btn-success {
            background: #238653;
            color: #fff;
        }

        .btn-success:hover {
            background: #1d7548;
        }

        .btn-excel {
            background: #eef8f1;
            color: #238653;
            border: 1px solid #d4eddd;
        }

        .info-box {
            background: #f7f9fc;
            border-right: 3px solid #2f80ed;
            padding: 11px 13px;
            margin-bottom: 20px;
            border-radius: 7px;
            color: #687386;
            font-size: 10px;
            line-height: 1.9;
        }

        .excel-info {
            background: #f7f9fc;
            border: 1px solid #e5eaf1;
            border-radius: 9px;
            padding: 13px;
            margin-bottom: 18px;
            color: #687386;
            font-size: 10px;
            line-height: 2;
        }

        .excel-info strong {
            color: #354052;
        }

        .excel-columns {
            margin-top: 8px;
            color: #3573c9;
            font-size: 9px;
        }

        .file-row {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-bottom: 15px;
        }

        .file-input {
            flex: 1;
            min-height: 40px;
            box-sizing: border-box;
            padding: 8px;
            border: 1px solid #dce2ea;
            border-radius: 9px;
            background: #fff;
            font-family: inherit;
            font-size: 10px;
        }

        .message {
            display: block;
            margin-top: 15px;
            padding: 10px 12px;
            border-radius: 8px;
            font-size: 10px;
            line-height: 1.9;
        }

        .success {
            background: #eaf8f0;
            color: #238653;
        }

        .error {
            background: #fff0f1;
            color: #c83b46;
        }

        .warning {
            background: #fff8e8;
            color: #9b6a00;
        }

        .report-summary {
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
            margin-bottom: 15px;
        }

        .summary-item {
            padding: 8px 12px;
            border-radius: 8px;
            font-size: 9px;
            background: #f5f7fa;
            color: #596273;
        }

        .summary-success {
            background: #eaf8f0;
            color: #238653;
        }

        .summary-error {
            background: #fff0f1;
            color: #c83b46;
        }

        .report-wrap {
            overflow-x: auto;
            -webkit-overflow-scrolling: touch;
        }

        .report-grid {
            width: 100%;
            min-width: 650px;
            border-collapse: collapse;
        }

        .report-grid th {
            padding: 10px 11px;
            background: #f8f9fb;
            color: #687386;
            font-size: 9px;
            text-align: right;
            white-space: nowrap;
            border-bottom: 1px solid #e8ebf0;
        }

        .report-grid td {
            padding: 9px 11px;
            color: #4d5869;
            font-size: 9px;
            line-height: 1.8;
            border-bottom: 1px solid #eef1f4;
            vertical-align: middle;
        }

        .report-success {
            color: #238653;
            font-weight: 700;
        }

        .report-error {
            color: #c83b46;
            font-weight: 700;
        }

        .sample-link {
            display: inline-block;
            margin-top: 8px;
            color: #2f80ed;
            font-size: 9px;
            text-decoration: none;
        }

        .sample-link:hover {
            text-decoration: underline;
        }

        @media(max-width:700px) {

            .form-row {
                grid-template-columns: 1fr;
                gap: 0;
            }

            .user-card-body {
                padding: 14px;
            }

            .user-card-head {
                padding: 0 14px;
            }

            .file-row {
                flex-direction: column;
                align-items: stretch;
            }

            .buttons {
                flex-wrap: wrap;
            }

        }

    </style>

</asp:Content>


<asp:Content ID="Content3"
    ContentPlaceHolderID="PageHeader"
    runat="server">

    مدیریت کاربران

</asp:Content>


<asp:Content ID="Content4"
    ContentPlaceHolderID="MainContent"
    runat="server">

    <div class="user-page">


        <!-- =====================================================
             ایجاد کاربر
             ===================================================== -->

        <div class="user-card">

            <div class="user-card-head">

                <div class="user-icon">
                    ＋
                </div>

                <div>

                    <h3>
                        ایجاد کاربر جدید
                    </h3>

                    <p>
                        ثبت اطلاعات یک کاربر عادی
                    </p>

                </div>

            </div>


            <div class="user-card-body">


                <div class="info-box">

                    اطلاعات کاربر در سامانه ثبت می‌شود.
                    این بخش فقط برای ایجاد کاربران عادی سامانه است.
                    تعریف کارشناسان از صفحه اختصاصی کارشناسان انجام می‌شود.

                </div>


                <!-- نام کاربری و نام -->

                <div class="form-row">

                    <div class="form-group">

                        <label class="form-label">

                            نام کاربری
                            <span class="required">*</span>

                        </label>

                        <asp:TextBox
                            ID="txtUserName"
                            runat="server"
                            CssClass="form-control"
                            MaxLength="256"
                            autocomplete="off"
                            AutoCompleteType="Disabled">
                        </asp:TextBox>

                    </div>


                    <div class="form-group">

                        <label class="form-label">

                            نام و نام خانوادگی
                            <span class="required">*</span>

                        </label>

                        <asp:TextBox
                            ID="txtFullName"
                            runat="server"
                            CssClass="form-control"
                            MaxLength="150"
                            autocomplete="off"
                            AutoCompleteType="Disabled">
                        </asp:TextBox>

                    </div>

                </div>


                <!-- واحد -->

                <div class="form-row">

                    <div class="form-group">

                        <label class="form-label">

                            واحد سازمانی
                            <span class="required">*</span>

                        </label>

                        <asp:DropDownList
                            ID="ddlDepartment"
                            runat="server"
                            CssClass="form-control">
                        </asp:DropDownList>

                    </div>


                    <div class="form-group">

                        <label class="form-label">

                            وضعیت حساب

                        </label>

                        <div class="checkbox-row">

                            <asp:CheckBox
                                ID="chkIsActive"
                                runat="server"
                                Checked="true" />

                            <label>
                                کاربر فعال باشد
                            </label>

                        </div>

                    </div>

                </div>


                <!-- رمز -->

                <div class="form-row">

                    <div class="form-group">

                        <label class="form-label">

                            رمز عبور
                            <span class="required">*</span>

                        </label>

                        <asp:TextBox
                            ID="txtPassword"
                            runat="server"
                            TextMode="Password"
                            CssClass="form-control"
                            MaxLength="100"
                            autocomplete="new-password">
                        </asp:TextBox>

                    </div>


                    <div class="form-group">

                        <label class="form-label">

                            تکرار رمز عبور
                            <span class="required">*</span>

                        </label>

                        <asp:TextBox
                            ID="txtConfirmPassword"
                            runat="server"
                            TextMode="Password"
                            CssClass="form-control"
                            MaxLength="100"
                            autocomplete="new-password">
                        </asp:TextBox>

                    </div>

                </div>


                <div class="buttons">

                    <asp:Button
                        ID="btnCreate"
                        runat="server"
                        Text="ایجاد کاربر"
                        CssClass="btn btn-primary"
                        OnClick="btnCreate_Click" />

                </div>


                <asp:Label
                    ID="lblMessage"
                    runat="server"
                    Visible="false">
                </asp:Label>


            </div>

        </div>



        <!-- =====================================================
             ورود گروهی از Excel
             ===================================================== -->

        <div class="user-card">

            <div class="user-card-head">

                <div class="user-icon">
                    ⇩
                </div>

                <div>

                    <h3>
                        ورود گروهی کاربران از Excel
                    </h3>

                    <p>
                        ثبت همزمان اطلاعات چند کاربر عادی
                    </p>

                </div>

            </div>


            <div class="user-card-body">


                <div class="excel-info">

                    <strong>
                        نکات مهم:
                    </strong>

                    <br />

                    فقط کاربران با نقش «کاربر» از طریق این فایل ایجاد می‌شوند.

                    <br />

                    واحد سازمانی باید دقیقاً مطابق نام واحد ثبت‌شده در سامانه باشد.

                    <br />

                    نام کاربری تکراری ثبت نخواهد شد.

                    <br />

                    هر ردیف مستقل بررسی می‌شود و خطای یک ردیف مانع ثبت سایر ردیف‌های صحیح نمی‌شود.

                    <div class="excel-columns">

                        ستون‌های فایل:
                        شماره ردیف،
                        نام کاربری،
                        نام و نام خانوادگی،
                        واحد سازمانی،
                        رمز عبور،
                        فعال

                    </div>


                    <asp:LinkButton
                        ID="btnDownloadTemplate"
                        runat="server"
                        CssClass="sample-link"
                        OnClick="btnDownloadTemplate_Click">

                        ↓ دانلود فایل نمونه Excel

                    </asp:LinkButton>

                </div>


                <div class="file-row">

                    <asp:FileUpload
                        ID="fuExcel"
                        runat="server"
                        CssClass="file-input" />

                    <asp:Button
                        ID="btnImportExcel"
                        runat="server"
                        Text="شروع ورود اطلاعات"
                        CssClass="btn btn-success"
                        OnClick="btnImportExcel_Click" />

                </div>


                <asp:Label
                    ID="lblExcelMessage"
                    runat="server"
                    Visible="false">
                </asp:Label>


            </div>

        </div>



        <!-- =====================================================
             گزارش ورود Excel
             ===================================================== -->

        <asp:Panel
            ID="pnlImportReport"
            runat="server"
            Visible="false"
            CssClass="user-card">


            <div class="user-card-head">

                <div class="user-icon">
                    ≡
                </div>

                <div>

                    <h3>
                        گزارش ورود اطلاعات
                    </h3>

                    <p>
                        نتیجه بررسی و ثبت ردیف‌های فایل Excel
                    </p>

                </div>

            </div>


            <div class="user-card-body">


                <div class="report-summary">

                    <asp:Label
                        ID="lblTotalRows"
                        runat="server"
                        CssClass="summary-item">
                    </asp:Label>

                    <asp:Label
                        ID="lblSuccessRows"
                        runat="server"
                        CssClass="summary-item summary-success">
                    </asp:Label>

                    <asp:Label
                        ID="lblErrorRows"
                        runat="server"
                        CssClass="summary-item summary-error">
                    </asp:Label>

                </div>


                <div class="report-wrap">

                    <asp:GridView
                        ID="gvImportReport"
                        runat="server"
                        AutoGenerateColumns="False"
                        CssClass="report-grid"
                        GridLines="None">

                        <Columns>

                            <asp:BoundField
                                DataField="RowNumber"
                                HeaderText="ردیف" />

                            <asp:BoundField
                                DataField="UserName"
                                HeaderText="نام کاربری" />

                            <asp:BoundField
                                DataField="FullName"
                                HeaderText="نام و نام خانوادگی" />

                            <asp:BoundField
                                DataField="DepartmentName"
                                HeaderText="واحد سازمانی" />

                            <asp:BoundField
                                DataField="Status"
                                HeaderText="وضعیت" />

                            <asp:BoundField
                                DataField="Message"
                                HeaderText="شرح نتیجه" />

                        </Columns>

                    </asp:GridView>

                </div>


            </div>

        </asp:Panel>


    </div>

</asp:Content>