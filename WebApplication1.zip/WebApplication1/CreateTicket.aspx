﻿<%@ Page Title="ثبت درخواست جدید"
    Language="C#"
    MasterPageFile="~/Site.Master"
    AutoEventWireup="true"
    CodeBehind="CreateTicket.aspx.cs"
    Inherits="WebApplication1.CreateTicket" %>

<asp:Content ID="Content1" ContentPlaceHolderID="MainContent" runat="server">

    <div class="page-header">
        <div>
            <h1>ثبت درخواست جدید</h1>
            <p>درخواست خدمات فناوری اطلاعات را ثبت کنید.</p>
        </div>

        <div>
            <asp:HyperLink
                ID="lnkBack"
                runat="server"
                CssClass="btn btn-secondary">
                بازگشت
            </asp:HyperLink>
        </div>
    </div>

    <div class="create-ticket-container">

        <div class="form-card">
               <!-- پیام -->
                <asp:Panel
    ID="pnlSuccessMessage"
    runat="server"
    CssClass="success-ticket-card"
    Visible="false">

    <div class="success-ticket-icon">
        ✓
    </div>

    <div class="success-ticket-content">

        <div class="success-ticket-title">
            درخواست شما با موفقیت ثبت شد
        </div>

        <div class="success-ticket-subtitle">
            درخواست شما با موفقیت در سامانه ثبت و برای بررسی مدیر در صف قرار گرفت.
        </div>

        <div class="success-ticket-info">

            <div class="success-ticket-item">

                <span class="success-ticket-label">
                    شماره درخواست
                </span>

                <strong
                    id="lblTicketNumber"
                    runat="server"
                    class="success-ticket-value">
                </strong>

            </div>


            <div class="success-ticket-item">

                <span class="success-ticket-label">
                    درخواست‌های در صف بررسی
                </span>

                <strong
                    id="lblPendingCount"
                    runat="server"
                    class="success-ticket-value">
                </strong>

            </div>

        </div>

    </div>

</asp:Panel>


<asp:Label
    ID="lblMessage"
    runat="server"
    CssClass="form-message"
    Visible="false">
</asp:Label>


            <div class="form-card-header">
                <h2>اطلاعات درخواست</h2>
                <span>لطفاً اطلاعات درخواست را با دقت وارد کنید.</span>
            </div>

            <div class="form-card-body">

                <!-- انتخاب درخواست کننده - فقط مدیر -->
                <asp:Panel
                    ID="pnlManagerRequester"
                    runat="server"
                    Visible="false"
                    CssClass="requester-section">

                    <div class="section-title">
                        <h3>درخواست‌کننده</h3>
                        <p>در صورت ثبت درخواست به نمایندگی از کاربر، فرد موردنظر را انتخاب کنید.</p>
                    </div>

                    <asp:HiddenField
                        ID="hfRequesterId"
                        runat="server" />

                    <div class="form-group">
                        <label for="<%= txtRequesterSearch.ClientID %>">
                            جستجوی کاربر
                        </label>

                        <asp:TextBox
                            ID="txtRequesterSearch"
                            runat="server"
                            CssClass="form-control"
                            placeholder="نام یا نام کاربری را وارد کنید..."
                            autocomplete="off">
                        </asp:TextBox>

                        <div
                            id="requesterSearchResults"
                            class="requester-results">

                            <asp:Repeater
                                ID="rptRequesters"
                                runat="server">

                                <ItemTemplate>

                                    <div
                                        class="requester-item"
                                        data-id="<%# Eval("UserId") %>"
                                        data-name="<%# Eval("DisplayName") %>"
                                        onclick="selectRequester(this);">

                                        <div class="requester-name">
                                            <%# Eval("DisplayName") %>
                                        </div>

                                        <div class="requester-username">
                                            <%# Eval("UserName") %>
                                        </div>

                                    </div>

                                </ItemTemplate>

                            </asp:Repeater>

                        </div>

                        <div
                            id="selectedRequester"
                            class="selected-requester"
                            style="display:none;">

                            <span class="selected-requester-label">
                                درخواست‌کننده انتخاب‌شده:
                            </span>

                            <strong id="selectedRequesterName"></strong>

                            <button
                                type="button"
                                class="clear-requester"
                                onclick="clearRequester();">
                                ×
                            </button>

                        </div>

                    </div>

                </asp:Panel>


                <!-- عنوان -->
                <div class="form-group">

                    <label for="<%= txtSubject.ClientID %>">
                        عنوان درخواست
                        <span class="required">*</span>
                    </label>

                    <asp:TextBox
                        ID="txtSubject"
                        runat="server"
                        CssClass="form-control"
                        MaxLength="250"
                        placeholder="عنوان درخواست را وارد کنید...">
                    </asp:TextBox>

                </div>


                <!-- دسته بندی و اولویت -->
                <div class="form-row">

                    <div class="form-group form-group-half">

                        <label for="<%= ddlCategory.ClientID %>">
                            دسته‌بندی
                            <span class="required">*</span>
                        </label>

                        <asp:DropDownList
                            ID="ddlCategory"
                            runat="server"
                            CssClass="form-control">

                            <asp:ListItem
                                Text="-- انتخاب دسته‌بندی --"
                                Value="">
                            </asp:ListItem>

                            <asp:ListItem
                                Text="نرم‌افزار"
                                Value="نرم‌افزار">
                            </asp:ListItem>

                            <asp:ListItem
                                Text="سخت‌افزار"
                                Value="سخت‌افزار">
                            </asp:ListItem>

                            <asp:ListItem
                                Text="شبکه"
                                Value="شبکه">
                            </asp:ListItem>

                            <asp:ListItem
                                Text="امنیت"
                                Value="امنیت">
                            </asp:ListItem>

                            <asp:ListItem
                                Text="سایر"
                                Value="سایر">
                            </asp:ListItem>

                        </asp:DropDownList>

                    </div>


                    <div class="form-group form-group-half">

                        <label for="<%= ddlPriority.ClientID %>">
                            اولویت
                            <span class="required">*</span>
                        </label>

                        <asp:DropDownList
                            ID="ddlPriority"
                            runat="server"
                            CssClass="form-control">

                            <asp:ListItem
                                Text="عادی"
                                Value="Normal">
                            </asp:ListItem>

                            <asp:ListItem
                                Text="کم"
                                Value="Low">
                            </asp:ListItem>

                            <asp:ListItem
                                Text="زیاد"
                                Value="High">
                            </asp:ListItem>

                            <asp:ListItem
                                Text="بحرانی"
                                Value="Critical">
                            </asp:ListItem>

                        </asp:DropDownList>

                    </div>

                </div>


                <!-- شرح درخواست -->
                <div class="form-group">

                    <label for="<%= txtDescription.ClientID %>">
                        شرح درخواست
                        <span class="required">*</span>
                    </label>

                    <asp:TextBox
                        ID="txtDescription"
                        runat="server"
                        CssClass="form-control description-box"
                        TextMode="MultiLine"
                        Rows="7"
                        placeholder="شرح کامل مشکل یا درخواست خود را وارد کنید...">
                    </asp:TextBox>

                </div>


             
                <!-- دکمه ها -->
                <div class="form-actions">

                    <asp:Button
                        ID="btnSubmit"
                        runat="server"
                        Text="ثبت درخواست"
                        CssClass="btn btn-primary"
                        OnClick="btnSubmit_Click" />

                    <asp:HyperLink
                        ID="lnkCancel"
                        runat="server"
                        CssClass="btn btn-secondary">
                        انصراف
                    </asp:HyperLink>

                </div>

            </div>

        </div>

    </div>


    <style type="text/css">

        .create-ticket-container {
            max-width: 1000px;
            margin: 0 auto;
        }

        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
        }

        .page-header h1 {
            margin: 0 0 7px 0;
            font-size: 26px;
        }

        .page-header p {
            margin: 0;
            color: #777;
        }

        .form-card {
            background: #fff;
            border: 1px solid #e5e7eb;
            border-radius: 12px;
            box-shadow: 0 3px 12px rgba(0,0,0,.04);
            overflow: hidden;
        }

        .form-card-header {
            padding: 22px 25px;
            border-bottom: 1px solid #eee;
            background: #fafbfc;
        }

        .form-card-header h2 {
            margin: 0 0 6px 0;
            font-size: 19px;
        }

        .form-card-header span {
            color: #777;
            font-size: 13px;
        }

        .form-card-body {
            padding: 28px;
        }

        .form-group {
            margin-bottom: 22px;
        }

        .form-row {
            display: flex;
            gap: 20px;
        }

        .form-group-half {
            flex: 1;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            font-size: 14px;
        }

        .required {
            color: #d9534f;
        }

        .form-control {
            width: 100%;
            box-sizing: border-box;
            border: 1px solid #d8dde3;
            border-radius: 7px;
            padding: 11px 13px;
            font-family: inherit;
            font-size: 14px;
            background: #fff;
            transition: border-color .2s, box-shadow .2s;
        }

        .form-control:focus {
            outline: none;
            border-color: #176b78;
            box-shadow: 0 0 0 3px rgba(23,107,120,.10);
        }

        .description-box {
            resize: vertical;
            min-height: 150px;
            line-height: 1.8;
        }

        .form-actions {
            display: flex;
            gap: 10px;
            margin-top: 10px;
            padding-top: 20px;
            border-top: 1px solid #eee;
        }

        .btn {
            display: inline-block;
            border: none;
            border-radius: 7px;
            padding: 10px 22px;
            text-decoration: none;
            cursor: pointer;
            font-family: inherit;
            font-size: 14px;
        }

        .btn-primary {
            background: #176b78;
            color: #fff;
        }

        .btn-primary:hover {
            background: #125662;
        }

        .btn-secondary {
            background: #f1f3f5;
            color: #444;
        }

        .btn-secondary:hover {
            background: #e5e7eb;
        }

        .form-message {
            display: block;
            margin: 15px 0;
            padding: 11px 14px;
            border-radius: 7px;
        }

        .requester-section {
            margin-bottom: 25px;
            padding-bottom: 20px;
            border-bottom: 1px solid #eee;
        }

        .section-title h3 {
            margin: 0 0 5px 0;
            font-size: 17px;
        }

        .section-title p {
            margin: 0 0 15px 0;
            color: #777;
            font-size: 13px;
        }

        .requester-results {
            position: relative;
            z-index: 20;
            max-height: 220px;
            overflow-y: auto;
            border: 1px solid #ddd;
            border-top: none;
            display: none;
            background: #fff;
        }

        .requester-item {
            padding: 11px 14px;
            border-bottom: 1px solid #eee;
            cursor: pointer;
        }

        .requester-item:hover {
            background: #f5f9fa;
        }

        .requester-name {
            font-weight: 600;
        }

        .requester-username {
            color: #888;
            font-size: 12px;
            margin-top: 3px;
        }

        .selected-requester {
            margin-top: 10px;
            padding: 10px 13px;
            background: #f1f8f9;
            border: 1px solid #c9e3e6;
            border-radius: 7px;
        }

        .selected-requester-label {
            color: #666;
            margin-left: 7px;
            font-size: 13px;
        }

        .clear-requester {
            float: left;
            border: none;
            background: transparent;
            color: #b44;
            font-size: 20px;
            cursor: pointer;
        }

        @media (max-width: 700px) {

            .form-row {
                display: block;
            }

            .form-group-half {
                width: 100%;
            }

            .page-header {
                display: block;
            }

            .page-header .btn {
                margin-top: 15px;
            }

            .form-card-body {
                padding: 18px;
            }

        }

        .success-ticket-card {
    display: flex;
    align-items: center;
    gap: 18px;
    margin: 20px 0;
    padding: 20px;
    background: #f0f9f5;
    border: 1px solid #c8e6d5;
    border-radius: 10px;
    direction: rtl;
}

.success-ticket-icon {
    width: 48px;
    height: 48px;
    min-width: 48px;
    border-radius: 50%;
    background: #2e8b57;
    color: #fff;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 27px;
    font-weight: bold;
}

.success-ticket-content {
    flex: 1;
}

.success-ticket-title {
    font-size: 17px;
    font-weight: 700;
    color: #246b45;
    margin-bottom: 6px;
}

.success-ticket-subtitle {
    font-size: 13px;
    color: #5f6f66;
    line-height: 1.8;
    margin-bottom: 15px;
}

.success-ticket-info {
    display: flex;
    gap: 12px;
    flex-wrap: wrap;
}

.success-ticket-item {
    min-width: 180px;
    padding: 10px 14px;
    background: #fff;
    border: 1px solid #d9ebe1;
    border-radius: 7px;
}

.success-ticket-label {
    display: block;
    color: #777;
    font-size: 12px;
    margin-bottom: 5px;
}

.success-ticket-value {
    display: block;
    color: #246b45;
    font-size: 16px;
}

@media (max-width: 700px) {

    .success-ticket-card {
        align-items: flex-start;
        padding: 16px;
    }

    .success-ticket-icon {
        width: 40px;
        height: 40px;
        min-width: 40px;
        font-size: 22px;
    }

    .success-ticket-info {
        display: block;
    }

    .success-ticket-item {
        margin-bottom: 8px;
    }
}

    </style>


    <script type="text/javascript">

        function selectRequester(element) {

            var id = element.getAttribute("data-id");
            var name = element.getAttribute("data-name");

            document.getElementById("<%= hfRequesterId.ClientID %>").value = id;

            document.getElementById("selectedRequesterName").innerHTML =
                name;

            document.getElementById("selectedRequester").style.display =
                "block";

            document.getElementById("requesterSearchResults").style.display =
                "none";

            document.getElementById("<%= txtRequesterSearch.ClientID %>").value =
                name;
        }


        function clearRequester() {

            document.getElementById("<%= hfRequesterId.ClientID %>").value =
                "";

            document.getElementById("<%= txtRequesterSearch.ClientID %>").value =
                "";

            document.getElementById("selectedRequester").style.display =
                "none";
        }


        document.addEventListener("DOMContentLoaded", function () {

            var searchBox =
                document.getElementById("<%= txtRequesterSearch.ClientID %>");

            var results =
                document.getElementById("requesterSearchResults");

            if (!searchBox || !results)
                return;

            searchBox.addEventListener("focus", function () {
                results.style.display = "block";
            });

            searchBox.addEventListener("input", function () {

                var value =
                    searchBox.value.toLowerCase().trim();

                var items =
                    results.getElementsByClassName("requester-item");

                for (var i = 0; i < items.length; i++) {

                    var text =
                        items[i].innerText.toLowerCase();

                    if (text.indexOf(value) >= 0)
                        items[i].style.display = "block";
                    else
                        items[i].style.display = "none";
                }

                results.style.display = "block";
            });

            document.addEventListener("click", function (event) {

                if (!searchBox.contains(event.target) &&
                    !results.contains(event.target)) {

                    results.style.display = "none";
                }

            });

        });

    </script>

</asp:Content>