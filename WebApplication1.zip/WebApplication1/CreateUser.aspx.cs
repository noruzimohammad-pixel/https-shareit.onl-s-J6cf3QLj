﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI.WebControls;

using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;

using NPOI.HSSF.UserModel;
using NPOI.SS.UserModel;
using NPOI.XSSF.UserModel;

using WebApplication1.Models;

namespace WebApplication1
{
    public partial class CreateUser : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Request.IsAuthenticated)
            {
                Response.Redirect("~/Login.aspx");
                return;
            }

            if (!User.IsInRole("Manager"))
            {
                Response.Redirect("~/Login.aspx");
                return;
            }

            if (!IsPostBack)
            {
                LoadDepartments();

                chkIsActive.Checked = true;

                lblMessage.Visible = false;
                lblExcelMessage.Visible = false;
                pnlImportReport.Visible = false;
            }
        }


        // =========================================================
        // بارگذاری واحدهای سازمانی
        // =========================================================

        private void LoadDepartments()
        {
            using (var db = new ApplicationDbContext())
            {
                var departments = db.Departments
                    .Where(d => d.IsActive)
                    .OrderBy(d => d.DepartmentName)
                    .ToList();

                ddlDepartment.Items.Clear();

                ddlDepartment.Items.Add(
                    new ListItem(
                        "انتخاب واحد سازمانی",
                        ""));

                foreach (var department in departments)
                {
                    ddlDepartment.Items.Add(
                        new ListItem(
                            department.DepartmentName,
                            department.DepartmentId.ToString()));
                }
            }
        }


        // =========================================================
        // ایجاد کاربر عادی
        // =========================================================

        protected void btnCreate_Click(
            object sender,
            EventArgs e)
        {
            lblMessage.Visible = false;
            lblMessage.Text = "";

            string userName =
                txtUserName.Text.Trim();

            string fullName =
                txtFullName.Text.Trim();

            string password =
                txtPassword.Text;

            string confirmPassword =
                txtConfirmPassword.Text;


            // -----------------------------------------------------
            // نام کاربری
            // -----------------------------------------------------

            if (string.IsNullOrEmpty(userName))
            {
                ShowError(
                    "لطفاً نام کاربری را وارد کنید.");

                return;
            }


            // -----------------------------------------------------
            // نام و نام خانوادگی
            // -----------------------------------------------------

            if (string.IsNullOrEmpty(fullName))
            {
                ShowError(
                    "لطفاً نام و نام خانوادگی را وارد کنید.");

                return;
            }


            // -----------------------------------------------------
            // واحد سازمانی
            // -----------------------------------------------------

            if (string.IsNullOrEmpty(
                ddlDepartment.SelectedValue))
            {
                ShowError(
                    "لطفاً واحد سازمانی را انتخاب کنید.");

                return;
            }


            int departmentId;

            if (!int.TryParse(
                ddlDepartment.SelectedValue,
                out departmentId))
            {
                ShowError(
                    "واحد سازمانی انتخاب‌شده معتبر نیست.");

                return;
            }


            // -----------------------------------------------------
            // رمز عبور
            // -----------------------------------------------------

            if (string.IsNullOrEmpty(password))
            {
                ShowError(
                    "لطفاً رمز عبور را وارد کنید.");

                return;
            }


            if (password.Length < 6)
            {
                ShowError(
                    "رمز عبور باید حداقل 6 کاراکتر باشد.");

                return;
            }


            if (password != confirmPassword)
            {
                ShowError(
                    "رمز عبور و تکرار آن یکسان نیستند.");

                return;
            }


            using (var db =
                new ApplicationDbContext())
            {
                // -------------------------------------------------
                // بررسی واحد سازمانی
                // -------------------------------------------------

                var department =
                    db.Departments.FirstOrDefault(
                        d =>
                            d.DepartmentId == departmentId &&
                            d.IsActive);

                if (department == null)
                {
                    ShowError(
                        "واحد سازمانی انتخاب‌شده معتبر نیست.");

                    return;
                }


                // -------------------------------------------------
                // UserManager
                // -------------------------------------------------

                var userManager =
                    new UserManager<ApplicationUser>(
                        new UserStore<ApplicationUser>(db));


                // -------------------------------------------------
                // بررسی نام کاربری تکراری
                // -------------------------------------------------

                var existingUser =
                    userManager.FindByName(userName);

                if (existingUser != null)
                {
                    ShowError(
                        "این نام کاربری قبلاً در سامانه ثبت شده است.");

                    return;
                }


                // -------------------------------------------------
                // ایجاد کاربر
                // -------------------------------------------------

                var user =
                    new ApplicationUser
                    {
                        UserName = userName
                    };


                IdentityResult createResult =
                    userManager.Create(
                        user,
                        password);


                if (!createResult.Succeeded)
                {
                    ShowError(
                        string.Join(
                            " ",
                            createResult.Errors));

                    return;
                }


                // -------------------------------------------------
                // نقش کاربر
                // -------------------------------------------------

                string role = "User";


                var roleManager =
                    new RoleManager<IdentityRole>(
                        new RoleStore<IdentityRole>(db));


                if (!roleManager.RoleExists(role))
                {
                    IdentityResult roleResult =
                        roleManager.Create(
                            new IdentityRole(role));

                    if (!roleResult.Succeeded)
                    {
                        ShowError(
                            "خطا در ایجاد نقش کاربر: " +
                            string.Join(
                                " ",
                                roleResult.Errors));

                        return;
                    }
                }


                // -------------------------------------------------
                // اختصاص نقش
                // -------------------------------------------------

                IdentityResult addRoleResult =
                    userManager.AddToRole(
                        user.Id,
                        role);


                if (!addRoleResult.Succeeded)
                {
                    ShowError(
                        string.Join(
                            " ",
                            addRoleResult.Errors));

                    return;
                }


                // -------------------------------------------------
                // پروفایل کاربر
                // -------------------------------------------------

                var profile =
                    new UserProfile
                    {
                        UserId =
                            user.Id,

                        FullName =
                            fullName,

                        DepartmentId =
                            departmentId,

                        UserCategory =
                            "General",

                        IsActive =
                            chkIsActive.Checked,

                        CreatedAt =
                            DateTime.Now
                    };


                db.UserProfiles.Add(profile);


                db.SaveChanges();


                ShowSuccess(
                    "کاربر با موفقیت ایجاد شد.");


                ClearForm();
            }
        }


        // =========================================================
        // دانلود قالب Excel
        // =========================================================

        protected void btnDownloadTemplate_Click(
            object sender,
            EventArgs e)
        {
            IWorkbook workbook =
                new XSSFWorkbook();


            ISheet sheet =
                workbook.CreateSheet("کاربران");


            // -----------------------------------------------------
            // عنوان ستون‌ها
            // -----------------------------------------------------

            IRow header =
                sheet.CreateRow(0);


            header.CreateCell(0).SetCellValue(
                "نام کاربری");

            header.CreateCell(1).SetCellValue(
                "نام و نام خانوادگی");

            header.CreateCell(2).SetCellValue(
                "واحد سازمانی");

            header.CreateCell(3).SetCellValue(
                "رمز عبور");

            header.CreateCell(4).SetCellValue(
                "فعال");


            // -----------------------------------------------------
            // ردیف نمونه
            // -----------------------------------------------------

            IRow sample =
                sheet.CreateRow(1);


            sample.CreateCell(0).SetCellValue(
                "user001");

            sample.CreateCell(1).SetCellValue(
                "علی رضایی");

            sample.CreateCell(2).SetCellValue(
                "فناوری اطلاعات");

            sample.CreateCell(3).SetCellValue(
                "123456");

            sample.CreateCell(4).SetCellValue(
                "بله");


            for (int i = 0; i < 5; i++)
            {
                sheet.AutoSizeColumn(i);
            }


            // -----------------------------------------------------
            // ارسال فایل
            // -----------------------------------------------------

            Response.Clear();

            Response.Buffer = true;

            Response.ContentType =
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";


            Response.AddHeader(
                "content-disposition",
                "attachment;filename=UsersTemplate.xlsx");


            using (MemoryStream stream =
                new MemoryStream())
            {
                workbook.Write(stream);

                Response.BinaryWrite(
                    stream.ToArray());
            }


            Response.Flush();

            HttpContext.Current
                .ApplicationInstance
                .CompleteRequest();
        }


        // =========================================================
        // شروع Import Excel
        // =========================================================

        protected void btnImportExcel_Click(
            object sender,
            EventArgs e)
        {
            lblExcelMessage.Visible = false;

            pnlImportReport.Visible = false;


            // -----------------------------------------------------
            // بررسی انتخاب فایل
            // -----------------------------------------------------

            if (!fuExcel.HasFile)
            {
                ShowExcelError(
                    "لطفاً ابتدا فایل Excel را انتخاب کنید.");

                return;
            }


            // -----------------------------------------------------
            // بررسی پسوند
            // -----------------------------------------------------

            string extension =
                Path.GetExtension(
                    fuExcel.FileName)
                .ToLower();


            if (extension != ".xlsx" &&
                extension != ".xls")
            {
                ShowExcelError(
                    "فرمت فایل معتبر نیست. فقط فایل‌های Excel با پسوند xlsx یا xls قابل قبول هستند.");

                return;
            }


            try
            {
                List<ImportResult> results =
                    new List<ImportResult>();


                // =================================================
                // نکته مهم:
                // واحدها را یک بار از DB می‌خوانیم.
                // NormalizeText بعد از ToList اجرا می‌شود
                // و دیگر داخل LINQ to Entities نیست.
                // =================================================

                List<DepartmentInfo> departments;

                using (var db =
                    new ApplicationDbContext())
                {
                    departments =
                        db.Departments
                            .Where(d => d.IsActive)
                            .Select(d =>
                                new DepartmentInfo
                                {
                                    DepartmentId =
                                        d.DepartmentId,

                                    DepartmentName =
                                        d.DepartmentName
                                })
                            .ToList();
                }


                using (Stream stream =
                    fuExcel.PostedFile.InputStream)
                {
                    IWorkbook workbook;


                    // -------------------------------------------------
                    // XLSX
                    // -------------------------------------------------

                    if (extension == ".xlsx")
                    {
                        workbook =
                            new XSSFWorkbook(stream);
                    }

                    // -------------------------------------------------
                    // XLS
                    // -------------------------------------------------

                    else
                    {
                        workbook =
                            new HSSFWorkbook(stream);
                    }


                    ISheet sheet =
                        workbook.GetSheetAt(0);


                    if (sheet == null)
                    {
                        ShowExcelError(
                            "فایل Excel فاقد Sheet معتبر است.");

                        return;
                    }


                    int lastRow =
                        sheet.LastRowNum;


                    if (lastRow < 1)
                    {
                        ShowExcelError(
                            "فایل Excel فاقد اطلاعات کاربر است.");

                        return;
                    }


                    // -------------------------------------------------
                    // بررسی Header
                    // -------------------------------------------------

                    ValidateHeaders(sheet);


                    // -------------------------------------------------
                    // جلوگیری از نام کاربری تکراری در همان فایل
                    // -------------------------------------------------

                    HashSet<string> excelUserNames =
                        new HashSet<string>(
                            StringComparer.OrdinalIgnoreCase);


                    // -------------------------------------------------
                    // پردازش ردیف‌ها
                    // -------------------------------------------------

                    for (int rowIndex = 1;
                         rowIndex <= lastRow;
                         rowIndex++)
                    {
                        IRow row =
                            sheet.GetRow(rowIndex);


                        if (IsEmptyRow(row))
                        {
                            continue;
                        }


                        ImportResult result =
                            ProcessExcelRow(
                                row,
                                rowIndex + 1,
                                excelUserNames,
                                departments);


                        results.Add(result);
                    }
                }


                // =================================================
                // نمایش گزارش
                // =================================================

                gvImportReport.DataSource =
                    results;

                gvImportReport.DataBind();


                pnlImportReport.Visible = true;


                int total =
                    results.Count;


                int success =
                    results.Count(
                        x => x.IsSuccess);


                int errors =
                    results.Count(
                        x => !x.IsSuccess);


                lblTotalRows.Text =
                    "تعداد ردیف‌ها: " +
                    total.ToString();


                lblSuccessRows.Text =
                    "ثبت موفق: " +
                    success.ToString();


                lblErrorRows.Text =
                    "دارای خطا: " +
                    errors.ToString();


                if (errors == 0)
                {
                    ShowExcelSuccess(
                        "ورود اطلاعات با موفقیت انجام شد. تعداد " +
                        success.ToString() +
                        " کاربر ثبت شد.");
                }
                else
                {
                    ShowExcelWarning(
                        "عملیات ورود اطلاعات انجام شد. " +
                        success.ToString() +
                        " کاربر ثبت شد و " +
                        errors.ToString() +
                        " ردیف دارای خطا بود.");
                }
            }
            catch (Exception ex)
            {
                ShowExcelError(
                    "خطا در خواندن فایل Excel: " +
                    ex.Message);
            }
        }


        // =========================================================
        // بررسی Header
        // =========================================================

        private void ValidateHeaders(
            ISheet sheet)
        {
            IRow header =
                sheet.GetRow(0);


            if (header == null)
            {
                throw new Exception(
                    "سطر عنوان ستون‌ها در فایل Excel پیدا نشد.");
            }


            string[] requiredHeaders =
            {
                "نام کاربری",
                "نام و نام خانوادگی",
                "واحد سازمانی",
                "رمز عبور",
                "فعال"
            };


            for (int i = 0;
                 i < requiredHeaders.Length;
                 i++)
            {
                string value =
                    GetCellText(
                        header.GetCell(i));


                if (!string.Equals(
                    NormalizeText(value),
                    NormalizeText(requiredHeaders[i]),
                    StringComparison.OrdinalIgnoreCase))
                {
                    throw new Exception(
                        "ساختار فایل Excel صحیح نیست. " +
                        "ستون شماره " +
                        (i + 1).ToString() +
                        " باید «" +
                        requiredHeaders[i] +
                        "» باشد.");
                }
            }
        }


        // =========================================================
        // پردازش هر ردیف Excel
        // =========================================================

        private ImportResult ProcessExcelRow(
            IRow row,
            int excelRowNumber,
            HashSet<string> excelUserNames,
            List<DepartmentInfo> departments)
        {
            ImportResult result =
                new ImportResult();


            result.RowNumber =
                excelRowNumber;


            // -----------------------------------------------------
            // خواندن سلول‌ها
            // -----------------------------------------------------

            result.UserName =
                GetCellText(
                    row.GetCell(0));


            result.FullName =
                GetCellText(
                    row.GetCell(1));


            result.DepartmentName =
                GetCellText(
                    row.GetCell(2));


            string password =
                GetCellText(
                    row.GetCell(3));


            string activeText =
                GetCellText(
                    row.GetCell(4));


            // -----------------------------------------------------
            // نام کاربری
            // -----------------------------------------------------

            if (string.IsNullOrEmpty(
                result.UserName))
            {
                return Fail(
                    result,
                    "نام کاربری وارد نشده است.");
            }


            // -----------------------------------------------------
            // نام و نام خانوادگی
            // -----------------------------------------------------

            if (string.IsNullOrEmpty(
                result.FullName))
            {
                return Fail(
                    result,
                    "نام و نام خانوادگی وارد نشده است.");
            }


            // -----------------------------------------------------
            // واحد سازمانی
            // -----------------------------------------------------

            if (string.IsNullOrEmpty(
                result.DepartmentName))
            {
                return Fail(
                    result,
                    "واحد سازمانی وارد نشده است.");
            }


            // -----------------------------------------------------
            // رمز عبور
            // -----------------------------------------------------

            if (string.IsNullOrEmpty(password))
            {
                return Fail(
                    result,
                    "رمز عبور وارد نشده است.");
            }


            if (password.Length < 6)
            {
                return Fail(
                    result,
                    "رمز عبور باید حداقل 6 کاراکتر باشد.");
            }


            // -----------------------------------------------------
            // تکراری بودن نام کاربری در خود Excel
            // -----------------------------------------------------

            string normalizedUserName =
                NormalizeText(
                    result.UserName);


            if (excelUserNames.Contains(
                normalizedUserName))
            {
                return Fail(
                    result,
                    "این نام کاربری در فایل Excel تکراری است.");
            }


            excelUserNames.Add(
                normalizedUserName);


            // -----------------------------------------------------
            // بررسی وضعیت فعال
            // -----------------------------------------------------

            bool isActive;


            if (!TryParseActive(
                activeText,
                out isActive))
            {
                return Fail(
                    result,
                    "مقدار ستون فعال معتبر نیست. " +
                    "مقادیر مجاز: بله، خیر، فعال، غیرفعال، 1 یا 0.");
            }


            // =====================================================
            // اصلاح اصلی:
            //
            // قبلاً این کار انجام می‌شد:
            //
            // db.Departments.FirstOrDefault(
            //     d => NormalizeText(d.DepartmentName)
            //          ==
            //          NormalizeText(result.DepartmentName)
            // );
            //
            // که باعث خطای LINQ to Entities می‌شد.
            //
            // اکنون departments قبلاً با ToList()
            // از DB گرفته شده و مقایسه در حافظه انجام می‌شود.
            // =====================================================

            string normalizedDepartmentName =
                NormalizeText(
                    result.DepartmentName);


            DepartmentInfo department =
                departments.FirstOrDefault(
                    d =>
                        NormalizeText(
                            d.DepartmentName)
                        ==
                        normalizedDepartmentName);


            if (department == null)
            {
                return Fail(
                    result,
                    "واحد سازمانی «" +
                    result.DepartmentName +
                    "» پیدا نشد یا غیرفعال است.");
            }


            // =====================================================
            // ثبت در دیتابیس
            // =====================================================

            using (var db =
                new ApplicationDbContext())
            {
                // -------------------------------------------------
                // بررسی مجدد نام کاربری در دیتابیس
                // -------------------------------------------------

                string normalizedDbUserName =
                    NormalizeText(
                        result.UserName);


                var allUsers =
                    db.Users
                        .Select(u => u.UserName)
                        .ToList();


                bool userExists =
                    allUsers.Any(
                        u =>
                            NormalizeText(u)
                            ==
                            normalizedDbUserName);


                if (userExists)
                {
                    return Fail(
                        result,
                        "این نام کاربری قبلاً در سامانه ثبت شده است.");
                }


                // -------------------------------------------------
                // تراکنش
                // -------------------------------------------------

                using (var transaction =
                    db.Database.BeginTransaction())
                {
                    try
                    {
                        // -----------------------------------------
                        // UserManager
                        // -----------------------------------------

                        var userManager =
                            new UserManager<ApplicationUser>(
                                new UserStore<ApplicationUser>(db));


                        var user =
                            new ApplicationUser
                            {
                                UserName =
                                    result.UserName
                            };


                        IdentityResult createResult =
                            userManager.Create(
                                user,
                                password);


                        if (!createResult.Succeeded)
                        {
                            transaction.Rollback();

                            return Fail(
                                result,
                                string.Join(
                                    " ",
                                    createResult.Errors));
                        }


                        // -----------------------------------------
                        // نقش User
                        // -----------------------------------------

                        string role =
                            "User";


                        var roleManager =
                            new RoleManager<IdentityRole>(
                                new RoleStore<IdentityRole>(db));


                        if (!roleManager.RoleExists(role))
                        {
                            IdentityResult roleResult =
                                roleManager.Create(
                                    new IdentityRole(role));


                            if (!roleResult.Succeeded)
                            {
                                transaction.Rollback();

                                return Fail(
                                    result,
                                    "خطا در ایجاد نقش کاربر: " +
                                    string.Join(
                                        " ",
                                        roleResult.Errors));
                            }
                        }


                        // -----------------------------------------
                        // اختصاص نقش
                        // -----------------------------------------

                        IdentityResult addRoleResult =
                            userManager.AddToRole(
                                user.Id,
                                role);


                        if (!addRoleResult.Succeeded)
                        {
                            transaction.Rollback();

                            return Fail(
                                result,
                                string.Join(
                                    " ",
                                    addRoleResult.Errors));
                        }


                        // -----------------------------------------
                        // UserProfile
                        // -----------------------------------------

                        var profile =
                            new UserProfile
                            {
                                UserId =
                                    user.Id,

                                FullName =
                                    result.FullName,

                                DepartmentId =
                                    department.DepartmentId,

                                UserCategory =
                                    "General",

                                IsActive =
                                    isActive,

                                CreatedAt =
                                    DateTime.Now
                            };


                        db.UserProfiles.Add(
                            profile);


                        db.SaveChanges();


                        transaction.Commit();


                        // -----------------------------------------
                        // نتیجه موفق
                        // -----------------------------------------

                        result.IsSuccess =
                            true;


                        result.Status =
                            "ثبت شد";


                        result.Message =
                            "کاربر با موفقیت ثبت شد.";


                        return result;
                    }
                    catch (Exception ex)
                    {
                        try
                        {
                            transaction.Rollback();
                        }
                        catch
                        {
                        }


                        return Fail(
                            result,
                            "خطا هنگام ثبت اطلاعات: " +
                            ex.Message);
                    }
                }
            }
        }


        // =========================================================
        // نتیجه خطا
        // =========================================================

        private ImportResult Fail(
            ImportResult result,
            string message)
        {
            result.IsSuccess =
                false;


            result.Status =
                "خطا";


            result.Message =
                message;


            return result;
        }


        // =========================================================
        // تبدیل مقدار فعال
        // =========================================================

        private bool TryParseActive(
            string value,
            out bool isActive)
        {
            isActive = true;


            string text =
                NormalizeText(value)
                .ToLower();


            if (text == "بله" ||
                text == "فعال" ||
                text == "1" ||
                text == "true")
            {
                isActive = true;

                return true;
            }


            if (text == "خیر" ||
                text == "غیرفعال" ||
                text == "غيرفعال" ||
                text == "0" ||
                text == "false")
            {
                isActive = false;

                return true;
            }


            return false;
        }


        // =========================================================
        // خواندن مقدار سلول Excel
        // =========================================================

        private string GetCellText(
            ICell cell)
        {
            if (cell == null)
                return "";


            if (cell.CellType ==
                CellType.Numeric)
            {
                return cell.NumericCellValue
                    .ToString();
            }


            if (cell.CellType ==
                CellType.Boolean)
            {
                return cell.BooleanCellValue
                    ? "بله"
                    : "خیر";
            }


            if (cell.CellType ==
                CellType.Formula)
            {
                try
                {
                    return cell.StringCellValue
                        .Trim();
                }
                catch
                {
                    try
                    {
                        return cell.NumericCellValue
                            .ToString();
                    }
                    catch
                    {
                        return "";
                    }
                }
            }


            return
                (cell.StringCellValue ?? "")
                .Trim();
        }


        // =========================================================
        // تشخیص ردیف خالی
        // =========================================================

        private bool IsEmptyRow(
            IRow row)
        {
            if (row == null)
                return true;


            for (int i = 0; i < 5; i++)
            {
                string value =
                    GetCellText(
                        row.GetCell(i));


                if (!string.IsNullOrEmpty(value))
                    return false;
            }


            return true;
        }


        // =========================================================
        // نرمال‌سازی متن فارسی
        // =========================================================

        private string NormalizeText(
            string value)
        {
            if (string.IsNullOrEmpty(value))
                return "";


            return value
                .Trim()
                .Replace("ي", "ی")
                .Replace("ى", "ی")
                .Replace("ك", "ک")
                .Replace("ة", "ه")
                .Replace("\u200c", " ");
        }


        // =========================================================
        // پاک کردن فرم
        // =========================================================

        private void ClearForm()
        {
            txtUserName.Text = "";

            txtFullName.Text = "";

            txtPassword.Text = "";

            txtConfirmPassword.Text = "";


            if (ddlDepartment.Items.Count > 0)
            {
                ddlDepartment.SelectedIndex = 0;
            }


            chkIsActive.Checked = true;
        }


        // =========================================================
        // پیام موفقیت ایجاد کاربر
        // =========================================================

        private void ShowSuccess(
            string message)
        {
            lblMessage.Text =
                message;


            lblMessage.CssClass =
                "message success";


            lblMessage.Visible =
                true;
        }


        // =========================================================
        // پیام خطا ایجاد کاربر
        // =========================================================

        private void ShowError(
            string message)
        {
            lblMessage.Text =
                message;


            lblMessage.CssClass =
                "message error";


            lblMessage.Visible =
                true;
        }


        // =========================================================
        // پیام Excel - موفق
        // =========================================================

        private void ShowExcelSuccess(
            string message)
        {
            lblExcelMessage.Text =
                message;


            lblExcelMessage.CssClass =
                "message success";


            lblExcelMessage.Visible =
                true;
        }


        // =========================================================
        // پیام Excel - هشدار
        // =========================================================

        private void ShowExcelWarning(
            string message)
        {
            lblExcelMessage.Text =
                message;


            lblExcelMessage.CssClass =
                "message warning";


            lblExcelMessage.Visible =
                true;
        }


        // =========================================================
        // پیام Excel - خطا
        // =========================================================

        private void ShowExcelError(
            string message)
        {
            lblExcelMessage.Text =
                message;


            lblExcelMessage.CssClass =
                "message error";


            lblExcelMessage.Visible =
                true;
        }


        // =========================================================
        // اطلاعات واحد سازمانی
        // =========================================================

        private class DepartmentInfo
        {
            public int DepartmentId
            {
                get;
                set;
            }


            public string DepartmentName
            {
                get;
                set;
            }
        }


        // =========================================================
        // نتیجه Import
        // =========================================================

        private class ImportResult
        {
            public int RowNumber
            {
                get;
                set;
            }


            public string UserName
            {
                get;
                set;
            }


            public string FullName
            {
                get;
                set;
            }


            public string DepartmentName
            {
                get;
                set;
            }


            public bool IsSuccess
            {
                get;
                set;
            }


            public string Status
            {
                get;
                set;
            }


            public string Message
            {
                get;
                set;
            }
        }
    }
}