﻿<%@ Page Language="C#" AutoEventWireup="true"
    CodeBehind="AutoCloseTickets.aspx.cs"
    Inherits="WebApplication1.AutoCloseTickets" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">

<head runat="server">
    <meta charset="utf-8" />
    <title>Auto Close Tickets</title>
</head>

<body>

<form id="form1" runat="server">

    <asp:Label
        ID="lblResult"
        runat="server">
    </asp:Label>

</form>

</body>

</html>