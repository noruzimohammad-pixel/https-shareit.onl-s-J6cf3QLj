﻿<%@ Page Title="جزئیات درخواست"
    Language="C#"
    MasterPageFile="~/Site.Master"
    AutoEventWireup="true"
    CodeBehind="SpecialistTicketDetails.aspx.cs"
    Inherits="WebApplication1.SpecialistTicketDetails" %>

<asp:Content ID="Content1"
    ContentPlaceHolderID="MainContent"
    runat="server">

    <style type="text/css">

        .ticket-page {
            direction: rtl;
            width: 100%;
            max-width: 1200px;
            margin: 0 auto;
            padding: 10px 0 35px 0;
            box-sizing: border-box;
        }

        .ticket-header {
            background: #ffffff;
            border: 1px solid #e7ebf0;
            border-radius: 14px;
            box-shadow: 0 4px 16px rgba(28,39,56,.05);
            padding: 20px 22px;
            margin-bottom: 18px;
        }

        .ticket-header-top {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 15px;
        }

        .ticket-title-area {
            min-width: 0;
        }

        .ticket-number {
            color: #2f80ed;
            font-size: 11px;
            font-weight: bold;
            margin-bottom: 5px;
        }

        .ticket-title {
            color: #273142;
            font-size: 20px;
            font-weight: bold;
            line-height: 1.8;
            margin: 0;
        }

        .ticket-meta {
            display: flex;
            align-items: center;
            gap: 7px;
            flex-wrap: wrap;
            margin-top: 8px;
        }

        .meta-pill {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            min-height: 26px;
            padding: 0 10px;
            border-radius: 20px;
            font-size: 10px;
            font-weight: bold;
        }

        .meta-status {
            background: #eaf2ff;
            color: #2f80ed;
        }

        .meta-priority {
            background: #fff3df;
            color: #d6810c;
        }

        .meta-category {
            background: #eef1f5;
            color: #697586;
        }

        .back-button {
            flex-shrink: 0;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            min-height: 38px;
            padding: 0 16px;
            background: #ffffff;
            border: 1px solid #dfe4eb;
            border-radius: 8px;
            color: #596577 !important;
            text-decoration: none !important;
            font-size: 11px;
            font-weight: bold;
        }

        .back-button:hover {
            background: #f8f9fb;
            border-color: #cfd6df;
        }

        .ticket-tabs {
            background: #ffffff;
            border: 1px solid #e7ebf0;
            border-radius: 14px;
            box-shadow: 0 4px 16px rgba(28,39,56,.05);
            overflow: hidden;
        }

        .tab-buttons {
            display: flex;
            align-items: stretch;
            background: #fafbfd;
            border-bottom: 1px solid #e8ebf0;
            overflow-x: auto;
        }

        .tab-button {
            border: 0;
            border-left: 1px solid #edf0f4;
            background: transparent;
            color: #7b8595;
            padding: 15px 22px;
            min-height: 54px;
            font-family: 'Vazirmatn', 'B Nazanin', 'B Zar', Tahoma, Arial, sans-serif;
            font-size: 12px;
            font-weight: bold;
            cursor: pointer;
            white-space: nowrap;
        }

        .tab-button:first-child {
            border-left: 0;
        }

        .tab-button:hover {
            background: #f5f7fa;
            color: #4f5c6d;
        }

        .tab-button.active {
            background: #ffffff;
            color: #2f80ed;
            box-shadow: inset 0 -3px 0 #2f80ed;
        }

        .tab-content {
            display: none;
            padding: 22px;
        }

        .tab-content.active {
            display: block;
        }

        .section-title {
            display: flex;
            align-items: center;
            gap: 9px;
            color: #273142;
            font-size: 14px;
            font-weight: bold;
            margin-bottom: 17px;
        }

        .section-title-icon {
            width: 7px;
            height: 22px;
            background: #2f80ed;
            border-radius: 5px;
        }

        .info-grid {
            display: grid;
            grid-template-columns: repeat(3, minmax(0, 1fr));
            gap: 12px;
        }

        .info-item {
            background: #f8f9fb;
            border: 1px solid #edf0f4;
            border-radius: 9px;
            padding: 13px 14px;
            min-width: 0;
        }

        .info-label {
            display: block;
            color: #8a94a3;
            font-size: 10px;
            margin-bottom: 6px;
        }

        .info-value {
            display: block;
            color: #354052;
            font-size: 11px;
            font-weight: bold;
            line-height: 1.8;
            word-break: break-word;
        }

        .description-title {
            color: #7b8595;
            font-size: 11px;
            font-weight: bold;
            margin: 22px 0 8px 0;
        }

        .description-box {
            background: #f8f9fb;
            border: 1px solid #edf0f4;
            border-radius: 9px;
            padding: 15px;
            color: #4d596a;
            font-size: 12px;
            line-height: 2.1;
            white-space: pre-wrap;
            min-height: 70px;
        }

        .operation-intro {
            background: #f8f9fb;
            border: 1px solid #edf0f4;
            border-radius: 9px;
            padding: 14px 16px;
            color: #687386;
            font-size: 11px;
            line-height: 2;
            margin-bottom: 16px;
        }

        .operation-panel {
            background: #ffffff;
            border: 1px solid #e7ebf0;
            border-radius: 10px;
            padding: 17px;
        }

        .operation-title {
            color: #354052;
            font-size: 12px;
            font-weight: bold;
            margin-bottom: 12px;
        }

        .action-textarea {
            width: 100%;
            min-height: 130px;
            resize: vertical;
            box-sizing: border-box;
            border: 1px solid #dfe4eb;
            border-radius: 8px;
            padding: 12px;
            background: #ffffff;
            color: #354052;
            font-family: 'Vazirmatn', 'B Nazanin', 'B Zar', Tahoma, Arial, sans-serif;
            font-size: 12px;
            line-height: 2;
            outline: none;
        }

        .action-textarea:focus {
            border-color: #2f80ed;
            box-shadow: 0 0 0 3px rgba(47,128,237,.08);
        }

        .operation-buttons {
            display: flex;
            align-items: center;
            flex-wrap: wrap;
            gap: 9px;
            margin-top: 13px;
        }

        .btn-primary-custom,
        .btn-success-custom,
        .btn-danger-custom,
        .btn-secondary-custom {
            min-height: 39px;
            padding: 0 16px;
            border: 0;
            border-radius: 8px;
            color: #ffffff;
            font-family: 'Vazirmatn', 'B Nazanin', 'B Zar', Tahoma, Arial, sans-serif;
            font-size: 11px;
            font-weight: bold;
            cursor: pointer;
        }

        .btn-primary-custom {
            background: #2f80ed;
        }

        .btn-primary-custom:hover {
            background: #256fd0;
        }

        .btn-success-custom {
            background: #239653;
        }

        .btn-success-custom:hover {
            background: #1d7e45;
        }

        .btn-danger-custom {
            background: #d63b2d;
        }

        .btn-danger-custom:hover {
            background: #bd3024;
        }

        .btn-secondary-custom {
            background: #697586;
        }

        .btn-secondary-custom:hover {
            background: #596577;
        }

        .diagnosis-panel {
            background: #f8f9fb;
            border: 1px solid #e7ebf0;
            border-radius: 11px;
            padding: 18px;
        }

        .diagnosis-intro {
            color: #687386;
            font-size: 11px;
            line-height: 2;
            margin-bottom: 17px;
        }

        .diagnosis-grid {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 14px;
        }

        .diagnosis-field {
            min-width: 0;
        }

        .diagnosis-label {
            display: block;
            color: #566173;
            font-size: 11px;
            font-weight: bold;
            margin-bottom: 7px;
        }

        .diagnosis-select {
            width: 100%;
            min-height: 41px;
            box-sizing: border-box;
            border: 1px solid #dfe4eb;
            border-radius: 8px;
            background: #ffffff;
            color: #354052;
            padding: 0 10px;
            font-family: 'Vazirmatn', 'B Nazanin', 'B Zar', Tahoma, Arial, sans-serif;
            font-size: 11px;
            outline: none;
        }

        .diagnosis-select:focus {
            border-color: #2f80ed;
            box-shadow: 0 0 0 3px rgba(47,128,237,.08);
        }

        .diagnosis-button-row {
            display: flex;
            justify-content: flex-start;
            margin-top: 15px;
        }

        .current-diagnosis {
            margin-top: 17px;
            padding: 14px 16px;
            background: #eef8f2;
            border: 1px solid #d5efdf;
            border-radius: 9px;
        }

        .current-diagnosis-title {
            color: #39815a;
            font-size: 10px;
            font-weight: bold;
            margin-bottom: 5px;
        }

        .current-diagnosis-value {
            color: #245e3d;
            font-size: 12px;
            font-weight: bold;
        }

        .return-panel {
            margin-top: 22px;
            background: #fff8f7;
            border: 1px solid #f0d6d2;
            border-radius: 11px;
            padding: 18px;
        }

        .return-title {
            display: flex;
            align-items: center;
            gap: 8px;
            color: #bd3024;
            font-size: 13px;
            font-weight: bold;
            margin-bottom: 8px;
        }

        .return-icon {
            width: 25px;
            height: 25px;
            border-radius: 50%;
            background: #fdeceb;
            color: #d63b2d;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font-size: 12px;
            font-weight: bold;
        }

        .return-description {
            color: #7e5b57;
            font-size: 10px;
            line-height: 2;
            margin-bottom: 13px;
        }

        .return-reason {
            width: 100%;
            min-height: 105px;
            box-sizing: border-box;
            resize: vertical;
            border: 1px solid #e8c8c3;
            border-radius: 8px;
            background: #ffffff;
            color: #4d3b38;
            padding: 11px;
            font-family: 'Vazirmatn', 'B Nazanin', 'B Zar', Tahoma, Arial, sans-serif;
            font-size: 11px;
            line-height: 2;
            outline: none;
        }

        .return-reason:focus {
            border-color: #d63b2d;
            box-shadow: 0 0 0 3px rgba(214,59,45,.08);
        }

        .return-buttons {
            display: flex;
            justify-content: flex-start;
            margin-top: 11px;
        }

        .message-box {
            display: block;
            margin-top: 15px;
            padding: 11px 14px;
            border-radius: 8px;
            font-size: 11px;
            line-height: 1.9;
        }

        .table-wrapper {
            width: 100%;
            overflow-x: auto;
            border: 1px solid #e8ebf0;
            border-radius: 10px;
        }

        .data-table {
            width: 100%;
            min-width: 700px;
            border-collapse: collapse;
        }

        .data-table th {
            background: #f8f9fb;
            color: #687386;
            font-size: 10px;
            font-weight: bold;
            padding: 13px 11px;
            text-align: right;
            border-bottom: 1px solid #e5e9ee;
            white-space: nowrap;
        }

        .data-table td {
            color: #465164;
            font-size: 10px;
            padding: 13px 11px;
            border-bottom: 1px solid #eef0f3;
            vertical-align: top;
            line-height: 1.9;
        }

        .data-table tr:last-child td {
            border-bottom: 0;
        }

        .data-table tr:hover td {
            background: #fafbfd;
        }

        .empty-message {
            text-align: center;
            color: #929baa;
            padding: 30px !important;
        }

        .back-bottom {
            margin-top: 18px;
            display: flex;
            justify-content: flex-start;
        }

        @media screen and (max-width: 900px) {
            .info-grid {
                grid-template-columns: repeat(2, minmax(0, 1fr));
            }
        }

        @media screen and (max-width: 650px) {

            .ticket-page {
                padding: 5px 0 25px 0;
            }

            .ticket-header {
                padding: 16px;
            }

            .ticket-header-top {
                align-items: flex-start;
                flex-direction: column;
            }

            .back-button {
                width: 100%;
            }

            .tab-button {
                padding: 13px 15px;
                font-size: 11px;
            }

            .tab-content {
                padding: 15px;
            }

            .info-grid,
            .diagnosis-grid {
                grid-template-columns: 1fr;
            }

            .operation-buttons {
                flex-direction: column;
                align-items: stretch;
            }

            .operation-buttons input,
            .diagnosis-button-row input,
            .return-buttons input {
                width: 100%;
            }
        }

    </style>

    <div class="ticket-page">

        <div class="ticket-header">

            <div class="ticket-header-top">

                <div class="ticket-title-area">

                    <div class="ticket-number">
                        درخواست شماره
                        <asp:Label ID="lblTicketId"
                            runat="server"></asp:Label>
                    </div>

                    <h1 class="ticket-title">
                        <asp:Label ID="lblSubject"
                            runat="server"></asp:Label>
                    </h1>

                    <div class="ticket-meta">

                        <span class="meta-pill meta-status">
                            <asp:Label ID="lblStatus"
                                runat="server"></asp:Label>
                        </span>

                        <span class="meta-pill meta-priority">
                            <asp:Label ID="lblPriority"
                                runat="server"></asp:Label>
                        </span>

                        <span class="meta-pill meta-category">
                            <asp:Label ID="lblCategory"
                                runat="server"></asp:Label>
                        </span>

                    </div>

                </div>

                <asp:HyperLink
                    ID="lnkBack"
                    runat="server"
                    NavigateUrl="~/SpecialistDashboard.aspx"
                    CssClass="back-button">
                    بازگشت به کارتابل
                </asp:HyperLink>

            </div>

        </div>

        <div class="ticket-tabs">

            <div class="tab-buttons">

                <button type="button"
                    id="btnTabInfo"
                    class="tab-button active"
                    onclick="showTab('tabInfo', this);">
                    اطلاعات درخواست
                </button>

                <button type="button"
                    id="btnTabDiagnosis"
                    class="tab-button"
                    onclick="showTab('tabDiagnosis', this);">
                    تشخیص مشکل
                </button>

                <button type="button"
                    id="btnTabOperations"
                    class="tab-button"
                    onclick="showTab('tabOperations', this);">
                    اقدامات متخصص
                </button>

                <button type="button"
                    id="btnTabActions"
                    class="tab-button"
                    onclick="showTab('tabActions', this);">
                    اقدامات انجام‌شده
                </button>

                <button type="button"
                    id="btnTabHistory"
                    class="tab-button"
                    onclick="showTab('tabHistory', this);">
                    تاریخچه درخواست
                </button>

            </div>

            <div id="tabInfo"
                class="tab-content active">

                <div class="section-title">
                    <span class="section-title-icon"></span>
                    اطلاعات درخواست
                </div>

                <div class="info-grid">

                    <div class="info-item">
                        <span class="info-label">شماره درخواست</span>
                        <asp:Label ID="lblInfoTicketId"
                            runat="server"
                            CssClass="info-value"></asp:Label>
                    </div>

                    <div class="info-item">
                        <span class="info-label">درخواست‌دهنده</span>
                        <asp:Label ID="lblRequester"
                            runat="server"
                            CssClass="info-value"></asp:Label>
                    </div>

                    <div class="info-item">
                        <span class="info-label">واحد / بخش</span>
                        <asp:Label ID="lblDepartment"
                            runat="server"
                            CssClass="info-value"></asp:Label>
                    </div>

                    <div class="info-item">
                        <span class="info-label">تاریخ ثبت</span>
                        <asp:Label ID="lblCreatedAt"
                            runat="server"
                            CssClass="info-value"></asp:Label>
                    </div>

                    <div class="info-item">
                        <span class="info-label">وضعیت</span>
                        <asp:Label ID="lblInfoStatus"
                            runat="server"
                            CssClass="info-value"></asp:Label>
                    </div>

                    <div class="info-item">
                        <span class="info-label">اولویت</span>
                        <asp:Label ID="lblInfoPriority"
                            runat="server"
                            CssClass="info-value"></asp:Label>
                    </div>

                    <div class="info-item">
                        <span class="info-label">دسته‌بندی انتخاب‌شده توسط کاربر</span>
                        <asp:Label ID="lblInfoCategory"
                            runat="server"
                            CssClass="info-value"></asp:Label>
                    </div>

                    <div class="info-item">
                        <span class="info-label">موضوع درخواست</span>
                        <asp:Label ID="lblInfoSubject"
                            runat="server"
                            CssClass="info-value"></asp:Label>
                    </div>

                </div>

                <div class="description-title">
                    شرح درخواست
                </div>

                <div class="description-box">
                    <asp:Label ID="lblDescription"
                        runat="server"></asp:Label>
                </div>

            </div>

            <div id="tabDiagnosis"
                class="tab-content">

                <div class="section-title">
                    <span class="section-title-icon"></span>
                    تشخیص مشکل
                </div>

                <div class="diagnosis-panel">

                    <div class="diagnosis-intro">
                        در این بخش حوزه و موضوع واقعی مشکل را پس از بررسی درخواست مشخص کنید.
                        این اطلاعات بیانگر تشخیص متخصص است و با دسته‌بندی اولیه انتخاب‌شده توسط درخواست‌دهنده تفاوت دارد.
                    </div>

                    <div class="diagnosis-grid">

                        <div class="diagnosis-field">

                            <label class="diagnosis-label">
                                حوزه واقعی مشکل
                            </label>

                            <asp:DropDownList
                                ID="ddlServiceCategory"
                                runat="server"
                                CssClass="diagnosis-select"
                                AutoPostBack="true"
                                OnSelectedIndexChanged="ddlServiceCategory_SelectedIndexChanged">
                            </asp:DropDownList>

                        </div>

                        <div class="diagnosis-field">

                            <label class="diagnosis-label">
                                موضوع واقعی مشکل
                            </label>

                            <asp:DropDownList
                                ID="ddlServiceTopic"
                                runat="server"
                                CssClass="diagnosis-select">
                            </asp:DropDownList>

                        </div>

                    </div>

                    <div class="diagnosis-button-row">

                        <asp:Button
                            ID="btnSaveDiagnosis"
                            runat="server"
                            Text="ثبت تشخیص مشکل"
                            CssClass="btn-primary-custom"
                            OnClick="btnSaveDiagnosis_Click"
                            OnClientClick="rememberTab('tabDiagnosis');" />

                    </div>

                    <asp:Panel
                        ID="pnlCurrentDiagnosis"
                        runat="server"
                        CssClass="current-diagnosis"
                        Visible="false">

                        <div class="current-diagnosis-title">
                            تشخیص ثبت‌شده
                        </div>

                        <div class="current-diagnosis-value">
                            <asp:Label
                                ID="lblCurrentDiagnosis"
                                runat="server">
                            </asp:Label>
                        </div>

                    </asp:Panel>

                </div>

                <div class="return-panel">

                    <div class="return-title">

                        <span class="return-icon">
                            !
                        </span>

                        مرجوع کردن درخواست

                    </div>

                    <div class="return-description">
                        اگر پس از بررسی مشخص شد حوزه یا دسته‌بندی انتخاب‌شده برای این درخواست
                        با ماهیت واقعی مشکل مطابقت ندارد، درخواست را برای بررسی و ارجاع مجدد
                        به مدیر برگردانید.
                    </div>

                    <asp:TextBox
                        ID="txtReturnReason"
                        runat="server"
                        CssClass="return-reason"
                        TextMode="MultiLine"
                        Rows="4"
                        placeholder="علت مرجوع کردن درخواست را به‌صورت واضح وارد کنید؛ برای مثال: مشکل مربوط به شبکه است و در حوزه نرم‌افزار ارجاع شده است.">
                    </asp:TextBox>

                    <div class="return-buttons">

                        <asp:Button
                            ID="btnReturnTicket"
                            runat="server"
                            Text="مرجوع کردن درخواست"
                            CssClass="btn-danger-custom"
                            OnClick="btnReturnTicket_Click"
                            OnClientClick="return confirmReturnTicket();" />

                    </div>

                </div>

            </div>

            <div id="tabOperations"
                class="tab-content">

                <div class="section-title">
                    <span class="section-title-icon"></span>
                    اقدامات متخصص
                </div>

                <div class="operation-intro">
                    اقدامات فنی، بررسی‌ها و کارهایی که برای رفع مشکل انجام می‌دهید
                    در این بخش ثبت می‌شوند. پس از تکمیل کار، درخواست برای تأیید
                    به درخواست‌دهنده ارسال خواهد شد.
                </div>

                <div class="operation-panel">

                    <asp:Panel
                        ID="pnlStart"
                        runat="server">

                        <div class="operation-title">
                            شروع رسیدگی
                        </div>

                        <div class="operation-intro">
                            این درخواست در وضعیت «ارجاع شده» قرار دارد.
                            برای آغاز رسیدگی، دکمه زیر را انتخاب کنید.
                        </div>

                        <div class="operation-buttons">

                            <asp:Button
                                ID="btnStartWork"
                                runat="server"
                                Text="شروع رسیدگی"
                                CssClass="btn-secondary-custom"
                                OnClick="btnStartWork_Click"
                                OnClientClick="rememberTab('tabOperations');" />

                        </div>

                    </asp:Panel>

                    <asp:Panel
                        ID="pnlWork"
                        runat="server"
                        Visible="false">

                        <div class="operation-title">
                            شرح اقدام / کار انجام‌شده
                        </div>

                        <asp:TextBox
                            ID="txtActionText"
                            runat="server"
                            CssClass="action-textarea"
                            TextMode="MultiLine"
                            Rows="5"
                            placeholder="اقدام انجام‌شده، بررسی‌ها، نتیجه کار و توضیحات لازم را وارد کنید...">
                        </asp:TextBox>

                        <div class="operation-buttons">

                            <asp:Button
                                ID="btnAddAction"
                                runat="server"
                                Text="ثبت اقدام"
                                CssClass="btn-secondary-custom"
                                OnClick="btnAddAction_Click"
                                OnClientClick="rememberTab('tabOperations');" />

                            <asp:Button
                                ID="btnFinishWork"
                                runat="server"
                                Text="اتمام کار و ارسال برای تأیید کاربر"
                                CssClass="btn-success-custom"
                                OnClick="btnFinishWork_Click"
                                OnClientClick="return finishWorkConfirm();" />

                        </div>

                    </asp:Panel>

                    <asp:Label
                        ID="lblMessage"
                        runat="server"
                        Visible="false"
                        CssClass="message-box">
                    </asp:Label>

                </div>

            </div>

            <div id="tabActions"
                class="tab-content">

                <div class="section-title">
                    <span class="section-title-icon"></span>
                    اقدامات انجام‌شده
                </div>

                <div class="table-wrapper">

                    <asp:GridView
                        ID="gvActions"
                        runat="server"
                        AutoGenerateColumns="False"
                        CssClass="data-table"
                        GridLines="None"
                        EmptyDataText="هنوز اقدامی ثبت نشده است">

                        <Columns>

                            <asp:BoundField
                                DataField="ActionDate"
                                HeaderText="تاریخ" />

                            <asp:BoundField
                                DataField="UserName"
                                HeaderText="متخصص" />

                            <asp:BoundField
                                DataField="ActionText"
                                HeaderText="شرح اقدام" />

                        </Columns>

                        <EmptyDataRowStyle
                            CssClass="empty-message" />

                    </asp:GridView>

                </div>

            </div>

            <div id="tabHistory"
                class="tab-content">

                <div class="section-title">
                    <span class="section-title-icon"></span>
                    تاریخچه درخواست
                </div>

                <div class="table-wrapper">

                    <asp:GridView
                        ID="gvHistory"
                        runat="server"
                        AutoGenerateColumns="False"
                        CssClass="data-table"
                        GridLines="None"
                        EmptyDataText="تاریخچه‌ای ثبت نشده است">

                        <Columns>

                            <asp:BoundField
                                DataField="HistoryDate"
                                HeaderText="تاریخ" />

                            <asp:BoundField
                                DataField="UserName"
                                HeaderText="کاربر" />

                            <asp:BoundField
                                DataField="OldStatus"
                                HeaderText="وضعیت قبلی" />

                            <asp:BoundField
                                DataField="NewStatus"
                                HeaderText="وضعیت جدید" />

                            <asp:BoundField
                                DataField="Description"
                                HeaderText="توضیحات" />

                        </Columns>

                        <EmptyDataRowStyle
                            CssClass="empty-message" />

                    </asp:GridView>

                </div>

            </div>

        </div>

        <div class="back-bottom">

            <asp:HyperLink
                ID="lnkBackBottom"
                runat="server"
                NavigateUrl="~/SpecialistTickets.aspx"
                CssClass="back-button">
                بازگشت به کارتابل
            </asp:HyperLink>

        </div>

        <asp:HiddenField
            ID="hfActiveTab"
            runat="server"
            Value="tabInfo" />

    </div>

    <script type="text/javascript">

        function showTab(tabId, button) {

            var tabs = document.getElementsByClassName("tab-content");

            for (var i = 0; i < tabs.length; i++) {
                tabs[i].className =
                    tabs[i].className.replace(" active", "");
            }

            var buttons = document.getElementsByClassName("tab-button");

            for (var j = 0; j < buttons.length; j++) {
                buttons[j].className =
                    buttons[j].className.replace(" active", "");
            }

            var selectedTab = document.getElementById(tabId);

            if (selectedTab) {
                selectedTab.className += " active";
            }

            if (button) {
                button.className += " active";
            }

            rememberTab(tabId);
        }

        function rememberTab(tabId) {

            var field =
                document.getElementById(
                    "<%= hfActiveTab.ClientID %>");

            if (field) {
                field.value = tabId;
            }
        }

        function restoreActiveTab() {

            var field =
                document.getElementById(
                    "<%= hfActiveTab.ClientID %>");

            if (!field || !field.value) {
                return;
            }

            var tabId = field.value;

            var tab =
                document.getElementById(tabId);

            if (!tab) {
                return;
            }

            var button = null;

            if (tabId === "tabInfo")
                button = document.getElementById("btnTabInfo");

            if (tabId === "tabDiagnosis")
                button = document.getElementById("btnTabDiagnosis");

            if (tabId === "tabOperations")
                button = document.getElementById("btnTabOperations");

            if (tabId === "tabActions")
                button = document.getElementById("btnTabActions");

            if (tabId === "tabHistory")
                button = document.getElementById("btnTabHistory");

            showTab(tabId, button);
        }

        function confirmReturnTicket() {

            var reason =
                document.getElementById(
                    "<%= txtReturnReason.ClientID %>");

            if (!reason || reason.value.trim() === "") {

                alert(
                    "لطفاً علت مرجوع کردن درخواست را وارد کنید."
                );

                if (reason) {
                    reason.focus();
                }

                return false;
            }

            rememberTab("tabDiagnosis");

            return confirm(
                "آیا از مرجوع کردن این درخواست برای ارجاع مجدد به مدیر مطمئن هستید؟"
            );
        }

        function finishWorkConfirm() {

            rememberTab("tabOperations");

            return confirm(
                "آیا از اتمام کار و ارسال درخواست برای تأیید کاربر مطمئن هستید؟"
            );
        }

        window.onload = function () {
            restoreActiveTab();
        };

    </script>

</asp:Content>