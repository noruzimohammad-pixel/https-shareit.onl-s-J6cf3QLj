﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Web.UI.WebControls;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;
using WebApplication1.Models;

namespace WebApplication1
{
    public partial class Users : System.Web.UI.Page
    {
        protected void Page_Load(
            object sender,
            EventArgs e)
        {
            if (!Request.IsAuthenticated)
            {
                Response.Redirect("~/Login.aspx");
                return;
            }

            if (!User.IsInRole("Manager"))
            {
                Response.Redirect("~/UserDashboard.aspx");
                return;
            }

            if (!IsPostBack)
            {
                LoadUsers();
            }
        }


        private void LoadUsers()
        {
            using (var db =
                new ApplicationDbContext())
            {
                var userManager =
                    new UserManager<ApplicationUser>(
                        new UserStore<ApplicationUser>(db));


                var users =
                    db.Users.ToList();


                var result =
                    new List<UserListItem>();


                foreach (var user in users)
                {
                    var profile =
                        db.UserProfiles.FirstOrDefault(
                            p =>
                                p.UserId == user.Id);


                    string fullName = "";

                    string departmentName = "";

                    string userCategory = "General";

                    bool isActive = true;

                    DateTime createdAt =
                        DateTime.MinValue;


                    if (profile != null)
                    {
                        fullName =
                            profile.FullName;

                        userCategory =
                            profile.UserCategory;

                        isActive =
                            profile.IsActive;

                        createdAt =
                            profile.CreatedAt;


                        if (profile.DepartmentId.HasValue)
                        {
                            var department =
                                db.Departments.FirstOrDefault(
                                    d =>
                                        d.DepartmentId ==
                                        profile.DepartmentId.Value);


                            if (department != null)
                            {
                                departmentName =
                                    department.DepartmentName;
                            }
                        }
                    }


                    string roleName =
                        "کاربر";


                    if (userManager.IsInRole(
                        user.Id,
                        "Manager"))
                    {
                        roleName =
                            "مدیر";
                    }
                    else if (
                        userManager.IsInRole(
                            user.Id,
                            "Specialist"))
                    {
                        roleName =
                            "کارشناس";
                    }


                    string userCategoryText;


                    if (userCategory ==
                        "Helpdesk")
                    {
                        userCategoryText =
                            "خدمات پشتیبانی فناوری اطلاعات";
                    }
                    else
                    {
                        userCategoryText =
                            "کاربر عمومی";
                    }


                    string specialties =
                        "";


                    if (roleName ==
                        "کارشناس")
                    {
                        var specialtyNames =
                            (
                                from ss
                                    in db.SpecialistSpecialties

                                join s
                                    in db.Specialties
                                    on ss.SpecialtyId
                                    equals s.SpecialtyId

                                where
                                    ss.UserId ==
                                    user.Id

                                    &&
                                    s.IsActive

                                orderby
                                    s.SpecialtyName

                                select
                                    s.SpecialtyName
                            ).ToList();


                        if (specialtyNames.Count > 0)
                        {
                            specialties =
                                string.Join(
                                    "، ",
                                    specialtyNames);
                        }
                        else
                        {
                            specialties =
                                "<span class=\"no-specialty\">بدون تخصص</span>";
                        }
                    }
                    else
                    {
                        specialties =
                            "<span class=\"no-specialty\">—</span>";
                    }


                    string statusText;

                    string statusCss;

                    string toggleText;

                    string toggleCss;


                    if (isActive)
                    {
                        statusText =
                            "فعال";

                        statusCss =
                            "status-active";

                        toggleText =
                            "غیرفعال کردن";

                        toggleCss =
                            "btn-toggle btn-disable";
                    }
                    else
                    {
                        statusText =
                            "غیرفعال";

                        statusCss =
                            "status-inactive";

                        toggleText =
                            "فعال کردن";

                        toggleCss =
                            "btn-toggle btn-enable";
                    }


                    result.Add(
                        new UserListItem
                        {
                            UserId =
                                user.Id,

                            UserName =
                                user.UserName,

                            FullName =
                                fullName,

                            DepartmentName =
                                departmentName,

                            UserCategoryText =
                                userCategoryText,

                            RoleName =
                                roleName,

                            Specialties =
                                specialties,

                            IsActive =
                                isActive,

                            StatusText =
                                statusText,

                            StatusCss =
                                statusCss,

                            ToggleText =
                                toggleText,

                            ToggleCss =
                                toggleCss,

                            CreatedAtText =
                                createdAt ==
                                    DateTime.MinValue
                                    ? ""
                                    : createdAt.ToString(
                                        "yyyy/MM/dd HH:mm")
                        });
                }


                result =
                    result
                        .OrderBy(
                            u =>
                                string.IsNullOrEmpty(
                                    u.FullName)
                                    ? u.UserName
                                    : u.FullName)
                        .ThenBy(
                            u =>
                                u.UserName)
                        .ToList();


                gvUsers.DataSource =
                    result;

                gvUsers.DataBind();


                lblUserCount.Text =
                    "تعداد کاربران: " +
                    result.Count.ToString();
            }
        }


        protected void btnToggleActive_Command(
            object sender,
            CommandEventArgs e)
        {
            string userId =
                Convert.ToString(
                    e.CommandArgument);


            if (string.IsNullOrEmpty(userId))
            {
                ShowError(
                    "شناسه کاربر معتبر نیست.");

                return;
            }


            string currentUserId =
                User.Identity.GetUserId();


            if (userId ==
                currentUserId)
            {
                ShowError(
                    "امکان تغییر وضعیت حساب کاربری خودتان وجود ندارد.");

                return;
            }


            using (var db =
                new ApplicationDbContext())
            {
                var profile =
                    db.UserProfiles.FirstOrDefault(
                        p =>
                            p.UserId ==
                            userId);


                if (profile == null)
                {
                    ShowError(
                        "اطلاعات پروفایل کاربر پیدا نشد.");

                    return;
                }


                profile.IsActive =
                    !profile.IsActive;


                db.SaveChanges();


                if (profile.IsActive)
                {
                    ShowSuccess(
                        "کاربر با موفقیت فعال شد.");
                }
                else
                {
                    ShowSuccess(
                        "کاربر با موفقیت غیرفعال شد.");
                }
            }


            LoadUsers();
        }


        private void ShowSuccess(
            string message)
        {
            lblMessage.Text =
                message;

            lblMessage.CssClass =
                "message success";

            lblMessage.Visible =
                true;
        }


        private void ShowError(
            string message)
        {
            lblMessage.Text =
                message;

            lblMessage.CssClass =
                "message error";

            lblMessage.Visible =
                true;
        }


        private class UserListItem
        {
            public string UserId
            {
                get;
                set;
            }

            public string UserName
            {
                get;
                set;
            }

            public string FullName
            {
                get;
                set;
            }

            public string DepartmentName
            {
                get;
                set;
            }

            public string UserCategoryText
            {
                get;
                set;
            }

            public string RoleName
            {
                get;
                set;
            }

            public string Specialties
            {
                get;
                set;
            }

            public bool IsActive
            {
                get;
                set;
            }

            public string StatusText
            {
                get;
                set;
            }

            public string StatusCss
            {
                get;
                set;
            }

            public string ToggleText
            {
                get;
                set;
            }

            public string ToggleCss
            {
                get;
                set;
            }

            public string CreatedAtText
            {
                get;
                set;
            }
        }
    }
}