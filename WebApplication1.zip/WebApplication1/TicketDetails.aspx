﻿<%@ Page Title="جزئیات درخواست"
    Language="C#"
    MasterPageFile="~/Site.Master"
    AutoEventWireup="true"
    CodeBehind="TicketDetails.aspx.cs"
    Inherits="WebApplication1.TicketDetails" %>

<asp:Content ID="Content1"
    ContentPlaceHolderID="MainContent"
    runat="server">

    <div class="page-header">

        <div>
            <h2>جزئیات درخواست</h2>
            <p>
                مشاهده و مدیریت درخواست
            </p>
        </div>

        <asp:HyperLink
            ID="lnkBack"
            runat="server"
            NavigateUrl="~/Tickets.aspx"
            CssClass="btn btn-secondary">
            بازگشت به درخواست‌ها
        </asp:HyperLink>

    </div>


    <!-- اطلاعات درخواست -->

    <div class="card">

        <div class="card-header">
            <h3>
                اطلاعات درخواست
            </h3>
        </div>

        <div class="card-body">

            <div class="ticket-info-grid">

                <div class="info-item">
                    <span>شماره درخواست</span>
                    <strong>
                        <asp:Label
                            ID="lblTicketId"
                            runat="server" />
                    </strong>
                </div>

                <div class="info-item">
                    <span>موضوع</span>
                    <strong>
                        <asp:Label
                            ID="lblSubject"
                            runat="server" />
                    </strong>
                </div>

                <div class="info-item">
                    <span>دسته‌بندی</span>
                    <strong>
                        <asp:Label
                            ID="lblCategory"
                            runat="server" />
                    </strong>
                </div>

                <div class="info-item">
                    <span>اولویت</span>
                    <strong>
                        <asp:Label
                            ID="lblPriority"
                            runat="server" />
                    </strong>
                </div>

                <div class="info-item">
                    <span>وضعیت</span>
                    <strong>
                        <asp:Label
                            ID="lblStatus"
                            runat="server" />
                    </strong>
                </div>

                <div class="info-item">
                    <span>تاریخ ثبت</span>
                    <strong>
                        <asp:Label
                            ID="lblCreatedAt"
                            runat="server" />
                    </strong>
                </div>

            </div>


            <div class="description-box">

                <div class="description-title">
                    شرح درخواست
                </div>

                <asp:Label
                    ID="lblDescription"
                    runat="server"
                    CssClass="description-text" />

            </div>

        </div>

    </div>


    <!-- پیام -->

    <asp:Label
        ID="lblMessage"
        runat="server"
        CssClass="message"
        Visible="false" />


    <!-- ارجاع -->

    <div class="card action-card">

        <div class="card-header">
            <h3>
                ارجاع درخواست
            </h3>
        </div>

        <div class="card-body">

            <div class="form-row">

                <div class="form-group">

                    <label>
                        اولویت
                    </label>

                    <asp:DropDownList
                        ID="ddlPriority"
                        runat="server"
                        CssClass="form-control">

                        <asp:ListItem
                            Text="کم"
                            Value="Low" />

                        <asp:ListItem
                            Text="عادی"
                            Value="Normal" />

                        <asp:ListItem
                            Text="زیاد"
                            Value="High" />

                        <asp:ListItem
                            Text="بحرانی"
                            Value="Critical" />

                    </asp:DropDownList>

                </div>


                <div class="form-group">

                    <label>
                        متخصص
                    </label>

                    <asp:DropDownList
                        ID="ddlSpecialist"
                        runat="server"
                        CssClass="form-control">
                    </asp:DropDownList>

                </div>

            </div>


            <div class="form-group">

                <label>
                    توضیحات ارجاع
                </label>

                <asp:TextBox
                    ID="txtAssignmentNote"
                    runat="server"
                    CssClass="form-control"
                    TextMode="MultiLine"
                    Rows="4"
                    placeholder="در صورت نیاز توضیحات مربوط به ارجاع را وارد کنید..." />

            </div>


            <asp:Button
                ID="btnAssign"
                runat="server"
                Text="ارجاع درخواست"
                CssClass="btn btn-primary"
                OnClick="btnAssign_Click" />

        </div>

    </div>


    <!-- تغییر وضعیت -->

    <div class="card action-card">

        <div class="card-header">
            <h3>
                تغییر وضعیت درخواست
            </h3>
        </div>

        <div class="card-body">

            <div class="form-group">

                <label>
                    وضعیت جدید
                </label>

                <asp:DropDownList
                    ID="ddlStatus"
                    runat="server"
                    CssClass="form-control">

                    <asp:ListItem
                        Text="جدید"
                        Value="New" />

                    <asp:ListItem
                        Text="ارجاع شده"
                        Value="Assigned" />

                    <asp:ListItem
                        Text="در حال انجام"
                        Value="InProgress" />

                    <asp:ListItem
                        Text="منتظر تأیید کاربر"
                        Value="WaitingConfirmation" />

                    <asp:ListItem
                        Text="خاتمه یافته"
                        Value="Closed" />

                </asp:DropDownList>

            </div>


            <div class="form-group">

                <label>
                    توضیحات
                </label>

                <asp:TextBox
                    ID="txtStatusNote"
                    runat="server"
                    CssClass="form-control"
                    TextMode="MultiLine"
                    Rows="4"
                    placeholder="توضیحات تغییر وضعیت..." />

            </div>


            <asp:Button
                ID="btnChangeStatus"
                runat="server"
                Text="ثبت تغییر وضعیت"
                CssClass="btn btn-primary"
                OnClick="btnChangeStatus_Click" />

        </div>

    </div>


    <!-- تاریخچه -->

    <div class="card">

        <div class="card-header">
            <h3>
                تاریخچه درخواست
            </h3>
        </div>

        <div class="card-body">

            <div class="table-wrapper">

                <asp:GridView
                    ID="gvHistory"
                    runat="server"
                    AutoGenerateColumns="False"
                    CssClass="data-grid"
                    GridLines="None"
                    EmptyDataText="تاریخچه‌ای برای این درخواست ثبت نشده است.">

                    <Columns>

                        <asp:BoundField
                            DataField="HistoryDate"
                            HeaderText="تاریخ" />

                        <asp:BoundField
                            DataField="UserName"
                            HeaderText="کاربر" />

                        <asp:BoundField
                            DataField="OldStatus"
                            HeaderText="وضعیت قبلی" />

                        <asp:BoundField
                            DataField="NewStatus"
                            HeaderText="وضعیت جدید" />

                        <asp:BoundField
                            DataField="Description"
                            HeaderText="توضیحات" />

                    </Columns>

                    <EmptyDataRowStyle
                        CssClass="empty-row" />

                </asp:GridView>

            </div>

        </div>

    </div>


    <style type="text/css">

        .card {
            background: #fff;
            border: 1px solid #e8ebf0;
            border-radius: 12px;
            margin-bottom: 20px;
            box-shadow: 0 3px 12px rgba(28,39,56,.04);
        }

        .card-header {
            min-height: 58px;
            padding: 0 20px;
            display: flex;
            align-items: center;
            border-bottom: 1px solid #edf0f4;
        }

        .card-header h3 {
            margin: 0;
            font-size: 14px;
            color: #273142;
        }

        .card-body {
            padding: 20px;
        }

        .ticket-info-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 15px;
        }

        .info-item {
            padding: 13px;
            background: #f8f9fb;
            border-radius: 8px;
        }

        .info-item span {
            display: block;
            color: #8a94a3;
            font-size: 11px;
            margin-bottom: 6px;
        }

        .info-item strong {
            color: #273142;
            font-size: 13px;
        }

        .description-box {
            margin-top: 20px;
            padding: 18px;
            background: #fafbfc;
            border: 1px solid #edf0f4;
            border-radius: 8px;
        }

        .description-title {
            font-size: 12px;
            font-weight: bold;
            color: #586273;
            margin-bottom: 10px;
        }

        .description-text {
            display: block;
            color: #424b59;
            line-height: 2;
            white-space: pre-line;
        }

        .action-card {
            margin-top: 20px;
        }

        .form-row {
            display: flex;
            gap: 20px;
        }

        .form-group {
            flex: 1;
            margin-bottom: 18px;
        }

        .form-group label {
            display: block;
            margin-bottom: 7px;
            font-size: 12px;
            font-weight: bold;
            color: #586273;
        }

        .form-control {
            width: 100%;
            box-sizing: border-box;
            border: 1px solid #dce1e7;
            border-radius: 7px;
            padding: 10px 12px;
            font-family: inherit;
            font-size: 13px;
            background: #fff;
        }

        .form-control:focus {
            outline: none;
            border-color: #176b78;
            box-shadow: 0 0 0 3px rgba(23,107,120,.09);
        }

        .btn {
            display: inline-block;
            padding: 10px 20px;
            border: none;
            border-radius: 7px;
            font-family: inherit;
            font-size: 13px;
            text-decoration: none;
            cursor: pointer;
        }

        .btn-primary {
            background: #176b78;
            color: #fff;
        }

        .btn-primary:hover {
            background: #125662;
        }

        .btn-secondary {
            background: #f1f3f5;
            color: #444;
        }

        .message {
            display: block;
            padding: 12px 15px;
            margin-bottom: 20px;
            border-radius: 7px;
            background: #eaf6ed;
            color: #28733a;
        }

        .table-wrapper {
            overflow-x: auto;
        }

        .data-grid {
            width: 100%;
            border-collapse: collapse;
            font-size: 12px;
        }

        .data-grid th {
            background: #f7f8fa;
            color: #657080;
            padding: 12px 10px;
            border-bottom: 1px solid #e8ebf0;
            white-space: nowrap;
        }

        .data-grid td {
            padding: 12px 10px;
            border-bottom: 1px solid #edf0f4;
            color: #424b59;
            vertical-align: top;
        }

        .empty-row td {
            padding: 30px;
            text-align: center;
            color: #9299a4;
        }

        @media (max-width: 800px) {

            .ticket-info-grid {
                grid-template-columns: 1fr;
            }

            .form-row {
                display: block;
            }

        }

    </style>

</asp:Content>