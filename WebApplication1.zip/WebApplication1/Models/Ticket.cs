﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace WebApplication1.Models
{
    public class Ticket
    {
        [Key]
        public int TicketId { get; set; }

        [Required]
        public string UserId { get; set; }

        [Required]
        [StringLength(250)]
        public string Subject { get; set; }

        [Required]
        public string Description { get; set; }

        [StringLength(50)]
        public string Category { get; set; }

        [Required]
        [StringLength(20)]
        public string Priority { get; set; }

        [Required]
        [StringLength(30)]
        public string Status { get; set; }

        public string AssignedTo { get; set; }

        public int? DepartmentId { get; set; }

        public DateTime CreatedAt { get; set; }

        public DateTime? AssignedAt { get; set; }

        public DateTime? ResolvedAt { get; set; }

        public DateTime? ClosedAt { get; set; }

        public bool UserConfirmed { get; set; }

        // وضعیت مشاهده درخواست توسط مدیر
        public bool ManagerViewed { get; set; }

        // تاریخ مشاهده درخواست توسط مدیر
        public DateTime? ManagerViewedAt { get; set; }

        public bool AutoClosed { get; set; }

        public DateTime? ConfirmationRequestedAt { get; set; }


        [ForeignKey("DepartmentId")]
        public virtual Department Department { get; set; }


        [ForeignKey("UserId")]
        public virtual ApplicationUser User { get; set; }


        [ForeignKey("AssignedTo")]
        public virtual ApplicationUser AssignedUser { get; set; }
        public int? ServiceTopicId { get; set; }

        [ForeignKey("ServiceTopicId")]
        public virtual ServiceTopic ServiceTopic { get; set; }
    }
}