﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace WebApplication1.Models
{
    public class TicketAction
    {
        [Key]
        public int ActionId { get; set; }

        [Required]
        public int TicketId { get; set; }

        [Required]
        public string UserId { get; set; }

        [Required]
        public string ActionText { get; set; }

        public DateTime ActionDate { get; set; }

        [ForeignKey("TicketId")]
        public virtual Ticket Ticket { get; set; }

        [ForeignKey("UserId")]
        public virtual ApplicationUser User { get; set; }
    }
}