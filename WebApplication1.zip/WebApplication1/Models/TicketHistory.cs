﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace WebApplication1.Models
{
    [Table("TicketHistory")]
    public class TicketHistory
    {
        [Key]
        public int HistoryId { get; set; }

        [Required]
        public int TicketId { get; set; }

        public string UserId { get; set; }

        [StringLength(30)]
        public string OldStatus { get; set; }

        [Required]
        [StringLength(30)]
        public string NewStatus { get; set; }

        [StringLength(500)]
        public string Description { get; set; }

        public DateTime HistoryDate { get; set; }

        [ForeignKey("TicketId")]
        public virtual Ticket Ticket { get; set; }

        [ForeignKey("UserId")]
        public virtual ApplicationUser User { get; set; }
    }
}