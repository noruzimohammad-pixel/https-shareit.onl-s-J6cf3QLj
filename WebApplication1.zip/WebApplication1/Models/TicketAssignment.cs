﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace WebApplication1.Models
{
    public class TicketAssignment
    {
        [Key]
        public int AssignmentId { get; set; }

        [Required]
        public int TicketId { get; set; }

        [Required]
        public string AssignedBy { get; set; }

        [Required]
        public string AssignedTo { get; set; }

        public DateTime AssignmentDate { get; set; }

        [StringLength(500)]
        public string Note { get; set; }

        public bool IsCurrent { get; set; }

        [ForeignKey("TicketId")]
        public virtual Ticket Ticket { get; set; }

        [ForeignKey("AssignedBy")]
        public virtual ApplicationUser AssignedByUser { get; set; }

        [ForeignKey("AssignedTo")]
        public virtual ApplicationUser AssignedToUser { get; set; }
    }
}