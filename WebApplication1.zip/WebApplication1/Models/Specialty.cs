﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace WebApplication1.Models
{
    public class Specialty
    {
        [Key]
        public int SpecialtyId { get; set; }

        [Required]
        [StringLength(100)]
        public string SpecialtyName { get; set; }

        [StringLength(500)]
        public string Description { get; set; }

        public bool IsActive { get; set; }

        public virtual ICollection<SpecialistSpecialty> SpecialistSpecialties { get; set; }

        public Specialty()
        {
            SpecialistSpecialties = new HashSet<SpecialistSpecialty>();
        }
    }
}