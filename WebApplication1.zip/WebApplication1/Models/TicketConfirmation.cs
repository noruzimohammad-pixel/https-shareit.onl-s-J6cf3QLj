﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace WebApplication1.Models
{
    public class TicketConfirmation
    {
        [Key]
        public int ConfirmationId { get; set; }

        [Required]
        public int TicketId { get; set; }

        [Required]
        public string UserId { get; set; }

        [Required]
        [StringLength(20)]
        public string ConfirmationStatus { get; set; }

        [StringLength(1000)]
        public string Comment { get; set; }

        public DateTime? ConfirmationDate { get; set; }

        public bool AutoConfirmed { get; set; }

        public DateTime CreatedAt { get; set; }

        [ForeignKey("TicketId")]
        public virtual Ticket Ticket { get; set; }

        [ForeignKey("UserId")]
        public virtual ApplicationUser User { get; set; }
    }
}