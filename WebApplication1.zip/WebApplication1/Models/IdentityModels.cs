﻿using Microsoft.AspNet.Identity.EntityFramework;
using System.Data.Entity;

namespace WebApplication1.Models
{
    public class ApplicationUser : IdentityUser
    {
    }

    public class ApplicationDbContext : IdentityDbContext<ApplicationUser>
    {
        public ApplicationDbContext()
            : base("DefaultConnection")
        {
            Database.SetInitializer<ApplicationDbContext>(null);
        }

        public DbSet<Department> Departments { get; set; }
        public DbSet<Ticket> Tickets { get; set; }
        public DbSet<TicketAction> TicketActions { get; set; }
        public DbSet<TicketHistory> TicketHistory { get; set; }
        public DbSet<TicketAssignment> TicketAssignments { get; set; }
        public DbSet<TicketConfirmation> TicketConfirmations { get; set; }
        public DbSet<UserProfile> UserProfiles { get; set; }
        public DbSet<Specialty> Specialties { get; set; }
        public DbSet<SpecialistSpecialty> SpecialistSpecialties { get; set; }
        public DbSet<ServiceCategory> ServiceCategories { get; set; }
        public DbSet<ServiceTopic> ServiceTopics { get; set; }

    }
}