﻿using System;
using System.Linq;
using System.Web.UI.WebControls;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;
using WebApplication1.Models;

namespace WebApplication1
{
    public partial class CreateSpecialist : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Request.IsAuthenticated)
            {
                Response.Redirect("~/Login.aspx");
                return;
            }

            if (!User.IsInRole("Manager"))
            {
                Response.Redirect("~/Login.aspx");
                return;
            }

            if (!IsPostBack)
            {
                LoadDepartments();
                LoadSpecialties();

                chkIsActive.Checked = true;

                lblMessage.Visible = false;
                lblMessage.Text = "";
            }
        }


        private void LoadDepartments()
        {
            using (var db = new ApplicationDbContext())
            {
                var departments = db.Departments
                    .Where(d => d.IsActive)
                    .OrderBy(d => d.DepartmentName)
                    .ToList();

                ddlDepartment.Items.Clear();

                ddlDepartment.Items.Add(
                    new ListItem(
                        "انتخاب واحد سازمانی",
                        ""));

                foreach (var department in departments)
                {
                    ddlDepartment.Items.Add(
                        new ListItem(
                            department.DepartmentName,
                            department.DepartmentId.ToString()));
                }
            }
        }


        private void LoadSpecialties()
        {
            using (var db = new ApplicationDbContext())
            {
                var specialties = db.Specialties
                    .Where(s => s.IsActive)
                    .OrderBy(s => s.SpecialtyName)
                    .ToList();

                cblSpecialties.Items.Clear();

                foreach (var specialty in specialties)
                {
                    cblSpecialties.Items.Add(
                        new ListItem(
                            specialty.SpecialtyName,
                            specialty.SpecialtyId.ToString()));
                }

                lblNoSpecialty.Visible =
                    specialties.Count == 0;
            }
        }


        protected void btnCreate_Click(
            object sender,
            EventArgs e)
        {
            lblMessage.Visible = false;
            lblMessage.Text = "";

            string userName =
                txtUserName.Text.Trim();

            string fullName =
                txtFullName.Text.Trim();

            string password =
                txtPassword.Text;

            string confirmPassword =
                txtConfirmPassword.Text;


            // بررسی نام کاربری

            if (string.IsNullOrEmpty(userName))
            {
                ShowError(
                    "لطفاً نام کاربری را وارد کنید.");

                return;
            }


            // بررسی نام و نام خانوادگی

            if (string.IsNullOrEmpty(fullName))
            {
                ShowError(
                    "لطفاً نام و نام خانوادگی را وارد کنید.");

                return;
            }


            // بررسی واحد سازمانی

            if (string.IsNullOrEmpty(
                ddlDepartment.SelectedValue))
            {
                ShowError(
                    "لطفاً واحد سازمانی را انتخاب کنید.");

                return;
            }


            // بررسی رمز عبور

            if (string.IsNullOrEmpty(password))
            {
                ShowError(
                    "لطفاً رمز عبور را وارد کنید.");

                return;
            }


            if (password.Length < 6)
            {
                ShowError(
                    "رمز عبور باید حداقل 6 کاراکتر باشد.");

                return;
            }


            if (password != confirmPassword)
            {
                ShowError(
                    "رمز عبور و تکرار آن یکسان نیستند.");

                return;
            }


            // بررسی شناسه واحد

            int departmentId;

            if (!int.TryParse(
                ddlDepartment.SelectedValue,
                out departmentId))
            {
                ShowError(
                    "واحد سازمانی انتخاب‌شده معتبر نیست.");

                return;
            }


            using (var db =
                new ApplicationDbContext())
            {
                // بررسی معتبر بودن واحد

                var department =
                    db.Departments.FirstOrDefault(
                        d =>
                            d.DepartmentId == departmentId &&
                            d.IsActive);

                if (department == null)
                {
                    ShowError(
                        "واحد سازمانی انتخاب‌شده معتبر نیست.");

                    return;
                }


                // ایجاد UserManager

                var userManager =
                    new UserManager<ApplicationUser>(
                        new UserStore<ApplicationUser>(db));


                // بررسی تکراری بودن نام کاربری

                var existingUser =
                    userManager.FindByName(userName);

                if (existingUser != null)
                {
                    ShowError(
                        "این نام کاربری قبلاً در سامانه ثبت شده است.");

                    return;
                }


                // ایجاد کاربر

                var user =
                    new ApplicationUser
                    {
                        UserName = userName
                    };


                IdentityResult createResult =
                    userManager.Create(
                        user,
                        password);


                if (!createResult.Succeeded)
                {
                    ShowError(
                        string.Join(
                            " ",
                            createResult.Errors));

                    return;
                }


                // RoleManager

                var roleManager =
                    new RoleManager<IdentityRole>(
                        new RoleStore<IdentityRole>(db));


                // ایجاد نقش Specialist در صورت عدم وجود

                if (!roleManager.RoleExists("Specialist"))
                {
                    IdentityResult createRoleResult =
                        roleManager.Create(
                            new IdentityRole("Specialist"));

                    if (!createRoleResult.Succeeded)
                    {
                        ShowError(
                            "خطا در ایجاد نقش کارشناس: " +
                            string.Join(
                                " ",
                                createRoleResult.Errors));

                        return;
                    }
                }


                // اختصاص نقش Specialist

                IdentityResult addRoleResult =
                    userManager.AddToRole(
                        user.Id,
                        "Specialist");


                if (!addRoleResult.Succeeded)
                {
                    ShowError(
                        string.Join(
                            " ",
                            addRoleResult.Errors));

                    return;
                }


                // ایجاد پروفایل کارشناس

                var profile =
                    new UserProfile
                    {
                        UserId = user.Id,

                        FullName = fullName,

                        DepartmentId = departmentId,

                        UserCategory = "Helpdesk",

                        IsActive =
                            chkIsActive.Checked,

                        CreatedAt =
                            DateTime.Now
                    };


                db.UserProfiles.Add(profile);


                // ثبت تخصص‌های انتخاب‌شده

                foreach (ListItem item
                    in cblSpecialties.Items)
                {
                    if (!item.Selected)
                    {
                        continue;
                    }


                    int specialtyId;

                    if (!int.TryParse(
                        item.Value,
                        out specialtyId))
                    {
                        continue;
                    }


                    // بررسی معتبر بودن تخصص

                    var specialty =
                        db.Specialties.FirstOrDefault(
                            s =>
                                s.SpecialtyId ==
                                specialtyId &&
                                s.IsActive);


                    if (specialty == null)
                    {
                        continue;
                    }


                    var specialistSpecialty =
                        new SpecialistSpecialty
                        {
                            UserId = user.Id,

                            SpecialtyId = specialtyId
                        };


                    db.SpecialistSpecialties.Add(
                        specialistSpecialty);
                }


                // ذخیره اطلاعات

                db.SaveChanges();


                ShowSuccess(
                    "کارشناس با موفقیت ایجاد شد.");

                ClearForm();
            }
        }


        private void ClearForm()
        {
            txtUserName.Text = "";

            txtFullName.Text = "";

            txtPassword.Text = "";

            txtConfirmPassword.Text = "";


            if (ddlDepartment.Items.Count > 0)
            {
                ddlDepartment.SelectedIndex = 0;
            }


            chkIsActive.Checked = true;


            foreach (ListItem item
                in cblSpecialties.Items)
            {
                item.Selected = false;
            }
        }


        private void ShowSuccess(
            string message)
        {
            lblMessage.Text = message;

            lblMessage.CssClass =
                "message success";

            lblMessage.Visible = true;
        }


        private void ShowError(
            string message)
        {
            lblMessage.Text = message;

            lblMessage.CssClass =
                "message error";

            lblMessage.Visible = true;
        }
    }
}