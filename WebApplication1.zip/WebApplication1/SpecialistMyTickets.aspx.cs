﻿using System;
using System.Linq;
using Microsoft.AspNet.Identity;
using WebApplication1.Models;

namespace WebApplication1
{
    public partial class SpecialistMyTickets : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Request.IsAuthenticated)
            {
                Response.Redirect("~/Login.aspx");
                return;
            }

            if (!User.IsInRole("Specialist"))
            {
                Response.Redirect("~/Login.aspx");
                return;
            }

            if (!IsPostBack)
            {
                LoadTickets();
            }
        }


        private void LoadTickets()
        {
            string currentUserId =
                User.Identity.GetUserId();


            using (var db = new ApplicationDbContext())
            {
                var tickets =
                    db.Tickets
                    .Where(t =>
                        t.UserId == currentUserId)
                    .OrderByDescending(t => t.CreatedAt)
                    .Select(t => new
                    {
                        t.TicketId,
                        t.Subject,
                        t.Category,
                        t.Priority,
                        t.Status,
                        t.CreatedAt
                    })
                    .ToList()
                    .Select(t => new
                    {
                        t.TicketId,
                        t.Subject,

                        Category =
                            GetCategoryText(t.Category),

                        Priority =
                            GetPriorityText(t.Priority),

                        Status =
                            GetStatusText(t.Status),

                        t.CreatedAt
                    })
                    .ToList();


                gvTickets.DataSource =
                    tickets;

                gvTickets.DataBind();
            }
        }


        private string GetCategoryText(string category)
        {
            switch (category)
            {
                case "نرم‌افزار":
                    return "نرم‌افزار";

                case "سخت‌افزار":
                    return "سخت‌افزار";

                case "شبکه":
                    return "شبکه";

                case "امنیت":
                    return "امنیت";

                case "سایر":
                    return "سایر";

                default:
                    return category;
            }
        }


        private string GetPriorityText(string priority)
        {
            switch (priority)
            {
                case "Low":
                    return "کم";

                case "Normal":
                    return "عادی";

                case "High":
                    return "زیاد";

                case "Critical":
                    return "بحرانی";

                default:
                    return priority;
            }
        }


        private string GetStatusText(string status)
        {
            switch (status)
            {
                case "New":
                    return "جدید";

                case "Assigned":
                    return "ارجاع شده";

                case "InProgress":
                    return "در حال انجام";

                case "WaitingConfirmation":
                    return "منتظر تأیید کاربر";

                case "Closed":
                    return "خاتمه یافته";

                default:
                    return status;
            }
        }
    }
}