﻿using System;
using System.Linq;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;
using WebApplication1.Models;

namespace WebApplication1
{
    public partial class ManagerDashboard : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Request.IsAuthenticated)
            {
                Response.Redirect("Login.aspx");
                return;
            }

            string userId = User.Identity.GetUserId();

            if (string.IsNullOrEmpty(userId))
            {
                Response.Redirect("Login.aspx");
                return;
            }

            using (var db = new ApplicationDbContext())
            {
                var userManager = new UserManager<ApplicationUser>(
                    new UserStore<ApplicationUser>(db));

                if (!userManager.IsInRole(userId, "Manager"))
                {
                    Response.Redirect("Login.aspx");
                    return;
                }
            }

            if (!IsPostBack)
                LoadDashboard();
        }

        private void LoadDashboard()
        {
            using (var db = new ApplicationDbContext())
            {
                int newCount = db.Tickets.Count(t => t.Status == "New");
                int assignedCount = db.Tickets.Count(t => t.Status == "Assigned");
                int processingCount = db.Tickets.Count(t => t.Status == "InProgress");
                int waitingCount = db.Tickets.Count(t => t.Status == "WaitingConfirmation");
                int closedCount = db.Tickets.Count(t => t.Status == "Closed");

                lblNewCount.Text = newCount.ToString();
                lblAssignedSubCount.Text = assignedCount.ToString();
                lblProcessingSubCount.Text = processingCount.ToString();
                lblInProgressCount.Text = (assignedCount + processingCount).ToString();
                lblWaitingCount.Text = waitingCount.ToString();
                lblClosedCount.Text = closedCount.ToString();

                var recentTickets = db.Tickets
                    .OrderByDescending(t => t.CreatedAt)
                    .Take(8)
                    .ToList()
                    .Select(t =>
                    {
                        var profile = db.UserProfiles.FirstOrDefault(p => p.UserId == t.UserId);
                        string requesterName = "نامشخص";
                        string departmentName = "نامشخص";

                        if (profile != null)
                        {
                            if (!string.IsNullOrEmpty(profile.FullName))
                                requesterName = profile.FullName;
                            if (profile.Department != null)
                                departmentName = profile.Department.DepartmentName;
                        }

                        return new
                        {
                            t.TicketId,
                            t.Subject,
                            RequesterName = requesterName,
                            DepartmentName = departmentName,
                            t.Category,
                            Priority = GetPriorityText(t.Priority),
                            PriorityValue = t.Priority,
                            Status = GetStatusText(t.Status),
                            StatusValue = t.Status,
                            t.CreatedAt
                        };
                    }).ToList();

                gvRecentTickets.DataSource = recentTickets;
                gvRecentTickets.DataBind();

                var closedTickets = db.Tickets
                    .Where(t => t.Status == "Closed")
                    .OrderByDescending(t => t.ClosedAt)
                    .ThenByDescending(t => t.TicketId)
                    .Take(10)
                    .ToList();

                var closedTicketList = closedTickets
                    .Select(t =>
                    {
                        var profile = db.UserProfiles.FirstOrDefault(p => p.UserId == t.UserId);
                        string requesterName = "نامشخص";
                        string departmentName = "نامشخص";

                        if (profile != null)
                        {
                            if (!string.IsNullOrEmpty(profile.FullName))
                                requesterName = profile.FullName;
                            if (profile.Department != null)
                                departmentName = profile.Department.DepartmentName;
                        }

                        var closedHistory = db.TicketHistory
                            .Where(h => h.TicketId == t.TicketId && h.NewStatus == "Closed")
                            .OrderByDescending(h => h.HistoryDate)
                            .FirstOrDefault();

                        DateTime? closedAt = closedHistory != null
                            ? closedHistory.HistoryDate
                            : t.ClosedAt;

                        return new
                        {
                            t.TicketId,
                            t.Subject,
                            RequesterName = requesterName,
                            DepartmentName = departmentName,
                            t.Category,
                            Priority = GetPriorityText(t.Priority),
                            PriorityValue = t.Priority,
                            ClosedAt = closedAt
                        };
                    }).ToList();

                gvClosedTickets.DataSource = closedTicketList;
                gvClosedTickets.DataBind();
            }
        }

        private string GetPriorityText(string priority)
        {
            switch (priority)
            {
                case "Low": return "کم";
                case "Normal": return "عادی";
                case "High": return "زیاد";
                case "Critical": return "بحرانی";
                default: return priority;
            }
        }

        public string GetPriorityCssClass(string priority)
        {
            switch (priority)
            {
                case "Low": return "manager-priority priority-low";
                case "Normal": return "manager-priority priority-normal";
                case "High": return "manager-priority priority-high";
                case "Critical": return "manager-priority priority-critical";
                default: return "manager-priority";
            }
        }

        private string GetStatusText(string status)
        {
            switch (status)
            {
                case "New": return "جدید";
                case "Assigned": return "ارجاع شده";
                case "InProgress": return "در حال رسیدگی";
                case "WaitingConfirmation": return "منتظر تأیید کاربر";
                case "Closed": return "خاتمه یافته";
                default: return status;
            }
        }

        public string GetStatusCssClass(string status)
        {
            switch (status)
            {
                case "New": return "manager-status manager-status-new";
                case "Assigned": return "manager-status manager-status-assigned";
                case "InProgress": return "manager-status manager-status-progress";
                case "WaitingConfirmation": return "manager-status manager-status-waiting";
                case "Closed": return "manager-status manager-status-closed";
                default: return "manager-status manager-status-new";
            }
        }
    }
}
