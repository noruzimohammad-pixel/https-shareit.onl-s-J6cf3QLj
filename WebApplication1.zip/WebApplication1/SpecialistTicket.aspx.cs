﻿using System;
using System.Linq;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;
using WebApplication1.Models;

namespace WebApplication1
{
    public partial class SpecialistTickets : System.Web.UI.Page
    {
        protected void Page_Load(
            object sender,
            EventArgs e)
        {
            if (!Request.IsAuthenticated)
            {
                Response.Redirect("~/Login.aspx");
                return;
            }

            string userId =
                User.Identity.GetUserId();

            if (string.IsNullOrEmpty(userId))
            {
                Response.Redirect("~/Login.aspx");
                return;
            }

            using (var db = new ApplicationDbContext())
            {
                var userManager =
                    new UserManager<ApplicationUser>(
                        new UserStore<ApplicationUser>(db));

                /*
                 * این صفحه فقط مخصوص Specialist است.
                 */
                if (!userManager.IsInRole(
                    userId,
                    "Specialist"))
                {
                    Response.Redirect("~/Login.aspx");
                    return;
                }
            }

            if (!IsPostBack)
            {
                LoadDashboard();
            }
        }


        // =========================================================
        // بارگذاری کارتابل
        // =========================================================

        private void LoadDashboard()
        {
            string userId =
                User.Identity.GetUserId();

            using (var db = new ApplicationDbContext())
            {
                /*
                 * فقط درخواست‌هایی که مستقیماً
                 * به این کارشناس ارجاع شده‌اند.
                 *
                 * درخواست‌های Closed از کارتابل فعال حذف می‌شوند.
                 */
                var tickets =
                    db.Tickets
                        .Where(t =>
                            t.AssignedTo == userId &&
                            t.Status != "Closed")
                        .OrderByDescending(
                            t => t.AssignedAt)
                        .ToList();


                // =================================================
                // آمار
                // =================================================

                int totalCount =
                    tickets.Count;


                int assignedCount =
                    tickets.Count(
                        t =>
                            t.Status == "Assigned");


                int inProgressCount =
                    tickets.Count(
                        t =>
                            t.Status == "InProgress");


                int waitingCount =
                    tickets.Count(
                        t =>
                            t.Status ==
                            "WaitingConfirmation");


                lblTotalCount.Text =
                    totalCount.ToString();

                lblAssignedCount.Text =
                    assignedCount.ToString();

                lblInProgressCount.Text =
                    inProgressCount.ToString();

                lblWaitingCount.Text =
                    waitingCount.ToString();


                // =================================================
                // اطلاعات درخواست‌ها
                // =================================================

                var result =
                    tickets
                        .Select(
                            t => new
                            {
                                t.TicketId,

                                t.Subject,

                                t.Category,

                                RequesterName =
                                    GetUserDisplayName(
                                        db,
                                        t.UserId),

                                PriorityText =
                                    GetPriorityText(
                                        t.Priority),

                                PriorityCss =
                                    GetPriorityCss(
                                        t.Priority),

                                StatusText =
                                    GetStatusText(
                                        t.Status),

                                StatusCss =
                                    GetStatusCss(
                                        t.Status),

                                AssignedAtText =
                                    t.AssignedAt.HasValue
                                    ? t.AssignedAt.Value.ToString(
                                        "yyyy/MM/dd HH:mm")
                                    : "—"
                            })
                        .ToList();


                gvTickets.DataSource =
                    result;

                gvTickets.DataBind();
            }
        }


        // =========================================================
        // نام درخواست‌کننده
        // =========================================================

        private string GetUserDisplayName(
            ApplicationDbContext db,
            string userId)
        {
            var profile =
                db.UserProfiles.FirstOrDefault(
                    p => p.UserId == userId);

            if (profile != null &&
                !string.IsNullOrEmpty(
                    profile.FullName))
            {
                return profile.FullName;
            }


            var user =
                db.Users.FirstOrDefault(
                    u => u.Id == userId);

            if (user != null)
            {
                return user.UserName;
            }


            return "نامشخص";
        }


        // =========================================================
        // ترجمه اولویت
        // =========================================================

        private string GetPriorityText(
            string priority)
        {
            switch (priority)
            {
                case "Low":
                    return "کم";

                case "Normal":
                    return "عادی";

                case "High":
                    return "زیاد";

                case "Critical":
                    return "بحرانی";

                default:
                    return priority;
            }
        }


        // =========================================================
        // کلاس ظاهری اولویت
        // =========================================================

        private string GetPriorityCss(
            string priority)
        {
            switch (priority)
            {
                case "Low":
                    return "priority priority-low";

                case "Normal":
                    return "priority priority-normal";

                case "High":
                    return "priority priority-high";

                case "Critical":
                    return "priority priority-critical";

                default:
                    return "priority";
            }
        }


        // =========================================================
        // ترجمه وضعیت
        // =========================================================

        private string GetStatusText(
            string status)
        {
            switch (status)
            {
                case "New":
                    return "جدید";

                case "Assigned":
                    return "ارجاع شده";

                case "InProgress":
                    return "در حال رسیدگی";

                case "Resolved":
                    return "حل شده";

                case "WaitingConfirmation":
                    return "منتظر تأیید";

                case "Closed":
                    return "خاتمه یافته";

                default:
                    return status;
            }
        }


        // =========================================================
        // کلاس ظاهری وضعیت
        // =========================================================

        private string GetStatusCss(
            string status)
        {
            switch (status)
            {
                case "Assigned":
                    return "status status-assigned";

                case "InProgress":
                    return "status status-progress";

                case "Resolved":
                    return "status status-resolved";

                case "WaitingConfirmation":
                    return "status status-waiting";

                default:
                    return "status";
            }
        }
    }
}