﻿using System;
using System.Linq;
using System.Web.UI;
using WebApplication1.Models;

namespace WebApplication1
{
    public partial class ServiceCategories : Page
    {
        private int SelectedCategoryId
        {
            get
            {
                int value;

                if (ViewState["SelectedCategoryId"] == null)
                    return 0;

                if (int.TryParse(
                    ViewState["SelectedCategoryId"].ToString(),
                    out value))
                {
                    return value;
                }

                return 0;
            }

            set
            {
                ViewState["SelectedCategoryId"] = value;
            }
        }


        private int EditingCategoryId
        {
            get
            {
                int value;

                if (ViewState["EditingCategoryId"] == null)
                    return 0;

                if (int.TryParse(
                    ViewState["EditingCategoryId"].ToString(),
                    out value))
                {
                    return value;
                }

                return 0;
            }

            set
            {
                ViewState["EditingCategoryId"] = value;
            }
        }


        private int EditingTopicId
        {
            get
            {
                int value;

                if (ViewState["EditingTopicId"] == null)
                    return 0;

                if (int.TryParse(
                    ViewState["EditingTopicId"].ToString(),
                    out value))
                {
                    return value;
                }

                return 0;
            }

            set
            {
                ViewState["EditingTopicId"] = value;
            }
        }


        protected void Page_Load(
            object sender,
            EventArgs e)
        {
            if (!Request.IsAuthenticated)
            {
                Response.Redirect("Login.aspx");
                return;
            }


            if (!User.IsInRole("Manager"))
            {
                Response.Redirect("Login.aspx");
                return;
            }


            if (!IsPostBack)
            {
                LoadCategories();

                pnlCategoryEdit.Visible = false;
                pnlTopicEdit.Visible = false;
                pnlSelectedCategory.Visible = false;

                btnNewTopic.Enabled = false;
            }
        }


        private void LoadCategories()
        {
            using (var db =
                new ApplicationDbContext())
            {
                var categories =
                    db.ServiceCategories
                    .OrderBy(c => c.DisplayOrder)
                    .ThenBy(c => c.CategoryName)
                    .Select(c => new
                    {
                        c.ServiceCategoryId,
                        c.CategoryName,
                        c.Description,
                        c.IsActive,

                        TopicCount =
                            db.ServiceTopics.Count(
                                t =>
                                    t.ServiceCategoryId ==
                                    c.ServiceCategoryId)
                    })
                    .ToList();


                rptCategories.DataSource =
                    categories;

                rptCategories.DataBind();


                lblNoCategories.Visible =
                    categories.Count == 0;
            }
        }


        private void LoadTopics()
        {
            if (SelectedCategoryId <= 0)
            {
                rptTopics.DataSource = null;
                rptTopics.DataBind();

                pnlSelectedCategory.Visible = false;
                lblNoTopics.Visible = false;

                btnNewTopic.Enabled = false;

                return;
            }


            using (var db =
                new ApplicationDbContext())
            {
                var category =
                    db.ServiceCategories
                    .FirstOrDefault(
                        c =>
                            c.ServiceCategoryId ==
                            SelectedCategoryId);


                if (category == null)
                {
                    SelectedCategoryId = 0;

                    rptTopics.DataSource = null;
                    rptTopics.DataBind();

                    pnlSelectedCategory.Visible = false;
                    lblNoTopics.Visible = false;

                    btnNewTopic.Enabled = false;

                    return;
                }


                lblSelectedCategoryName.Text =
                    category.CategoryName;


                pnlSelectedCategory.Visible =
                    true;


                btnNewTopic.Enabled =
                    true;


                var topics =
                    db.ServiceTopics
                    .Where(
                        t =>
                            t.ServiceCategoryId ==
                            SelectedCategoryId)
                    .OrderBy(t => t.DisplayOrder)
                    .ThenBy(t => t.TopicName)
                    .Select(t => new
                    {
                        t.ServiceTopicId,
                        t.TopicName,
                        t.Description,
                        t.IsActive
                    })
                    .ToList();


                rptTopics.DataSource =
                    topics;

                rptTopics.DataBind();


                lblNoTopics.Visible =
                    topics.Count == 0;
            }
        }


        protected void btnNewCategory_Click(
            object sender,
            EventArgs e)
        {
            EditingCategoryId = 0;

            txtCategoryName.Text = "";
            txtCategoryDescription.Text = "";

            chkCategoryActive.Checked = true;

            lblCategoryEditTitle.Text =
                "افزودن حوزه جدید";

            pnlCategoryEdit.Visible = true;

            HideMessage();
        }


        protected void btnCancelCategory_Click(
            object sender,
            EventArgs e)
        {
            EditingCategoryId = 0;

            txtCategoryName.Text = "";
            txtCategoryDescription.Text = "";

            chkCategoryActive.Checked = true;

            pnlCategoryEdit.Visible = false;

            HideMessage();
        }


        protected void btnSaveCategory_Click(
            object sender,
            EventArgs e)
        {
            string name =
                txtCategoryName.Text.Trim();

            string description =
                txtCategoryDescription.Text.Trim();


            if (string.IsNullOrEmpty(name))
            {
                ShowMessage(
                    "نام حوزه را وارد کنید.",
                    "error");

                pnlCategoryEdit.Visible = true;

                return;
            }


            using (var db =
                new ApplicationDbContext())
            {
                bool duplicate =
                    db.ServiceCategories.Any(
                        c =>
                            c.CategoryName == name &&
                            c.ServiceCategoryId !=
                            EditingCategoryId);


                if (duplicate)
                {
                    ShowMessage(
                        "حوزه‌ای با این نام قبلاً ثبت شده است.",
                        "error");

                    pnlCategoryEdit.Visible = true;

                    return;
                }


                if (EditingCategoryId == 0)
                {
                    int maxOrder =
                        db.ServiceCategories
                        .Select(c => (int?)c.DisplayOrder)
                        .Max() ?? 0;


                    var category =
                        new ServiceCategory
                        {
                            CategoryName = name,
                            Description = description,
                            IsActive =
                                chkCategoryActive.Checked,
                            DisplayOrder =
                                maxOrder + 1,
                            CreatedAt =
                                DateTime.Now
                        };


                    db.ServiceCategories.Add(category);

                    db.SaveChanges();


                    SelectedCategoryId =
                        category.ServiceCategoryId;


                    ShowMessage(
                        "حوزه با موفقیت ایجاد شد.",
                        "success");
                }
                else
                {
                    var category =
                        db.ServiceCategories
                        .FirstOrDefault(
                            c =>
                                c.ServiceCategoryId ==
                                EditingCategoryId);


                    if (category == null)
                    {
                        ShowMessage(
                            "حوزه موردنظر پیدا نشد.",
                            "error");

                        return;
                    }


                    category.CategoryName =
                        name;

                    category.Description =
                        description;

                    category.IsActive =
                        chkCategoryActive.Checked;


                    db.SaveChanges();


                    ShowMessage(
                        "اطلاعات حوزه با موفقیت ویرایش شد.",
                        "success");
                }
            }


            EditingCategoryId = 0;

            pnlCategoryEdit.Visible = false;

            LoadCategories();
            LoadTopics();
        }


        protected void btnNewTopic_Click(
            object sender,
            EventArgs e)
        {
            if (SelectedCategoryId <= 0)
            {
                ShowMessage(
                    "ابتدا یک حوزه را انتخاب کنید.",
                    "error");

                return;
            }


            EditingTopicId = 0;

            txtTopicName.Text = "";
            txtTopicDescription.Text = "";

            chkTopicActive.Checked = true;

            lblTopicEditTitle.Text =
                "افزودن موضوع جدید";

            pnlTopicEdit.Visible = true;

            HideMessage();
        }


        protected void btnCancelTopic_Click(
            object sender,
            EventArgs e)
        {
            EditingTopicId = 0;

            txtTopicName.Text = "";
            txtTopicDescription.Text = "";

            chkTopicActive.Checked = true;

            pnlTopicEdit.Visible = false;

            HideMessage();
        }


        protected void btnSaveTopic_Click(
            object sender,
            EventArgs e)
        {
            if (SelectedCategoryId <= 0)
            {
                ShowMessage(
                    "ابتدا یک حوزه را انتخاب کنید.",
                    "error");

                return;
            }


            string name =
                txtTopicName.Text.Trim();

            string description =
                txtTopicDescription.Text.Trim();


            if (string.IsNullOrEmpty(name))
            {
                ShowMessage(
                    "نام موضوع را وارد کنید.",
                    "error");

                pnlTopicEdit.Visible = true;

                return;
            }


            using (var db =
                new ApplicationDbContext())
            {
                bool duplicate =
                    db.ServiceTopics.Any(
                        t =>
                            t.ServiceCategoryId ==
                            SelectedCategoryId &&
                            t.TopicName == name &&
                            t.ServiceTopicId !=
                            EditingTopicId);


                if (duplicate)
                {
                    ShowMessage(
                        "موضوعی با این نام در این حوزه قبلاً ثبت شده است.",
                        "error");

                    pnlTopicEdit.Visible = true;

                    return;
                }


                if (EditingTopicId == 0)
                {
                    int maxOrder =
                        db.ServiceTopics
                        .Where(
                            t =>
                                t.ServiceCategoryId ==
                                SelectedCategoryId)
                        .Select(
                            t =>
                                (int?)t.DisplayOrder)
                        .Max() ?? 0;


                    var topic =
                        new ServiceTopic
                        {
                            ServiceCategoryId =
                                SelectedCategoryId,

                            TopicName =
                                name,

                            Description =
                                description,

                            IsActive =
                                chkTopicActive.Checked,

                            DisplayOrder =
                                maxOrder + 1,

                            CreatedAt =
                                DateTime.Now
                        };


                    db.ServiceTopics.Add(topic);

                    db.SaveChanges();


                    ShowMessage(
                        "موضوع با موفقیت ایجاد شد.",
                        "success");
                }
                else
                {
                    var topic =
                        db.ServiceTopics
                        .FirstOrDefault(
                            t =>
                                t.ServiceTopicId ==
                                EditingTopicId);


                    if (topic == null)
                    {
                        ShowMessage(
                            "موضوع موردنظر پیدا نشد.",
                            "error");

                        return;
                    }


                    topic.TopicName =
                        name;

                    topic.Description =
                        description;

                    topic.IsActive =
                        chkTopicActive.Checked;


                    db.SaveChanges();


                    ShowMessage(
                        "اطلاعات موضوع با موفقیت ویرایش شد.",
                        "success");
                }
            }


            EditingTopicId = 0;

            pnlTopicEdit.Visible = false;

            LoadCategories();
            LoadTopics();
        }


        protected void rptCategories_ItemCommand(
            object source,
            System.Web.UI.WebControls.RepeaterCommandEventArgs e)
        {
            int id;


            if (!int.TryParse(
                e.CommandArgument.ToString(),
                out id))
            {
                return;
            }


            if (e.CommandName ==
                "SelectCategory")
            {
                SelectedCategoryId = id;

                EditingTopicId = 0;

                pnlTopicEdit.Visible = false;

                HideMessage();

                LoadCategories();
                LoadTopics();

                return;
            }


            if (e.CommandName ==
                "EditCategory")
            {
                EditCategory(id);

                return;
            }


            if (e.CommandName ==
                "ToggleCategory")
            {
                ToggleCategory(id);

                return;
            }
        }


        private void EditCategory(int id)
        {
            using (var db =
                new ApplicationDbContext())
            {
                var category =
                    db.ServiceCategories
                    .FirstOrDefault(
                        c =>
                            c.ServiceCategoryId ==
                            id);


                if (category == null)
                {
                    ShowMessage(
                        "حوزه موردنظر پیدا نشد.",
                        "error");

                    return;
                }


                EditingCategoryId = id;


                txtCategoryName.Text =
                    category.CategoryName;

                txtCategoryDescription.Text =
                    category.Description;

                chkCategoryActive.Checked =
                    category.IsActive;


                lblCategoryEditTitle.Text =
                    "ویرایش حوزه";


                pnlCategoryEdit.Visible =
                    true;


                HideMessage();
            }
        }


        private void ToggleCategory(int id)
        {
            using (var db =
                new ApplicationDbContext())
            {
                var category =
                    db.ServiceCategories
                    .FirstOrDefault(
                        c =>
                            c.ServiceCategoryId ==
                            id);


                if (category == null)
                {
                    ShowMessage(
                        "حوزه موردنظر پیدا نشد.",
                        "error");

                    return;
                }


                category.IsActive =
                    !category.IsActive;


                db.SaveChanges();


                SelectedCategoryId = id;


                ShowMessage(
                    category.IsActive
                        ? "حوزه فعال شد."
                        : "حوزه غیرفعال شد.",
                    "success");
            }


            LoadCategories();
            LoadTopics();
        }


        protected void rptTopics_ItemCommand(
            object source,
            System.Web.UI.WebControls.RepeaterCommandEventArgs e)
        {
            int id;


            if (!int.TryParse(
                e.CommandArgument.ToString(),
                out id))
            {
                return;
            }


            if (e.CommandName ==
                "EditTopic")
            {
                EditTopic(id);

                return;
            }


            if (e.CommandName ==
                "ToggleTopic")
            {
                ToggleTopic(id);

                return;
            }
        }


        private void EditTopic(int id)
        {
            using (var db =
                new ApplicationDbContext())
            {
                var topic =
                    db.ServiceTopics
                    .FirstOrDefault(
                        t =>
                            t.ServiceTopicId ==
                            id);


                if (topic == null)
                {
                    ShowMessage(
                        "موضوع موردنظر پیدا نشد.",
                        "error");

                    return;
                }


                SelectedCategoryId =
                    topic.ServiceCategoryId;


                EditingTopicId = id;


                txtTopicName.Text =
                    topic.TopicName;

                txtTopicDescription.Text =
                    topic.Description;

                chkTopicActive.Checked =
                    topic.IsActive;


                lblTopicEditTitle.Text =
                    "ویرایش موضوع";


                pnlTopicEdit.Visible =
                    true;


                HideMessage();

                LoadCategories();
                LoadTopics();
            }
        }


        private void ToggleTopic(int id)
        {
            using (var db =
                new ApplicationDbContext())
            {
                var topic =
                    db.ServiceTopics
                    .FirstOrDefault(
                        t =>
                            t.ServiceTopicId ==
                            id);


                if (topic == null)
                {
                    ShowMessage(
                        "موضوع موردنظر پیدا نشد.",
                        "error");

                    return;
                }


                SelectedCategoryId =
                    topic.ServiceCategoryId;


                topic.IsActive =
                    !topic.IsActive;


                db.SaveChanges();


                ShowMessage(
                    topic.IsActive
                        ? "موضوع فعال شد."
                        : "موضوع غیرفعال شد.",
                    "success");
            }


            LoadCategories();
            LoadTopics();
        }


        protected string GetCategoryCss(
            object id)
        {
            int categoryId;


            if (!int.TryParse(
                id.ToString(),
                out categoryId))
            {
                return "category-item";
            }


            if (categoryId ==
                SelectedCategoryId)
            {
                return
                    "category-item category-item-selected";
            }


            return "category-item";
        }


        protected string GetActiveBadgeCss(
            object value)
        {
            bool active;


            if (bool.TryParse(
                value.ToString(),
                out active))
            {
                return active
                    ? "badge-service badge-active"
                    : "badge-service badge-inactive";
            }


            return
                "badge-service badge-inactive";
        }


        protected string GetActiveText(
            object value)
        {
            bool active;


            if (bool.TryParse(
                value.ToString(),
                out active))
            {
                return active
                    ? "فعال"
                    : "غیرفعال";
            }


            return "غیرفعال";
        }


        protected string GetToggleText(
            object value)
        {
            bool active;


            if (bool.TryParse(
                value.ToString(),
                out active))
            {
                return active
                    ? "غیرفعال"
                    : "فعال";
            }


            return "فعال";
        }


        private void ShowMessage(
            string message,
            string type)
        {
            lblMessage.Text =
                message;

            lblMessage.Visible =
                true;


            if (type == "success")
            {
                lblMessage.CssClass =
                    "message-service message-success";
            }
            else if (type == "error")
            {
                lblMessage.CssClass =
                    "message-service message-error";
            }
            else
            {
                lblMessage.CssClass =
                    "message-service message-info";
            }
        }


        private void HideMessage()
        {
            lblMessage.Text = "";

            lblMessage.Visible = false;
        }
    }
}