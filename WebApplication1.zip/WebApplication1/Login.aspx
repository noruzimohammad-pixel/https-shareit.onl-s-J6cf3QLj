﻿<%@ Page Language="C#" AutoEventWireup="true"
    CodeBehind="Login.aspx.cs"
    Inherits="WebApplication1.Login" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml" lang="fa" dir="rtl">
<head runat="server">

    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <title>ورود به سامانه خدمات فناوری اطلاعات</title>

    <!-- CSS اصلی صفحه ورود -->
    <link href="CSS/Login.css" rel="stylesheet" type="text/css" />

</head>

<body>

    <form id="form1" runat="server">

        <div class="page">

            <div class="login-panel">

                <!-- ========================= -->
                <!-- بخش معرفی سامانه -->
                <!-- ========================= -->

                <div class="information">

                    <div class="information-content">

                        <div class="ministry-name">
                            وزارت تعاون، کار و رفاه اجتماعی
                        </div>

                        <div class="information-line"></div>

                        <h1>
                            سامانه خدمات فناوری اطلاعات
                        </h1>

                        <p class="information-description">
                            سامانه مدیریت و پیگیری درخواست‌های خدمات فناوری اطلاعات
                        </p>

                        <div class="features">

                            <div class="feature">
                                <span class="feature-icon">✓</span>
                                <span>ثبت و پیگیری درخواست‌های فناوری اطلاعات</span>
                            </div>

                            <div class="feature">
                                <span class="feature-icon">✓</span>
                                <span>مدیریت و ارجاع درخواست‌ها</span>
                            </div>

                            <div class="feature">
                                <span class="feature-icon">✓</span>
                                <span>ثبت اقدامات و سوابق انجام کار</span>
                            </div>

                            <div class="feature">
                                <span class="feature-icon">✓</span>
                                <span>پیگیری وضعیت درخواست‌ها</span>
                            </div>

                        </div>

                    </div>

                </div>


                <!-- ========================= -->
                <!-- بخش ورود -->
                <!-- ========================= -->

                <div class="login-section">

                    <div class="login-content">

                        <div class="login-header">

                            <div class="login-icon">
                                <span>♙</span>
                            </div>

                            <h2>
                                ورود به سامانه
                            </h2>

                            <p>
                                لطفاً اطلاعات حساب کاربری خود را وارد کنید
                            </p>

                        </div>


                        <!-- نام کاربری -->

                        <div class="form-group">

                            <label for="txtUserName">
                                نام کاربری
                            </label>

                            <asp:TextBox
                                ID="txtUserName"
                                runat="server"
                                CssClass="form-control"
                                placeholder="نام کاربری خود را وارد کنید">
                            </asp:TextBox>

                        </div>


                        <!-- رمز عبور -->

                        <div class="form-group">

                            <label for="txtPassword">
                                رمز عبور
                            </label>

                            <asp:TextBox
                                ID="txtPassword"
                                runat="server"
                                TextMode="Password"
                                CssClass="form-control"
                                placeholder="رمز عبور خود را وارد کنید">
                            </asp:TextBox>

                        </div>


                        <!-- دکمه ورود -->

                        <asp:Button
                            ID="btnLogin"
                            runat="server"
                            Text="ورود به سامانه"
                            CssClass="login-button"
                            OnClick="btnLogin_Click" />


                        <!-- پیام سیستم -->

                        <asp:Label
                            ID="lblMessage"
                            runat="server"
                            Visible="false">
                        </asp:Label>


                        <div class="login-footer">
                            سامانه خدمات فناوری اطلاعات
                        </div>

                    </div>

                </div>

            </div>

        </div>

    </form>

</body>
</html>