﻿using System;
using System.Linq;
using Microsoft.AspNet.Identity;
using WebApplication1.Models;

namespace WebApplication1
{
    public partial class UserTickets : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Request.IsAuthenticated)
            {
                Response.Redirect("~/Login.aspx");
                return;
            }

            if (User.IsInRole("Manager") ||
                User.IsInRole("Specialist"))
            {
                Response.Redirect("~/Login.aspx");
                return;
            }

            if (!IsPostBack)
            {
                LoadTickets();
            }
        }


        private void LoadTickets()
        {
            string currentUserId = User.Identity.GetUserId();

            if (string.IsNullOrEmpty(currentUserId))
            {
                Response.Redirect("~/Login.aspx");
                return;
            }

            using (var db = new ApplicationDbContext())
            {
                // -----------------------------------------
                // فقط درخواست‌های منتظر تأیید
                // -----------------------------------------

                int waitingCount = db.Tickets.Count(t =>
                    t.UserId == currentUserId &&
                    t.Status == "WaitingConfirmation");


                // -----------------------------------------
                // نمایش پیام
                // -----------------------------------------

                if (waitingCount > 0)
                {
                    pnlWaiting.Visible = true;

                    if (waitingCount == 1)
                    {
                        lblWaitingMessage.Text =
                            "یک درخواست منتظر تأیید شماست. " +
                            "لطفاً نتیجه رسیدگی را بررسی کنید.";
                    }
                    else
                    {
                        lblWaitingMessage.Text =
                            "تعداد " + waitingCount +
                            " درخواست منتظر تأیید شماست. " +
                            "لطفاً نتیجه رسیدگی درخواست‌ها را بررسی کنید.";
                    }
                }
                else
                {
                    pnlWaiting.Visible = false;
                    lblWaitingMessage.Text = "";
                }


                // -----------------------------------------
                // فقط درخواست‌های WaitingConfirmation
                // -----------------------------------------

                var tickets = db.Tickets
                    .Where(t =>
                        t.UserId == currentUserId &&
                        t.Status == "WaitingConfirmation")
                    .OrderByDescending(t => t.CreatedAt)
                    .Select(t => new
                    {
                        t.TicketId,
                        t.Subject,
                        t.Category,
                        t.Priority,
                        t.Status,
                        t.CreatedAt
                    })
                    .ToList()
                    .Select(t => new
                    {
                        t.TicketId,
                        t.Subject,

                        Category = GetCategoryText(
                            t.Category),

                        PriorityText = GetPriorityText(
                            t.Priority),

                        StatusText = GetStatusText(
                            t.Status),

                        StatusCss = GetStatusCss(
                            t.Status),

                        CreatedAtText = t.CreatedAt
                            .ToString("yyyy/MM/dd HH:mm")
                    })
                    .ToList();


                // -----------------------------------------
                // نمایش در GridView
                // -----------------------------------------

                gvTickets.DataSource = tickets;
                gvTickets.DataBind();
            }
        }


        private string GetCategoryText(string category)
        {
            switch (category)
            {
                case "نرم‌افزار":
                    return "نرم‌افزار";

                case "سخت‌افزار":
                    return "سخت‌افزار";

                case "شبکه":
                    return "شبکه";

                case "امنیت":
                    return "امنیت";

                case "سایر":
                    return "سایر";

                default:
                    return category;
            }
        }


        private string GetPriorityText(string priority)
        {
            switch (priority)
            {
                case "Low":
                    return "کم";

                case "Normal":
                    return "عادی";

                case "High":
                    return "زیاد";

                case "Critical":
                    return "بحرانی";

                default:
                    return priority;
            }
        }


        private string GetStatusText(string status)
        {
            switch (status)
            {
                case "New":
                    return "جدید";

                case "Assigned":
                    return "ارجاع شده";

                case "InProgress":
                    return "در حال رسیدگی";

                case "WaitingConfirmation":
                    return "منتظر تأیید کاربر";

                case "Closed":
                    return "خاتمه یافته";

                default:
                    return status;
            }
        }


        private string GetStatusCss(string status)
        {
            switch (status)
            {
                case "WaitingConfirmation":
                    return "status-waiting";

                default:
                    return "status-normal";
            }
        }
    }
}