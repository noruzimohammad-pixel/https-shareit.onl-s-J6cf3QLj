﻿<%@ Page Title="جزئیات درخواست"
    Language="C#"
    MasterPageFile="~/Site.Master"
    AutoEventWireup="true"
    CodeBehind="UserTicket.aspx.cs"
    Inherits="WebApplication1.UserTicket" %>

<asp:Content ID="Content1"
    ContentPlaceHolderID="TitleContent"
    runat="server">
    جزئیات درخواست
</asp:Content>


<asp:Content ID="Content2"
    ContentPlaceHolderID="HeadContent"
    runat="server">

    <style type="text/css">

        /* ==========================================
           کارت اصلی
           ========================================== */

        .ticket-detail-card {
            background: #ffffff;
            border-radius: 14px;
            padding: 24px;
            margin-bottom: 20px;
            box-shadow: 0 3px 15px rgba(0,0,0,.06);
        }


        /* ==========================================
           اطلاعات درخواست
           ========================================== */

        .ticket-info-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 18px;
        }

        .info-item {
            background: #f8f9fc;
            border-radius: 10px;
            padding: 14px 16px;
        }

        .info-label {
            display: block;
            color: #777;
            font-size: 12px;
            margin-bottom: 7px;
        }

        .info-value {
            font-weight: 600;
            color: #222;
        }


        /* ==========================================
           شرح درخواست
           ========================================== */

        .description-box {
            background: #f8f9fc;
            border-radius: 10px;
            padding: 18px;
            line-height: 2;
            white-space: pre-wrap;
            min-height: 100px;
        }


        /* ==========================================
           اقدامات کارشناس
           ========================================== */

        .action-item {
            border-right: 3px solid #4f46e5;
            background: #f8f9fc;
            padding: 15px 18px;
            margin-bottom: 12px;
            border-radius: 8px;
        }

        .action-header {
            display: flex;
            justify-content: space-between;
            margin-bottom: 8px;
            color: #777;
            font-size: 12px;
        }

        .action-text {
            line-height: 1.9;
            white-space: pre-wrap;
        }


        /* ==========================================
           پیام سیستم
           ========================================== */

        .message {
            display: block;
            padding: 13px 16px;
            margin-bottom: 18px;
            border-radius: 8px;
            font-size: 13px;
            line-height: 1.8;
        }

        .message.success {
            background: #e8f5e9;
            color: #2e7d32;
            border: 1px solid #c8e6c9;
        }

        .message.error {
            background: #ffebee;
            color: #c62828;
            border: 1px solid #ffcdd2;
        }


        /* ==========================================
           بخش تأیید
           ========================================== */

        .confirmation-box {
            background: #f8f9fc;
            border-radius: 12px;
            padding: 20px;
            margin-top: 10px;
        }

        .confirmation-box textarea {
            width: 100%;
            min-height: 120px;
            box-sizing: border-box;
            padding: 13px;
            border: 1px solid #dfe3ea;
            border-radius: 9px;
            font-family: inherit;
            font-size: 14px;
            resize: vertical;
            line-height: 1.8;
        }


        /* عنوان توضیحات */

        .comment-title {
            font-size: 14px;
            font-weight: 700;
            color: #374151;
            margin-bottom: 7px;
        }


        /* توضیح زیر عنوان */

        .comment-description {
            font-size: 12px;
            line-height: 1.9;
            color: #6b7280;
            margin-bottom: 12px;
        }


        /* کادر توضیحات */

        .confirmation-textbox {
            width: 100%;
            min-height: 120px;
            box-sizing: border-box;
            padding: 13px;
            border: 1px solid #dfe3ea;
            border-radius: 9px;
            font-family: inherit;
            font-size: 14px;
            resize: vertical;
            line-height: 1.8;
        }

        .confirmation-textbox:focus {
            border-color: #4f46e5;
            outline: none;
        }


        /* ==========================================
           دکمه‌های تأیید
           ========================================== */

        .confirmation-buttons {
            margin-top: 14px;
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }


        /* دکمه تأیید */

        .btn-success {
            background: #2e7d32;
            color: #ffffff !important;
            border: none;
            border-radius: 7px;
            padding: 10px 18px;
            font-family: inherit;
            font-size: 13px;
            cursor: pointer;
        }

        .btn-success:hover {
            background: #256628;
        }


        /* دکمه عدم تأیید */

        .btn-danger {
            background: #e53935;
            color: #ffffff !important;
            border: none;
            border-radius: 7px;
            padding: 10px 18px;
            font-family: inherit;
            font-size: 13px;
            cursor: pointer;
        }

        .btn-danger:hover {
            background: #c62828;
        }


        /* ==========================================
           پیام خالی
           ========================================== */

        .empty-message {
            display: block;
            text-align: center;
            padding: 25px;
            color: #888;
            font-size: 13px;
        }


        /* ==========================================
           موبایل
           ========================================== */

        @media (max-width: 700px) {

            .ticket-info-grid {
                grid-template-columns: 1fr;
            }

            .action-header {
                display: block;
            }

            .confirmation-buttons {
                flex-direction: column;
            }

            .confirmation-buttons input,
            .confirmation-buttons button {
                width: 100%;
            }

        }

    </style>

</asp:Content>


<asp:Content ID="Content3"
    ContentPlaceHolderID="PageHeader"
    runat="server">

    <div class="page-title">

        <h1>
            جزئیات درخواست
        </h1>

        <p>
            مشاهده وضعیت و نتیجه رسیدگی به درخواست
        </p>

    </div>

</asp:Content>


<asp:Content ID="Content4"
    ContentPlaceHolderID="MainContent"
    runat="server">


    <!-- ==========================================
         پیام سیستم
         ========================================== -->

    <asp:Label
        ID="lblMessage"
        runat="server"
        Visible="false"
        CssClass="message">
    </asp:Label>


    <!-- ==========================================
         اطلاعات درخواست
         ========================================== -->

    <div class="ticket-detail-card">

        <h3>
            اطلاعات درخواست
        </h3>


        <div class="ticket-info-grid">


            <!-- شماره درخواست -->

            <div class="info-item">

                <span class="info-label">
                    شماره درخواست
                </span>

                <asp:Label
                    ID="lblTicketId"
                    runat="server"
                    CssClass="info-value">
                </asp:Label>

            </div>


            <!-- عنوان -->

            <div class="info-item">

                <span class="info-label">
                    عنوان
                </span>

                <asp:Label
                    ID="lblSubject"
                    runat="server"
                    CssClass="info-value">
                </asp:Label>

            </div>


            <!-- دسته‌بندی -->

            <div class="info-item">

                <span class="info-label">
                    دسته‌بندی
                </span>

                <asp:Label
                    ID="lblCategory"
                    runat="server"
                    CssClass="info-value">
                </asp:Label>

            </div>


            <!-- اولویت -->

            <div class="info-item">

                <span class="info-label">
                    اولویت
                </span>

                <asp:Label
                    ID="lblPriority"
                    runat="server"
                    CssClass="info-value">
                </asp:Label>

            </div>


            <!-- وضعیت -->

            <div class="info-item">

                <span class="info-label">
                    وضعیت
                </span>

                <asp:Label
                    ID="lblStatus"
                    runat="server"
                    CssClass="info-value">
                </asp:Label>

            </div>


            <!-- تاریخ ثبت -->

            <div class="info-item">

                <span class="info-label">
                    تاریخ ثبت
                </span>

                <asp:Label
                    ID="lblCreatedAt"
                    runat="server"
                    CssClass="info-value">
                </asp:Label>

            </div>


        </div>


        <br />


        <!-- شرح درخواست -->

        <h4>
            شرح درخواست
        </h4>

        <div class="description-box">

            <asp:Label
                ID="lblDescription"
                runat="server">
            </asp:Label>

        </div>

    </div>


    <!-- ==========================================
         اقدامات انجام شده
         ========================================== -->

    <div class="ticket-detail-card">

        <h3>
            اقدامات انجام‌شده
        </h3>


        <asp:Repeater
            ID="rptActions"
            runat="server">

            <ItemTemplate>

                <div class="action-item">


                    <div class="action-header">

                        <span>
                            <%# Eval("UserName") %>
                        </span>

                        <span>
                            <%# Eval("ActionDateText") %>
                        </span>

                    </div>


                    <div class="action-text">

                        <%# Eval("ActionText") %>

                    </div>


                </div>

            </ItemTemplate>

        </asp:Repeater>


        <asp:Label
            ID="lblNoActions"
            runat="server"
            Text="هنوز اقدامی برای این درخواست ثبت نشده است."
            CssClass="empty-message"
            Visible="false">
        </asp:Label>

    </div>


    <!-- ==========================================
         تأیید نتیجه رسیدگی
         ========================================== -->

    <asp:Panel
        ID="pnlConfirmation"
        runat="server"
        Visible="false"
        CssClass="ticket-detail-card">


        <h3>
            تأیید نتیجه رسیدگی
        </h3>


        <p>
            در صورتی که مشکل شما برطرف شده است،
            نتیجه رسیدگی را تأیید کنید.
        </p>


        <div class="confirmation-box">


            <!-- عنوان توضیحات -->

            <div class="comment-title">
                توضیح نتیجه رسیدگی
            </div>


            <!-- توضیح برای کاربر -->

            <div class="comment-description">

                در صورت تأیید، نوشتن توضیح اختیاری است.
                اما برای عدم تأیید نتیجه رسیدگی، وارد کردن توضیح الزامی است
                تا کارشناس بداند چه بخشی از مشکل نیاز به ادامه رسیدگی دارد.

            </div>


            <!-- کادر توضیحات -->

            <asp:TextBox
                ID="txtConfirmationComment"
                runat="server"
                TextMode="MultiLine"
                CssClass="confirmation-textbox"
                placeholder="در صورت عدم تأیید، توضیح دهید چه مشکلی برطرف نشده یا چه اقدامی نیاز به ادامه دارد...">
            </asp:TextBox>


            <!-- دکمه‌ها -->

            <div class="confirmation-buttons">


                <!-- تأیید -->

                <asp:Button
                    ID="btnConfirm"
                    runat="server"
                    Text="تأیید و خاتمه درخواست"
                    CssClass="btn-success"
                    OnClick="btnConfirm_Click"
                    OnClientClick="return confirm('آیا از تأیید نتیجه رسیدگی و خاتمه درخواست اطمینان دارید؟');" />


                <!-- عدم تأیید -->

                <asp:Button
                    ID="btnReject"
                    runat="server"
                    Text="عدم تأیید / نیاز به ادامه رسیدگی"
                    CssClass="btn-danger"
                    OnClick="btnReject_Click"
                    OnClientClick="return confirm('آیا نتیجه رسیدگی را تأیید نمی‌کنید و درخواست نیاز به ادامه رسیدگی دارد؟');" />


            </div>

        </div>

    </asp:Panel>

</asp:Content>