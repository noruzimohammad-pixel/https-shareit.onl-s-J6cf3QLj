﻿<%@ Page Title="درخواست‌های من"
    Language="C#"
    MasterPageFile="~/Site.Master"
    AutoEventWireup="true"
    CodeBehind="UserTickets.aspx.cs"
    Inherits="WebApplication1.UserTickets" %>

<asp:Content ID="Content1"
    ContentPlaceHolderID="MainContent"
    runat="server">

    <style type="text/css">

        .tickets-page {
            direction: rtl;
            padding: 24px 26px;
        }

        .tickets-header {
            margin-bottom: 22px;
        }

        .tickets-title {
            margin: 0;
            font-size: 24px;
            font-weight: 700;
            color: #1f2937;
        }

        .tickets-subtitle {
            margin-top: 7px;
            color: #6b7280;
            font-size: 14px;
        }

        .waiting-box {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 15px;
            margin-bottom: 18px;
            padding: 14px 18px;
            background: #fff8e6;
            border: 1px solid #f2d58a;
            border-right: 4px solid #e5a900;
            border-radius: 10px;
            color: #6b5200;
        }

        .waiting-content {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .waiting-icon {
            width: 34px;
            height: 34px;
            border-radius: 50%;
            background: #f5c542;
            color: #fff;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 18px;
            font-weight: bold;
            flex-shrink: 0;
        }

        .waiting-title {
            font-size: 14px;
            font-weight: 700;
            margin-bottom: 3px;
        }

        .waiting-text {
            font-size: 12px;
            color: #806a20;
        }

        .tickets-card {
            background: #fff;
            border-radius: 15px;
            padding: 20px;
            box-shadow: 0 3px 15px rgba(0,0,0,.06);
            border: 1px solid #eef1f5;
        }

        .ticket-table {
            width: 100%;
            border-collapse: collapse;
            direction: rtl;
            font-size: 13px;
        }

        .ticket-table th {
            background: #f7f8fa;
            color: #374151;
            font-weight: 700;
            padding: 11px 9px;
            border: 1px solid #e5e7eb;
            white-space: nowrap;
            text-align: center;
        }

        .ticket-table td {
            padding: 10px 9px;
            border: 1px solid #e5e7eb;
            color: #374151;
            text-align: center;
            vertical-align: middle;
        }

        .ticket-table tr:hover td {
            background: #fafbfc;
        }

        .ticket-link {
            color: #245b89 !important;
            text-decoration: none !important;
            font-weight: 600;
        }

        .ticket-link:hover {
            color: #1d4b70 !important;
            text-decoration: underline !important;
        }

        .ticket-view-button {
            display: inline-block;
            min-width: 58px;
            padding: 6px 12px;
            background: #eef3f8;
            color: #2c5f8a !important;
            border: 1px solid #d5e0ea;
            border-radius: 5px;
            text-decoration: none !important;
            font-size: 12px;
            font-weight: 600;
            white-space: nowrap;
            text-align: center;
            box-sizing: border-box;
        }

        .ticket-view-button:hover {
            background: #2c5f8a;
            color: #fff !important;
            border-color: #2c5f8a;
        }

        .status-waiting {
            display: inline-block;
            padding: 5px 9px;
            border-radius: 5px;
            background: #fff4d6;
            color: #946c00;
            font-size: 12px;
            font-weight: 600;
        }

        .status-normal {
            font-size: 12px;
        }

        @media screen and (max-width: 700px) {

            .tickets-page {
                padding: 15px;
            }

            .tickets-card {
                overflow-x: auto;
            }

            .ticket-table {
                min-width: 850px;
            }

            .waiting-box {
                flex-direction: column;
                align-items: flex-start;
            }
        }

    </style>


    <div class="tickets-page">

        <div class="tickets-header">

            <h1 class="tickets-title">
                درخواست‌های من
            </h1>

            <div class="tickets-subtitle">
                مشاهده و پیگیری درخواست‌های ثبت‌شده
            </div>

        </div>


        <!-- هشدار درخواست‌های منتظر تأیید -->

        <asp:Panel
            ID="pnlWaiting"
            runat="server"
            CssClass="waiting-box"
            Visible="false">

            <div class="waiting-content">

                <div class="waiting-icon">
                    !
                </div>

                <div>

                    <div class="waiting-title">
                        درخواست منتظر تأیید شماست
                    </div>

                    <div class="waiting-text">

                        <asp:Label
                            ID="lblWaitingMessage"
                            runat="server">
                        </asp:Label>

                    </div>

                </div>

            </div>

        </asp:Panel>


        <div class="tickets-card">

            <asp:GridView
                ID="gvTickets"
                runat="server"
                AutoGenerateColumns="False"
                CssClass="ticket-table"
                GridLines="Both"
                EmptyDataText="درخواستی برای نمایش وجود ندارد.">

                <Columns>

                    <asp:BoundField
                        DataField="TicketId"
                        HeaderText="شماره" />

                    <asp:TemplateField
                        HeaderText="عنوان درخواست">

                        <ItemTemplate>

                            <asp:HyperLink
                                ID="lnkSubject"
                                runat="server"
                                Text='<%# Eval("Subject") %>'
                                NavigateUrl='<%# "UserTicket.aspx?id=" + Eval("TicketId") %>'
                                CssClass="ticket-link">
                            </asp:HyperLink>

                        </ItemTemplate>

                    </asp:TemplateField>


                    <asp:BoundField
                        DataField="Category"
                        HeaderText="دسته‌بندی" />


                    <asp:BoundField
                        DataField="PriorityText"
                        HeaderText="اولویت" />


                    <asp:TemplateField
                        HeaderText="وضعیت">

                        <ItemTemplate>

                            <asp:Label
                                ID="lblStatus"
                                runat="server"
                                Text='<%# Eval("StatusText") %>'
                                CssClass='<%# Eval("StatusCss") %>'>
                            </asp:Label>

                        </ItemTemplate>

                    </asp:TemplateField>


                    <asp:BoundField
                        DataField="CreatedAtText"
                        HeaderText="تاریخ ثبت" />


                    <asp:TemplateField
                        HeaderText="مشاهده">

                        <ItemTemplate>

                            <asp:HyperLink
                                ID="lnkView"
                                runat="server"
                                Text="مشاهده"
                                NavigateUrl='<%# "UserTicket.aspx?id=" + Eval("TicketId") %>'
                                CssClass="ticket-view-button">
                            </asp:HyperLink>

                        </ItemTemplate>

                        <ItemStyle HorizontalAlign="Center" />

                    </asp:TemplateField>

                </Columns>

            </asp:GridView>

        </div>

    </div>

</asp:Content>