﻿<%@ Page Title="درخواست‌های ثبت‌شده من"
    Language="C#"
    MasterPageFile="~/Site.Master"
    AutoEventWireup="true"
    CodeBehind="SpecialistMyTickets.aspx.cs"
    Inherits="WebApplication1.SpecialistMyTickets" %>

<asp:Content ID="Content1"
    ContentPlaceHolderID="MainContent"
    runat="server">

    <style type="text/css">

        .my-tickets-page {
            direction: rtl;
        }

        .page-intro {
            margin-bottom: 25px;
        }

        .page-intro h2 {
            margin: 0 0 8px 0;
            font-size: 24px;
            color: #202938;
        }

        .page-intro p {
            margin: 0;
            color: #7b8491;
            font-size: 13px;
        }

        .tickets-box {
            background: #ffffff;
            border: 1px solid #edf0f4;
            border-radius: 12px;
            box-shadow: 0 3px 12px rgba(0,0,0,.045);
            overflow: hidden;
        }

        .tickets-header {
            padding: 20px 22px;
            border-bottom: 1px solid #edf0f4;
        }

        .tickets-title {
            font-size: 17px;
            font-weight: bold;
            color: #202938;
        }

        .tickets-subtitle {
            margin-top: 5px;
            color: #89919d;
            font-size: 12px;
        }

        .tickets-grid {
            width: 100%;
            border-collapse: collapse;
        }

        .tickets-grid th {
            background: #f8f9fb;
            color: #687281;
            font-size: 12px;
            padding: 13px 14px;
            border-bottom: 1px solid #e9edf2;
            text-align: right;
            white-space: nowrap;
        }

        .tickets-grid td {
            padding: 14px;
            border-bottom: 1px solid #f0f2f5;
            color: #3d4653;
            font-size: 13px;
        }

        .tickets-grid tr:hover {
            background: #fafbfd;
        }

        .view-link {
            display: inline-block;
            padding: 7px 13px;
            background: #334155;
            color: #ffffff !important;
            text-decoration: none;
            border-radius: 6px;
            font-size: 12px;
        }

        .view-link:hover {
            background: #1e293b;
        }

        .empty-message {
            display: block;
            padding: 35px;
            text-align: center;
            color: #89919d;
        }

    </style>


    <div class="my-tickets-page">


        <div class="page-intro">

            <h2>
                درخواست‌های ثبت‌شده من
            </h2>

            <p>
                درخواست‌هایی که شما به عنوان درخواست‌کننده ثبت کرده‌اید
            </p>

        </div>


        <div class="tickets-box">


            <div class="tickets-header">

                <div class="tickets-title">
                    درخواست‌های من
                </div>

                <div class="tickets-subtitle">
                    این بخش فقط درخواست‌هایی را نمایش می‌دهد که توسط شما ثبت شده‌اند.
                </div>

            </div>


            <asp:GridView
                ID="gvTickets"
                runat="server"
                AutoGenerateColumns="False"
                CssClass="tickets-grid"
                GridLines="None"
                EmptyDataText="هنوز درخواستی توسط شما ثبت نشده است.">

                <Columns>


                    <asp:BoundField
                        DataField="TicketId"
                        HeaderText="شماره" />


                    <asp:BoundField
                        DataField="Subject"
                        HeaderText="موضوع" />


                    <asp:BoundField
                        DataField="Category"
                        HeaderText="دسته‌بندی" />


                    <asp:BoundField
                        DataField="Priority"
                        HeaderText="اولویت" />


                    <asp:BoundField
                        DataField="Status"
                        HeaderText="وضعیت" />


                    <asp:BoundField
                        DataField="CreatedAt"
                        HeaderText="تاریخ ثبت"
                        DataFormatString="{0:yyyy/MM/dd HH:mm}" />


                    <asp:HyperLinkField
                        HeaderText="عملیات"
                        Text="مشاهده جزئیات"
                        DataNavigateUrlFields="TicketId"
                        DataNavigateUrlFormatString="UserTicketDetails.aspx?id={0}"
                        ControlStyle-CssClass="view-link" />


                </Columns>


                <EmptyDataRowStyle
                    CssClass="empty-message" />

            </asp:GridView>


        </div>

    </div>

</asp:Content>