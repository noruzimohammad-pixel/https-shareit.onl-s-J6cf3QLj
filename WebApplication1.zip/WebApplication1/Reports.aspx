﻿<%@ Page Title="گزارش‌ها و آمار مدیریتی"
    CodePage="65001"
    Language="C#"
    MasterPageFile="~/Site.Master"
    AutoEventWireup="true"
    CodeBehind="Reports.aspx.cs"
    Inherits="WebApplication1.Reports" %>

<asp:Content ID="Content1"
    ContentPlaceHolderID="TitleContent"
    runat="server">
    گزارش‌ها و آمار مدیریتی
</asp:Content>

<asp:Content ID="Content2"
    ContentPlaceHolderID="PageHeader"
    runat="server">
    گزارش‌ها و آمار مدیریتی
</asp:Content>

<asp:Content ID="Content3"
    ContentPlaceHolderID="MainContent"
    runat="server">

<style>

    .reports-page {
        width: 100%;
    }

    /* =====================================================
       فیلترهای اصلی
       ===================================================== */

    .report-filter-card {
        background: #ffffff;
        border: 1px solid #e5e7eb;
        border-radius: 14px;
        padding: 20px;
        margin-bottom: 22px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.04);
    }

    .report-filter-title {
        font-size: 17px;
        font-weight: 700;
        color: #1f2937;
        margin-bottom: 18px;
    }

    .report-filter-grid {
        display: grid;
        grid-template-columns: repeat(4, minmax(180px, 1fr));
        gap: 16px;
    }

    .report-filter-item {
        display: flex;
        flex-direction: column;
        gap: 7px;
    }

    .report-filter-item label {
        font-size: 13px;
        font-weight: 600;
        color: #4b5563;
    }

    .report-filter-item input,
    .report-filter-item select {
        width: 100%;
        height: 42px;
        padding: 0 12px;
        border: 1px solid #d1d5db;
        border-radius: 8px;
        background: #ffffff;
        color: #374151;
        font-family: inherit;
        font-size: 13px;
        box-sizing: border-box;
    }

    .report-filter-item input:focus,
    .report-filter-item select:focus {
        outline: none;
        border-color: #2563eb;
        box-shadow: 0 0 0 2px rgba(37,99,235,0.08);
    }

    .report-filter-actions {
        display: flex;
        align-items: flex-end;
        gap: 10px;
    }

    .report-button {
        height: 42px;
        padding: 0 22px;
        border: none;
        border-radius: 8px;
        font-family: inherit;
        font-size: 13px;
        font-weight: 600;
        cursor: pointer;
    }

    .report-button-primary {
        background: #2563eb;
        color: #ffffff;
    }

    .report-button-primary:hover {
        background: #1d4ed8;
    }

    .report-button-secondary {
        background: #f3f4f6;
        color: #374151;
        border: 1px solid #d1d5db;
    }

    .report-button-secondary:hover {
        background: #e5e7eb;
    }


    /* =====================================================
       کارت‌های آماری
       ===================================================== */

    .report-stats-grid {
        display: grid;
        grid-template-columns: repeat(6, minmax(130px, 1fr));
        gap: 14px;
        margin-bottom: 24px;
    }

    .report-stat-card {
        background: #ffffff;
        border: 1px solid #e5e7eb;
        border-radius: 14px;
        padding: 18px;
        min-height: 95px;
        box-sizing: border-box;
        box-shadow: 0 2px 8px rgba(0,0,0,0.03);
    }

    .report-stat-title {
        font-size: 12px;
        color: #6b7280;
        margin-bottom: 10px;
    }

    .report-stat-value {
        font-size: 27px;
        font-weight: 700;
        color: #111827;
    }


    /* =====================================================
       تب‌ها
       ===================================================== */

    .report-tabs {
        display: flex;
        flex-wrap: wrap;
        gap: 8px;
        background: #ffffff;
        border: 1px solid #e5e7eb;
        border-radius: 14px;
        padding: 10px;
        margin-bottom: 16px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.03);
    }

    .report-tab {
        display: inline-block;
        padding: 11px 18px;
        border-radius: 8px;
        color: #4b5563;
        text-decoration: none;
        font-size: 13px;
        font-weight: 600;
        background: transparent;
        transition: 0.2s;
    }

    .report-tab:hover {
        background: #f3f4f6;
        color: #1f2937;
    }

    .report-tab-active {
        background: #2563eb;
        color: #ffffff !important;
    }


    /* =====================================================
       بخش گزارش
       ===================================================== */

    .report-section {
        background: #ffffff;
        border: 1px solid #e5e7eb;
        border-radius: 14px;
        padding: 20px;
        margin-bottom: 22px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.03);
    }

    .report-section-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 15px;
        margin-bottom: 18px;
    }

    .report-section-title {
        margin: 0;
        font-size: 17px;
        font-weight: 700;
        color: #1f2937;
    }

    .report-result-count {
        font-size: 12px;
        color: #6b7280;
    }


    /* =====================================================
       جستجوی داخل گزارش
       ===================================================== */

    .report-search {
        display: flex;
        gap: 8px;
        margin-bottom: 16px;
    }

    .report-search input {
        height: 40px;
        width: 320px;
        max-width: 100%;
        padding: 0 12px;
        border: 1px solid #d1d5db;
        border-radius: 8px;
        font-family: inherit;
        font-size: 13px;
        box-sizing: border-box;
    }

    .report-search input:focus {
        outline: none;
        border-color: #2563eb;
        box-shadow: 0 0 0 2px rgba(37,99,235,0.08);
    }

    .report-search-button {
        height: 40px;
        padding: 0 18px;
        border: none;
        border-radius: 8px;
        background: #374151;
        color: #ffffff;
        font-family: inherit;
        font-size: 13px;
        cursor: pointer;
    }

    .report-search-button:hover {
        background: #1f2937;
    }

    .report-clear-search-button {
        height: 40px;
        padding: 0 15px;
        border: 1px solid #d1d5db;
        border-radius: 8px;
        background: #ffffff;
        color: #4b5563;
        font-family: inherit;
        font-size: 13px;
        cursor: pointer;
    }


    /* =====================================================
       جدول
       ===================================================== */

    .report-table-wrapper {
        width: 100%;
        overflow-x: auto;
    }

    .report-grid {
        width: 100%;
        border-collapse: collapse;
        font-size: 13px;
    }

    .report-grid th {
        background: #f8fafc;
        color: #374151;
        font-weight: 700;
        padding: 12px 10px;
        border-bottom: 1px solid #e5e7eb;
        text-align: right;
        white-space: nowrap;
    }

    .report-grid td {
        padding: 12px 10px;
        border-bottom: 1px solid #f0f1f3;
        color: #4b5563;
        text-align: right;
        white-space: nowrap;
    }

    .report-grid tr:hover td {
        background: #fafafa;
    }

    .numeric-column {
        text-align: center !important;
    }


    /* =====================================================
       صفحه‌بندی
       ===================================================== */

    .report-pagination {
        display: flex;
        justify-content: center;
        align-items: center;
        gap: 6px;
        margin-top: 18px;
        flex-wrap: wrap;
    }

    .report-pagination a,
    .report-pagination span {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        min-width: 34px;
        height: 34px;
        padding: 0 8px;
        border-radius: 7px;
        text-decoration: none;
        font-size: 12px;
        box-sizing: border-box;
    }

    .report-pagination a {
        background: #f3f4f6;
        color: #374151;
    }

    .report-pagination a:hover {
        background: #e5e7eb;
    }

    .report-pagination span {
        background: #2563eb;
        color: #ffffff;
        font-weight: 700;
    }


    .service-report-divider {
        height: 1px;
        background: #eef0f3;
        margin: 24px 0;
    }

    .service-subheader {
        margin-bottom: 14px;
    }

    .report-subtitle {
        margin: 0;
        font-size: 15px;
        font-weight: 700;
        color: #374151;
    }

    .service-mismatch-box {
        display: flex;
        align-items: center;
        gap: 12px;
        margin-top: 22px;
        padding: 14px 16px;
        border: 1px solid #e5e7eb;
        border-radius: 10px;
        background: #f8fafc;
    }

    .service-mismatch-title {
        font-size: 13px;
        font-weight: 700;
        color: #374151;
    }

    .advanced-report-note {
        margin-bottom: 16px;
        padding: 12px 14px;
        border: 1px solid #e5e7eb;
        border-radius: 10px;
        background: #f8fafc;
        color: #6b7280;
        font-size: 12px;
        line-height: 22px;
    }

    .advanced-report-metrics {
        display: grid;
        grid-template-columns: repeat(4, minmax(150px, 1fr));
        gap: 12px;
        margin-bottom: 18px;
    }

    .advanced-report-metric {
        border: 1px solid #e5e7eb;
        border-radius: 10px;
        padding: 13px 14px;
        background: #ffffff;
    }

    .advanced-report-metric-title {
        font-size: 11px;
        color: #6b7280;
        margin-bottom: 7px;
    }

    .advanced-report-metric-value {
        font-size: 20px;
        font-weight: 700;
        color: #1f2937;
    }

    @media screen and (max-width: 900px) {
        .advanced-report-metrics {
            grid-template-columns: repeat(2, minmax(140px, 1fr));
        }
    }

    @media screen and (max-width: 600px) {
        .advanced-report-metrics {
            grid-template-columns: 1fr;
        }
    }

    .service-mismatch-value {
        min-width: 32px;
        height: 32px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        border-radius: 8px;
        background: #2563eb;
        color: #ffffff;
        font-weight: 700;
        font-size: 13px;
    }

    .service-mismatch-text {
        font-size: 12px;
        color: #6b7280;
    }


    /* =====================================================
       Responsive
       ===================================================== */

    @media (max-width: 1200px) {

        .report-filter-grid {
            grid-template-columns: repeat(3, minmax(180px, 1fr));
        }

        .report-stats-grid {
            grid-template-columns: repeat(3, minmax(130px, 1fr));
        }
    }


    @media (max-width: 800px) {

        .report-filter-grid {
            grid-template-columns: repeat(2, minmax(150px, 1fr));
        }

        .report-stats-grid {
            grid-template-columns: repeat(2, minmax(130px, 1fr));
        }

        .report-section-header {
            flex-direction: column;
            align-items: flex-start;
        }
    }


    @media (max-width: 550px) {

        .report-filter-grid {
            grid-template-columns: 1fr;
        }

        .report-stats-grid {
            grid-template-columns: 1fr 1fr;
        }

        .report-filter-actions {
            flex-direction: column;
            align-items: stretch;
        }

        .report-button {
            width: 100%;
        }

        .report-search {
            flex-wrap: wrap;
        }

        .report-search input {
            width: 100%;
        }
    }

</style>


<div class="reports-page">


    <!-- =====================================================
         فیلترهای اصلی
         ===================================================== -->

    <div class="report-filter-card">

        <div class="report-filter-title">
            فیلترهای اصلی گزارش
        </div>

        <div class="report-filter-grid">


            <div class="report-filter-item">

                <label>از تاریخ</label>

                <asp:TextBox
                    ID="txtFromDate"
                    runat="server"
                    placeholder="مثلاً 1405/01/01">
                </asp:TextBox>

            </div>


            <div class="report-filter-item">

                <label>تا تاریخ</label>

                <asp:TextBox
                    ID="txtToDate"
                    runat="server"
                    placeholder="مثلاً 1405/12/29">
                </asp:TextBox>

            </div>


            <div class="report-filter-item">

                <label>واحد سازمانی</label>

                <asp:DropDownList
                    ID="ddlDepartment"
                    runat="server">

                    <asp:ListItem
                        Text="همه واحدها"
                        Value="">
                    </asp:ListItem>

                </asp:DropDownList>

            </div>


            <div class="report-filter-item">

                <label>کارشناس</label>

                <asp:DropDownList
                    ID="ddlSpecialist"
                    runat="server">

                    <asp:ListItem
                        Text="همه کارشناسان"
                        Value="">
                    </asp:ListItem>

                </asp:DropDownList>

            </div>


            <div class="report-filter-item">

                <label>دسته‌بندی</label>

                <asp:DropDownList
                    ID="ddlCategory"
                    runat="server">

                    <asp:ListItem
                        Text="همه دسته‌ها"
                        Value="">
                    </asp:ListItem>

                    <asp:ListItem
                        Text="نرم‌افزار"
                        Value="نرم‌افزار">
                    </asp:ListItem>

                    <asp:ListItem
                        Text="سخت‌افزار"
                        Value="سخت‌افزار">
                    </asp:ListItem>

                    <asp:ListItem
                        Text="شبکه"
                        Value="شبکه">
                    </asp:ListItem>

                    <asp:ListItem
                        Text="امنیت"
                        Value="امنیت">
                    </asp:ListItem>

                    <asp:ListItem
                        Text="سایر"
                        Value="سایر">
                    </asp:ListItem>

                </asp:DropDownList>

            </div>


            <div class="report-filter-item">

                <label>اولویت</label>

                <asp:DropDownList
                    ID="ddlPriority"
                    runat="server">

                    <asp:ListItem
                        Text="همه اولویت‌ها"
                        Value="">
                    </asp:ListItem>

                    <asp:ListItem
                        Text="کم"
                        Value="Low">
                    </asp:ListItem>

                    <asp:ListItem
                        Text="عادی"
                        Value="Normal">
                    </asp:ListItem>

                    <asp:ListItem
                        Text="زیاد"
                        Value="High">
                    </asp:ListItem>

                    <asp:ListItem
                        Text="بحرانی"
                        Value="Critical">
                    </asp:ListItem>

                </asp:DropDownList>

            </div>


            <div class="report-filter-item">

                <label>وضعیت</label>

                <asp:DropDownList
                    ID="ddlStatus"
                    runat="server">

                    <asp:ListItem
                        Text="همه وضعیت‌ها"
                        Value="">
                    </asp:ListItem>

                    <asp:ListItem
                        Text="جدید"
                        Value="New">
                    </asp:ListItem>

                    <asp:ListItem
                        Text="ارجاع شده"
                        Value="Assigned">
                    </asp:ListItem>

                    <asp:ListItem
                        Text="در حال انجام"
                        Value="InProgress">
                    </asp:ListItem>

                    <asp:ListItem
                        Text="منتظر تأیید کاربر"
                        Value="WaitingConfirmation">
                    </asp:ListItem>

                    <asp:ListItem
                        Text="خاتمه یافته"
                        Value="Closed">
                    </asp:ListItem>

                </asp:DropDownList>

            </div>


            <div class="report-filter-actions">

                <asp:Button
                    ID="btnGenerateReport"
                    runat="server"
                    Text="نمایش گزارش"
                    CssClass="report-button report-button-primary"
                    OnClick="btnGenerateReport_Click" />

                <asp:Button
                    ID="btnClearFilters"
                    runat="server"
                    Text="حذف فیلترها"
                    CssClass="report-button report-button-secondary"
                    OnClick="btnClearFilters_Click" />

            </div>

        </div>

    </div>


    <!-- =====================================================
         کارت‌های آماری
         ===================================================== -->

    <div class="report-stats-grid">


        <div class="report-stat-card">

            <div class="report-stat-title">
                کل درخواست‌ها
            </div>

            <asp:Label
                ID="lblTotalCount"
                runat="server"
                CssClass="report-stat-value"
                Text="0">
            </asp:Label>

        </div>


        <div class="report-stat-card">

            <div class="report-stat-title">
                جدید
            </div>

            <asp:Label
                ID="lblNewCount"
                runat="server"
                CssClass="report-stat-value"
                Text="0">
            </asp:Label>

        </div>


        <div class="report-stat-card">

            <div class="report-stat-title">
                در حال انجام
            </div>

            <asp:Label
                ID="lblInProgressCount"
                runat="server"
                CssClass="report-stat-value"
                Text="0">
            </asp:Label>

        </div>


        <div class="report-stat-card">

            <div class="report-stat-title">
                منتظر تأیید
            </div>

            <asp:Label
                ID="lblWaitingCount"
                runat="server"
                CssClass="report-stat-value"
                Text="0">
            </asp:Label>

        </div>


        <div class="report-stat-card">

            <div class="report-stat-title">
                خاتمه یافته
            </div>

            <asp:Label
                ID="lblClosedCount"
                runat="server"
                CssClass="report-stat-value"
                Text="0">
            </asp:Label>

        </div>


        <div class="report-stat-card">

            <div class="report-stat-title">
                برگشتی از کاربر
            </div>

            <asp:Label
                ID="lblRejectedCount"
                runat="server"
                CssClass="report-stat-value"
                Text="0">
            </asp:Label>

        </div>


    </div>


    <!-- =====================================================
         تب‌های گزارش
         ===================================================== -->

    <div class="report-tabs">


        <asp:LinkButton
            ID="btnRequesterTab"
            runat="server"
            CssClass="report-tab"
            CommandArgument="Requester"
            OnClick="ReportTab_Click">

            درخواست‌کنندگان

        </asp:LinkButton>


        <asp:LinkButton
            ID="btnDepartmentTab"
            runat="server"
            CssClass="report-tab"
            CommandArgument="Department"
            OnClick="ReportTab_Click">

            واحدها

        </asp:LinkButton>


        <asp:LinkButton
            ID="btnCategoryTab"
            runat="server"
            CssClass="report-tab"
            CommandArgument="Category"
            OnClick="ReportTab_Click">

            خدمات

        </asp:LinkButton>


        <asp:LinkButton
            ID="btnStatusTab"
            runat="server"
            CssClass="report-tab"
            CommandArgument="Status"
            OnClick="ReportTab_Click">

            وضعیت

        </asp:LinkButton>


        <asp:LinkButton
            ID="btnSpecialistTab"
            runat="server"
            CssClass="report-tab"
            CommandArgument="Specialist"
            OnClick="ReportTab_Click">

            عملکرد کارشناسان

        </asp:LinkButton>


        <asp:LinkButton
            ID="btnPriorityTab"
            runat="server"
            CssClass="report-tab"
            CommandArgument="Priority"
            OnClick="ReportTab_Click">

            اولویت‌ها

        </asp:LinkButton>


        <asp:LinkButton
            ID="btnTimingTab"
            runat="server"
            CssClass="report-tab"
            CommandArgument="Timing"
            OnClick="ReportTab_Click">

            زمان رسیدگی

        </asp:LinkButton>


        <asp:LinkButton
            ID="btnAgingTab"
            runat="server"
            CssClass="report-tab"
            CommandArgument="Aging"
            OnClick="ReportTab_Click">

            درخواست‌های باز

        </asp:LinkButton>


        <asp:LinkButton
            ID="btnReturnedTab"
            runat="server"
            CssClass="report-tab"
            CommandArgument="Returned"
            OnClick="ReportTab_Click">

            درخواست‌های برگشتی

        </asp:LinkButton>


        <asp:LinkButton
            ID="btnActionsTab"
            runat="server"
            CssClass="report-tab"
            CommandArgument="Actions"
            OnClick="ReportTab_Click">

            اقدامات کارشناسان

        </asp:LinkButton>


        <asp:LinkButton
            ID="btnTrendTab"
            runat="server"
            CssClass="report-tab"
            CommandArgument="Trend"
            OnClick="ReportTab_Click">

            روند درخواست‌ها

        </asp:LinkButton>


        <asp:LinkButton
            ID="btnUnassignedTab"
            runat="server"
            CssClass="report-tab"
            CommandArgument="Unassigned"
            OnClick="ReportTab_Click">

            بدون تخصیص

        </asp:LinkButton>


    </div>


    <!-- =====================================================
         گزارش درخواست‌کنندگان
         ===================================================== -->

    <asp:Panel
        ID="pnlRequester"
        runat="server"
        CssClass="report-section">

        <div class="report-section-header">

            <h2 class="report-section-title">
                گزارش بر اساس درخواست‌کننده
            </h2>

            <asp:Label
                ID="lblRequesterResultCount"
                runat="server"
                CssClass="report-result-count">
            </asp:Label>

        </div>


        <div class="report-search">

            <asp:TextBox
                ID="txtRequesterSearch"
                runat="server"
                placeholder="جستجوی نام درخواست‌کننده یا نام کاربری">
            </asp:TextBox>

            <asp:Button
                ID="btnRequesterSearch"
                runat="server"
                Text="جستجو"
                CssClass="report-search-button"
                OnClick="btnRequesterSearch_Click" />

            <asp:Button
                ID="btnRequesterClearSearch"
                runat="server"
                Text="پاک کردن"
                CssClass="report-clear-search-button"
                OnClick="btnRequesterClearSearch_Click" />

        </div>


        <div class="report-table-wrapper">

            <asp:GridView
                ID="gvRequesterReport"
                runat="server"
                AutoGenerateColumns="False"
                CssClass="report-grid"
                GridLines="None"
                AllowPaging="True"
                PageSize="10"
                OnPageIndexChanging="gvRequesterReport_PageIndexChanging"
                EmptyDataText="اطلاعاتی برای نمایش وجود ندارد">

                <Columns>

                    <asp:BoundField
                        DataField="RequesterName"
                        HeaderText="درخواست‌کننده" />

                    <asp:BoundField
                        DataField="UserName"
                        HeaderText="نام کاربری" />

                    <asp:BoundField
                        DataField="DepartmentName"
                        HeaderText="واحد سازمانی" />

                    <asp:BoundField
                        DataField="TotalCount"
                        HeaderText="کل"
                        ItemStyle-CssClass="numeric-column" />

                    <asp:BoundField
                        DataField="NewCount"
                        HeaderText="جدید"
                        ItemStyle-CssClass="numeric-column" />

                    <asp:BoundField
                        DataField="InProgressCount"
                        HeaderText="در حال انجام"
                        ItemStyle-CssClass="numeric-column" />

                    <asp:BoundField
                        DataField="WaitingCount"
                        HeaderText="منتظر تأیید"
                        ItemStyle-CssClass="numeric-column" />

                    <asp:BoundField
                        DataField="ClosedCount"
                        HeaderText="خاتمه یافته"
                        ItemStyle-CssClass="numeric-column" />

                    <asp:BoundField
                        DataField="RejectedCount"
                        HeaderText="برگشتی"
                        ItemStyle-CssClass="numeric-column" />

                </Columns>

            </asp:GridView>

        </div>

    </asp:Panel>


    <!-- =====================================================
         گزارش واحدها
         ===================================================== -->

    <asp:Panel
        ID="pnlDepartment"
        runat="server"
        CssClass="report-section">

        <div class="report-section-header">

            <h2 class="report-section-title">
                گزارش بر اساس واحد سازمانی
            </h2>

            <asp:Label
                ID="lblDepartmentResultCount"
                runat="server"
                CssClass="report-result-count">
            </asp:Label>

        </div>


        <div class="report-search">

            <asp:TextBox
                ID="txtDepartmentSearch"
                runat="server"
                placeholder="جستجوی نام واحد">
            </asp:TextBox>

            <asp:Button
                ID="btnDepartmentSearch"
                runat="server"
                Text="جستجو"
                CssClass="report-search-button"
                OnClick="btnDepartmentSearch_Click" />

            <asp:Button
                ID="btnDepartmentClearSearch"
                runat="server"
                Text="پاک کردن"
                CssClass="report-clear-search-button"
                OnClick="btnDepartmentClearSearch_Click" />

        </div>


        <div class="report-table-wrapper">

            <asp:GridView
                ID="gvDepartmentReport"
                runat="server"
                AutoGenerateColumns="False"
                CssClass="report-grid"
                GridLines="None"
                AllowPaging="True"
                PageSize="10"
                OnPageIndexChanging="gvDepartmentReport_PageIndexChanging"
                EmptyDataText="اطلاعاتی برای نمایش وجود ندارد">

                <Columns>

                    <asp:BoundField
                        DataField="DepartmentName"
                        HeaderText="واحد سازمانی" />

                    <asp:BoundField
                        DataField="Count"
                        HeaderText="تعداد درخواست"
                        ItemStyle-CssClass="numeric-column" />

                </Columns>

            </asp:GridView>

        </div>

    </asp:Panel>


    <!-- =====================================================
         گزارش دسته‌بندی
         ===================================================== -->

    <asp:Panel
        ID="pnlCategory"
        runat="server"
        CssClass="report-section">

        <div class="report-section-header">

            <h2 class="report-section-title">
                گزارش خدمات و دسته‌بندی
            </h2>

            <asp:Label
                ID="lblCategoryResultCount"
                runat="server"
                CssClass="report-result-count">
            </asp:Label>

        </div>


        <div class="report-search">

            <asp:TextBox
                ID="txtCategorySearch"
                runat="server"
                placeholder="جستجوی دسته‌بندی اولیه کاربر">
            </asp:TextBox>

            <asp:Button
                ID="btnCategorySearch"
                runat="server"
                Text="جستجو"
                CssClass="report-search-button"
                OnClick="btnCategorySearch_Click" />

            <asp:Button
                ID="btnCategoryClearSearch"
                runat="server"
                Text="پاک کردن"
                CssClass="report-clear-search-button"
                OnClick="btnCategoryClearSearch_Click" />

        </div>


        <div class="report-table-wrapper">

            <asp:GridView
                ID="gvCategoryReport"
                runat="server"
                AutoGenerateColumns="False"
                CssClass="report-grid"
                GridLines="None"
                AllowPaging="True"
                PageSize="10"
                OnPageIndexChanging="gvCategoryReport_PageIndexChanging"
                EmptyDataText="اطلاعاتی برای نمایش وجود ندارد">

                <Columns>

                    <asp:BoundField
                        DataField="Category"
                        HeaderText="دسته‌بندی" />

                    <asp:BoundField
                        DataField="Count"
                        HeaderText="تعداد"
                        ItemStyle-CssClass="numeric-column" />

                </Columns>

            </asp:GridView>

        </div>

        <div class="service-report-divider"></div>

        <div class="report-section-header service-subheader">

            <h3 class="report-subtitle">
                گزارش بر اساس حوزه خدمات
            </h3>

            <asp:Label
                ID="lblServiceCategoryResultCount"
                runat="server"
                CssClass="report-result-count">
            </asp:Label>

        </div>

        <div class="report-search">

            <asp:TextBox
                ID="txtServiceCategorySearch"
                runat="server"
                placeholder="جستجوی حوزه خدمت">
            </asp:TextBox>

            <asp:Button
                ID="btnServiceCategorySearch"
                runat="server"
                Text="جستجو"
                CssClass="report-search-button"
                OnClick="btnServiceCategorySearch_Click" />

            <asp:Button
                ID="btnServiceCategoryClearSearch"
                runat="server"
                Text="پاک کردن"
                CssClass="report-clear-search-button"
                OnClick="btnServiceCategoryClearSearch_Click" />

        </div>

        <div class="report-table-wrapper">

            <asp:GridView
                ID="gvServiceCategoryReport"
                runat="server"
                AutoGenerateColumns="False"
                CssClass="report-grid"
                GridLines="None"
                AllowPaging="True"
                PageSize="10"
                OnPageIndexChanging="gvServiceCategoryReport_PageIndexChanging"
                EmptyDataText="برای حوزه‌های خدمات اطلاعاتی ثبت نشده است">

                <Columns>

                    <asp:BoundField
                        DataField="ServiceCategoryName"
                        HeaderText="حوزه خدمت" />

                    <asp:BoundField
                        DataField="Count"
                        HeaderText="تعداد درخواست"
                        ItemStyle-CssClass="numeric-column" />

                </Columns>

            </asp:GridView>

        </div>

        <div class="service-report-divider"></div>

        <div class="report-section-header service-subheader">

            <h3 class="report-subtitle">
                گزارش بر اساس موضوع خدمت
            </h3>

            <asp:Label
                ID="lblServiceTopicResultCount"
                runat="server"
                CssClass="report-result-count">
            </asp:Label>

        </div>

        <div class="report-search">

            <asp:TextBox
                ID="txtServiceTopicSearch"
                runat="server"
                placeholder="جستجوی موضوع خدمت">
            </asp:TextBox>

            <asp:Button
                ID="btnServiceTopicSearch"
                runat="server"
                Text="جستجو"
                CssClass="report-search-button"
                OnClick="btnServiceTopicSearch_Click" />

            <asp:Button
                ID="btnServiceTopicClearSearch"
                runat="server"
                Text="پاک کردن"
                CssClass="report-clear-search-button"
                OnClick="btnServiceTopicClearSearch_Click" />

        </div>

        <div class="report-table-wrapper">

            <asp:GridView
                ID="gvServiceTopicReport"
                runat="server"
                AutoGenerateColumns="False"
                CssClass="report-grid"
                GridLines="None"
                AllowPaging="True"
                PageSize="10"
                OnPageIndexChanging="gvServiceTopicReport_PageIndexChanging"
                EmptyDataText="برای موضوعات خدمات اطلاعاتی ثبت نشده است">

                <Columns>

                    <asp:BoundField
                        DataField="ServiceCategoryName"
                        HeaderText="حوزه خدمت" />

                    <asp:BoundField
                        DataField="ServiceTopicName"
                        HeaderText="موضوع خدمت" />

                    <asp:BoundField
                        DataField="Count"
                        HeaderText="تعداد درخواست"
                        ItemStyle-CssClass="numeric-column" />

                </Columns>

            </asp:GridView>

        </div>

        <div class="service-mismatch-box">
            <div class="service-mismatch-title">
                موارد اصلاح دسته‌بندی توسط کارشناس
            </div>
            <asp:Label
                ID="lblServiceMismatchCount"
                runat="server"
                CssClass="service-mismatch-value"
                Text="0">
            </asp:Label>
            <span class="service-mismatch-text">
                درخواست که حوزه اولیه ثبت‌شده توسط کاربر با حوزه تشخیص‌داده‌شده توسط کارشناس متفاوت بوده است.
            </span>
        </div>

    </asp:Panel>



    <!-- =====================================================
         گزارش اولویت‌ها
         ===================================================== -->

    <asp:Panel
        ID="pnlPriority"
        runat="server"
        CssClass="report-section">

        <div class="report-section-header">
            <h2 class="report-section-title">گزارش بر اساس اولویت</h2>
            <asp:Label ID="lblPriorityResultCount" runat="server" CssClass="report-result-count" />
        </div>

        <div class="advanced-report-note">
            توزیع درخواست‌های فیلترشده بر اساس اولویت ثبت‌شده در درخواست.
        </div>

        <div class="report-table-wrapper">
            <asp:GridView
                ID="gvPriorityReport"
                runat="server"
                AutoGenerateColumns="False"
                CssClass="report-grid"
                GridLines="None"
                EmptyDataText="اطلاعاتی برای نمایش وجود ندارد">
                <Columns>
                    <asp:BoundField DataField="Priority" HeaderText="اولویت" />
                    <asp:BoundField DataField="Count" HeaderText="تعداد درخواست" ItemStyle-CssClass="numeric-column" />
                    <asp:BoundField DataField="Percent" HeaderText="سهم از کل" ItemStyle-CssClass="numeric-column" />
                </Columns>
            </asp:GridView>
        </div>

    </asp:Panel>


    <!-- =====================================================
         گزارش زمان رسیدگی
         ===================================================== -->

    <asp:Panel
        ID="pnlTiming"
        runat="server"
        CssClass="report-section">

        <div class="report-section-header">
            <h2 class="report-section-title">گزارش زمان رسیدگی و حل درخواست‌ها</h2>
            <asp:Label ID="lblTimingResultCount" runat="server" CssClass="report-result-count" />
        </div>

        <div class="advanced-report-note">
            زمان‌ها بر اساس اطلاعات واقعی ثبت‌شده در درخواست محاسبه می‌شوند؛ «زمان حل» از ثبت درخواست تا ResolvedAt و «زمان خاتمه» از ثبت درخواست تا ClosedAt است.
        </div>

        <div class="advanced-report-metrics">
            <div class="advanced-report-metric">
                <div class="advanced-report-metric-title">میانگین زمان تا تخصیص</div>
                <asp:Label ID="lblAvgAssignmentHours" runat="server" CssClass="advanced-report-metric-value" Text="-" />
            </div>
            <div class="advanced-report-metric">
                <div class="advanced-report-metric-title">میانگین زمان تا حل</div>
                <asp:Label ID="lblAvgResolutionHours" runat="server" CssClass="advanced-report-metric-value" Text="-" />
            </div>
            <div class="advanced-report-metric">
                <div class="advanced-report-metric-title">میانگین زمان تا خاتمه</div>
                <asp:Label ID="lblAvgClosureHours" runat="server" CssClass="advanced-report-metric-value" Text="-" />
            </div>
            <div class="advanced-report-metric">
                <div class="advanced-report-metric-title">طولانی‌ترین زمان حل</div>
                <asp:Label ID="lblMaxResolutionHours" runat="server" CssClass="advanced-report-metric-value" Text="-" />
            </div>
        </div>

        <div class="report-table-wrapper">
            <asp:GridView
                ID="gvTimingReport"
                runat="server"
                AutoGenerateColumns="False"
                CssClass="report-grid"
                GridLines="None"
                EmptyDataText="اطلاعات زمانی کافی برای نمایش وجود ندارد">
                <Columns>
                    <asp:BoundField DataField="Metric" HeaderText="شاخص" />
                    <asp:BoundField DataField="Value" HeaderText="مقدار" />
                    <asp:BoundField DataField="Count" HeaderText="تعداد رکورد قابل محاسبه" ItemStyle-CssClass="numeric-column" />
                </Columns>
            </asp:GridView>
        </div>

    </asp:Panel>


    <!-- =====================================================
         گزارش درخواست‌های باز و قدیمی
         ===================================================== -->

    <asp:Panel
        ID="pnlAging"
        runat="server"
        CssClass="report-section">

        <div class="report-section-header">
            <h2 class="report-section-title">گزارش درخواست‌های باز و قدیمی</h2>
            <asp:Label ID="lblAgingResultCount" runat="server" CssClass="report-result-count" />
        </div>

        <div class="advanced-report-note">
            این گزارش فقط درخواست‌های خاتمه‌نیافته را بررسی می‌کند و آنها را بر اساس مدت زمان سپری‌شده از ثبت درخواست دسته‌بندی می‌کند؛ این دسته‌بندی به معنی SLA رسمی نیست.
        </div>

        <div class="report-table-wrapper">
            <asp:GridView
                ID="gvAgingReport"
                runat="server"
                AutoGenerateColumns="False"
                CssClass="report-grid"
                GridLines="None"
                EmptyDataText="درخواست باز وجود ندارد">
                <Columns>
                    <asp:BoundField DataField="Bucket" HeaderText="بازه سنی درخواست" />
                    <asp:BoundField DataField="Count" HeaderText="تعداد" ItemStyle-CssClass="numeric-column" />
                    <asp:BoundField DataField="OldestDate" HeaderText="قدیمی‌ترین تاریخ ثبت" />
                </Columns>
            </asp:GridView>
        </div>

    </asp:Panel>


    <!-- =====================================================
         گزارش درخواست‌های برگشتی
         ===================================================== -->

    <asp:Panel
        ID="pnlReturned"
        runat="server"
        CssClass="report-section">

        <div class="report-section-header">
            <h2 class="report-section-title">گزارش درخواست‌های برگشتی</h2>
            <asp:Label ID="lblReturnedResultCount" runat="server" CssClass="report-result-count" />
        </div>

        <div class="advanced-report-note">
            برگشت در این گزارش بر اساس سابقه تغییر وضعیت از «ارجاع شده» یا «در حال انجام» به «جدید» شناسایی می‌شود؛ یعنی درخواست برای بررسی مجدد به کارتابل مدیریت برگشته است.
        </div>

        <div class="report-table-wrapper">
            <asp:GridView
                ID="gvReturnedReport"
                runat="server"
                AutoGenerateColumns="False"
                CssClass="report-grid"
                GridLines="None"
                EmptyDataText="درخواست برگشتی ثبت نشده است">
                <Columns>
                    <asp:BoundField DataField="Type" HeaderText="شاخص" />
                    <asp:BoundField DataField="Count" HeaderText="تعداد" ItemStyle-CssClass="numeric-column" />
                    <asp:BoundField DataField="LastDate" HeaderText="آخرین مورد" />
                </Columns>
            </asp:GridView>
        </div>

    </asp:Panel>


    <!-- =====================================================
         گزارش اقدامات کارشناسان
         ===================================================== -->

    <asp:Panel
        ID="pnlActions"
        runat="server"
        CssClass="report-section">

        <div class="report-section-header">
            <h2 class="report-section-title">گزارش اقدامات انجام‌شده توسط کارشناسان</h2>
            <asp:Label ID="lblActionsResultCount" runat="server" CssClass="report-result-count" />
        </div>

        <div class="advanced-report-note">
            تعداد اقدامات ثبت‌شده و تعداد درخواست‌هایی که هر کارشناس روی آنها اقدام ثبت کرده است، بر اساس بازه و فیلترهای انتخاب‌شده نمایش داده می‌شود.
        </div>

        <div class="report-table-wrapper">
            <asp:GridView
                ID="gvActionsReport"
                runat="server"
                AutoGenerateColumns="False"
                CssClass="report-grid"
                GridLines="None"
                AllowPaging="True"
                PageSize="10"
                OnPageIndexChanging="gvActionsReport_PageIndexChanging"
                EmptyDataText="اقدامی برای نمایش وجود ندارد">
                <Columns>
                    <asp:BoundField DataField="SpecialistName" HeaderText="کارشناس" />
                    <asp:BoundField DataField="TicketCount" HeaderText="تعداد درخواست" ItemStyle-CssClass="numeric-column" />
                    <asp:BoundField DataField="ActionCount" HeaderText="تعداد اقدامات" ItemStyle-CssClass="numeric-column" />
                    <asp:BoundField DataField="AverageActions" HeaderText="میانگین اقدام به ازای درخواست" ItemStyle-CssClass="numeric-column" />
                    <asp:BoundField DataField="LastActionDate" HeaderText="آخرین اقدام" />
                </Columns>
            </asp:GridView>
        </div>

    </asp:Panel>


    <!-- =====================================================
         گزارش روند درخواست‌ها
         ===================================================== -->

    <asp:Panel
        ID="pnlTrend"
        runat="server"
        CssClass="report-section">

        <div class="report-section-header">
            <h2 class="report-section-title">گزارش روند ثبت درخواست‌ها</h2>
            <asp:Label ID="lblTrendResultCount" runat="server" CssClass="report-result-count" />
        </div>

        <div class="advanced-report-note">
            روند ماهانه درخواست‌های ثبت‌شده در بازه انتخاب‌شده، به همراه تعداد خاتمه‌یافته و در انتظار تأیید کاربر.
        </div>

        <div class="report-table-wrapper">
            <asp:GridView
                ID="gvTrendReport"
                runat="server"
                AutoGenerateColumns="False"
                CssClass="report-grid"
                GridLines="None"
                EmptyDataText="اطلاعاتی برای نمایش روند وجود ندارد">
                <Columns>
                    <asp:BoundField DataField="Month" HeaderText="ماه" />
                    <asp:BoundField DataField="TotalCount" HeaderText="کل ثبت‌شده" ItemStyle-CssClass="numeric-column" />
                    <asp:BoundField DataField="ClosedCount" HeaderText="خاتمه‌یافته" ItemStyle-CssClass="numeric-column" />
                    <asp:BoundField DataField="WaitingCount" HeaderText="منتظر تأیید" ItemStyle-CssClass="numeric-column" />
                    <asp:BoundField DataField="NewCount" HeaderText="هنوز جدید" ItemStyle-CssClass="numeric-column" />
                </Columns>
            </asp:GridView>
        </div>

    </asp:Panel>


    <!-- =====================================================
         گزارش درخواست‌های بدون تخصیص
         ===================================================== -->

    <asp:Panel
        ID="pnlUnassigned"
        runat="server"
        CssClass="report-section">

        <div class="report-section-header">
            <h2 class="report-section-title">گزارش درخواست‌های بدون تخصیص</h2>
            <asp:Label ID="lblUnassignedResultCount" runat="server" CssClass="report-result-count" />
        </div>

        <div class="advanced-report-note">
            درخواست‌های جدیدی که در بازه و فیلترهای انتخاب‌شده هنوز به کارشناس تخصیص داده نشده‌اند.
        </div>

        <div class="report-table-wrapper">
            <asp:GridView
                ID="gvUnassignedReport"
                runat="server"
                AutoGenerateColumns="False"
                CssClass="report-grid"
                GridLines="None"
                EmptyDataText="درخواست بدون تخصیص وجود ندارد">
                <Columns>
                    <asp:BoundField DataField="DepartmentName" HeaderText="واحد" />
                    <asp:BoundField DataField="Count" HeaderText="تعداد" ItemStyle-CssClass="numeric-column" />
                    <asp:BoundField DataField="OldestDate" HeaderText="قدیمی‌ترین تاریخ" />
                </Columns>
            </asp:GridView>
        </div>

    </asp:Panel>


    <!-- =====================================================
         گزارش وضعیت
         ===================================================== -->

    <asp:Panel
        ID="pnlStatus"
        runat="server"
        CssClass="report-section">

        <div class="report-section-header">

            <h2 class="report-section-title">
                گزارش بر اساس وضعیت
            </h2>

            <asp:Label
                ID="lblStatusResultCount"
                runat="server"
                CssClass="report-result-count">
            </asp:Label>

        </div>


        <div class="report-search">

            <asp:TextBox
                ID="txtStatusSearch"
                runat="server"
                placeholder="جستجوی وضعیت">
            </asp:TextBox>

            <asp:Button
                ID="btnStatusSearch"
                runat="server"
                Text="جستجو"
                CssClass="report-search-button"
                OnClick="btnStatusSearch_Click" />

            <asp:Button
                ID="btnStatusClearSearch"
                runat="server"
                Text="پاک کردن"
                CssClass="report-clear-search-button"
                OnClick="btnStatusClearSearch_Click" />

        </div>


        <div class="report-table-wrapper">

            <asp:GridView
                ID="gvStatusReport"
                runat="server"
                AutoGenerateColumns="False"
                CssClass="report-grid"
                GridLines="None"
                AllowPaging="True"
                PageSize="10"
                OnPageIndexChanging="gvStatusReport_PageIndexChanging"
                EmptyDataText="اطلاعاتی برای نمایش وجود ندارد">

                <Columns>

                    <asp:BoundField
                        DataField="Status"
                        HeaderText="وضعیت" />

                    <asp:BoundField
                        DataField="Count"
                        HeaderText="تعداد"
                        ItemStyle-CssClass="numeric-column" />

                </Columns>

            </asp:GridView>

        </div>

    </asp:Panel>


    <!-- =====================================================
         عملکرد کارشناسان
         ===================================================== -->

    <asp:Panel
        ID="pnlSpecialist"
        runat="server"
        CssClass="report-section">

        <div class="report-section-header">

            <h2 class="report-section-title">
                عملکرد کارشناسان
            </h2>

            <asp:Label
                ID="lblSpecialistResultCount"
                runat="server"
                CssClass="report-result-count">
            </asp:Label>

        </div>


        <div class="report-search">

            <asp:TextBox
                ID="txtSpecialistSearch"
                runat="server"
                placeholder="جستجوی نام کارشناس">
            </asp:TextBox>

            <asp:Button
                ID="btnSpecialistSearch"
                runat="server"
                Text="جستجو"
                CssClass="report-search-button"
                OnClick="btnSpecialistSearch_Click" />

            <asp:Button
                ID="btnSpecialistClearSearch"
                runat="server"
                Text="پاک کردن"
                CssClass="report-clear-search-button"
                OnClick="btnSpecialistClearSearch_Click" />

        </div>


        <div class="report-table-wrapper">

            <asp:GridView
                ID="gvSpecialistReport"
                runat="server"
                AutoGenerateColumns="False"
                CssClass="report-grid"
                GridLines="None"
                AllowPaging="True"
                PageSize="10"
                OnPageIndexChanging="gvSpecialistReport_PageIndexChanging"
                EmptyDataText="اطلاعاتی برای نمایش وجود ندارد">

                <Columns>

                    <asp:BoundField
                        DataField="SpecialistName"
                        HeaderText="کارشناس" />

                    <asp:BoundField
                        DataField="AssignedCount"
                        HeaderText="ارجاع شده"
                        ItemStyle-CssClass="numeric-column" />

                    <asp:BoundField
                        DataField="InProgressCount"
                        HeaderText="در حال انجام"
                        ItemStyle-CssClass="numeric-column" />

                    <asp:BoundField
                        DataField="WaitingCount"
                        HeaderText="منتظر تأیید"
                        ItemStyle-CssClass="numeric-column" />

                    <asp:BoundField
                        DataField="ClosedCount"
                        HeaderText="خاتمه یافته"
                        ItemStyle-CssClass="numeric-column" />

                </Columns>

            </asp:GridView>

        </div>

    </asp:Panel>


</div>

</asp:Content>