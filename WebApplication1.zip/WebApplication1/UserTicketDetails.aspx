﻿<%@ Page Title="جزئیات درخواست" Language="C#" MasterPageFile="~/Site.Master"
    AutoEventWireup="true" CodeBehind="UserTicketDetails.aspx.cs"
    Inherits="WebApplication1.UserTicketDetails" %>

<asp:Content ID="Content1" ContentPlaceHolderID="MainContent" runat="server">

    <style>
        .page-container {
            direction: rtl;
            padding: 25px;
        }

        .page-title {
            font-size: 25px;
            font-weight: bold;
            color: #263238;
            margin-bottom: 20px;
        }

        .ticket-box {
            background: #fff;
            border-radius: 10px;
            padding: 22px;
            margin-bottom: 20px;
            box-shadow: 0 2px 8px rgba(0,0,0,.08);
        }

        .section-title {
            font-size: 19px;
            font-weight: bold;
            color: #37474f;
            margin-bottom: 18px;
            padding-bottom: 10px;
            border-bottom: 1px solid #eee;
        }

        .info-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 15px;
        }

        .info-item {
            background: #f8f9fa;
            padding: 12px 15px;
            border-radius: 6px;
        }

        .info-label {
            display: block;
            color: #777;
            font-size: 13px;
            margin-bottom: 5px;
        }

        .info-value {
            font-weight: bold;
            color: #263238;
        }

        .description-box {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 6px;
            line-height: 2;
            white-space: pre-wrap;
        }

        .confirmation-box {
            background: #fffde7;
            border: 1px solid #f0d879;
            border-radius: 8px;
            padding: 20px;
        }

        .confirmation-text {
            line-height: 2;
            margin-bottom: 15px;
        }

        .form-control {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            box-sizing: border-box;
            font-family: inherit;
        }

        .action-button {
            border: none;
            padding: 10px 22px;
            border-radius: 5px;
            cursor: pointer;
            color: white;
            font-family: inherit;
            margin-left: 8px;
        }

        .btn-confirm {
            background: #388e3c;
        }

        .btn-confirm:hover {
            background: #2e7d32;
        }

        .btn-reject {
            background: #d32f2f;
        }

        .btn-reject:hover {
            background: #b71c1c;
        }

        .btn-back {
            background: #78909c;
            color: white;
            text-decoration: none;
            padding: 9px 18px;
            border-radius: 5px;
            display: inline-block;
        }

        .message {
            display: block;
            margin-top: 15px;
            padding: 10px;
            border-radius: 5px;
        }

        .actions-grid,
        .history-grid {
            width: 100%;
            border-collapse: collapse;
        }

        .actions-grid th,
        .history-grid th {
            background: #f5f7f8;
            padding: 11px;
            text-align: right;
            border-bottom: 1px solid #ddd;
        }

        .actions-grid td,
        .history-grid td {
            padding: 11px;
            border-bottom: 1px solid #eee;
            vertical-align: top;
        }

        .empty-message {
            text-align: center;
            color: #888;
            padding: 25px;
        }

        @media (max-width: 700px) {
            .info-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>

    <div class="page-container">

        <div class="page-title">
            جزئیات درخواست
        </div>

        <!-- اطلاعات درخواست -->
        <div class="ticket-box">

            <div class="section-title">
                اطلاعات درخواست
            </div>

            <div class="info-grid">

                <div class="info-item">
                    <span class="info-label">شماره درخواست</span>
                    <asp:Label ID="lblTicketId"
                        runat="server"
                        CssClass="info-value"></asp:Label>
                </div>

                <div class="info-item">
                    <span class="info-label">وضعیت</span>
                    <asp:Label ID="lblStatus"
                        runat="server"
                        CssClass="info-value"></asp:Label>
                </div>

                <div class="info-item">
                    <span class="info-label">موضوع</span>
                    <asp:Label ID="lblSubject"
                        runat="server"
                        CssClass="info-value"></asp:Label>
                </div>

                <div class="info-item">
                    <span class="info-label">دسته‌بندی</span>
                    <asp:Label ID="lblCategory"
                        runat="server"
                        CssClass="info-value"></asp:Label>
                </div>

                <div class="info-item">
                    <span class="info-label">اولویت</span>
                    <asp:Label ID="lblPriority"
                        runat="server"
                        CssClass="info-value"></asp:Label>
                </div>

                <div class="info-item">
                    <span class="info-label">تاریخ ثبت</span>
                    <asp:Label ID="lblCreatedAt"
                        runat="server"
                        CssClass="info-value"></asp:Label>
                </div>

            </div>

            <br />

            <div class="info-label">
                شرح درخواست
            </div>

            <div class="description-box">
                <asp:Label ID="lblDescription"
                    runat="server"></asp:Label>
            </div>

        </div>

        <!-- اقدامات متخصص -->
        <div class="ticket-box">

            <div class="section-title">
                اقدامات انجام‌شده توسط متخصص
            </div>

            <asp:GridView ID="gvActions"
                runat="server"
                AutoGenerateColumns="False"
                CssClass="actions-grid"
                GridLines="None"
                EmptyDataText="هنوز اقدامی ثبت نشده است">

                <Columns>

                    <asp:BoundField
                        DataField="ActionDate"
                        HeaderText="تاریخ" />

                    <asp:BoundField
                        DataField="UserName"
                        HeaderText="متخصص" />

                    <asp:BoundField
                        DataField="ActionText"
                        HeaderText="شرح اقدام" />

                </Columns>

                <EmptyDataRowStyle CssClass="empty-message" />

            </asp:GridView>

        </div>

        <!-- تأیید کاربر -->
        <asp:Panel ID="pnlConfirmation"
            runat="server"
            Visible="false">

            <div class="ticket-box">

                <div class="section-title">
                    تأیید انجام درخواست
                </div>

                <div class="confirmation-box">

                    <div class="confirmation-text">
                        متخصص اعلام کرده است که رسیدگی به این درخواست انجام شده است.
                        لطفاً نتیجه را بررسی کنید.
                        در صورت رفع مشکل، درخواست را تأیید کنید.
                        در غیر این صورت می‌توانید عدم رفع مشکل را اعلام کنید.
                    </div>

                    <div style="margin-bottom:10px;">
                        <label>
                            توضیحات (اختیاری)
                        </label>
                    </div>

                    <asp:TextBox ID="txtConfirmationComment"
                        runat="server"
                        CssClass="form-control"
                        TextMode="MultiLine"
                        Rows="4"
                        placeholder="در صورت نیاز توضیحات خود را وارد کنید...">
                    </asp:TextBox>

                    <br />

                    <asp:Button ID="btnConfirm"
                        runat="server"
                        Text="تأیید انجام درخواست"
                        CssClass="action-button btn-confirm"
                        OnClick="btnConfirm_Click"
                        OnClientClick="return confirm('آیا از تأیید انجام درخواست مطمئن هستید؟');" />

                    <asp:Button ID="btnReject"
                        runat="server"
                        Text="مشکل هنوز رفع نشده است"
                        CssClass="action-button btn-reject"
                        OnClick="btnReject_Click"
                        OnClientClick="return confirm('آیا مطمئن هستید که مشکل هنوز رفع نشده است؟');" />

                </div>

            </div>

        </asp:Panel>

        <!-- تاریخچه -->
        <div class="ticket-box">

            <div class="section-title">
                تاریخچه درخواست
            </div>

            <asp:GridView ID="gvHistory"
                runat="server"
                AutoGenerateColumns="False"
                CssClass="history-grid"
                GridLines="None"
                EmptyDataText="تاریخچه‌ای ثبت نشده است">

                <Columns>

                    <asp:BoundField
                        DataField="HistoryDate"
                        HeaderText="تاریخ" />

                    <asp:BoundField
                        DataField="UserName"
                        HeaderText="کاربر" />

                    <asp:BoundField
                        DataField="OldStatus"
                        HeaderText="وضعیت قبلی" />

                    <asp:BoundField
                        DataField="NewStatus"
                        HeaderText="وضعیت جدید" />

                    <asp:BoundField
                        DataField="Description"
                        HeaderText="توضیحات" />

                </Columns>

                <EmptyDataRowStyle CssClass="empty-message" />

            </asp:GridView>

        </div>

        <asp:Label ID="lblMessage"
            runat="server"
            Visible="false"
            CssClass="message">
        </asp:Label>

        <br />

        <asp:HyperLink ID="lnkBack"
            runat="server"
            NavigateUrl="~/UserDashboard.aspx"
            CssClass="btn-back">
            بازگشت به درخواست‌های من
        </asp:HyperLink>

    </div>

</asp:Content>