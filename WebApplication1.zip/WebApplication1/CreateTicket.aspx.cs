﻿using System;
using System.Linq;
using System.Web.UI;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;
using WebApplication1.Models;

namespace WebApplication1
{
    public partial class CreateTicket : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Request.IsAuthenticated)
            {
                Response.Redirect("~/Login.aspx");
                return;
            }

            if (!IsPostBack)
            {
                LoadPage();
            }
        }


        private void LoadPage()
        {
            string userId = User.Identity.GetUserId();

            using (var db = new ApplicationDbContext())
            {
                var userManager =
                    new UserManager<ApplicationUser>(
                        new UserStore<ApplicationUser>(db));

                bool isManager =
                    userManager.IsInRole(userId, "Manager");

                if (isManager)
                {
                    pnlManagerRequester.Visible = true;

                    LoadRequesters();

                    lnkBack.NavigateUrl =
                        "~/ManagerDashboard.aspx";

                    lnkCancel.NavigateUrl =
                        "~/ManagerDashboard.aspx";
                }
                else if (userManager.IsInRole(userId, "Specialist"))
                {
                    pnlManagerRequester.Visible = false;

                    lnkBack.NavigateUrl =
                        "~/SpecialistDashboard.aspx";

                    lnkCancel.NavigateUrl =
                        "~/SpecialistDashboard.aspx";
                }
                else
                {
                    pnlManagerRequester.Visible = false;

                    lnkBack.NavigateUrl =
                        "~/UserDashboard.aspx";

                    lnkCancel.NavigateUrl =
                        "~/UserDashboard.aspx";
                }
            }

            lblMessage.Visible = false;
            lblMessage.Text = "";

            pnlSuccessMessage.Visible = false;

            lblTicketNumber.InnerText = "";
            lblPendingCount.InnerText = "";
        }


        private void LoadRequesters()
        {
            using (var db = new ApplicationDbContext())
            {
                var requesters =
                    (from u in db.Users
                     join p in db.UserProfiles
                     on u.Id equals p.UserId into profiles
                     from p in profiles.DefaultIfEmpty()
                     orderby p.FullName
                     select new
                     {
                         UserId = u.Id,
                         UserName = u.UserName,
                         FullName = p != null ? p.FullName : ""
                     })
                    .ToList()
                    .Select(x => new
                    {
                        x.UserId,
                        x.UserName,
                        DisplayName =
                            !string.IsNullOrEmpty(x.FullName)
                                ? x.FullName
                                : x.UserName
                    })
                    .ToList();

                rptRequesters.DataSource = requesters;
                rptRequesters.DataBind();
            }
        }


        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            lblMessage.Visible = false;
            lblMessage.Text = "";

            pnlSuccessMessage.Visible = false;

            string currentUserId =
                User.Identity.GetUserId();

            if (string.IsNullOrEmpty(currentUserId))
            {
                ShowError("کاربر جاری شناسایی نشد.");
                return;
            }


            // عنوان
            if (string.IsNullOrWhiteSpace(txtSubject.Text))
            {
                ShowError(
                    "لطفاً عنوان درخواست را وارد کنید.");

                return;
            }


            // دسته‌بندی
            if (string.IsNullOrEmpty(
                ddlCategory.SelectedValue))
            {
                ShowError(
                    "لطفاً دسته‌بندی درخواست را انتخاب کنید.");

                return;
            }


            // اولویت
            if (string.IsNullOrEmpty(
                ddlPriority.SelectedValue))
            {
                ShowError(
                    "لطفاً اولویت درخواست را انتخاب کنید.");

                return;
            }


            // شرح
            if (string.IsNullOrWhiteSpace(
                txtDescription.Text))
            {
                ShowError(
                    "لطفاً شرح درخواست را وارد کنید.");

                return;
            }


            using (var db =
                new ApplicationDbContext())
            {
                var userManager =
                    new UserManager<ApplicationUser>(
                        new UserStore<ApplicationUser>(db));


                bool isManager =
                    userManager.IsInRole(
                        currentUserId,
                        "Manager");


                bool isSpecialist =
                    userManager.IsInRole(
                        currentUserId,
                        "Specialist");


                string requesterId =
                    currentUserId;


                // =====================================================
                // مدیر می‌تواند به نمایندگی از کاربر درخواست ثبت کند
                // =====================================================

                if (isManager)
                {
                    if (string.IsNullOrEmpty(
                        hfRequesterId.Value))
                    {
                        ShowError(
                            "لطفاً درخواست‌کننده را انتخاب کنید.");

                        return;
                    }


                    requesterId =
                        hfRequesterId.Value;


                    var requester =
                        userManager.FindById(
                            requesterId);


                    if (requester == null)
                    {
                        ShowError(
                            "کاربر انتخاب‌شده معتبر نیست.");

                        return;
                    }
                }


                // =====================================================
                // ایجاد درخواست
                // =====================================================

                var ticket =
                    new Ticket
                    {
                        UserId =
                            requesterId,

                        Subject =
                            txtSubject.Text.Trim(),

                        Description =
                            txtDescription.Text.Trim(),

                        Category =
                            ddlCategory.SelectedValue,

                        Priority =
                            ddlPriority.SelectedValue,

                        Status =
                            "New",

                        AssignedTo =
                            null,

                        DepartmentId =
                            null,

                        CreatedAt =
                            DateTime.Now,

                        AssignedAt =
                            null,

                        ResolvedAt =
                            null,

                        ClosedAt =
                            null,

                        UserConfirmed =
                            false,

                        ManagerViewed =
                            false,

                        ManagerViewedAt =
                            null,

                        AutoClosed =
                            false,

                        ConfirmationRequestedAt =
                            null
                    };


                // =====================================================
                // تعیین واحد سازمانی درخواست
                // =====================================================

                var profile =
                    db.UserProfiles.FirstOrDefault(
                        p =>
                            p.UserId ==
                            requesterId);


                if (profile != null)
                {
                    ticket.DepartmentId =
                        profile.DepartmentId;
                }


                db.Tickets.Add(ticket);

                db.SaveChanges();


                // =====================================================
                // ثبت تاریخچه
                // =====================================================

                string historyDescription;


                if (isManager)
                {
                    historyDescription =
                        "درخواست توسط مدیر سامانه به نمایندگی از کاربر ثبت شد.";
                }
                else if (isSpecialist)
                {
                    historyDescription =
                        "درخواست توسط کارشناس فناوری اطلاعات ثبت شد.";
                }
                else
                {
                    historyDescription =
                        "درخواست توسط کاربر ثبت شد.";
                }


                var history =
                    new TicketHistory
                    {
                        TicketId =
                            ticket.TicketId,

                        UserId =
                            currentUserId,

                        OldStatus =
                            null,

                        NewStatus =
                            "New",

                        Description =
                            historyDescription,

                        HistoryDate =
                            DateTime.Now
                    };


                db.TicketHistory.Add(history);

                db.SaveChanges();


                // =====================================================
                // شمارش درخواست‌های در صف بررسی
                // =====================================================
                //
                // درخواست‌هایی که وضعیت آنها New است
                // و هنوز به کارشناس تخصیص داده نشده‌اند.
                //
                // درخواست تازه ثبت‌شده نیز در این عدد لحاظ می‌شود.
                // =====================================================

                int pendingCount =
                    db.Tickets.Count(
                        t =>
                            t.Status == "New" &&
                            t.AssignedTo == null);


                // =====================================================
                // نمایش نتیجه موفقیت
                // =====================================================

                lblTicketNumber.InnerText =
                    ticket.TicketId.ToString();


                if (pendingCount == 0)
                {
                    lblPendingCount.InnerText =
                        "بدون درخواست در انتظار";
                }
                else
                {
                    lblPendingCount.InnerText =
                        pendingCount.ToString() +
                        " درخواست";
                }


                pnlSuccessMessage.Visible =
                    true;


                // پیام قدیمی مخفی باشد
                lblMessage.Visible =
                    false;


                // پاک کردن اطلاعات فرم
                ClearForm();
            }
        }


        // =============================================================
        // پاک کردن فرم بعد از ثبت موفق
        // =============================================================

        private void ClearForm()
        {
            txtSubject.Text = "";

            txtDescription.Text = "";

            ddlCategory.SelectedIndex = 0;

            ddlPriority.SelectedValue = "Normal";


            // فقط برای مدیر
            hfRequesterId.Value = "";

            txtRequesterSearch.Text = "";


            // مخفی کردن درخواست‌کننده انتخاب‌شده
            ClientScript.RegisterStartupScript(
                GetType(),
                "ClearRequester",
                "if(document.getElementById('selectedRequester'))" +
                "{document.getElementById('selectedRequester').style.display='none';}" +
                "if(document.getElementById('requesterSearchResults'))" +
                "{document.getElementById('requesterSearchResults').style.display='none';}",
                true);
        }


        // =============================================================
        // نمایش خطا
        // =============================================================

        private void ShowError(string message)
        {
            pnlSuccessMessage.Visible =
                false;


            lblMessage.Text =
                message;


            lblMessage.CssClass =
                "form-message message-error";


            lblMessage.Visible =
                true;
        }


        // =============================================================
        // نمایش پیام موفقیت قدیمی
        // در حال حاضر کارت موفقیت استفاده می‌شود.
        // =============================================================

        private void ShowSuccess(string message)
        {
            lblMessage.Text =
                message;


            lblMessage.CssClass =
                "form-message message-success";


            lblMessage.Visible =
                true;
        }
    }
}