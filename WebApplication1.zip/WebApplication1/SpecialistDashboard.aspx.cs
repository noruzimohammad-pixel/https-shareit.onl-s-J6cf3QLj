﻿using System;
using System.Linq;
using System.Web.UI;
using System.Web.UI.WebControls;
using Microsoft.AspNet.Identity;
using WebApplication1.Models;

namespace WebApplication1
{
    public partial class SpecialistDashboard : System.Web.UI.Page
    {
        private string SelectedStatus
        {
            get
            {
                if (ViewState["SelectedStatus"] == null)
                    return "All";

                return ViewState["SelectedStatus"].ToString();
            }

            set
            {
                ViewState["SelectedStatus"] = value;
            }
        }


        protected void Page_Load(
            object sender,
            EventArgs e)
        {
            if (!Request.IsAuthenticated)
            {
                Response.Redirect("~/Login.aspx");
                return;
            }


            if (!User.IsInRole("Specialist"))
            {
                Response.Redirect("~/Login.aspx");
                return;
            }


            if (!IsPostBack)
            {
                string status =
                    Request.QueryString["status"];


                if (string.IsNullOrEmpty(status))
                {
                    status = "All";
                }


                if (!IsValidStatus(status))
                {
                    status = "All";
                }


                SelectedStatus = status;


                LoadDashboard();
            }
        }


        private bool IsValidStatus(
            string status)
        {
            return
                status == "All" ||
                status == "Assigned" ||
                status == "InProgress" ||
                status == "WaitingConfirmation" ||
                status == "Closed";
        }


        private void LoadDashboard()
        {
            string currentUserId =
                User.Identity.GetUserId();


            using (var db =
                new ApplicationDbContext())
            {
                /*
                 * =====================================
                 * تعداد درخواست‌ها
                 * =====================================
                 */

                int allCount =
                    db.Tickets.Count(t =>
                        t.AssignedTo ==
                        currentUserId);


                int assignedCount =
                    db.Tickets.Count(t =>
                        t.AssignedTo ==
                        currentUserId &&
                        t.Status ==
                        "Assigned");


                int inProgressCount =
                    db.Tickets.Count(t =>
                        t.AssignedTo ==
                        currentUserId &&
                        t.Status ==
                        "InProgress");


                int waitingCount =
                    db.Tickets.Count(t =>
                        t.AssignedTo ==
                        currentUserId &&
                        t.Status ==
                        "WaitingConfirmation");


                int closedCount =
                    db.Tickets.Count(t =>
                        t.AssignedTo ==
                        currentUserId &&
                        t.Status ==
                        "Closed");


                /*
                 * =====================================
                 * نمایش تعداد روی دکمه‌ها
                 * =====================================
                 */

                btnAll.Text =
                    "همه درخواست‌ها (" +
                    allCount +
                    ")";


                btnAssigned.Text =
                    "ارجاع شده (" +
                    assignedCount +
                    ")";


                btnInProgress.Text =
                    "در حال رسیدگی (" +
                    inProgressCount +
                    ")";


                btnWaiting.Text =
                    "منتظر تأیید کاربر (" +
                    waitingCount +
                    ")";


                btnClosed.Text =
                    "خاتمه یافته (" +
                    closedCount +
                    ")";


                /*
                 * =====================================
                 * دریافت درخواست‌های متخصص
                 * =====================================
                 */

                var query =
                    db.Tickets
                    .Where(t =>
                        t.AssignedTo ==
                        currentUserId);


                /*
                 * =====================================
                 * اعمال فیلتر
                 * =====================================
                 */

                if (SelectedStatus != "All")
                {
                    string selectedStatus =
                        SelectedStatus;


                    query =
                        query.Where(t =>
                            t.Status ==
                            selectedStatus);
                }


                /*
                 * =====================================
                 * مرتب‌سازی
                 * =====================================
                 */

                var tickets =
                    query
                    .OrderByDescending(
                        t => t.CreatedAt)
                    .Select(t => new
                    {
                        t.TicketId,
                        t.Subject,
                        t.Category,
                        t.Priority,
                        StatusValue =
                            t.Status,
                        t.CreatedAt
                    })
                    .ToList()
                    .Select(t => new
                    {
                        t.TicketId,
                        t.Subject,

                        Category =
                            GetCategoryText(
                                t.Category),

                        Priority =
                            GetPriorityText(
                                t.Priority),

                        StatusValue =
                            t.StatusValue,

                        Status =
                            GetStatusText(
                                t.StatusValue),

                        CreatedAt =
                            t.CreatedAt.ToString(
                                "yyyy/MM/dd HH:mm")
                    })
                    .ToList();


                /*
                 * =====================================
                 * نمایش جدول
                 * =====================================
                 */

                gvTickets.DataSource =
                    tickets;

                gvTickets.DataBind();
            }


            /*
             * =====================================
             * عنوان فیلتر فعال
             * =====================================
             */

            lblCurrentFilter.Text =
                GetStatusFilterText(
                    SelectedStatus);


            /*
             * =====================================
             * مشخص کردن دکمه فعال
             * =====================================
             */

            SetFilterButtonStyle();
        }


        protected void StatusFilter_Command(
            object sender,
            CommandEventArgs e)
        {
            string status =
                e.CommandArgument.ToString();


            if (!IsValidStatus(status))
            {
                status = "All";
            }


            SelectedStatus =
                status;


            /*
             * وضعیت انتخاب‌شده
             * در URL هم ذخیره می‌شود.
             */

            Response.Redirect(
                "~/SpecialistDashboard.aspx?status="
                + Server.UrlEncode(status));
        }


        private void SetFilterButtonStyle()
        {
            string baseClass =
                "specialist-filter-button";


            btnAll.CssClass =
                baseClass;

            btnAssigned.CssClass =
                baseClass;

            btnInProgress.CssClass =
                baseClass;

            btnWaiting.CssClass =
                baseClass;

            btnClosed.CssClass =
                baseClass;


            switch (SelectedStatus)
            {
                case "Assigned":

                    btnAssigned.CssClass =
                        baseClass +
                        " specialist-filter-button-active";

                    break;


                case "InProgress":

                    btnInProgress.CssClass =
                        baseClass +
                        " specialist-filter-button-active";

                    break;


                case "WaitingConfirmation":

                    btnWaiting.CssClass =
                        baseClass +
                        " specialist-filter-button-active";

                    break;


                case "Closed":

                    btnClosed.CssClass =
                        baseClass +
                        " specialist-filter-button-active";

                    break;


                default:

                    btnAll.CssClass =
                        baseClass +
                        " specialist-filter-button-active";

                    break;
            }
        }


        private string GetStatusFilterText(
            string status)
        {
            switch (status)
            {
                case "Assigned":

                    return "ارجاع شده";


                case "InProgress":

                    return "در حال رسیدگی";


                case "WaitingConfirmation":

                    return "منتظر تأیید کاربر";


                case "Closed":

                    return "خاتمه یافته";


                default:

                    return "همه درخواست‌ها";
            }
        }


        public string GetStatusCssClass(
            string status)
        {
            switch (status)
            {
                case "Assigned":

                    return
                        "specialist-status status-assigned";


                case "InProgress":

                    return
                        "specialist-status status-progress";


                case "WaitingConfirmation":

                    return
                        "specialist-status status-waiting";


                case "Closed":

                    return
                        "specialist-status status-closed";


                default:

                    return
                        "specialist-status status-new";
            }
        }


        private string GetCategoryText(
            string category)
        {
            switch (category)
            {
                case "نرم‌افزار":

                    return "نرم‌افزار";


                case "سخت‌افزار":

                    return "سخت‌افزار";


                case "شبکه":

                    return "شبکه";


                case "امنیت":

                    return "امنیت";


                case "سایر":

                    return "سایر";


                default:

                    return category;
            }
        }


        private string GetPriorityText(
            string priority)
        {
            switch (priority)
            {
                case "Low":

                    return "کم";


                case "Normal":

                    return "عادی";


                case "High":

                    return "زیاد";


                case "Critical":

                    return "بحرانی";


                default:

                    return priority;
            }
        }


        private string GetStatusText(
            string status)
        {
            switch (status)
            {
                case "New":

                    return "جدید";


                case "Assigned":

                    return "ارجاع شده";


                case "InProgress":

                    return "در حال رسیدگی";


                case "WaitingConfirmation":

                    return "منتظر تأیید کاربر";


                case "Closed":

                    return "خاتمه یافته";


                default:

                    return status;
            }
        }
    }
}