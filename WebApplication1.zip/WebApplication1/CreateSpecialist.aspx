﻿<%@ Page Title="ایجاد کارشناس جدید" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true" CodeBehind="CreateSpecialist.aspx.cs" Inherits="WebApplication1.CreateSpecialist" %>

<asp:Content ID="Content1"
    ContentPlaceHolderID="TitleContent"
    runat="server">

    ایجاد کارشناس جدید

</asp:Content>


<asp:Content ID="Content2"
    ContentPlaceHolderID="HeadContent"
    runat="server">

    <style type="text/css">

        .specialist-form-container {
            max-width: 900px;
            margin: 0 auto;
        }

        .form-card {
            background: #fff;
            border-radius: 10px;
            padding: 25px;
            box-shadow: 0 2px 10px rgba(0,0,0,.06);
        }

        .section-title {
            font-size: 16px;
            font-weight: bold;
            color: #333;
            padding-bottom: 12px;
            margin-bottom: 20px;
            border-bottom: 1px solid #eee;
        }

        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 18px;
        }

        .form-group {
            margin-bottom: 18px;
        }

        .form-label {
            display: block;
            margin-bottom: 7px;
            color: #555;
            font-size: 13px;
        }

        .required {
            color: #c62828;
        }

        .form-control {
            width: 100%;
            box-sizing: border-box;
            padding: 10px 12px;
            border: 1px solid #d5d9df;
            border-radius: 6px;
            font-family: Tahoma, Arial;
            font-size: 13px;
            background: #fff;
        }

        .form-control:focus {
            border-color: #1976d2;
            outline: none;
        }

        .checkbox-row {
            display: flex;
            align-items: center;
            gap: 8px;
            margin-top: 8px;
        }

        .checkbox-row label {
            font-size: 13px;
            color: #444;
        }

        .info {
            background: #e3f2fd;
            color: #1565c0;
            padding: 12px;
            border-radius: 6px;
            margin-bottom: 20px;
            font-size: 12px;
            line-height: 1.8;
        }

        .specialties-box {
            background: #f7f9fb;
            border: 1px solid #e1e5e9;
            border-radius: 7px;
            padding: 15px;
            margin-top: 5px;
        }

        .specialties-description {
            color: #777;
            font-size: 12px;
            line-height: 1.8;
            margin-bottom: 15px;
        }

        .specialties-list {
            display: flex;
            flex-wrap: wrap;
            gap: 10px 20px;
        }

        .specialty-item {
            display: inline-block;
            font-size: 13px;
            color: #444;
        }

        .specialty-item input {
            margin-left: 6px;
            vertical-align: middle;
        }

        .no-specialty {
            color: #888;
            font-size: 12px;
            padding: 8px 0;
        }

        .buttons {
            margin-top: 25px;
            padding-top: 20px;
            border-top: 1px solid #eee;
        }

        .btn {
            border: none;
            border-radius: 6px;
            padding: 11px 22px;
            font-family: Tahoma, Arial;
            font-size: 13px;
            cursor: pointer;
        }

        .btn-primary {
            background: #1976d2;
            color: #fff;
        }

        .btn-primary:hover {
            background: #1565c0;
        }

        .btn-secondary {
            background: #eceff1;
            color: #333;
            text-decoration: none;
            display: inline-block;
            margin-right: 8px;
        }

        .btn-secondary:hover {
            background: #dfe3e6;
        }

        .message {
            display: block;
            margin-top: 18px;
            padding: 10px 12px;
            border-radius: 6px;
            font-size: 13px;
            line-height: 1.8;
        }

        .success {
            background: #e8f5e9;
            color: #2e7d32;
        }

        .error {
            background: #ffebee;
            color: #c62828;
        }

        @media (max-width: 700px) {

            .form-row {
                grid-template-columns: 1fr;
            }

            .form-card {
                padding: 18px;
            }

            .specialist-form-container {
                width: 100%;
            }

        }

    </style>

</asp:Content>


<asp:Content ID="Content3"
    ContentPlaceHolderID="PageHeader"
    runat="server">

    ایجاد کارشناس جدید

</asp:Content>


<asp:Content ID="Content4"
    ContentPlaceHolderID="MainContent"
    runat="server">

    <div class="specialist-form-container">

        <div class="form-card">

            <div class="section-title">
                اطلاعات کارشناس
            </div>


            <div class="info">

                اطلاعات کارشناس در سامانه ثبت می‌شود.
                نقش این حساب به صورت خودکار «کارشناس» تعیین خواهد شد
                و تخصص‌های انتخاب‌شده برای ارجاع درخواست‌ها مورد استفاده قرار می‌گیرند.

            </div>


            <!-- نام کاربری و نام -->

            <div class="form-row">

                <div class="form-group">

                    <label class="form-label">

                        نام کاربری

                        <span class="required">*</span>

                    </label>

                    <asp:TextBox
                        ID="txtUserName"
                        runat="server"
                        CssClass="form-control"
                        MaxLength="256"
                        autocomplete="off">
                    </asp:TextBox>

                </div>


                <div class="form-group">

                    <label class="form-label">

                        نام و نام خانوادگی

                        <span class="required">*</span>

                    </label>

                    <asp:TextBox
                        ID="txtFullName"
                        runat="server"
                        CssClass="form-control"
                        MaxLength="150">
                    </asp:TextBox>

                </div>

            </div>


            <!-- واحد سازمانی و وضعیت -->

            <div class="form-row">

                <div class="form-group">

                    <label class="form-label">

                        واحد سازمانی

                        <span class="required">*</span>

                    </label>

                    <asp:DropDownList
                        ID="ddlDepartment"
                        runat="server"
                        CssClass="form-control">

                    </asp:DropDownList>

                </div>


                <div class="form-group">

                    <label class="form-label">

                        وضعیت حساب

                    </label>

                    <div class="checkbox-row">

                        <asp:CheckBox
                            ID="chkIsActive"
                            runat="server"
                            Checked="true" />

                        <label>

                            کارشناس فعال باشد

                        </label>

                    </div>

                </div>

            </div>


            <!-- رمز عبور -->

            <div class="form-row">

                <div class="form-group">

                    <label class="form-label">

                        رمز عبور

                        <span class="required">*</span>

                    </label>

                    <asp:TextBox
                        ID="txtPassword"
                        runat="server"
                        TextMode="Password"
                        CssClass="form-control"
                        MaxLength="100"
                        autocomplete="new-password">
                    </asp:TextBox>

                </div>


                <div class="form-group">

                    <label class="form-label">

                        تکرار رمز عبور

                        <span class="required">*</span>

                    </label>

                    <asp:TextBox
                        ID="txtConfirmPassword"
                        runat="server"
                        TextMode="Password"
                        CssClass="form-control"
                        MaxLength="100"
                        autocomplete="new-password">
                    </asp:TextBox>

                </div>

            </div>


            <!-- تخصص‌ها -->

            <div class="section-title">

                تخصص‌های کارشناس

            </div>


            <div class="specialties-box">

                <div class="specialties-description">

                    یک یا چند تخصص را برای این کارشناس انتخاب کنید.
                    تخصص‌ها برای ارجاع و تخصیص درخواست‌های پشتیبانی استفاده خواهند شد.
                    در آینده نیز امکان تغییر تخصص‌ها از بخش «مدیریت تخصص کارشناسان» وجود دارد.

                </div>


                <div class="specialties-list">

                    <asp:CheckBoxList
                        ID="cblSpecialties"
                        runat="server"
                        RepeatDirection="Horizontal"
                        RepeatLayout="Flow"
                        CssClass="specialty-item">

                    </asp:CheckBoxList>

                </div>


                <asp:Label
                    ID="lblNoSpecialty"
                    runat="server"
                    CssClass="no-specialty"
                    Visible="false">

                    در حال حاضر تخصص فعالی برای انتخاب وجود ندارد.

                </asp:Label>

            </div>


            <!-- دکمه‌ها -->

            <div class="buttons">

                <asp:Button
                    ID="btnCreate"
                    runat="server"
                    Text="ایجاد کارشناس"
                    CssClass="btn btn-primary"
                    OnClick="btnCreate_Click" />


                <asp:HyperLink
                    ID="lnkBack"
                    runat="server"
                    NavigateUrl="~/Users.aspx"
                    CssClass="btn btn-secondary">

                    بازگشت

                </asp:HyperLink>

            </div>


            <!-- پیام -->

            <asp:Label
                ID="lblMessage"
                runat="server">
            </asp:Label>


        </div>

    </div>

</asp:Content>