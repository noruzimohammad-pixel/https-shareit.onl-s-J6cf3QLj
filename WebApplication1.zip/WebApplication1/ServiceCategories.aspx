﻿<%@ Page Title="مدیریت دسته‌بندی خدمات"
    Language="C#"
    MasterPageFile="~/Site.Master"
    AutoEventWireup="true"
    CodeBehind="ServiceCategories.aspx.cs"
    Inherits="WebApplication1.ServiceCategories" %>

<asp:Content ID="Content1"
    ContentPlaceHolderID="TitleContent"
    runat="server">
    مدیریت دسته‌بندی خدمات
</asp:Content>

<asp:Content ID="Content2"
    ContentPlaceHolderID="HeadContent"
    runat="server">

    <style type="text/css">

        .service-page {
            direction: rtl;
            font-family: Vazirmatn, Tahoma, Arial, sans-serif;
        }

        .service-intro {
            background: linear-gradient(135deg, #1976d2, #1565c0);
            color: #fff;
            border-radius: 16px;
            padding: 22px 24px;
            margin-bottom: 20px;
            box-shadow: 0 8px 25px rgba(25,118,210,.15);
        }

        .service-intro h2 {
            margin: 0 0 7px 0;
            font-size: 21px;
            font-weight: 700;
        }

        .service-intro p {
            margin: 0;
            font-size: 13px;
            opacity: .9;
            line-height: 1.9;
        }

        .service-layout {
            display: grid;
            grid-template-columns: minmax(280px, 360px) minmax(0, 1fr);
            gap: 20px;
            align-items: start;
        }

        .service-card {
            background: #fff;
            border-radius: 14px;
            box-shadow: 0 3px 16px rgba(0,0,0,.06);
            overflow: hidden;
        }

        .service-card-header {
            padding: 18px 20px;
            border-bottom: 1px solid #edf0f3;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 12px;
        }

        .service-card-title {
            margin: 0;
            font-size: 16px;
            font-weight: 700;
            color: #263238;
        }

        .service-card-subtitle {
            margin: 5px 0 0 0;
            color: #8a949e;
            font-size: 11px;
        }

        .service-card-body {
            padding: 20px;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-label {
            display: block;
            margin-bottom: 7px;
            font-size: 12px;
            color: #455a64;
            font-weight: 600;
        }

        .form-control {
            width: 100%;
            box-sizing: border-box;
            border: 1px solid #dce2e7;
            border-radius: 8px;
            padding: 10px 12px;
            min-height: 42px;
            font-family: Vazirmatn, Tahoma, Arial, sans-serif;
            font-size: 13px;
            color: #263238;
            background: #fff;
            outline: none;
            transition: all .2s ease;
        }

        textarea.form-control {
            min-height: 90px;
            resize: vertical;
        }

        .form-control:focus {
            border-color: #1976d2;
            box-shadow: 0 0 0 3px rgba(25,118,210,.08);
        }

        .form-check {
            display: flex;
            align-items: center;
            gap: 8px;
            margin-top: 4px;
            color: #455a64;
            font-size: 12px;
        }

        .form-check input {
            width: 17px;
            height: 17px;
        }

        .button-row {
            display: flex;
            gap: 8px;
            flex-wrap: wrap;
            margin-top: 18px;
        }

        .btn-service {
            border: 0;
            border-radius: 8px;
            padding: 10px 16px;
            min-height: 40px;
            font-family: Vazirmatn, Tahoma, Arial, sans-serif;
            font-size: 12px;
            cursor: pointer;
            transition: all .2s ease;
        }

        .btn-service:hover {
            transform: translateY(-1px);
        }

        .btn-primary-service {
            background: #1976d2;
            color: #fff;
        }

        .btn-primary-service:hover {
            background: #1565c0;
        }

        .btn-secondary-service {
            background: #eef1f4;
            color: #455a64;
        }

        .btn-secondary-service:hover {
            background: #e2e6ea;
        }

        .btn-danger-service {
            background: #ffebee;
            color: #c62828;
        }

        .btn-danger-service:hover {
            background: #ffcdd2;
        }

        .btn-success-service {
            background: #e8f5e9;
            color: #2e7d32;
        }

        .category-list {
            display: flex;
            flex-direction: column;
        }

        .category-item {
            border-bottom: 1px solid #edf0f3;
            padding: 14px 16px;
            cursor: pointer;
            transition: all .2s ease;
        }

        .category-item:last-child {
            border-bottom: none;
        }

        .category-item:hover {
            background: #f8fafc;
        }

        .category-item-selected {
            background: #eef6ff;
            border-right: 4px solid #1976d2;
            padding-right: 12px;
        }

        .category-main {
            display: flex;
            align-items: flex-start;
            justify-content: space-between;
            gap: 10px;
        }

        .category-name {
            font-size: 13px;
            font-weight: 700;
            color: #263238;
        }

        .category-description {
            color: #8a949e;
            font-size: 11px;
            line-height: 1.8;
            margin-top: 4px;
        }

        .category-meta {
            margin-top: 8px;
            display: flex;
            align-items: center;
            gap: 7px;
            flex-wrap: wrap;
        }

        .badge-service {
            display: inline-flex;
            align-items: center;
            padding: 3px 8px;
            border-radius: 20px;
            font-size: 10px;
            white-space: nowrap;
        }

        .badge-active {
            background: #e8f5e9;
            color: #2e7d32;
        }

        .badge-inactive {
            background: #f5f5f5;
            color: #757575;
        }

        .badge-count {
            background: #eef1f4;
            color: #546e7a;
        }

        .category-actions {
            display: flex;
            gap: 5px;
            flex-shrink: 0;
        }

        .mini-btn {
            border: 0;
            border-radius: 6px;
            padding: 6px 9px;
            font-family: Vazirmatn, Tahoma, Arial, sans-serif;
            font-size: 10px;
            cursor: pointer;
        }

        .mini-edit {
            background: #e3f2fd;
            color: #1565c0;
        }

        .mini-status {
            background: #fff8e1;
            color: #ef6c00;
        }

        .topic-empty {
            padding: 35px 15px;
            text-align: center;
            color: #9aa3aa;
            font-size: 12px;
        }

        .topic-list {
            display: flex;
            flex-direction: column;
        }

        .topic-item {
            padding: 15px 0;
            border-bottom: 1px solid #edf0f3;
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 15px;
        }

        .topic-item:last-child {
            border-bottom: none;
        }

        .topic-name {
            font-size: 13px;
            color: #263238;
            font-weight: 600;
        }

        .topic-description {
            color: #8a949e;
            font-size: 11px;
            margin-top: 4px;
            line-height: 1.7;
        }

        .topic-actions {
            display: flex;
            align-items: center;
            gap: 6px;
            flex-shrink: 0;
        }

        .message-service {
            display: block;
            margin-bottom: 15px;
            padding: 10px 12px;
            border-radius: 8px;
            font-size: 12px;
            line-height: 1.8;
        }

        .message-success {
            background: #e8f5e9;
            color: #2e7d32;
        }

        .message-error {
            background: #ffebee;
            color: #c62828;
        }

        .message-info {
            background: #e3f2fd;
            color: #1565c0;
        }

        .edit-box {
            background: #f8fafc;
            border: 1px solid #e7ebef;
            border-radius: 10px;
            padding: 15px;
            margin-bottom: 18px;
        }

        .edit-box-title {
            font-size: 13px;
            font-weight: 700;
            color: #37474f;
            margin-bottom: 13px;
        }

        .topic-header-info {
            background: #f8fafc;
            border-radius: 10px;
            padding: 12px 14px;
            margin-bottom: 10px;
        }

        .topic-header-info strong {
            color: #1976d2;
            font-size: 14px;
        }

        .topic-header-info span {
            display: block;
            margin-top: 4px;
            color: #7b8790;
            font-size: 11px;
        }

        @media (max-width: 900px) {

            .service-layout {
                grid-template-columns: 1fr;
            }

            .service-card-body {
                padding: 16px;
            }

            .service-intro {
                padding: 18px;
            }

            .service-intro h2 {
                font-size: 18px;
            }

        }

        @media (max-width: 600px) {

            .service-card-header {
                padding: 15px;
                align-items: flex-start;
            }

            .service-card-body {
                padding: 13px;
            }

            .category-main {
                flex-direction: column;
            }

            .category-actions {
                width: 100%;
            }

            .category-actions .mini-btn {
                flex: 1;
            }

            .topic-item {
                flex-direction: column;
                align-items: flex-start;
            }

            .topic-actions {
                width: 100%;
            }

            .topic-actions .mini-btn {
                flex: 1;
            }

            .button-row {
                flex-direction: column;
            }

            .btn-service {
                width: 100%;
            }

            .service-intro {
                border-radius: 10px;
            }

        }

    </style>

</asp:Content>

<asp:Content ID="Content3"
    ContentPlaceHolderID="PageHeader"
    runat="server">

    مدیریت دسته‌بندی خدمات

</asp:Content>

<asp:Content ID="Content4"
    ContentPlaceHolderID="MainContent"
    runat="server">

    <div class="service-page">

        <div class="service-intro">

            <h2>
                مدیریت ساختار خدمات فناوری اطلاعات
            </h2>

            <p>
                در این بخش می‌توانید حوزه‌های خدمات و موضوعات مربوط به هر حوزه را مدیریت کنید.
                این دسته‌بندی‌ها در مراحل بعدی برای ثبت و گزارش‌گیری درخواست‌ها استفاده خواهند شد.
            </p>

        </div>


        <asp:Label
            ID="lblMessage"
            runat="server"
            Visible="false"
            CssClass="message-service">
        </asp:Label>


        <div class="service-layout">


            <div class="service-card">

                <div class="service-card-header">

                    <div>
                        <h3 class="service-card-title">
                            حوزه‌های خدمات
                        </h3>

                        <p class="service-card-subtitle">
                            انتخاب حوزه برای مشاهده موضوعات
                        </p>
                    </div>

                    <asp:Button
                        ID="btnNewCategory"
                        runat="server"
                        Text="+ حوزه جدید"
                        CssClass="btn-service btn-primary-service"
                        OnClick="btnNewCategory_Click" />

                </div>


                <div class="service-card-body">


                    <asp:Panel
                        ID="pnlCategoryEdit"
                        runat="server"
                        Visible="false"
                        CssClass="edit-box">

                        <div class="edit-box-title">

                            <asp:Label
                                ID="lblCategoryEditTitle"
                                runat="server"
                                Text="افزودن حوزه جدید">
                            </asp:Label>

                        </div>


                        <div class="form-group">

                            <label class="form-label">
                                نام حوزه
                            </label>

                            <asp:TextBox
                                ID="txtCategoryName"
                                runat="server"
                                CssClass="form-control"
                                MaxLength="100">
                            </asp:TextBox>

                        </div>


                        <div class="form-group">

                            <label class="form-label">
                                توضیحات
                            </label>

                            <asp:TextBox
                                ID="txtCategoryDescription"
                                runat="server"
                                CssClass="form-control"
                                TextMode="MultiLine"
                                MaxLength="500">
                            </asp:TextBox>

                        </div>


                        <div class="form-check">

                            <asp:CheckBox
                                ID="chkCategoryActive"
                                runat="server"
                                Checked="true" />

                            <span>
                                حوزه فعال باشد
                            </span>

                        </div>


                        <div class="button-row">

                            <asp:Button
                                ID="btnSaveCategory"
                                runat="server"
                                Text="ثبت اطلاعات"
                                CssClass="btn-service btn-primary-service"
                                OnClick="btnSaveCategory_Click" />

                            <asp:Button
                                ID="btnCancelCategory"
                                runat="server"
                                Text="انصراف"
                                CssClass="btn-service btn-secondary-service"
                                CausesValidation="false"
                                OnClick="btnCancelCategory_Click" />

                        </div>

                    </asp:Panel>


                    <div class="category-list">

                        <asp:Repeater
                            ID="rptCategories"
                            runat="server"
                            OnItemCommand="rptCategories_ItemCommand">

                            <ItemTemplate>

                                <asp:LinkButton
                                    ID="btnSelectCategory"
                                    runat="server"
                                    CommandName="SelectCategory"
                                    CommandArgument='<%# Eval("ServiceCategoryId") %>'
                                    CausesValidation="false"
                                    Style="text-decoration:none;color:inherit;display:block;">

                                    <div class='<%# GetCategoryCss(Eval("ServiceCategoryId")) %>'>

                                        <div class="category-main">

                                            <div>

                                                <div class="category-name">
                                                    <%# Eval("CategoryName") %>
                                                </div>

                                                <div class="category-description">
                                                    <%# Eval("Description") %>
                                                </div>

                                                <div class="category-meta">

                                                    <span class='<%# GetActiveBadgeCss(Eval("IsActive")) %>'>
                                                        <%# GetActiveText(Eval("IsActive")) %>
                                                    </span>

                                                    <span class="badge-service badge-count">
                                                        <%# Eval("TopicCount") %> موضوع
                                                    </span>

                                                </div>

                                            </div>


                                            <div class="category-actions">

                                                <asp:Button
                                                    ID="btnEditCategory"
                                                    runat="server"
                                                    Text="ویرایش"
                                                    CssClass="mini-btn mini-edit"
                                                    CommandName="EditCategory"
                                                    CommandArgument='<%# Eval("ServiceCategoryId") %>'
                                                    CausesValidation="false" />

                                                <asp:Button
                                                    ID="btnToggleCategory"
                                                    runat="server"
                                                    Text='<%# GetToggleText(Eval("IsActive")) %>'
                                                    CssClass="mini-btn mini-status"
                                                    CommandName="ToggleCategory"
                                                    CommandArgument='<%# Eval("ServiceCategoryId") %>'
                                                    CausesValidation="false" />

                                            </div>

                                        </div>

                                    </div>

                                </asp:LinkButton>

                            </ItemTemplate>

                        </asp:Repeater>


                        <asp:Label
                            ID="lblNoCategories"
                            runat="server"
                            Visible="false"
                            CssClass="topic-empty">

                            هنوز حوزه‌ای ثبت نشده است.

                        </asp:Label>

                    </div>

                </div>

            </div>



            <div class="service-card">

                <div class="service-card-header">

                    <div>

                        <h3 class="service-card-title">
                            موضوعات حوزه
                        </h3>

                        <p class="service-card-subtitle">
                            موضوعات قابل انتخاب برای حوزه انتخاب‌شده
                        </p>

                    </div>


                    <asp:Button
                        ID="btnNewTopic"
                        runat="server"
                        Text="+ موضوع جدید"
                        CssClass="btn-service btn-primary-service"
                        CausesValidation="false"
                        OnClick="btnNewTopic_Click" />

                </div>


                <div class="service-card-body">


                    <asp:Panel
                        ID="pnlTopicEdit"
                        runat="server"
                        Visible="false"
                        CssClass="edit-box">

                        <div class="edit-box-title">

                            <asp:Label
                                ID="lblTopicEditTitle"
                                runat="server"
                                Text="افزودن موضوع جدید">
                            </asp:Label>

                        </div>


                        <div class="form-group">

                            <label class="form-label">
                                نام موضوع
                            </label>

                            <asp:TextBox
                                ID="txtTopicName"
                                runat="server"
                                CssClass="form-control"
                                MaxLength="150">
                            </asp:TextBox>

                        </div>


                        <div class="form-group">

                            <label class="form-label">
                                توضیحات
                            </label>

                            <asp:TextBox
                                ID="txtTopicDescription"
                                runat="server"
                                CssClass="form-control"
                                TextMode="MultiLine"
                                MaxLength="500">
                            </asp:TextBox>

                        </div>


                        <div class="form-check">

                            <asp:CheckBox
                                ID="chkTopicActive"
                                runat="server"
                                Checked="true" />

                            <span>
                                موضوع فعال باشد
                            </span>

                        </div>


                        <div class="button-row">

                            <asp:Button
                                ID="btnSaveTopic"
                                runat="server"
                                Text="ثبت اطلاعات"
                                CssClass="btn-service btn-primary-service"
                                OnClick="btnSaveTopic_Click" />

                            <asp:Button
                                ID="btnCancelTopic"
                                runat="server"
                                Text="انصراف"
                                CssClass="btn-service btn-secondary-service"
                                CausesValidation="false"
                                OnClick="btnCancelTopic_Click" />

                        </div>

                    </asp:Panel>


                    <asp:Panel
                        ID="pnlSelectedCategory"
                        runat="server"
                        Visible="false">

                        <div class="topic-header-info">

                            <asp:Label
                                ID="lblSelectedCategoryName"
                                runat="server">
                            </asp:Label>

                            <span>
                                موضوعات ثبت‌شده برای این حوزه
                            </span>

                        </div>

                    </asp:Panel>


                    <div class="topic-list">

                        <asp:Repeater
                            ID="rptTopics"
                            runat="server"
                            OnItemCommand="rptTopics_ItemCommand">

                            <ItemTemplate>

                                <div class="topic-item">

                                    <div>

                                        <div class="topic-name">
                                            <%# Eval("TopicName") %>
                                        </div>

                                        <div class="topic-description">
                                            <%# Eval("Description") %>
                                        </div>

                                        <div class="category-meta">

                                            <span class='<%# GetActiveBadgeCss(Eval("IsActive")) %>'>
                                                <%# GetActiveText(Eval("IsActive")) %>
                                            </span>

                                        </div>

                                    </div>


                                    <div class="topic-actions">

                                        <asp:Button
                                            ID="btnEditTopic"
                                            runat="server"
                                            Text="ویرایش"
                                            CssClass="mini-btn mini-edit"
                                            CommandName="EditTopic"
                                            CommandArgument='<%# Eval("ServiceTopicId") %>'
                                            CausesValidation="false" />

                                        <asp:Button
                                            ID="btnToggleTopic"
                                            runat="server"
                                            Text='<%# GetToggleText(Eval("IsActive")) %>'
                                            CssClass="mini-btn mini-status"
                                            CommandName="ToggleTopic"
                                            CommandArgument='<%# Eval("ServiceTopicId") %>'
                                            CausesValidation="false" />

                                    </div>

                                </div>

                            </ItemTemplate>

                        </asp:Repeater>


                        <asp:Label
                            ID="lblNoTopics"
                            runat="server"
                            Visible="false"
                            CssClass="topic-empty">

                            برای این حوزه هنوز موضوعی ثبت نشده است.

                        </asp:Label>

                    </div>

                </div>

            </div>

        </div>

    </div>

</asp:Content>