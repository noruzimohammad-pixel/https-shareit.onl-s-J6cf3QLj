﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication1
{
    public partial class ServiceManagement : Page
    {
        private readonly string connectionString =
            ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;


        private int SelectedCategoryId
        {
            get
            {
                object value = ViewState["SelectedCategoryId"];

                if (value == null)
                    return 0;

                return Convert.ToInt32(value);
            }

            set
            {
                ViewState["SelectedCategoryId"] = value;
            }
        }


        private int EditCategoryId
        {
            get
            {
                object value = ViewState["EditCategoryId"];

                if (value == null)
                    return 0;

                return Convert.ToInt32(value);
            }

            set
            {
                ViewState["EditCategoryId"] = value;
            }
        }


        private int EditTopicId
        {
            get
            {
                object value = ViewState["EditTopicId"];

                if (value == null)
                    return 0;

                return Convert.ToInt32(value);
            }

            set
            {
                ViewState["EditTopicId"] = value;
            }
        }


        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadCategories();

                pnlCategoryEdit.Visible = false;
                pnlTopicEdit.Visible = false;
                pnlSelectedCategory.Visible = false;
                pnlTopics.Visible = false;
                pnlNoCategory.Visible = true;
            }
        }


        private void LoadCategories()
        {
            LoadCategories(txtCategorySearch.Text.Trim());
        }


        private void LoadCategories(string searchText)
        {
            DataTable table = new DataTable();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string sql = @"
                    SELECT
                        c.ServiceCategoryId,
                        c.CategoryName,
                        c.Description,
                        c.IsActive,
                        c.DisplayOrder,
                        COUNT(t.ServiceTopicId) AS TopicCount
                    FROM ServiceCategories c
                    LEFT JOIN ServiceTopics t
                        ON c.ServiceCategoryId = t.ServiceCategoryId
                    WHERE
                        (@Search = ''
                         OR c.CategoryName LIKE N'%' + @Search + N'%'
                         OR ISNULL(c.Description, N'') LIKE N'%' + @Search + N'%')
                    GROUP BY
                        c.ServiceCategoryId,
                        c.CategoryName,
                        c.Description,
                        c.IsActive,
                        c.DisplayOrder
                    ORDER BY
                        c.DisplayOrder,
                        c.ServiceCategoryId;";


                using (SqlCommand command = new SqlCommand(sql, connection))
                {
                    command.Parameters.Add("@Search", SqlDbType.NVarChar, 100)
                        .Value = searchText ?? string.Empty;

                    using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                    {
                        adapter.Fill(table);
                    }
                }
            }


            rptCategories.DataSource = table;
            rptCategories.DataBind();

            pnlCategoryEmpty.Visible = table.Rows.Count == 0;
        }


        private void LoadSelectedCategory()
        {
            if (SelectedCategoryId <= 0)
            {
                pnlSelectedCategory.Visible = false;
                pnlTopics.Visible = false;
                pnlNoCategory.Visible = true;
                return;
            }


            DataTable categoryTable = new DataTable();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string sql = @"
                    SELECT
                        ServiceCategoryId,
                        CategoryName,
                        Description,
                        IsActive
                    FROM ServiceCategories
                    WHERE ServiceCategoryId = @CategoryId;";


                using (SqlCommand command = new SqlCommand(sql, connection))
                {
                    command.Parameters.Add("@CategoryId", SqlDbType.Int)
                        .Value = SelectedCategoryId;

                    using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                    {
                        adapter.Fill(categoryTable);
                    }
                }
            }


            if (categoryTable.Rows.Count == 0)
            {
                SelectedCategoryId = 0;

                pnlSelectedCategory.Visible = false;
                pnlTopics.Visible = false;
                pnlNoCategory.Visible = true;

                return;
            }


            DataRow category = categoryTable.Rows[0];


            lblSelectedCategoryName.Text =
                Convert.ToString(category["CategoryName"]);

            lblSelectedCategoryDescription.Text =
                Convert.ToString(category["Description"]);


            pnlSelectedCategory.Visible = true;
            pnlNoCategory.Visible = false;
            pnlTopics.Visible = true;


            LoadTopics();
        }


        private void LoadTopics()
        {
            if (SelectedCategoryId <= 0)
            {
                pnlTopics.Visible = false;
                pnlNoCategory.Visible = true;
                return;
            }


            DataTable table = new DataTable();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string sql = @"
                    SELECT
                        ServiceTopicId,
                        ServiceCategoryId,
                        TopicName,
                        Description,
                        IsActive,
                        DisplayOrder
                    FROM ServiceTopics
                    WHERE ServiceCategoryId = @CategoryId
                    ORDER BY DisplayOrder, ServiceTopicId;";


                using (SqlCommand command = new SqlCommand(sql, connection))
                {
                    command.Parameters.Add("@CategoryId", SqlDbType.Int)
                        .Value = SelectedCategoryId;

                    using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                    {
                        adapter.Fill(table);
                    }
                }
            }


            rptTopics.DataSource = table;
            rptTopics.DataBind();

            pnlTopicEmpty.Visible = table.Rows.Count == 0;
        }


        private void LoadCategoryDropDown()
        {
            ddlTopicCategory.Items.Clear();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string sql = @"
                    SELECT
                        ServiceCategoryId,
                        CategoryName
                    FROM ServiceCategories
                    WHERE IsActive = 1
                    ORDER BY DisplayOrder, CategoryName;";


                using (SqlCommand command = new SqlCommand(sql, connection))
                {
                    connection.Open();

                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        ddlTopicCategory.DataSource = reader;
                        ddlTopicCategory.DataTextField = "CategoryName";
                        ddlTopicCategory.DataValueField = "ServiceCategoryId";
                        ddlTopicCategory.DataBind();
                    }
                }
            }


            ddlTopicCategory.Items.Insert(
                0,
                new ListItem("انتخاب حوزه", "")
            );
        }


        protected void txtCategorySearch_TextChanged(object sender, EventArgs e)
        {
            LoadCategories(txtCategorySearch.Text.Trim());

            if (SelectedCategoryId > 0)
                LoadSelectedCategory();
        }


        protected void rptCategories_ItemCommand(
            object source,
            RepeaterCommandEventArgs e)
        {
            int categoryId;

            if (!int.TryParse(Convert.ToString(e.CommandArgument), out categoryId))
                return;


            if (e.CommandName == "SelectCategory")
            {
                SelectedCategoryId = categoryId;

                pnlCategoryEdit.Visible = false;
                pnlTopicEdit.Visible = false;

                LoadCategories(txtCategorySearch.Text.Trim());
                LoadSelectedCategory();

                return;
            }


            if (e.CommandName == "EditCategory")
            {
                EditCategory(categoryId);
                return;
            }


            if (e.CommandName == "ToggleCategory")
            {
                ToggleCategory(categoryId);
                return;
            }
        }


        protected void rptTopics_ItemCommand(
            object source,
            RepeaterCommandEventArgs e)
        {
            int topicId;

            if (!int.TryParse(Convert.ToString(e.CommandArgument), out topicId))
                return;


            if (e.CommandName == "EditTopic")
            {
                EditTopic(topicId);
                return;
            }


            if (e.CommandName == "ToggleTopic")
            {
                ToggleTopic(topicId);
                return;
            }
        }


        protected void btnNewCategory_Click(object sender, EventArgs e)
        {
            EditCategoryId = 0;

            txtCategoryName.Text = string.Empty;
            txtCategoryDescription.Text = string.Empty;
            chkCategoryActive.Checked = true;

            lblCategoryEditTitle.Text = "افزودن حوزه جدید";

            pnlCategoryEdit.Visible = true;

            pnlTopicEdit.Visible = false;
        }


        protected void btnCancelCategory_Click(object sender, EventArgs e)
        {
            EditCategoryId = 0;

            txtCategoryName.Text = string.Empty;
            txtCategoryDescription.Text = string.Empty;
            chkCategoryActive.Checked = true;

            pnlCategoryEdit.Visible = false;
        }


        protected void btnSaveCategory_Click(object sender, EventArgs e)
        {
            string categoryName = txtCategoryName.Text.Trim();
            string description = txtCategoryDescription.Text.Trim();
            bool isActive = chkCategoryActive.Checked;


            if (string.IsNullOrWhiteSpace(categoryName))
            {
                ShowMessage(
                    "نام حوزه خدمات را وارد کنید.",
                    "warning"
                );

                return;
            }


            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();


                string duplicateSql = @"
                    SELECT COUNT(*)
                    FROM ServiceCategories
                    WHERE CategoryName = @CategoryName
                      AND ServiceCategoryId <> @CategoryId;";


                using (SqlCommand duplicateCommand =
                    new SqlCommand(duplicateSql, connection))
                {
                    duplicateCommand.Parameters.Add(
                        "@CategoryName",
                        SqlDbType.NVarChar,
                        100).Value = categoryName;

                    duplicateCommand.Parameters.Add(
                        "@CategoryId",
                        SqlDbType.Int).Value = EditCategoryId;


                    int duplicateCount =
                        Convert.ToInt32(duplicateCommand.ExecuteScalar());


                    if (duplicateCount > 0)
                    {
                        ShowMessage(
                            "حوزه‌ای با این نام قبلاً ثبت شده است.",
                            "warning"
                        );

                        return;
                    }
                }


                if (EditCategoryId == 0)
                {
                    string insertSql = @"
                        INSERT INTO ServiceCategories
                        (
                            CategoryName,
                            Description,
                            IsActive,
                            DisplayOrder,
                            CreatedAt
                        )
                        VALUES
                        (
                            @CategoryName,
                            @Description,
                            @IsActive,
                            ISNULL(
                                (
                                    SELECT MAX(DisplayOrder) + 1
                                    FROM ServiceCategories
                                ),
                                1
                            ),
                            GETDATE()
                        );";


                    using (SqlCommand command =
                        new SqlCommand(insertSql, connection))
                    {
                        command.Parameters.Add(
                            "@CategoryName",
                            SqlDbType.NVarChar,
                            100).Value = categoryName;

                        command.Parameters.Add(
                            "@Description",
                            SqlDbType.NVarChar,
                            500).Value =
                                string.IsNullOrWhiteSpace(description)
                                    ? (object)DBNull.Value
                                    : description;

                        command.Parameters.Add(
                            "@IsActive",
                            SqlDbType.Bit).Value = isActive;


                        command.ExecuteNonQuery();
                    }


                    ShowMessage(
                        "حوزه جدید با موفقیت ثبت شد.",
                        "success"
                    );
                }
                else
                {
                    string updateSql = @"
                        UPDATE ServiceCategories
                        SET
                            CategoryName = @CategoryName,
                            Description = @Description,
                            IsActive = @IsActive
                        WHERE ServiceCategoryId = @CategoryId;";


                    using (SqlCommand command =
                        new SqlCommand(updateSql, connection))
                    {
                        command.Parameters.Add(
                            "@CategoryName",
                            SqlDbType.NVarChar,
                            100).Value = categoryName;

                        command.Parameters.Add(
                            "@Description",
                            SqlDbType.NVarChar,
                            500).Value =
                                string.IsNullOrWhiteSpace(description)
                                    ? (object)DBNull.Value
                                    : description;

                        command.Parameters.Add(
                            "@IsActive",
                            SqlDbType.Bit).Value = isActive;

                        command.Parameters.Add(
                            "@CategoryId",
                            SqlDbType.Int).Value = EditCategoryId;


                        command.ExecuteNonQuery();
                    }


                    ShowMessage(
                        "اطلاعات حوزه با موفقیت ویرایش شد.",
                        "success"
                    );
                }
            }


            EditCategoryId = 0;

            pnlCategoryEdit.Visible = false;

            LoadCategories(txtCategorySearch.Text.Trim());
            LoadSelectedCategory();
        }


        private void EditCategory(int categoryId)
        {
            DataTable table = new DataTable();


            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string sql = @"
                    SELECT
                        CategoryName,
                        Description,
                        IsActive
                    FROM ServiceCategories
                    WHERE ServiceCategoryId = @CategoryId;";


                using (SqlCommand command = new SqlCommand(sql, connection))
                {
                    command.Parameters.Add(
                        "@CategoryId",
                        SqlDbType.Int).Value = categoryId;


                    using (SqlDataAdapter adapter =
                        new SqlDataAdapter(command))
                    {
                        adapter.Fill(table);
                    }
                }
            }


            if (table.Rows.Count == 0)
            {
                ShowMessage(
                    "حوزه موردنظر پیدا نشد.",
                    "error"
                );

                return;
            }


            DataRow row = table.Rows[0];


            EditCategoryId = categoryId;


            txtCategoryName.Text =
                Convert.ToString(row["CategoryName"]);

            txtCategoryDescription.Text =
                Convert.ToString(row["Description"]);

            chkCategoryActive.Checked =
                Convert.ToBoolean(row["IsActive"]);


            lblCategoryEditTitle.Text =
                "ویرایش حوزه خدمات";


            pnlCategoryEdit.Visible = true;

            pnlTopicEdit.Visible = false;
        }


        private void ToggleCategory(int categoryId)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string sql = @"
                    UPDATE ServiceCategories
                    SET IsActive =
                        CASE
                            WHEN IsActive = 1 THEN 0
                            ELSE 1
                        END
                    WHERE ServiceCategoryId = @CategoryId;";


                using (SqlCommand command =
                    new SqlCommand(sql, connection))
                {
                    command.Parameters.Add(
                        "@CategoryId",
                        SqlDbType.Int).Value = categoryId;

                    connection.Open();

                    command.ExecuteNonQuery();
                }
            }


            ShowMessage(
                "وضعیت حوزه با موفقیت تغییر کرد.",
                "success"
            );


            LoadCategories(txtCategorySearch.Text.Trim());

            LoadSelectedCategory();
        }


        protected void btnNewTopic_Click(object sender, EventArgs e)
        {
            if (SelectedCategoryId <= 0)
            {
                ShowMessage(
                    "ابتدا یک حوزه خدمات را انتخاب کنید.",
                    "warning"
                );

                return;
            }


            EditTopicId = 0;


            LoadCategoryDropDown();


            if (ddlTopicCategory.Items.FindByValue(
                SelectedCategoryId.ToString()) != null)
            {
                ddlTopicCategory.SelectedValue =
                    SelectedCategoryId.ToString();
            }


            txtTopicName.Text = string.Empty;
            txtTopicDescription.Text = string.Empty;
            txtDisplayOrder.Text = GetNextTopicOrder(
                SelectedCategoryId).ToString();

            chkTopicActive.Checked = true;


            lblTopicEditTitle.Text =
                "افزودن موضوع جدید";


            pnlTopicEdit.Visible = true;
        }


        protected void btnCancelTopic_Click(object sender, EventArgs e)
        {
            EditTopicId = 0;

            txtTopicName.Text = string.Empty;
            txtTopicDescription.Text = string.Empty;

            pnlTopicEdit.Visible = false;
        }


        protected void btnSaveTopic_Click(object sender, EventArgs e)
        {
            string topicName = txtTopicName.Text.Trim();
            string description = txtTopicDescription.Text.Trim();


            int categoryId;

            if (!int.TryParse(
                ddlTopicCategory.SelectedValue,
                out categoryId))
            {
                ShowMessage(
                    "حوزه موضوع را انتخاب کنید.",
                    "warning"
                );

                return;
            }


            if (string.IsNullOrWhiteSpace(topicName))
            {
                ShowMessage(
                    "نام موضوع را وارد کنید.",
                    "warning"
                );

                return;
            }


            int displayOrder;

            if (!int.TryParse(
                txtDisplayOrder.Text.Trim(),
                out displayOrder))
            {
                displayOrder = 1;
            }


            if (displayOrder < 1)
                displayOrder = 1;


            bool isActive = chkTopicActive.Checked;


            using (SqlConnection connection =
                new SqlConnection(connectionString))
            {
                connection.Open();


                string duplicateSql = @"
                    SELECT COUNT(*)
                    FROM ServiceTopics
                    WHERE ServiceCategoryId = @CategoryId
                      AND TopicName = @TopicName
                      AND ServiceTopicId <> @TopicId;";


                using (SqlCommand duplicateCommand =
                    new SqlCommand(duplicateSql, connection))
                {
                    duplicateCommand.Parameters.Add(
                        "@CategoryId",
                        SqlDbType.Int).Value = categoryId;

                    duplicateCommand.Parameters.Add(
                        "@TopicName",
                        SqlDbType.NVarChar,
                        150).Value = topicName;

                    duplicateCommand.Parameters.Add(
                        "@TopicId",
                        SqlDbType.Int).Value = EditTopicId;


                    int count =
                        Convert.ToInt32(
                            duplicateCommand.ExecuteScalar());


                    if (count > 0)
                    {
                        ShowMessage(
                            "موضوعی با این نام در این حوزه قبلاً ثبت شده است.",
                            "warning"
                        );

                        return;
                    }
                }


                if (EditTopicId == 0)
                {
                    string insertSql = @"
                        INSERT INTO ServiceTopics
                        (
                            ServiceCategoryId,
                            TopicName,
                            Description,
                            IsActive,
                            DisplayOrder,
                            CreatedAt
                        )
                        VALUES
                        (
                            @CategoryId,
                            @TopicName,
                            @Description,
                            @IsActive,
                            @DisplayOrder,
                            GETDATE()
                        );";


                    using (SqlCommand command =
                        new SqlCommand(insertSql, connection))
                    {
                        command.Parameters.Add(
                            "@CategoryId",
                            SqlDbType.Int).Value = categoryId;

                        command.Parameters.Add(
                            "@TopicName",
                            SqlDbType.NVarChar,
                            150).Value = topicName;

                        command.Parameters.Add(
                            "@Description",
                            SqlDbType.NVarChar,
                            500).Value =
                                string.IsNullOrWhiteSpace(description)
                                    ? (object)DBNull.Value
                                    : description;

                        command.Parameters.Add(
                            "@IsActive",
                            SqlDbType.Bit).Value = isActive;

                        command.Parameters.Add(
                            "@DisplayOrder",
                            SqlDbType.Int).Value = displayOrder;


                        command.ExecuteNonQuery();
                    }


                    ShowMessage(
                        "موضوع جدید با موفقیت ثبت شد.",
                        "success"
                    );
                }
                else
                {
                    string updateSql = @"
                        UPDATE ServiceTopics
                        SET
                            ServiceCategoryId = @CategoryId,
                            TopicName = @TopicName,
                            Description = @Description,
                            IsActive = @IsActive,
                            DisplayOrder = @DisplayOrder
                        WHERE ServiceTopicId = @TopicId;";


                    using (SqlCommand command =
                        new SqlCommand(updateSql, connection))
                    {
                        command.Parameters.Add(
                            "@CategoryId",
                            SqlDbType.Int).Value = categoryId;

                        command.Parameters.Add(
                            "@TopicName",
                            SqlDbType.NVarChar,
                            150).Value = topicName;

                        command.Parameters.Add(
                            "@Description",
                            SqlDbType.NVarChar,
                            500).Value =
                                string.IsNullOrWhiteSpace(description)
                                    ? (object)DBNull.Value
                                    : description;

                        command.Parameters.Add(
                            "@IsActive",
                            SqlDbType.Bit).Value = isActive;

                        command.Parameters.Add(
                            "@DisplayOrder",
                            SqlDbType.Int).Value = displayOrder;

                        command.Parameters.Add(
                            "@TopicId",
                            SqlDbType.Int).Value = EditTopicId;


                        command.ExecuteNonQuery();
                    }


                    ShowMessage(
                        "اطلاعات موضوع با موفقیت ویرایش شد.",
                        "success"
                    );
                }
            }


            EditTopicId = 0;


            if (SelectedCategoryId != categoryId)
                SelectedCategoryId = categoryId;


            pnlTopicEdit.Visible = false;


            LoadCategories(txtCategorySearch.Text.Trim());
            LoadSelectedCategory();
        }


        private void EditTopic(int topicId)
        {
            DataTable table = new DataTable();


            using (SqlConnection connection =
                new SqlConnection(connectionString))
            {
                string sql = @"
                    SELECT
                        ServiceTopicId,
                        ServiceCategoryId,
                        TopicName,
                        Description,
                        IsActive,
                        DisplayOrder
                    FROM ServiceTopics
                    WHERE ServiceTopicId = @TopicId;";


                using (SqlCommand command =
                    new SqlCommand(sql, connection))
                {
                    command.Parameters.Add(
                        "@TopicId",
                        SqlDbType.Int).Value = topicId;


                    using (SqlDataAdapter adapter =
                        new SqlDataAdapter(command))
                    {
                        adapter.Fill(table);
                    }
                }
            }


            if (table.Rows.Count == 0)
            {
                ShowMessage(
                    "موضوع موردنظر پیدا نشد.",
                    "error"
                );

                return;
            }


            DataRow row = table.Rows[0];


            EditTopicId = topicId;


            int categoryId =
                Convert.ToInt32(row["ServiceCategoryId"]);


            SelectedCategoryId = categoryId;


            LoadCategoryDropDown();


            if (ddlTopicCategory.Items.FindByValue(
                categoryId.ToString()) != null)
            {
                ddlTopicCategory.SelectedValue =
                    categoryId.ToString();
            }


            txtTopicName.Text =
                Convert.ToString(row["TopicName"]);

            txtTopicDescription.Text =
                Convert.ToString(row["Description"]);

            txtDisplayOrder.Text =
                Convert.ToString(row["DisplayOrder"]);

            chkTopicActive.Checked =
                Convert.ToBoolean(row["IsActive"]);


            lblTopicEditTitle.Text =
                "ویرایش موضوع خدمت";


            pnlTopicEdit.Visible = true;


            LoadCategories(txtCategorySearch.Text.Trim());
            LoadSelectedCategory();
        }


        private void ToggleTopic(int topicId)
        {
            using (SqlConnection connection =
                new SqlConnection(connectionString))
            {
                string sql = @"
                    UPDATE ServiceTopics
                    SET IsActive =
                        CASE
                            WHEN IsActive = 1 THEN 0
                            ELSE 1
                        END
                    WHERE ServiceTopicId = @TopicId;";


                using (SqlCommand command =
                    new SqlCommand(sql, connection))
                {
                    command.Parameters.Add(
                        "@TopicId",
                        SqlDbType.Int).Value = topicId;

                    connection.Open();

                    command.ExecuteNonQuery();
                }
            }


            ShowMessage(
                "وضعیت موضوع با موفقیت تغییر کرد.",
                "success"
            );


            LoadCategories(txtCategorySearch.Text.Trim());
            LoadSelectedCategory();
        }


        private int GetNextTopicOrder(int categoryId)
        {
            using (SqlConnection connection =
                new SqlConnection(connectionString))
            {
                string sql = @"
                    SELECT ISNULL(MAX(DisplayOrder), 0) + 1
                    FROM ServiceTopics
                    WHERE ServiceCategoryId = @CategoryId;";


                using (SqlCommand command =
                    new SqlCommand(sql, connection))
                {
                    command.Parameters.Add(
                        "@CategoryId",
                        SqlDbType.Int).Value = categoryId;

                    connection.Open();

                    return Convert.ToInt32(
                        command.ExecuteScalar());
                }
            }
        }


        private void ShowMessage(string message, string type)
        {
            lblMessage.Text = message;

            lblMessage.Visible = true;

            lblMessage.CssClass = "message";


            if (type == "success")
            {
                lblMessage.CssClass +=
                    " message-success";
            }
            else if (type == "warning")
            {
                lblMessage.CssClass +=
                    " message-warning";
            }
            else
            {
                lblMessage.CssClass +=
                    " message-error";
            }
        }


        protected string GetCategoryCss(int categoryId)
        {
            if (categoryId == SelectedCategoryId)
                return "category-item category-item-selected";

            return "category-item";
        }


        protected string GetActiveBadgeCss(bool isActive)
        {
            return isActive
                ? "badge badge-active"
                : "badge badge-inactive";
        }


        protected string GetActiveText(bool isActive)
        {
            return isActive
                ? "فعال"
                : "غیرفعال";
        }


        protected string GetToggleText(bool isActive)
        {
            return isActive
                ? "غیرفعال کردن"
                : "فعال کردن";
        }
    }
}