﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Web.UI;
using System.Web.UI.WebControls;
using WebApplication1.Models;
using Microsoft.AspNet.Identity.EntityFramework;

namespace WebApplication1
{
    public partial class Tickets : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Request.IsAuthenticated)
            {
                Response.Redirect("~/Login.aspx");
                return;
            }

            if (!User.IsInRole("Manager"))
            {
                Response.Redirect("~/Login.aspx");
                return;
            }

            if (!IsPostBack)
            {
                ViewState["StatusFilter"] = "All";
                ViewState["ViewFilter"] = "All";

                // شروع از صفحه اول
                gvTickets.PageIndex = 0;

                LoadSpecialists();
                LoadCounts();
                LoadTickets();

                SetStatusFilterStyle();
                SetViewFilterStyle();
            }
        }


        // =========================================================
        // بارگذاری کارشناسان
        // =========================================================

        private void LoadSpecialists()
        {
            string selectedValue = ddlSpecialist.SelectedValue;

            using (var db = new ApplicationDbContext())
            {
                var specialistRole = db.Roles
                    .FirstOrDefault(r => r.Name == "Specialist");

                ddlSpecialist.Items.Clear();

                ddlSpecialist.Items.Add(
                    new ListItem(
                        "همه کارشناسان",
                        ""));

                if (specialistRole == null)
                    return;

                var specialistIds = db.Set<Microsoft.AspNet.Identity.EntityFramework.IdentityUserRole>()
                    .Where(ur => ur.RoleId == specialistRole.Id)
                    .Select(ur => ur.UserId)
                    .ToList();

                var specialists = db.Users
                    .Where(u => specialistIds.Contains(u.Id))
                    .Select(u => new
                    {
                        u.Id,
                        u.UserName
                    })
                    .OrderBy(u => u.UserName)
                    .ToList();

                foreach (var specialist in specialists)
                {
                    string fullName = GetUserDisplayName(
                        db,
                        specialist.Id,
                        specialist.UserName);

                    ddlSpecialist.Items.Add(
                        new ListItem(
                            fullName,
                            specialist.Id));
                }

                if (!string.IsNullOrEmpty(selectedValue) &&
                    ddlSpecialist.Items.FindByValue(selectedValue) != null)
                {
                    ddlSpecialist.SelectedValue = selectedValue;
                }
            }
        }


        // =========================================================
        // نام نمایشی کاربر
        // =========================================================

        private string GetUserDisplayName(
            ApplicationDbContext db,
            string userId,
            string userName)
        {
            var profile = db.UserProfiles
                .FirstOrDefault(
                    p => p.UserId == userId);

            if (profile != null &&
                !string.IsNullOrEmpty(profile.FullName))
            {
                return profile.FullName;
            }

            return userName;
        }


        // =========================================================
        // شمارنده‌ها
        // =========================================================

        private void LoadCounts()
        {
            using (var db = new ApplicationDbContext())
            {
                lblNewCount.Text =
                    db.Tickets.Count(
                        t => t.Status == "New")
                    .ToString();

                lblAssignedCount.Text =
                    db.Tickets.Count(
                        t => t.Status == "Assigned")
                    .ToString();

                lblInProgressCount.Text =
                    db.Tickets.Count(
                        t => t.Status == "InProgress")
                    .ToString();

                lblWaitingCount.Text =
                    db.Tickets.Count(
                        t => t.Status == "WaitingConfirmation")
                    .ToString();

                lblClosedCount.Text =
                    db.Tickets.Count(
                        t => t.Status == "Closed")
                    .ToString();

                lblUnreadCount.Text =
                    db.Tickets.Count(
                        t => !t.ManagerViewed)
                    .ToString();
            }
        }


        // =========================================================
        // فیلتر وضعیت
        // =========================================================

        protected void StatusFilter_Command(
            object sender,
            CommandEventArgs e)
        {
            string status =
                e.CommandArgument == null
                    ? "All"
                    : e.CommandArgument.ToString();

            ViewState["StatusFilter"] = status;

            // با تغییر فیلتر، همیشه از صفحه اول شروع شود
            gvTickets.PageIndex = 0;

            LoadTickets();

            SetStatusFilterStyle();
            SetViewFilterStyle();
        }


        // =========================================================
        // فیلتر مشاهده
        // =========================================================

        protected void ViewFilter_Command(
            object sender,
            CommandEventArgs e)
        {
            string viewFilter =
                e.CommandArgument == null
                    ? "All"
                    : e.CommandArgument.ToString();

            ViewState["ViewFilter"] = viewFilter;

            // با تغییر فیلتر، همیشه از صفحه اول شروع شود
            gvTickets.PageIndex = 0;

            LoadTickets();

            SetStatusFilterStyle();
            SetViewFilterStyle();
        }


        // =========================================================
        // اعمال فیلترهای پیشرفته
        // =========================================================

        protected void btnApplyFilters_Click(
            object sender,
            EventArgs e)
        {
            // با اعمال فیلتر، از صفحه اول شروع شود
            gvTickets.PageIndex = 0;

            LoadTickets();

            SetStatusFilterStyle();
            SetViewFilterStyle();
        }


        // =========================================================
        // پاک کردن فیلترهای پیشرفته
        // =========================================================

        protected void btnClearFilters_Click(
            object sender,
            EventArgs e)
        {
            ddlSpecialist.SelectedIndex = 0;
            ddlCategory.SelectedIndex = 0;
            ddlPriority.SelectedIndex = 0;

            txtFromDate.Text = "";
            txtToDate.Text = "";

            ViewState["StatusFilter"] = "All";
            ViewState["ViewFilter"] = "All";

            // بعد از پاک کردن فیلترها
            // برگشت به صفحه اول
            gvTickets.PageIndex = 0;

            LoadTickets();

            SetStatusFilterStyle();
            SetViewFilterStyle();
        }


        // =========================================================
        // صفحه‌بندی GridView
        // =========================================================

      /*  protected void gvTickets_PageIndexChanging(
            object sender,
            GridViewPageEventArgs e)
        {
            // شماره صفحه جدید
            gvTickets.PageIndex = e.NewPageIndex;

            // بارگذاری مجدد اطلاعات
            // با همان فیلترهای فعلی
            LoadTickets();

            SetStatusFilterStyle();
            SetViewFilterStyle();
        }

        */
        // =========================================================
        // بارگذاری درخواست‌ها
        // =========================================================

        private void LoadTickets()
        {
            string statusFilter =
                ViewState["StatusFilter"] == null
                    ? "All"
                    : ViewState["StatusFilter"].ToString();

            string viewFilter =
                ViewState["ViewFilter"] == null
                    ? "All"
                    : ViewState["ViewFilter"].ToString();


            string specialistFilter =
                ddlSpecialist.SelectedValue;

            string categoryFilter =
                ddlCategory.SelectedValue;

            string priorityFilter =
                ddlPriority.SelectedValue;


            DateTime? fromDate =
                ParsePersianDate(txtFromDate.Text);

            DateTime? toDate =
                ParsePersianDate(txtToDate.Text);


            using (var db = new ApplicationDbContext())
            {
                var query =
                    db.Tickets.AsQueryable();


                // =================================================
                // وضعیت
                // =================================================

                if (statusFilter != "All")
                {
                    query =
                        query.Where(
                            t => t.Status == statusFilter);
                }


                // =================================================
                // خوانده شده / خوانده نشده
                // =================================================

                if (viewFilter == "Unread")
                {
                    query =
                        query.Where(
                            t => !t.ManagerViewed);
                }
                else if (viewFilter == "Read")
                {
                    query =
                        query.Where(
                            t => t.ManagerViewed);
                }


                // =================================================
                // کارشناس
                // =================================================

                if (!string.IsNullOrEmpty(
                    specialistFilter))
                {
                    query =
                        query.Where(
                            t =>
                                t.AssignedTo ==
                                specialistFilter);
                }


                // =================================================
                // دسته‌بندی
                // =================================================

                if (!string.IsNullOrEmpty(
                    categoryFilter))
                {
                    query =
                        query.Where(
                            t =>
                                t.Category ==
                                categoryFilter);
                }


                // =================================================
                // اولویت
                // =================================================

                if (!string.IsNullOrEmpty(
                    priorityFilter))
                {
                    query =
                        query.Where(
                            t =>
                                t.Priority ==
                                priorityFilter);
                }


                // =================================================
                // تاریخ شروع
                // =================================================

                if (fromDate.HasValue)
                {
                    DateTime startDate =
                        fromDate.Value.Date;

                    query =
                        query.Where(
                            t =>
                                t.CreatedAt >=
                                startDate);
                }


                // =================================================
                // تاریخ پایان
                // =================================================

                if (toDate.HasValue)
                {
                    DateTime endDate =
                        toDate.Value.Date.AddDays(1);

                    query =
                        query.Where(
                            t =>
                                t.CreatedAt <
                                endDate);
                }


                // =================================================
                // دریافت اطلاعات خام
                // =================================================

                var rawTickets =
                    query
                    .OrderByDescending(
                        t => t.CreatedAt)
                    .Select(
                        t => new
                        {
                            t.TicketId,
                            t.UserId,
                            t.Subject,
                            t.Category,
                            t.Priority,
                            t.Status,
                            t.CreatedAt,
                            t.ManagerViewed,

                            DepartmentName =
                                t.Department != null
                                    ? t.Department.DepartmentName
                                    : ""
                        })
                    .ToList();


                // =================================================
                // شناسه کاربران
                // =================================================

                var userIds =
                    rawTickets
                    .Select(
                        t => t.UserId)
                    .Where(
                        id =>
                            !string.IsNullOrEmpty(id))
                    .Distinct()
                    .ToList();


                // =================================================
                // پروفایل کاربران
                // =================================================

                var profiles =
                    db.UserProfiles
                    .Where(
                        p =>
                            userIds.Contains(
                                p.UserId))
                    .ToList()
                    .ToDictionary(
                        p => p.UserId,
                        p => p.FullName);


                // =================================================
                // کاربران Identity
                // =================================================

                var users =
                    db.Users
                    .Where(
                        u =>
                            userIds.Contains(
                                u.Id))
                    .ToList()
                    .ToDictionary(
                        u => u.Id,
                        u => u.UserName);


                // =================================================
                // تبدیل اطلاعات برای GridView
                // =================================================

                var tickets =
                    rawTickets
                    .Select(
                        t => new
                        {
                            t.TicketId,

                            RequesterName =
                                profiles.ContainsKey(
                                    t.UserId)
                                &&
                                !string.IsNullOrEmpty(
                                    profiles[t.UserId])
                                    ?
                                    profiles[t.UserId]
                                    :
                                    (
                                        users.ContainsKey(
                                            t.UserId)
                                        ?
                                        users[t.UserId]
                                        :
                                        "-"
                                    ),

                            t.DepartmentName,

                            t.Subject,

                            Category =
                                GetCategoryText(
                                    t.Category),

                            Priority =
                                GetPriorityText(
                                    t.Priority),

                            Status =
                                GetStatusText(
                                    t.Status),

                            CreatedAt =
                                t.CreatedAt.ToString(
                                    "yyyy/MM/dd HH:mm"),

                            ViewStatus =
                                t.ManagerViewed
                                    ? "خوانده شده"
                                    : "خوانده نشده",

                            IsViewed =
                                t.ManagerViewed
                        })
                    .ToList();


                // =================================================
                // تعداد کل نتایج
                // =================================================

                // توجه:
                // این تعداد کل درخواست‌های فیلترشده است
                // و به تعداد رکوردهای صفحه جاری محدود نمی‌شود.

                lblResultCount.Text =
                    tickets.Count.ToString();


                // =================================================
                // اطمینان از معتبر بودن PageIndex
                // =================================================

                int totalPages = 0;

                if (tickets.Count > 0)
                {
                    totalPages =
                        (int)Math.Ceiling(
                            (double)tickets.Count / gvTickets.PageSize);
                }

                if (totalPages == 0)
                {
                    gvTickets.PageIndex = 0;
                }
                else if (gvTickets.PageIndex >= totalPages)
                {
                    gvTickets.PageIndex =
                        totalPages - 1;
                }


                // =================================================
                // نمایش GridView
                // =================================================

                gvTickets.DataSource =
                    tickets;

                gvTickets.DataBind();
            }
        }


        // =========================================================
        // تبدیل تاریخ شمسی
        // =========================================================

        private DateTime? ParsePersianDate(
            string value)
        {
            if (string.IsNullOrWhiteSpace(value))
                return null;


            value = value.Trim()
                .Replace("-", "/")
                .Replace(".", "/");


            string[] parts =
                value.Split('/');


            if (parts.Length != 3)
                return null;


            int year;
            int month;
            int day;


            if (!int.TryParse(
                parts[0],
                out year))
            {
                return null;
            }


            if (!int.TryParse(
                parts[1],
                out month))
            {
                return null;
            }


            if (!int.TryParse(
                parts[2],
                out day))
            {
                return null;
            }


            try
            {
                PersianCalendar pc =
                    new PersianCalendar();


                return pc.ToDateTime(
                    year,
                    month,
                    day,
                    0,
                    0,
                    0,
                    0);
            }
            catch
            {
                return null;
            }
        }


        // =========================================================
        // RowDataBound
        // =========================================================



        protected void gvTickets_PageIndexChanging(object sender,
    GridViewPageEventArgs e)
        {
            gvTickets.PageIndex = e.NewPageIndex;
            LoadTickets();
        }




        protected void gvTickets_RowDataBound(
            object sender,
            GridViewRowEventArgs e)
        {
            if (e.Row.RowType !=
                DataControlRowType.DataRow)
            {
                return;
            }


            object viewedObject =
                DataBinder.Eval(
                    e.Row.DataItem,
                    "IsViewed");


            bool isViewed = false;


            if (viewedObject != null)
            {
                bool.TryParse(
                    viewedObject.ToString(),
                    out isViewed);
            }


            Label lblViewStatus =
                e.Row.FindControl(
                    "lblViewStatus") as Label;


            if (lblViewStatus == null)
                return;


            if (isViewed)
            {
                lblViewStatus.CssClass =
                    "tickets-view-status tickets-view-status-read";
            }
            else
            {
                lblViewStatus.CssClass =
                    "tickets-view-status tickets-view-status-unread";

                e.Row.CssClass =
                    "tickets-unread-row";
            }
        }


        // =========================================================
        // ظاهر فیلتر وضعیت
        // =========================================================

        private void SetStatusFilterStyle()
        {
            string filter =
                ViewState["StatusFilter"] == null
                    ? "All"
                    : ViewState["StatusFilter"].ToString();


            btnAll.CssClass =
                "tickets-filter-button";

            btnNew.CssClass =
                "tickets-filter-button";

            btnAssigned.CssClass =
                "tickets-filter-button";

            btnInProgress.CssClass =
                "tickets-filter-button";

            btnWaiting.CssClass =
                "tickets-filter-button";

            btnClosed.CssClass =
                "tickets-filter-button";


            switch (filter)
            {
                case "New":

                    btnNew.CssClass =
                        "tickets-filter-button tickets-filter-button-active";

                    break;


                case "Assigned":

                    btnAssigned.CssClass =
                        "tickets-filter-button tickets-filter-button-active";

                    break;


                case "InProgress":

                    btnInProgress.CssClass =
                        "tickets-filter-button tickets-filter-button-active";

                    break;


                case "WaitingConfirmation":

                    btnWaiting.CssClass =
                        "tickets-filter-button tickets-filter-button-active";

                    break;


                case "Closed":

                    btnClosed.CssClass =
                        "tickets-filter-button tickets-filter-button-active";

                    break;


                default:

                    btnAll.CssClass =
                        "tickets-filter-button tickets-filter-button-active";

                    break;
            }
        }


        // =========================================================
        // ظاهر فیلتر مشاهده
        // =========================================================

        private void SetViewFilterStyle()
        {
            string filter =
                ViewState["ViewFilter"] == null
                    ? "All"
                    : ViewState["ViewFilter"].ToString();


            btnViewAll.CssClass =
                "tickets-view-button";

            btnUnread.CssClass =
                "tickets-view-button";

            btnRead.CssClass =
                "tickets-view-button";


            switch (filter)
            {
                case "Unread":

                    btnUnread.CssClass =
                        "tickets-view-button tickets-view-button-active";

                    break;


                case "Read":

                    btnRead.CssClass =
                        "tickets-view-button tickets-view-button-active";

                    break;


                default:

                    btnViewAll.CssClass =
                        "tickets-view-button tickets-view-button-active";

                    break;
            }
        }


        // =========================================================
        // دسته‌بندی
        // =========================================================

        private string GetCategoryText(
            string category)
        {
            switch (category)
            {
                case "نرم‌افزار":
                    return "نرم‌افزار";

                case "سخت‌افزار":
                    return "سخت‌افزار";

                case "شبکه":
                    return "شبکه";

                case "امنیت":
                    return "امنیت";

                case "سایر":
                    return "سایر";

                default:
                    return category;
            }
        }


        // =========================================================
        // اولویت
        // =========================================================

        private string GetPriorityText(
            string priority)
        {
            switch (priority)
            {
                case "Low":
                    return "کم";

                case "Normal":
                    return "عادی";

                case "High":
                    return "زیاد";

                case "Critical":
                    return "بحرانی";

                default:
                    return priority;
            }
        }


        // =========================================================
        // وضعیت
        // =========================================================

        private string GetStatusText(
            string status)
        {
            switch (status)
            {
                case "New":
                    return "جدید";

                case "Assigned":
                    return "ارجاع شده";

                case "InProgress":
                    return "در حال انجام";

                case "WaitingConfirmation":
                    return "منتظر تأیید کاربر";

                case "Closed":
                    return "خاتمه یافته";

                default:
                    return status;
            }
        }
    }
}