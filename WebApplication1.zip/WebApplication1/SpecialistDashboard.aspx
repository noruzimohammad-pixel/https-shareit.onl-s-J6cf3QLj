﻿<%@ Page Title="داشبورد متخصص"
    Language="C#"
    MasterPageFile="~/Site.Master"
    AutoEventWireup="true"
    CodeBehind="SpecialistDashboard.aspx.cs"
    Inherits="WebApplication1.SpecialistDashboard" %>

<asp:Content ID="Content1"
    ContentPlaceHolderID="MainContent"
    runat="server">

    <style type="text/css">

        /* =========================================
           SPECIALIST DASHBOARD
           ========================================= */

        .specialist-filter-card {
            background: #ffffff;
            border: 1px solid #e8ebf0;
            border-radius: 12px;
            box-shadow: 0 3px 12px rgba(28, 39, 56, 0.04);
            margin-bottom: 24px;
            overflow: hidden;
        }

        .specialist-filter-header {
            min-height: 58px;
            padding: 0 20px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            border-bottom: 1px solid #edf0f4;
        }

        .specialist-filter-header h3 {
            margin: 0;
            font-size: 14px;
            color: #273142;
        }

        .specialist-filter-header span {
            color: #929baa;
            font-size: 10px;
        }

        .specialist-filter-buttons {
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
            padding: 16px 20px;
        }

        .specialist-filter-button {
            min-height: 38px;
            padding: 0 15px;
            border: 1px solid #dfe3e9;
            border-radius: 7px;
            background: #ffffff;
            color: #596477;
            cursor: pointer;
            font-family: inherit;
            font-size: 11px;
            font-weight: 500;
            transition: all 0.2s ease;
        }

        .specialist-filter-button:hover {
            background: #f4f7fb;
            border-color: #cfd6e0;
        }

        .specialist-filter-button-active {
            background: #2f80ed;
            border-color: #2f80ed;
            color: #ffffff;
        }

        .specialist-filter-button-active:hover {
            background: #1769d0;
            border-color: #1769d0;
        }


        /* =========================================
           TABLE
           ========================================= */

        .specialist-table-card {
            background: #ffffff;
            border: 1px solid #e8ebf0;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 3px 12px rgba(28, 39, 56, 0.04);
        }

        .specialist-table-header {
            min-height: 58px;
            padding: 0 20px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            border-bottom: 1px solid #edf0f4;
        }

        .specialist-table-header h3 {
            margin: 0;
            font-size: 14px;
            color: #273142;
        }

        .specialist-table-header span {
            color: #929baa;
            font-size: 10px;
        }

        .specialist-table-wrapper {
            width: 100%;
            overflow-x: auto;
        }

        .specialist-table {
            width: 100%;
            border-collapse: collapse;
            min-width: 850px;
        }

        .specialist-table th {
            background: #f8f9fb;
            color: #687386;
            font-size: 11px;
            font-weight: bold;
            padding: 14px 12px;
            text-align: right;
            border-bottom: 1px solid #e7eaf0;
        }

        .specialist-table td {
            padding: 14px 12px;
            font-size: 11px;
            color: #465164;
            border-bottom: 1px solid #eef0f3;
        }

        .specialist-table tr:last-child td {
            border-bottom: 0;
        }

        .specialist-table tr:hover td {
            background: #fafbfd;
        }


        /* =========================================
           TICKET LINK
           ========================================= */

        .ticket-link {
            color: #2f80ed;
            font-weight: bold;
            text-decoration: none;
        }

        .ticket-link:hover {
            color: #1769d0;
            text-decoration: underline;
        }


        /* =========================================
           STATUS
           ========================================= */

        .specialist-status {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            min-height: 25px;
            padding: 0 9px;
            border-radius: 20px;
            font-size: 10px;
            font-weight: bold;
            white-space: nowrap;
        }

        .status-assigned {
            background: #eaf2ff;
            color: #2f80ed;
        }

        .status-progress {
            background: #fff3df;
            color: #d6810c;
        }

        .status-waiting {
            background: #f0eaff;
            color: #7655d6;
        }

        .status-closed {
            background: #e8f8ef;
            color: #239653;
        }

        .status-new {
            background: #eef1f5;
            color: #697586;
        }


        /* =========================================
           EMPTY
           ========================================= */

        .empty-message {
            padding: 40px 20px;
            text-align: center;
            color: #929baa;
            font-size: 12px;
        }


        /* =========================================
           MOBILE
           ========================================= */

        @media screen and (max-width: 650px) {

            .specialist-filter-header {
                padding: 12px 15px;
                min-height: auto;
                flex-direction: column;
                align-items: flex-start;
                gap: 5px;
            }

            .specialist-filter-buttons {
                padding: 14px;
                gap: 7px;
            }

            .specialist-filter-button {
                flex: 1 1 calc(50% - 7px);
                min-height: 40px;
                padding: 0 8px;
                font-size: 10px;
            }

            .specialist-table-header {
                padding: 12px 15px;
                min-height: auto;
            }

        }

    </style>


    <!-- =========================================
         عنوان صفحه
         ========================================= -->

    <div class="page-header">

        <div>

            <h2>
                داشبورد متخصص
            </h2>

            <p>
                کارتابل درخواست‌های ارجاع‌شده به شما
            </p>

        </div>

    </div>


    <!-- =========================================
         فیلتر کارتابل + تعداد درخواست‌ها
         ========================================= -->

    <div class="specialist-filter-card">

        <div class="specialist-filter-header">

            <h3>
                فیلتر درخواست‌ها
            </h3>

            <span>
                وضعیت درخواست مورد نظر را انتخاب کنید
            </span>

        </div>


        <div class="specialist-filter-buttons">

            <asp:Button
                ID="btnAll"
                runat="server"
                CommandArgument="All"
                OnCommand="StatusFilter_Command"
                CssClass="specialist-filter-button" />


            <asp:Button
                ID="btnAssigned"
                runat="server"
                CommandArgument="Assigned"
                OnCommand="StatusFilter_Command"
                CssClass="specialist-filter-button" />


            <asp:Button
                ID="btnInProgress"
                runat="server"
                CommandArgument="InProgress"
                OnCommand="StatusFilter_Command"
                CssClass="specialist-filter-button" />


            <asp:Button
                ID="btnWaiting"
                runat="server"
                CommandArgument="WaitingConfirmation"
                OnCommand="StatusFilter_Command"
                CssClass="specialist-filter-button" />


            <asp:Button
                ID="btnClosed"
                runat="server"
                CommandArgument="Closed"
                OnCommand="StatusFilter_Command"
                CssClass="specialist-filter-button" />

        </div>

    </div>


    <!-- =========================================
         جدول کارتابل
         ========================================= -->

    <div class="specialist-table-card">

        <div class="specialist-table-header">

            <h3>
                درخواست‌های من
            </h3>

            <span>

                <asp:Label
                    ID="lblCurrentFilter"
                    runat="server"
                    Text="همه درخواست‌ها">
                </asp:Label>

            </span>

        </div>


        <div class="specialist-table-wrapper">

            <asp:GridView
                ID="gvTickets"
                runat="server"
                AutoGenerateColumns="False"
                CssClass="specialist-table"
                GridLines="None"
                EmptyDataText="درخواستی با این وضعیت وجود ندارد.">

                <Columns>

                    <asp:BoundField
                        DataField="TicketId"
                        HeaderText="شماره" />


                    <asp:TemplateField
                        HeaderText="موضوع">

                        <ItemTemplate>

                            <asp:HyperLink
                                ID="lnkSubject"
                                runat="server"
                                NavigateUrl='<%# "SpecialistTicketDetails.aspx?id=" + Eval("TicketId") %>'
                                Text='<%# Eval("Subject") %>'
                                CssClass="ticket-link">
                            </asp:HyperLink>

                        </ItemTemplate>

                    </asp:TemplateField>


                    <asp:BoundField
                        DataField="Category"
                        HeaderText="دسته‌بندی" />


                    <asp:BoundField
                        DataField="Priority"
                        HeaderText="اولویت" />


                    <asp:TemplateField
                        HeaderText="وضعیت">

                        <ItemTemplate>

                            <span class='<%# GetStatusCssClass(Eval("StatusValue").ToString()) %>'>

                                <%# Eval("Status") %>

                            </span>

                        </ItemTemplate>

                    </asp:TemplateField>


                    <asp:BoundField
                        DataField="CreatedAt"
                        HeaderText="تاریخ ثبت" />


                    <asp:TemplateField
                        HeaderText="عملیات">

                        <ItemTemplate>

                            <asp:HyperLink
                                ID="lnkDetails"
                                runat="server"
                                NavigateUrl='<%# "SpecialistTicketDetails.aspx?id=" + Eval("TicketId") %>'
                                Text="مشاهده جزئیات"
                                CssClass="btn btn-primary btn-small">
                            </asp:HyperLink>

                        </ItemTemplate>

                    </asp:TemplateField>

                </Columns>

                <EmptyDataRowStyle
                    CssClass="empty-message" />

            </asp:GridView>

        </div>

    </div>

</asp:Content>