﻿using System;
using System.Linq;
using System.Web.UI;
using Microsoft.AspNet.Identity;
using WebApplication1.Models;

namespace WebApplication1
{
    public partial class TicketDetails : System.Web.UI.Page
    {
        private int TicketId
        {
            get
            {
                int id;

                if (int.TryParse(
                    Request.QueryString["id"],
                    out id))
                {
                    return id;
                }

                return 0;
            }
        }


        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Request.IsAuthenticated)
            {
                Response.Redirect("~/Login.aspx");
                return;
            }

            if (!User.IsInRole("Manager"))
            {
                Response.Redirect("~/Login.aspx");
                return;
            }

            if (TicketId <= 0)
            {
                Response.Redirect("~/Tickets.aspx");
                return;
            }

            if (!IsPostBack)
            {
                MarkTicketAsViewed();

                LoadTicket();

                LoadSpecialists();

                LoadHistory();
            }
        }


        private void MarkTicketAsViewed()
        {
            using (var db = new ApplicationDbContext())
            {
                var ticket =
                    db.Tickets.FirstOrDefault(
                        t => t.TicketId == TicketId);

                if (ticket == null)
                {
                    Response.Redirect("~/Tickets.aspx");
                    return;
                }

                if (!ticket.ManagerViewed)
                {
                    ticket.ManagerViewed = true;
                    ticket.ManagerViewedAt =
                        DateTime.Now;

                    db.SaveChanges();
                }
            }
        }


        private void LoadTicket()
        {
            using (var db = new ApplicationDbContext())
            {
                var ticket =
                    db.Tickets.FirstOrDefault(
                        t => t.TicketId == TicketId);

                if (ticket == null)
                {
                    Response.Redirect("~/Tickets.aspx");
                    return;
                }

                lblTicketId.Text =
                    ticket.TicketId.ToString();

                lblSubject.Text =
                    ticket.Subject;

                lblDescription.Text =
                    ticket.Description;

                lblCategory.Text =
                    GetCategoryText(ticket.Category);

                lblPriority.Text =
                    GetPriorityText(ticket.Priority);

                lblStatus.Text =
                    GetStatusText(ticket.Status);

                lblCreatedAt.Text =
                    ticket.CreatedAt.ToString(
                        "yyyy/MM/dd HH:mm");


                ddlPriority.SelectedValue =
                    ticket.Priority;

                ddlStatus.SelectedValue =
                    ticket.Status;
            }
        }


        private void LoadSpecialists()
        {
            using (var db = new ApplicationDbContext())
            {
                var ticket =
                    db.Tickets.FirstOrDefault(
                        t => t.TicketId == TicketId);

                if (ticket == null)
                    return;


                var specialistIds =
                    (from u in db.Users
                     join p in db.UserProfiles
                     on u.Id equals p.UserId
                     where p.IsActive
                     select u.Id)
                    .ToList();


                var userManager =
                    new Microsoft.AspNet.Identity.UserManager<
                        ApplicationUser>(
                        new Microsoft.AspNet.Identity.EntityFramework.UserStore<
                            ApplicationUser>(db));


                var specialists =
                    specialistIds
                    .Where(id =>
                        userManager.IsInRole(
                            id,
                            "Specialist"))
                    .ToList();


                var list =
                    specialists
                    .Select(id =>
                    {
                        var user =
                            db.Users.FirstOrDefault(
                                u => u.Id == id);

                        var profile =
                            db.UserProfiles.FirstOrDefault(
                                p => p.UserId == id);

                        return new
                        {
                            Id = id,

                            Name =
                                profile != null &&
                                !string.IsNullOrEmpty(
                                    profile.FullName)
                                    ? profile.FullName
                                    : user.UserName
                        };
                    })
                    .OrderBy(x => x.Name)
                    .ToList();


                ddlSpecialist.Items.Clear();

                ddlSpecialist.Items.Add(
                    new System.Web.UI.WebControls.ListItem(
                        "-- انتخاب متخصص --",
                        ""));


                foreach (var item in list)
                {
                    ddlSpecialist.Items.Add(
                        new System.Web.UI.WebControls.ListItem(
                            item.Name,
                            item.Id));
                }


                if (!string.IsNullOrEmpty(
                    ticket.AssignedTo))
                {
                    var existing =
                        ddlSpecialist.Items.FindByValue(
                            ticket.AssignedTo);

                    if (existing != null)
                    {
                        ddlSpecialist.SelectedValue =
                            ticket.AssignedTo;
                    }
                }
            }
        }


        private void LoadHistory()
        {
            using (var db = new ApplicationDbContext())
            {
                var history =
                    db.TicketHistory
                    .Where(h =>
                        h.TicketId == TicketId)
                    .OrderByDescending(
                        h => h.HistoryDate)
                    .ToList()
                    .Select(h => new
                    {
                        h.HistoryId,

                        HistoryDate =
                            h.HistoryDate.ToString(
                                "yyyy/MM/dd HH:mm"),

                        UserName =
                            GetHistoryUserName(
                                db,
                                h.UserId),

                        OldStatus =
                            GetStatusText(
                                h.OldStatus),

                        NewStatus =
                            GetStatusText(
                                h.NewStatus),

                        h.Description
                    })
                    .ToList();


                gvHistory.DataSource =
                    history;

                gvHistory.DataBind();
            }
        }


        private string GetHistoryUserName(
            ApplicationDbContext db,
            string userId)
        {
            if (string.IsNullOrEmpty(userId))
                return "سیستم";


            var profile =
                db.UserProfiles.FirstOrDefault(
                    p => p.UserId == userId);

            if (profile != null &&
                !string.IsNullOrEmpty(
                    profile.FullName))
            {
                return profile.FullName;
            }


            var user =
                db.Users.FirstOrDefault(
                    u => u.Id == userId);

            if (user != null &&
                !string.IsNullOrEmpty(
                    user.UserName))
            {
                return user.UserName;
            }

            return "نامشخص";
        }


        protected void btnAssign_Click(
            object sender,
            EventArgs e)
        {
            if (string.IsNullOrEmpty(
                ddlSpecialist.SelectedValue))
            {
                ShowError(
                    "لطفاً متخصص را انتخاب کنید.");
                return;
            }


            string currentUserId =
                User.Identity.GetUserId();

            string specialistId =
                ddlSpecialist.SelectedValue;


            using (var db =
                new ApplicationDbContext())
            {
                var ticket =
                    db.Tickets.FirstOrDefault(
                        t => t.TicketId == TicketId);

                if (ticket == null)
                {
                    ShowError(
                        "درخواست پیدا نشد.");
                    return;
                }


                var userManager =
                    new Microsoft.AspNet.Identity.UserManager<
                        ApplicationUser>(
                        new Microsoft.AspNet.Identity.EntityFramework.UserStore<
                            ApplicationUser>(db));


                var specialist =
                    userManager.FindById(
                        specialistId);

                if (specialist == null ||
                    !userManager.IsInRole(
                        specialistId,
                        "Specialist"))
                {
                    ShowError(
                        "متخصص انتخاب‌شده معتبر نیست.");
                    return;
                }


                string oldStatus =
                    ticket.Status;


                string oldAssignedTo =
                    ticket.AssignedTo;


                // غیرفعال کردن ارجاع قبلی
                var previousAssignments =
                    db.TicketAssignments
                    .Where(a =>
                        a.TicketId == TicketId &&
                        a.IsCurrent)
                    .ToList();


                foreach (var item
                    in previousAssignments)
                {
                    item.IsCurrent = false;
                }


                ticket.Priority =
                    ddlPriority.SelectedValue;

                ticket.AssignedTo =
                    specialistId;

                ticket.AssignedAt =
                    DateTime.Now;

                ticket.Status =
                    "Assigned";


                var assignment =
                    new TicketAssignment
                    {
                        TicketId =
                            TicketId,

                        AssignedBy =
                            currentUserId,

                        AssignedTo =
                            specialistId,

                        AssignmentDate =
                            DateTime.Now,

                        Note =
                            txtAssignmentNote.Text.Trim(),

                        IsCurrent =
                            true
                    };


                db.TicketAssignments.Add(
                    assignment);


                var history =
                    new TicketHistory
                    {
                        TicketId =
                            TicketId,

                        UserId =
                            currentUserId,

                        OldStatus =
                            oldStatus,

                        NewStatus =
                            "Assigned",

                        Description =
                            string.IsNullOrEmpty(
                                txtAssignmentNote.Text.Trim())
                                ? "درخواست به متخصص ارجاع شد."
                                : "درخواست به متخصص ارجاع شد: " +
                                  txtAssignmentNote.Text.Trim(),

                        HistoryDate =
                            DateTime.Now
                    };


                db.TicketHistory.Add(
                    history);


                db.SaveChanges();
            }


            ShowSuccess(
                "درخواست با موفقیت به متخصص ارجاع شد.");


            LoadTicket();

            LoadSpecialists();

            LoadHistory();

            txtAssignmentNote.Text = "";
        }


        protected void btnChangeStatus_Click(
            object sender,
            EventArgs e)
        {
            string newStatus =
                ddlStatus.SelectedValue;


            using (var db =
                new ApplicationDbContext())
            {
                var ticket =
                    db.Tickets.FirstOrDefault(
                        t => t.TicketId == TicketId);

                if (ticket == null)
                {
                    ShowError(
                        "درخواست پیدا نشد.");
                    return;
                }


                if (ticket.Status == newStatus)
                {
                    ShowError(
                        "وضعیت انتخاب‌شده با وضعیت فعلی یکسان است.");
                    return;
                }


                string oldStatus =
                    ticket.Status;


                ticket.Status =
                    newStatus;


                if (newStatus == "InProgress")
                {
                    if (!ticket.AssignedAt.HasValue)
                    {
                        ticket.AssignedAt =
                            DateTime.Now;
                    }
                }


                if (newStatus == "Closed")
                {
                    ticket.ClosedAt =
                        DateTime.Now;
                }
                else
                {
                    ticket.ClosedAt =
                        null;
                }


                var note =
                    txtStatusNote.Text.Trim();


                var description =
                    string.IsNullOrEmpty(note)
                        ? "وضعیت درخواست توسط مدیر تغییر کرد."
                        : "وضعیت درخواست توسط مدیر تغییر کرد: " +
                          note;


                var history =
                    new TicketHistory
                    {
                        TicketId =
                            TicketId,

                        UserId =
                            User.Identity.GetUserId(),

                        OldStatus =
                            oldStatus,

                        NewStatus =
                            newStatus,

                        Description =
                            description,

                        HistoryDate =
                            DateTime.Now
                    };


                db.TicketHistory.Add(
                    history);


                db.SaveChanges();
            }


            ShowSuccess(
                "وضعیت درخواست با موفقیت تغییر کرد.");


            LoadTicket();

            LoadHistory();

            txtStatusNote.Text = "";
        }


        private void ShowSuccess(
            string message)
        {
            lblMessage.Text =
                message;

            lblMessage.CssClass =
                "message message-success";

            lblMessage.Visible =
                true;
        }


        private void ShowError(
            string message)
        {
            lblMessage.Text =
                message;

            lblMessage.CssClass =
                "message message-error";

            lblMessage.Visible =
                true;
        }


        private string GetCategoryText(
            string category)
        {
            switch (category)
            {
                case "نرم‌افزار":
                    return "نرم‌افزار";

                case "سخت‌افزار":
                    return "سخت‌افزار";

                case "شبکه":
                    return "شبکه";

                case "امنیت":
                    return "امنیت";

                case "سایر":
                    return "سایر";

                default:
                    return category;
            }
        }


        private string GetPriorityText(
            string priority)
        {
            switch (priority)
            {
                case "Low":
                    return "کم";

                case "Normal":
                    return "عادی";

                case "High":
                    return "زیاد";

                case "Critical":
                    return "بحرانی";

                default:
                    return priority;
            }
        }


        private string GetStatusText(
            string status)
        {
            switch (status)
            {
                case "New":
                    return "جدید";

                case "Assigned":
                    return "ارجاع شده";

                case "InProgress":
                    return "در حال انجام";

                case "WaitingConfirmation":
                    return "منتظر تأیید کاربر";

                case "Closed":
                    return "خاتمه یافته";

                default:
                    return string.IsNullOrEmpty(status)
                        ? "-"
                        : status;
            }
        }
    }
}