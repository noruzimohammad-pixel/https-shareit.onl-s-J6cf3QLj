﻿using System;
using System.Configuration;
using WebApplication1.Helpers;

namespace WebApplication1.Maintenance
{
    public partial class AutoClose : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                string configuredToken =
     ConfigurationManager.AppSettings["AutoCloseToken"];

                string requestToken =
                    Request.Headers["X-AutoClose-Token"];

                if (string.IsNullOrEmpty(requestToken))
                {
                    requestToken =
                        Request.QueryString["token"];
                }

                if (string.IsNullOrEmpty(configuredToken))
                {
                    Response.StatusCode = 500;
                    lblResult.Text = "AutoCloseToken در Web.config تنظیم نشده است.";
                    return;
                }

                if (string.IsNullOrEmpty(requestToken) ||
                    requestToken != configuredToken)
                {
                    Response.StatusCode = 403;
                    lblResult.Text = "دسترسی غیرمجاز.";
                    return;
                }
                int closedCount =
                    TicketAutoCloseService.ProcessAutoClose();

                lblResult.Text =
                    "عملیات با موفقیت انجام شد. تعداد درخواست‌های خاتمه‌یافته: "
                    + closedCount.ToString();

                Response.StatusCode = 200;
            }
            catch (Exception ex)
            {
                Response.StatusCode = 500;

                lblResult.Text =
                    "خطا در اجرای عملیات: " +
                    Server.HtmlEncode(ex.Message);
            }
        }
    }
}