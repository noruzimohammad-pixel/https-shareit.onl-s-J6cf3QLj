﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="AutoClose.aspx.cs" Inherits="WebApplication1.Maintenance.AutoClose" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>Auto Close</title>
</head>
<body>
    <form id="form1" runat="server">
        <asp:Label ID="lblResult" runat="server"></asp:Label>
    </form>
</body>
</html>