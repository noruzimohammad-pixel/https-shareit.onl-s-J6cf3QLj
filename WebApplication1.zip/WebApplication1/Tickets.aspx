﻿<%@ Page Title="مدیریت درخواست‌ها"
    Language="C#"
    MasterPageFile="~/Site.Master"
    AutoEventWireup="true"
    CodeBehind="Tickets.aspx.cs"
    Inherits="WebApplication1.Tickets" %>

<asp:Content ID="Content1"
    ContentPlaceHolderID="MainContent"
    runat="server">

    <div class="tickets-page">

        <!-- =====================================================
             HEADER
             ===================================================== -->

        <div class="tickets-page-header">

            <div class="tickets-page-title">

                <h2>مدیریت درخواست‌ها</h2>

                <p>
                    مشاهده، بررسی و مدیریت درخواست‌های ثبت‌شده
                </p>

            </div>


            <asp:HyperLink
                ID="lnkCreateTicket"
                runat="server"
                NavigateUrl="~/CreateTicket.aspx"
                CssClass="tickets-create-button">

                + ثبت درخواست جدید

            </asp:HyperLink>

        </div>


        <!-- =====================================================
             FILTER CARD
             ===================================================== -->

        <div class="tickets-filter-card">

            <div class="tickets-filter-title">
                فیلتر درخواست‌ها
            </div>


            <!-- =================================================
                 STATUS FILTER
                 ================================================= -->

            <div class="filter-section">

                <div class="filter-section-title">
                    وضعیت درخواست
                </div>


                <div class="tickets-filter-buttons">


                  

                    <div class="ticket-filter-item">

                        <asp:Button
                            ID="btnAll"
                            runat="server"
                            Text="همه"
                            CommandArgument="All"
                            OnCommand="StatusFilter_Command"
                            CssClass="tickets-filter-button" />

                    </div>


              

                    <div class="ticket-filter-item">

                        <asp:Button
                            ID="btnNew"
                            runat="server"
                            Text="جدید"
                            CommandArgument="New"
                            OnCommand="StatusFilter_Command"
                            CssClass="tickets-filter-button" />

                        <asp:Label
                            ID="lblNewCount"
                            runat="server"
                            CssClass="tickets-count" />

                    </div>


                

                    <div class="ticket-filter-item">

                        <asp:Button
                            ID="btnAssigned"
                            runat="server"
                            Text="ارجاع شده"
                            CommandArgument="Assigned"
                            OnCommand="StatusFilter_Command"
                            CssClass="tickets-filter-button" />

                        <asp:Label
                            ID="lblAssignedCount"
                            runat="server"
                            CssClass="tickets-count" />

                    </div>


                  
                    <div class="ticket-filter-item">

                        <asp:Button
                            ID="btnInProgress"
                            runat="server"
                            Text="در حال انجام"
                            CommandArgument="InProgress"
                            OnCommand="StatusFilter_Command"
                            CssClass="tickets-filter-button" />

                        <asp:Label
                            ID="lblInProgressCount"
                            runat="server"
                            CssClass="tickets-count" />

                    </div>


                
                    <div class="ticket-filter-item">

                        <asp:Button
                            ID="btnWaiting"
                            runat="server"
                            Text="منتظر تأیید"
                            CommandArgument="WaitingConfirmation"
                            OnCommand="StatusFilter_Command"
                            CssClass="tickets-filter-button" />

                        <asp:Label
                            ID="lblWaitingCount"
                            runat="server"
                            CssClass="tickets-count" />

                    </div>


                 

                    <div class="ticket-filter-item">

                        <asp:Button
                            ID="btnClosed"
                            runat="server"
                            Text="خاتمه یافته"
                            CommandArgument="Closed"
                            OnCommand="StatusFilter_Command"
                            CssClass="tickets-filter-button" />

                        <asp:Label
                            ID="lblClosedCount"
                            runat="server"
                            CssClass="tickets-count" />

                    </div>


                </div>

            </div>


            <div class="tickets-separator"></div>


            <!-- =================================================
                 VIEW FILTER
                 ================================================= -->

            <div class="tickets-view-filter">

                <span class="tickets-view-title">
                    نمایش:
                </span>


                <asp:Button
                    ID="btnViewAll"
                    runat="server"
                    Text="همه"
                    CommandArgument="All"
                    OnCommand="ViewFilter_Command"
                    CssClass="tickets-view-button" />


                <asp:Button
                    ID="btnUnread"
                    runat="server"
                    Text="خوانده نشده"
                    CommandArgument="Unread"
                    OnCommand="ViewFilter_Command"
                    CssClass="tickets-view-button" />


                <asp:Label
                    ID="lblUnreadCount"
                    runat="server"
                    CssClass="tickets-view-count" />


                <asp:Button
                    ID="btnRead"
                    runat="server"
                    Text="خوانده شده"
                    CommandArgument="Read"
                    OnCommand="ViewFilter_Command"
                    CssClass="tickets-view-button" />

            </div>


            <div class="tickets-separator"></div>


            <!-- =================================================
                 ADVANCED FILTER HEADER
                 ================================================= -->

            <div class="advanced-filter-header">

                <button
                    type="button"
                    class="advanced-filter-toggle"
                    onclick="toggleAdvancedFilters(); return false;">

                    <span class="advanced-filter-toggle-title">
                        فیلترهای پیشرفته
                    </span>

                    <span
                        id="advancedFilterArrow"
                        class="advanced-filter-arrow">
                        ▼
                    </span>

                </button>

            </div>


            <!-- =================================================
                 ADVANCED FILTERS
                 ================================================= -->

            <div
                id="advancedFilterPanel"
                class="advanced-filter-section">


                <div class="advanced-filter-grid">


                    <!-- SPECIALIST -->

                    <div class="filter-field">

                        <label>
                            کارشناس
                        </label>

                        <asp:DropDownList
                            ID="ddlSpecialist"
                            runat="server"
                            CssClass="tickets-filter-select">

                            <asp:ListItem
                                Text="همه کارشناسان"
                                Value="" />

                        </asp:DropDownList>

                    </div>


             

                    <div class="filter-field">

                        <label>
                            دسته‌بندی
                        </label>

                        <asp:DropDownList
                            ID="ddlCategory"
                            runat="server"
                            CssClass="tickets-filter-select">

                            <asp:ListItem
                                Text="همه دسته‌بندی‌ها"
                                Value="" />

                            <asp:ListItem
                                Text="نرم‌افزار"
                                Value="نرم‌افزار" />

                            <asp:ListItem
                                Text="سخت‌افزار"
                                Value="سخت‌افزار" />

                            <asp:ListItem
                                Text="شبکه"
                                Value="شبکه" />

                            <asp:ListItem
                                Text="امنیت"
                                Value="امنیت" />

                            <asp:ListItem
                                Text="سایر"
                                Value="سایر" />

                        </asp:DropDownList>

                    </div>


                    <!-- PRIORITY -->

                    <div class="filter-field">

                        <label>
                            اولویت
                        </label>

                        <asp:DropDownList
                            ID="ddlPriority"
                            runat="server"
                            CssClass="tickets-filter-select">

                            <asp:ListItem
                                Text="همه اولویت‌ها"
                                Value="" />

                            <asp:ListItem
                                Text="کم"
                                Value="Low" />

                            <asp:ListItem
                                Text="عادی"
                                Value="Normal" />

                            <asp:ListItem
                                Text="زیاد"
                                Value="High" />

                            <asp:ListItem
                                Text="بحرانی"
                                Value="Critical" />

                        </asp:DropDownList>

                    </div>


             
                    <div class="filter-field">

                        <label>
                            از تاریخ
                        </label>

                        <asp:TextBox
                            ID="txtFromDate"
                            runat="server"
                            CssClass="tickets-filter-input"
                            placeholder="مثلاً 1405/06/01" />

                    </div>


                  

                    <div class="filter-field">

                        <label>
                            تا تاریخ
                        </label>

                        <asp:TextBox
                            ID="txtToDate"
                            runat="server"
                            CssClass="tickets-filter-input"
                            placeholder="مثلاً 1405/06/31" />

                    </div>


                </div>


              

                <div class="advanced-filter-actions">

                    <asp:Button
                        ID="btnApplyFilters"
                        runat="server"
                        Text="اعمال فیلتر"
                        CssClass="tickets-apply-button"
                        OnClick="btnApplyFilters_Click" />


                    <asp:Button
                        ID="btnClearFilters"
                        runat="server"
                        Text="پاک کردن فیلترها"
                        CssClass="tickets-clear-button"
                        OnClick="btnClearFilters_Click"
                        CausesValidation="false" />

                </div>


            </div>

        </div>


        <!-- =====================================================
             TICKETS LIST
             ===================================================== -->

        <div class="tickets-list-card">


            <div class="tickets-list-header">

                <div>

                    <h3>
                        فهرست درخواست‌ها
                    </h3>

                    <span>
                        درخواست‌های ثبت‌شده در سامانه
                    </span>

                </div>


                <div class="tickets-result-count">

                    تعداد نتایج:

                    <asp:Label
                        ID="lblResultCount"
                        runat="server"
                        Text="0" />

                </div>

            </div>


            <!-- =================================================
                 TABLE
                 ================================================= -->

            <div class="tickets-table-container">

              
                    <asp:GridView
    ID="gvTickets"
    runat="server"
    AutoGenerateColumns="False"
    GridLines="None"
    CssClass="tickets-grid"
    OnRowDataBound="gvTickets_RowDataBound"
    OnPageIndexChanging="gvTickets_PageIndexChanging"
    AllowPaging="true"
    PageSize="10"
    EmptyDataText="درخواستی با این فیلترها وجود ندارد.">

                    <Columns>


                   
                        <asp:BoundField
                            DataField="TicketId"
                            HeaderText="شماره" />


                    

                        <asp:BoundField
                            DataField="RequesterName"
                            HeaderText="درخواست‌کننده" />


                      
                        <asp:BoundField
                            DataField="DepartmentName"
                            HeaderText="واحد" />


                   
                        <asp:BoundField
                            DataField="Subject"
                            HeaderText="موضوع" />


                      
                        <asp:BoundField
                            DataField="Category"
                            HeaderText="دسته‌بندی" />


                     

                        <asp:BoundField
                            DataField="Priority"
                            HeaderText="اولویت" />


                     
                        <asp:BoundField
                            DataField="Status"
                            HeaderText="وضعیت" />


                     
                        <asp:BoundField
                            DataField="CreatedAt"
                            HeaderText="تاریخ ثبت" />


                   

                        <asp:TemplateField
                            HeaderText="وضعیت مشاهده">

                            <ItemTemplate>

                                <asp:Label
                                    ID="lblViewStatus"
                                    runat="server"
                                    Text='<%# Eval("ViewStatus") %>'
                                    CssClass="tickets-view-status" />

                            </ItemTemplate>

                        </asp:TemplateField>


                        <asp:HyperLinkField
                            Text="مشاهده جزئیات"
                            DataNavigateUrlFields="TicketId"
                            DataNavigateUrlFormatString="TicketDetails.aspx?id={0}"
                            HeaderText="عملیات"
                            ItemStyle-CssClass="tickets-details-link" />


                    </Columns>


                    <EmptyDataRowStyle
                        CssClass="tickets-empty-row" />


                </asp:GridView>

            </div>

        </div>

    </div>


    <!-- =========================================================
         CSS
         ========================================================= -->

    <style type="text/css">


        /* =====================================================
           PAGE
           ===================================================== */

        .tickets-page {
            width: 100%;
            box-sizing: border-box;
        }


        /* =====================================================
           HEADER
           ===================================================== */

        .tickets-page-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 20px;
        }


        .tickets-page-title h2 {
            margin: 0 0 5px 0;
            padding: 0;

            color: #273142;

            font-size: 21px;
            font-weight: bold;
            line-height: 30px;
        }


        .tickets-page-title p {
            margin: 0;
            padding: 0;

            color: #9aa2ad;

            font-size: 11px;
            line-height: 18px;
        }


        /* =====================================================
           CREATE BUTTON
           ===================================================== */

        .tickets-create-button {
            display: inline-block;

            padding: 10px 17px;

            background: #176b78;

            border: 1px solid #176b78;
            border-radius: 7px;

            color: #ffffff !important;

            text-decoration: none !important;

            font-family: Tahoma, Arial, sans-serif;
            font-size: 12px;
            line-height: 18px;
        }


        .tickets-create-button:hover {
            background: #125b67;
            border-color: #125b67;
        }


        /* =====================================================
           FILTER CARD
           ===================================================== */

        .tickets-filter-card {
            width: 100%;

            background: #ffffff;

            border: 1px solid #e7ebef;
            border-radius: 12px;

            padding: 20px;
            margin-bottom: 20px;

            box-shadow: 0 3px 12px rgba(28,39,56,.04);

            box-sizing: border-box;
        }


        .tickets-filter-title {
            display: block;

            margin-bottom: 18px;

            color: #273142;

            font-family: Tahoma, Arial, sans-serif;

            font-size: 14px;
            font-weight: bold;

            line-height: 20px;
        }


        .filter-section-title {
            display: block;

            margin-bottom: 12px;

            color: #687181;

            font-family: Tahoma, Arial, sans-serif;

            font-size: 11px;
            font-weight: bold;
        }


        /* =====================================================
           STATUS FILTERS
           ===================================================== */

        .tickets-filter-buttons {
            display: flex;

            align-items: center;
            justify-content: flex-start;

            flex-wrap: wrap;

            gap: 8px;

            width: 100%;
        }


        .ticket-filter-item {
            display: flex;

            align-items: center;

            width: auto;
            height: 38px;
        }


        .tickets-filter-button {
            display: inline-block !important;

            width: auto !important;
            min-width: 78px !important;

            height: 38px !important;

            padding: 0 13px !important;
            margin: 0 !important;

            box-sizing: border-box !important;

            background: #ffffff !important;

            border: 1px solid #dfe4e9 !important;
            border-radius: 7px !important;

            color: #596273 !important;

            font-family: Tahoma, Arial, sans-serif !important;

            font-size: 12px !important;
            font-weight: normal !important;

            line-height: 36px !important;

            text-align: center !important;
            text-decoration: none !important;

            cursor: pointer !important;

            outline: none !important;

            opacity: 1 !important;
            visibility: visible !important;
        }


        .tickets-filter-button:hover {
            background: #f3f8f9 !important;

            border-color: #176b78 !important;

            color: #176b78 !important;
        }


        .tickets-filter-button-active {
            background: #176b78 !important;

            border-color: #176b78 !important;

            color: #ffffff !important;
        }


        .tickets-filter-button-active:hover {
            background: #125b67 !important;

            border-color: #125b67 !important;

            color: #ffffff !important;
        }


        /* =====================================================
           COUNT
           ===================================================== */

        .tickets-count {
            display: inline-flex;

            align-items: center;
            justify-content: center;

            min-width: 20px;
            height: 22px;

            margin-right: 5px;
            padding: 0 4px;

            background: #f0f2f4;

            border-radius: 5px;

            color: #66707e;

            font-family: Tahoma, Arial, sans-serif;

            font-size: 10px;
            font-weight: bold;

            line-height: 22px;

            box-sizing: border-box;
        }


        /* =====================================================
           SEPARATOR
           ===================================================== */

        .tickets-separator {
            width: 100%;
            height: 1px;

            margin: 18px 0 15px;

            background: #edf0f3;
        }


        /* =====================================================
           VIEW FILTER
           ===================================================== */

        .tickets-view-filter {
            display: flex;

            align-items: center;

            flex-wrap: wrap;

            gap: 7px;
        }


        .tickets-view-title {
            color: #7b8492;

            font-family: Tahoma, Arial, sans-serif;

            font-size: 12px;
        }


        .tickets-view-button {
            display: inline-block !important;

            width: auto !important;
            min-width: 60px !important;

            height: 32px !important;

            padding: 0 11px !important;
            margin: 0 !important;

            background: #f4f5f7 !important;

            border: 1px solid transparent !important;
            border-radius: 6px !important;

            color: #687181 !important;

            font-family: Tahoma, Arial, sans-serif !important;

            font-size: 11px !important;

            line-height: 30px !important;

            text-align: center !important;

            cursor: pointer !important;

            outline: none !important;

            box-sizing: border-box !important;
        }


        .tickets-view-button:hover {
            background: #e7f2f4 !important;

            color: #176b78 !important;
        }


        .tickets-view-button-active {
            background: #e7f2f4 !important;

            border-color: #d6e9ec !important;

            color: #176b78 !important;
        }


        .tickets-view-count {
            display: inline-flex;

            align-items: center;
            justify-content: center;

            min-width: 20px;
            height: 22px;

            margin-right: -3px;
            padding: 0 5px;

            background: #fff0d8;

            border-radius: 5px;

            color: #a96900;

            font-family: Tahoma, Arial, sans-serif;

            font-size: 10px;
            font-weight: bold;

            line-height: 22px;
        }


        /* =====================================================
           ADVANCED FILTER HEADER
           ===================================================== */

        .advanced-filter-header {
            width: 100%;
        }


        .advanced-filter-toggle {
            display: flex;

            align-items: center;
            justify-content: space-between;

            width: 100%;

            height: 40px;

            padding: 0 12px;

            background: #f8fafb;

            border: 1px solid #e4e9ed;
            border-radius: 7px;

            color: #687181;

            font-family: Tahoma, Arial, sans-serif;

            font-size: 11px;
            font-weight: bold;

            cursor: pointer;

            outline: none;
        }


        .advanced-filter-toggle:hover {
            background: #f1f7f8;

            border-color: #cbdde0;

            color: #176b78;
        }


        .advanced-filter-toggle-title {
            display: inline-block;
        }


        .advanced-filter-arrow {
            display: inline-flex;

            align-items: center;
            justify-content: center;

            width: 22px;
            height: 22px;

            color: #176b78;

            font-size: 10px;

            transition: transform .2s ease;
        }


        .advanced-filter-arrow.open {
            transform: rotate(180deg);
        }


        /* =====================================================
           ADVANCED FILTERS
           ===================================================== */

        .advanced-filter-section {
            display: none;

            width: 100%;

            margin-top: 15px;

            padding-top: 2px;
        }


        .advanced-filter-section.open {
            display: block;
        }


        .advanced-filter-grid {
            display: grid;

            grid-template-columns:
                repeat(5, minmax(140px, 1fr));

            gap: 14px;

            width: 100%;
        }


        .filter-field {
            display: flex;

            flex-direction: column;

            min-width: 0;
        }


        .filter-field label {
            margin-bottom: 7px;

            color: #687181;

            font-family: Tahoma, Arial, sans-serif;

            font-size: 11px;
            font-weight: bold;
        }


        .tickets-filter-select,
        .tickets-filter-input {
            width: 100%;

            height: 38px;

            padding: 0 10px;

            box-sizing: border-box;

            background: #ffffff;

            border: 1px solid #dfe4e9;
            border-radius: 7px;

            color: #4f5968;

            font-family: Tahoma, Arial, sans-serif;

            font-size: 11px;

            outline: none;
        }


        .tickets-filter-select:focus,
        .tickets-filter-input:focus {
            border-color: #176b78;

            box-shadow:
                0 0 0 2px rgba(23,107,120,.08);
        }


        .tickets-filter-input {
            direction: rtl;
        }


        .tickets-filter-input::placeholder {
            color: #a7adb5;
        }


        /* =====================================================
           FILTER ACTIONS
           ===================================================== */

        .advanced-filter-actions {
            display: flex;

            align-items: center;

            gap: 8px;

            margin-top: 16px;
        }


        .tickets-apply-button,
        .tickets-clear-button {
            height: 36px !important;

            padding: 0 18px !important;

            border-radius: 7px !important;

            font-family: Tahoma, Arial, sans-serif !important;

            font-size: 11px !important;

            cursor: pointer !important;
        }


        .tickets-apply-button {
            background: #176b78 !important;

            border: 1px solid #176b78 !important;

            color: #ffffff !important;
        }


        .tickets-apply-button:hover {
            background: #125b67 !important;

            border-color: #125b67 !important;
        }


        .tickets-clear-button {
            background: #ffffff !important;

            border: 1px solid #dfe4e9 !important;

            color: #687181 !important;
        }


        .tickets-clear-button:hover {
            background: #f5f6f7 !important;

            border-color: #cbd1d8 !important;
        }


        /* =====================================================
           RESULT COUNT
           ===================================================== */

        .tickets-result-count {
            color: #8a929e;

            font-family: Tahoma, Arial, sans-serif;

            font-size: 11px;
        }


        .tickets-result-count span {
            display: inline-flex;

            align-items: center;
            justify-content: center;

            min-width: 25px;
            height: 24px;

            margin-right: 5px;
            padding: 0 7px;

            background: #f0f5f6;

            border-radius: 5px;

            color: #176b78;

            font-weight: bold;
        }


        /* =====================================================
           LIST
           ===================================================== */

        .tickets-list-card {
            width: 100%;

            background: #ffffff;

            border: 1px solid #e7ebef;
            border-radius: 12px;

            box-shadow:
                0 3px 12px rgba(28,39,56,.04);

            overflow: hidden;
        }


        .tickets-list-header {
            min-height: 62px;

            padding: 0 20px;

            display: flex;

            align-items: center;
            justify-content: space-between;

            border-bottom: 1px solid #edf0f3;

            box-sizing: border-box;
        }


        .tickets-list-header h3 {
            margin: 0 0 4px 0;

            color: #273142;

            font-family: Tahoma, Arial, sans-serif;

            font-size: 14px;
            font-weight: bold;
        }


        .tickets-list-header span {
            color: #9aa2ad;

            font-family: Tahoma, Arial, sans-serif;

            font-size: 10px;
        }


        /* =====================================================
           TABLE CONTAINER
           ===================================================== */

        .tickets-table-container {
            width: 100%;

            overflow-x: auto;

            padding: 20px;

            box-sizing: border-box;
        }


        /* =====================================================
           TABLE
           ===================================================== */

        .tickets-grid {
            width: 100%;

            border-collapse: collapse;

            border-spacing: 0;

            font-family: Tahoma, Arial, sans-serif;
        }


        .tickets-grid th {
            padding: 12px 10px;

            background: #f7f8fa;

            border-bottom: 1px solid #e5e9ee;

            color: #657080;

            font-size: 11px;
            font-weight: bold;

            text-align: right;

            white-space: nowrap;
        }


        .tickets-grid td {
            padding: 12px 10px;

            background: #ffffff;

            border-bottom: 1px solid #edf0f3;

            color: #424b59;

            font-size: 11px;

            vertical-align: middle;

            white-space: nowrap;
        }


        .tickets-grid tr:hover td {
            background: #fafcfd;
        }


        .tickets-grid tr.tickets-unread-row td {
            background: #fff9ed;
        }


        .tickets-grid tr.tickets-unread-row:hover td {
            background: #fff4dc;
        }


        /* =====================================================
           VIEW STATUS
           ===================================================== */

        .tickets-view-status {
            display: inline-block;

            padding: 4px 8px;

            background: #f1f3f5;

            border-radius: 5px;

            color: #777777;

            font-size: 10px;
        }


        .tickets-view-status-read {
            background: #eaf6ed;

            color: #39804a;
        }


        .tickets-view-status-unread {
            background: #fff0d8;

            color: #b36b00;
        }


        /* =====================================================
           DETAILS
           ===================================================== */

        .tickets-details-link {
            color: #176b78 !important;

            font-family: Tahoma, Arial, sans-serif;

            font-size: 11px;
            font-weight: bold;

            text-decoration: none !important;
        }


        .tickets-details-link:hover {
            color: #125b67 !important;

            text-decoration: underline !important;
        }


        /* =====================================================
           EMPTY
           ===================================================== */

        .tickets-empty-row td {
            padding: 35px 20px;

            color: #9299a4;

            text-align: center;
        }


        /* =====================================================
           PAGINATION
           فقط Pager
           ===================================================== */

        .tickets-grid tr.tickets-grid-pager {
            height: 45px !important;

            background: #fafcfd !important;
        }


        .tickets-grid tr.tickets-grid-pager:hover td {
            background: #fafcfd !important;
        }


        .tickets-grid tr.tickets-grid-pager > td {
            padding: 7px 0 !important;

            background: #fafcfd !important;

            border-top: 1px solid #edf0f3 !important;

            border-bottom: none !important;

            text-align: center !important;

            vertical-align: middle !important;
        }


        /* داخلی Pager */

        .tickets-grid tr.tickets-grid-pager table {
            width: auto !important;

            margin: 0 auto !important;

            padding: 0 !important;

            border: none !important;

            border-collapse: separate !important;

            border-spacing: 3px 0 !important;

            direction: ltr !important;
        }


        .tickets-grid tr.tickets-grid-pager table tr {
            height: auto !important;

            background: transparent !important;
        }


        .tickets-grid tr.tickets-grid-pager table td {
            width: auto !important;

            min-width: 0 !important;

            height: 28px !important;

            margin: 0 !important;

            padding: 0 !important;

            background: transparent !important;

            border: none !important;

            text-align: center !important;

            vertical-align: middle !important;

            font-size: 0 !important;
        }


        /* شماره صفحه */

        .tickets-grid tr.tickets-grid-pager table td a {
            display: inline-block !important;

            width: 28px !important;
            height: 28px !important;

            min-width: 28px !important;
            max-width: 28px !important;

            margin: 0 !important;
            padding: 0 !important;

            box-sizing: border-box !important;

            background: #f7f9fa !important;

            border: 1px solid #dfe6ea !important;

            border-radius: 6px !important;

            color: #455a64 !important;

            font-family: Tahoma, Arial, sans-serif !important;

            font-size: 11px !important;
            font-weight: normal !important;

            line-height: 26px !important;

            text-align: center !important;

            text-decoration: none !important;
        }


        .tickets-grid tr.tickets-grid-pager table td a:hover {
            background: #eaf5f7 !important;

            border-color: #176b78 !important;

            color: #176b78 !important;

            text-decoration: none !important;
        }


        /* صفحه فعال */

        .tickets-grid tr.tickets-grid-pager table td span {
            display: inline-block !important;

            width: 28px !important;
            height: 28px !important;

            min-width: 28px !important;
            max-width: 28px !important;

            margin: 0 !important;
            padding: 0 !important;

            box-sizing: border-box !important;

            background: #176b78 !important;

            border: 1px solid #176b78 !important;

            border-radius: 6px !important;

            color: #ffffff !important;

            font-family: Tahoma, Arial, sans-serif !important;

            font-size: 11px !important;
            font-weight: normal !important;

            line-height: 26px !important;

            text-align: center !important;
        }


        /* =====================================================
           RESPONSIVE
           ===================================================== */

        @media screen and (max-width: 1100px) {

            .advanced-filter-grid {
                grid-template-columns:
                    repeat(3, minmax(140px, 1fr));
            }

        }


        @media screen and (max-width: 800px) {

            .tickets-page-header {
                display: block;
            }


            .tickets-create-button {
                margin-top: 12px;
            }


            .tickets-filter-buttons {
                gap: 6px;
            }


            .tickets-filter-button {
                min-width: 65px !important;

                padding-left: 9px !important;
                padding-right: 9px !important;
            }


            .advanced-filter-grid {
                grid-template-columns:
                    repeat(2, minmax(130px, 1fr));
            }

        }


        @media screen and (max-width: 500px) {

            .advanced-filter-grid {
                grid-template-columns: 1fr;
            }


            .advanced-filter-actions {
                flex-direction: column;

                align-items: stretch;
            }


            .tickets-apply-button,
            .tickets-clear-button {
                width: 100%;
            }


            .tickets-list-header {
                display: block;

                padding-top: 15px;
                padding-bottom: 15px;
            }


            .tickets-result-count {
                margin-top: 10px;
            }


            .tickets-grid tr.tickets-grid-pager table {
                border-spacing: 2px 0 !important;
            }


            .tickets-grid tr.tickets-grid-pager table td a,
            .tickets-grid tr.tickets-grid-pager table td span {
                width: 26px !important;
                height: 26px !important;

                min-width: 26px !important;
                max-width: 26px !important;

                line-height: 24px !important;

                font-size: 10px !important;
            }

        }



        /* =========================================
   GRIDVIEW PAGINATION
   ========================================= */

.tickets-grid .tickets-pager {
    background: #ffffff !important;
    border-top: 1px solid #edf0f3 !important;
    height: 48px !important;
}

.tickets-grid .tickets-pager td {
    padding: 8px 4px !important;
    text-align: center !important;
    border: none !important;
    background: #ffffff !important;
}

.tickets-grid .tickets-pager a,
.tickets-grid .tickets-pager span {
    display: inline-flex !important;
    align-items: center !important;
    justify-content: center !important;

    min-width: 28px !important;
    height: 28px !important;

    margin: 0 2px !important;
    padding: 0 7px !important;

    box-sizing: border-box !important;

    border: 1px solid #dfe4e9 !important;
    border-radius: 5px !important;

    background: #ffffff !important;

    color: #687181 !important;

    font-family: Tahoma, Arial, sans-serif !important;
    font-size: 10px !important;
    font-weight: normal !important;

    line-height: 26px !important;

    text-decoration: none !important;
}

.tickets-grid .tickets-pager a:hover {
    background: #f3f8f9 !important;
    border-color: #176b78 !important;
    color: #176b78 !important;
}

.tickets-grid .tickets-pager span {
    background: #176b78 !important;
    border-color: #176b78 !important;
    color: #ffffff !important;
    font-weight: bold !important;
}

    </style>


    <!-- =========================================================
         ADVANCED FILTER TOGGLE SCRIPT
         ========================================================= -->

    <script type="text/javascript">

        function toggleAdvancedFilters() {

            var panel =
                document.getElementById("advancedFilterPanel");

            var arrow =
                document.getElementById("advancedFilterArrow");


            if (!panel || !arrow) {
                return;
            }


            if (panel.className.indexOf("open") === -1) {

                panel.className =
                    "advanced-filter-section open";

                arrow.className =
                    "advanced-filter-arrow open";

            }
            else {

                panel.className =
                    "advanced-filter-section";

                arrow.className =
                    "advanced-filter-arrow";

            }

        }

    </script>

</asp:Content>