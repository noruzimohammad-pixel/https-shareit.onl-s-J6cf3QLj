﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web.UI;
using System.Web.UI.WebControls;
using WebApplication1.Models;

namespace WebApplication1
{
    public partial class ServiceTopics : Page
    {
        private int SelectedCategoryId
        {
            get
            {
                object value = ViewState["SelectedCategoryId"];

                if (value == null)
                    return 0;

                int id;

                if (int.TryParse(value.ToString(), out id))
                    return id;

                return 0;
            }
            set
            {
                ViewState["SelectedCategoryId"] = value;
            }
        }

        private int EditTopicId
        {
            get
            {
                object value = ViewState["EditTopicId"];

                if (value == null)
                    return 0;

                int id;

                if (int.TryParse(value.ToString(), out id))
                    return id;

                return 0;
            }
            set
            {
                ViewState["EditTopicId"] = value;
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadCategories();

                pnlTopicEdit.Visible = false;
                pnlSelectedCategory.Visible = false;
                pnlNoCategorySelected.Visible = true;
                lblNoTopics.Visible = false;
            }
        }

        private void LoadCategories()
        {
            string search = txtCategorySearch == null
                ? ""
                : txtCategorySearch.Text.Trim();

            using (var db = new ApplicationDbContext())
            {
                string sql = @"
                    SELECT
                        c.ServiceCategoryId,
                        c.CategoryName,
                        c.Description,
                        c.IsActive,
                        (
                            SELECT COUNT(*)
                            FROM ServiceTopics t
                            WHERE t.ServiceCategoryId = c.ServiceCategoryId
                        ) AS TopicCount
                    FROM ServiceCategories c
                    WHERE 1 = 1
                ";

                if (!string.IsNullOrEmpty(search))
                {
                    sql += @"
                        AND c.CategoryName LIKE @Search
                    ";
                }

                sql += @"
                    ORDER BY
                        c.DisplayOrder ASC,
                        c.CategoryName ASC
                ";

                List<CategoryItem> list;

                if (string.IsNullOrEmpty(search))
                {
                    list = db.Database.SqlQuery<CategoryItem>(sql).ToList();
                }
                else
                {
                    list = db.Database.SqlQuery<CategoryItem>(
                        sql,
                        new SqlParameter("@Search", "%" + search + "%")
                    ).ToList();
                }

                rptCategories.DataSource = list;
                rptCategories.DataBind();

                lblNoCategories.Visible = list.Count == 0;
            }
        }

        private void LoadSelectedCategory()
        {
            int categoryId = SelectedCategoryId;

            if (categoryId <= 0)
            {
                pnlSelectedCategory.Visible = false;
                pnlNoCategorySelected.Visible = true;
                return;
            }

            using (var db = new ApplicationDbContext())
            {
                var category = db.Database.SqlQuery<CategoryItem>(
                    @"
                    SELECT
                        c.ServiceCategoryId,
                        c.CategoryName,
                        c.Description,
                        c.IsActive,
                        (
                            SELECT COUNT(*)
                            FROM ServiceTopics t
                            WHERE t.ServiceCategoryId = c.ServiceCategoryId
                        ) AS TopicCount
                    FROM ServiceCategories c
                    WHERE c.ServiceCategoryId = @CategoryId
                    ",
                    new SqlParameter("@CategoryId", categoryId)
                ).FirstOrDefault();

                if (category == null)
                {
                    SelectedCategoryId = 0;
                    pnlSelectedCategory.Visible = false;
                    pnlNoCategorySelected.Visible = true;
                    return;
                }

                lblSelectedCategoryName.Text =
                    Server.HtmlEncode(category.CategoryName);

                lblSelectedCategoryDescription.Text =
                    Server.HtmlEncode(
                        string.IsNullOrEmpty(category.Description)
                            ? "توضیحاتی برای این حوزه ثبت نشده است."
                            : category.Description
                    );

                pnlSelectedCategory.Visible = true;
                pnlNoCategorySelected.Visible = false;
            }

            LoadTopics();
        }

        private void LoadTopics()
        {
            int categoryId = SelectedCategoryId;

            if (categoryId <= 0)
            {
                rptTopics.DataSource = null;
                rptTopics.DataBind();

                lblNoTopics.Visible = false;
                return;
            }

            using (var db = new ApplicationDbContext())
            {
                var list = db.Database.SqlQuery<TopicItem>(
                    @"
                    SELECT
                        t.ServiceTopicId,
                        t.ServiceCategoryId,
                        t.TopicName,
                        t.Description,
                        t.IsActive,
                        t.DisplayOrder,
                        t.CreatedAt
                    FROM ServiceTopics t
                    WHERE t.ServiceCategoryId = @CategoryId
                    ORDER BY
                        t.DisplayOrder ASC,
                        t.TopicName ASC
                    ",
                    new SqlParameter("@CategoryId", categoryId)
                ).ToList();

                rptTopics.DataSource = list;
                rptTopics.DataBind();

                lblNoTopics.Visible = list.Count == 0;
            }
        }

        protected void txtCategorySearch_TextChanged(object sender, EventArgs e)
        {
            LoadCategories();

            if (SelectedCategoryId > 0)
            {
                LoadSelectedCategory();
            }
        }

        protected void rptCategories_ItemCommand(
            object source,
            RepeaterCommandEventArgs e)
        {
            if (e.CommandName != "SelectCategory")
                return;

            int categoryId;

            if (!int.TryParse(e.CommandArgument.ToString(), out categoryId))
                return;

            SelectedCategoryId = categoryId;

            CancelTopicEdit(false);

            LoadCategories();
            LoadSelectedCategory();
        }

        protected void btnNewTopic_Click(object sender, EventArgs e)
        {
            if (SelectedCategoryId <= 0)
            {
                ShowError("ابتدا یک حوزه خدمات را انتخاب کنید.");
                return;
            }

            EditTopicId = 0;

            ClearTopicForm();

            ddlTopicCategory.SelectedValue =
                SelectedCategoryId.ToString();

            lblTopicEditTitle.Text = "افزودن موضوع جدید";

            pnlTopicEdit.Visible = true;

            LoadSelectedCategory();
        }

        protected void btnSaveTopic_Click(object sender, EventArgs e)
        {
            HideMessage();

            string topicName = txtTopicName.Text.Trim();
            string description = txtTopicDescription.Text.Trim();

            int categoryId;
            int displayOrder;

            if (!int.TryParse(ddlTopicCategory.SelectedValue, out categoryId) ||
                categoryId <= 0)
            {
                ShowError("لطفاً حوزه خدمت را انتخاب کنید.");
                return;
            }

            if (string.IsNullOrWhiteSpace(topicName))
            {
                ShowError("نام موضوع را وارد کنید.");
                return;
            }

            if (!int.TryParse(txtDisplayOrder.Text.Trim(), out displayOrder))
            {
                ShowError("ترتیب نمایش باید یک عدد صحیح باشد.");
                return;
            }

            if (displayOrder < 0)
            {
                ShowError("ترتیب نمایش نمی‌تواند منفی باشد.");
                return;
            }

            using (var db = new ApplicationDbContext())
            {
                int categoryExists = db.Database.SqlQuery<int>(
                    @"
                    SELECT COUNT(*)
                    FROM ServiceCategories
                    WHERE ServiceCategoryId = @CategoryId
                    ",
                    new SqlParameter("@CategoryId", categoryId)
                ).First();

                if (categoryExists == 0)
                {
                    ShowError("حوزه انتخاب‌شده وجود ندارد.");
                    return;
                }

                int duplicateCount;

                if (EditTopicId > 0)
                {
                    duplicateCount = db.Database.SqlQuery<int>(
                        @"
                        SELECT COUNT(*)
                        FROM ServiceTopics
                        WHERE ServiceCategoryId = @CategoryId
                          AND TopicName = @TopicName
                          AND ServiceTopicId <> @TopicId
                        ",
                        new SqlParameter("@CategoryId", categoryId),
                        new SqlParameter("@TopicName", topicName),
                        new SqlParameter("@TopicId", EditTopicId)
                    ).First();

                    if (duplicateCount > 0)
                    {
                        ShowError("موضوعی با این نام در این حوزه قبلاً ثبت شده است.");
                        return;
                    }

                    db.Database.ExecuteSqlCommand(
                        @"
                        UPDATE ServiceTopics
                        SET
                            ServiceCategoryId = @CategoryId,
                            TopicName = @TopicName,
                            Description = @Description,
                            IsActive = @IsActive,
                            DisplayOrder = @DisplayOrder
                        WHERE ServiceTopicId = @TopicId
                        ",
                        new SqlParameter("@CategoryId", categoryId),
                        new SqlParameter("@TopicName", topicName),
                        new SqlParameter("@Description",
                            string.IsNullOrEmpty(description)
                                ? (object)DBNull.Value
                                : description),
                        new SqlParameter("@IsActive", chkTopicActive.Checked),
                        new SqlParameter("@DisplayOrder", displayOrder),
                        new SqlParameter("@TopicId", EditTopicId)
                    );

                    SelectedCategoryId = categoryId;

                    EditTopicId = 0;

                    ClearTopicForm();

                    pnlTopicEdit.Visible = false;

                    ShowSuccess("موضوع با موفقیت ویرایش شد.");

                    LoadCategories();
                    LoadSelectedCategory();

                    return;
                }

                duplicateCount = db.Database.SqlQuery<int>(
                    @"
                    SELECT COUNT(*)
                    FROM ServiceTopics
                    WHERE ServiceCategoryId = @CategoryId
                      AND TopicName = @TopicName
                    ",
                    new SqlParameter("@CategoryId", categoryId),
                    new SqlParameter("@TopicName", topicName)
                ).First();

                if (duplicateCount > 0)
                {
                    ShowError("موضوعی با این نام در این حوزه قبلاً ثبت شده است.");
                    return;
                }

                db.Database.ExecuteSqlCommand(
                    @"
                    INSERT INTO ServiceTopics
                    (
                        ServiceCategoryId,
                        TopicName,
                        Description,
                        IsActive,
                        DisplayOrder,
                        CreatedAt
                    )
                    VALUES
                    (
                        @CategoryId,
                        @TopicName,
                        @Description,
                        @IsActive,
                        @DisplayOrder,
                        GETDATE()
                    )
                    ",
                    new SqlParameter("@CategoryId", categoryId),
                    new SqlParameter("@TopicName", topicName),
                    new SqlParameter("@Description",
                        string.IsNullOrEmpty(description)
                            ? (object)DBNull.Value
                            : description),
                    new SqlParameter("@IsActive", chkTopicActive.Checked),
                    new SqlParameter("@DisplayOrder", displayOrder)
                );

                SelectedCategoryId = categoryId;

                ClearTopicForm();

                pnlTopicEdit.Visible = false;

                ShowSuccess("موضوع جدید با موفقیت ثبت شد.");

                LoadCategories();
                LoadSelectedCategory();
            }
        }

        protected void btnCancelTopic_Click(object sender, EventArgs e)
        {
            CancelTopicEdit(true);
        }

        private void CancelTopicEdit(bool reload)
        {
            EditTopicId = 0;

            ClearTopicForm();

            pnlTopicEdit.Visible = false;

            if (reload)
            {
                LoadCategories();

                if (SelectedCategoryId > 0)
                    LoadSelectedCategory();
            }
        }

        private void ClearTopicForm()
        {
            txtTopicName.Text = "";
            txtTopicDescription.Text = "";
            txtDisplayOrder.Text = "0";

            chkTopicActive.Checked = true;

            ddlTopicCategory.Items.Clear();
            LoadTopicCategories();

            if (SelectedCategoryId > 0 &&
                ddlTopicCategory.Items.FindByValue(
                    SelectedCategoryId.ToString()) != null)
            {
                ddlTopicCategory.SelectedValue =
                    SelectedCategoryId.ToString();
            }

            lblTopicEditTitle.Text = "افزودن موضوع جدید";
        }

        private void LoadTopicCategories()
        {
            using (var db = new ApplicationDbContext())
            {
                var list = db.Database.SqlQuery<CategoryItem>(
                    @"
                    SELECT
                        ServiceCategoryId,
                        CategoryName,
                        Description,
                        IsActive,
                        0 AS TopicCount
                    FROM ServiceCategories
                    WHERE IsActive = 1
                    ORDER BY
                        DisplayOrder ASC,
                        CategoryName ASC
                    "
                ).ToList();

                ddlTopicCategory.Items.Clear();

                ddlTopicCategory.Items.Add(
                    new ListItem("انتخاب حوزه خدمت", "")
                );

                foreach (var category in list)
                {
                    ddlTopicCategory.Items.Add(
                        new ListItem(
                            category.CategoryName,
                            category.ServiceCategoryId.ToString()
                        )
                    );
                }
            }
        }

        protected void rptTopics_ItemCommand(
            object source,
            RepeaterCommandEventArgs e)
        {
            int topicId;

            if (!int.TryParse(e.CommandArgument.ToString(), out topicId))
                return;

            if (e.CommandName == "EditTopic")
            {
                EditTopic(topicId);
                return;
            }

            if (e.CommandName == "ToggleTopic")
            {
                ToggleTopic(topicId);
            }
        }

        private void EditTopic(int topicId)
        {
            using (var db = new ApplicationDbContext())
            {
                var topic = db.Database.SqlQuery<TopicItem>(
                    @"
                    SELECT
                        ServiceTopicId,
                        ServiceCategoryId,
                        TopicName,
                        Description,
                        IsActive,
                        DisplayOrder,
                        CreatedAt
                    FROM ServiceTopics
                    WHERE ServiceTopicId = @TopicId
                    ",
                    new SqlParameter("@TopicId", topicId)
                ).FirstOrDefault();

                if (topic == null)
                {
                    ShowError("موضوع موردنظر پیدا نشد.");
                    return;
                }

                EditTopicId = topic.ServiceTopicId;

                SelectedCategoryId = topic.ServiceCategoryId;

                LoadTopicCategories();

                if (ddlTopicCategory.Items.FindByValue(
                    topic.ServiceCategoryId.ToString()) != null)
                {
                    ddlTopicCategory.SelectedValue =
                        topic.ServiceCategoryId.ToString();
                }

                txtTopicName.Text = topic.TopicName ?? "";
                txtTopicDescription.Text = topic.Description ?? "";
                txtDisplayOrder.Text =
                    topic.DisplayOrder.ToString();

                chkTopicActive.Checked = topic.IsActive;

                lblTopicEditTitle.Text =
                    "ویرایش موضوع";

                pnlTopicEdit.Visible = true;

                LoadCategories();
                LoadSelectedCategory();
            }
        }

        private void ToggleTopic(int topicId)
        {
            using (var db = new ApplicationDbContext())
            {
                var topic = db.Database.SqlQuery<TopicItem>(
                    @"
                    SELECT
                        ServiceTopicId,
                        ServiceCategoryId,
                        TopicName,
                        Description,
                        IsActive,
                        DisplayOrder,
                        CreatedAt
                    FROM ServiceTopics
                    WHERE ServiceTopicId = @TopicId
                    ",
                    new SqlParameter("@TopicId", topicId)
                ).FirstOrDefault();

                if (topic == null)
                {
                    ShowError("موضوع موردنظر پیدا نشد.");
                    return;
                }

                bool newStatus = !topic.IsActive;

                db.Database.ExecuteSqlCommand(
                    @"
                    UPDATE ServiceTopics
                    SET IsActive = @IsActive
                    WHERE ServiceTopicId = @TopicId
                    ",
                    new SqlParameter("@IsActive", newStatus),
                    new SqlParameter("@TopicId", topicId)
                );

                SelectedCategoryId = topic.ServiceCategoryId;

                ShowSuccess(
                    newStatus
                        ? "موضوع فعال شد."
                        : "موضوع غیرفعال شد."
                );

                LoadCategories();
                LoadSelectedCategory();
            }
        }

        public string GetCategoryCss(object categoryId)
        {
            int id;

            if (!int.TryParse(categoryId.ToString(), out id))
                return "category-item";

            if (id == SelectedCategoryId)
                return "category-item category-item-selected";

            return "category-item";
        }

        public string GetActiveBadgeCss(object value)
        {
            bool active = Convert.ToBoolean(value);

            return active
                ? "badge-service badge-active"
                : "badge-service badge-inactive";
        }

        public string GetActiveText(object value)
        {
            bool active = Convert.ToBoolean(value);

            return active
                ? "فعال"
                : "غیرفعال";
        }

        public string GetToggleText(object value)
        {
            bool active = Convert.ToBoolean(value);

            return active
                ? "غیرفعال کردن"
                : "فعال کردن";
        }

        private void ShowSuccess(string message)
        {
            lblMessage.Text = Server.HtmlEncode(message);
            lblMessage.CssClass =
                "message-service message-success";
            lblMessage.Visible = true;
        }

        private void ShowError(string message)
        {
            lblMessage.Text = Server.HtmlEncode(message);
            lblMessage.CssClass =
                "message-service message-error";
            lblMessage.Visible = true;
        }

        private void HideMessage()
        {
            lblMessage.Visible = false;
            lblMessage.Text = "";
        }

        public class CategoryItem
        {
            public int ServiceCategoryId { get; set; }
            public string CategoryName { get; set; }
            public string Description { get; set; }
            public bool IsActive { get; set; }
            public int TopicCount { get; set; }
        }

        public class TopicItem
        {
            public int ServiceTopicId { get; set; }
            public int ServiceCategoryId { get; set; }
            public string TopicName { get; set; }
            public string Description { get; set; }
            public bool IsActive { get; set; }
            public int DisplayOrder { get; set; }
            public DateTime CreatedAt { get; set; }
        }
    }
}