﻿using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;
using WebApplication1.Models;

namespace WebApplication1
{
    public static class IdentityConfig
    {
        public static void CreateRoles()
        {
            using (var context = new ApplicationDbContext())
            {
                var roleManager = new RoleManager<IdentityRole>(
                    new RoleStore<IdentityRole>(context));

                string[] roles =
                {
                    "User",
                    "Manager",
                    "Specialist"
                };

                foreach (var role in roles)
                {
                    if (!roleManager.RoleExists(role))
                    {
                        roleManager.Create(new IdentityRole(role));
                    }
                }
            }
        }

        public static void CreateAdminUser()
        {
            using (var context = new ApplicationDbContext())
            {
                var userManager = new UserManager<ApplicationUser>(
                    new UserStore<ApplicationUser>(context));

                string userName = "admin";
                string password = "Admin@123456";

                var user = userManager.FindByName(userName);

                if (user == null)
                {
                    user = new ApplicationUser
                    {
                        UserName = userName
                    };

                    var result = userManager.Create(user, password);

                    if (result.Succeeded)
                    {
                        userManager.AddToRole(user.Id, "Manager");
                    }
                }
                else
                {
                    if (!userManager.IsInRole(user.Id, "Manager"))
                    {
                        userManager.AddToRole(user.Id, "Manager");
                    }

                    userManager.RemovePassword(user.Id);
                    userManager.AddPassword(user.Id, password);
                }
            }
        }
    }
}

