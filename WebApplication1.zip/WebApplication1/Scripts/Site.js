﻿(function () {

    "use strict";


    /* =========================================================
       SIDEBAR
       ========================================================= */

    window.toggleSidebar = function () {

        var sidebar =
            document.getElementById("sidebar");

        var overlay =
            document.getElementById("sidebarOverlay");

        var menuButton =
            document.querySelector(".mobile-menu-button");


        if (!sidebar)
            return;


        var isOpen =
            sidebar.classList.contains("mobile-open");


        if (isOpen) {

            sidebar.classList.remove(
                "mobile-open"
            );


            if (overlay) {

                overlay.classList.remove(
                    "active"
                );
            }


            if (menuButton) {

                menuButton.setAttribute(
                    "aria-expanded",
                    "false"
                );
            }

        }
        else {

            sidebar.classList.add(
                "mobile-open"
            );


            if (overlay) {

                overlay.classList.add(
                    "active"
                );
            }


            if (menuButton) {

                menuButton.setAttribute(
                    "aria-expanded",
                    "true"
                );
            }
        }
    };


    /* =========================================================
       CLOSE SIDEBAR
       ========================================================= */

    window.closeSidebarOnMobile = function () {

        if (window.innerWidth > 800)
            return;


        var sidebar =
            document.getElementById("sidebar");

        var overlay =
            document.getElementById("sidebarOverlay");

        var menuButton =
            document.querySelector(".mobile-menu-button");


        if (sidebar) {

            sidebar.classList.remove(
                "mobile-open"
            );
        }


        if (overlay) {

            overlay.classList.remove(
                "active"
            );
        }


        if (menuButton) {

            menuButton.setAttribute(
                "aria-expanded",
                "false"
            );
        }
    };


    /* =========================================================
       ESC KEY
       ========================================================= */

    document.addEventListener(
        "keydown",
        function (event) {

            if (event.key === "Escape") {

                window.closeSidebarOnMobile();
            }

        }
    );


    /* =========================================================
       RESIZE
       ========================================================= */

    window.addEventListener(
        "resize",
        function () {

            if (window.innerWidth > 800) {

                var sidebar =
                    document.getElementById(
                        "sidebar"
                    );

                var overlay =
                    document.getElementById(
                        "sidebarOverlay"
                    );

                var menuButton =
                    document.querySelector(
                        ".mobile-menu-button"
                    );


                if (sidebar) {

                    sidebar.classList.remove(
                        "mobile-open"
                    );
                }


                if (overlay) {

                    overlay.classList.remove(
                        "active"
                    );
                }


                if (menuButton) {

                    menuButton.setAttribute(
                        "aria-expanded",
                        "false"
                    );
                }
            }

        }
    );


    /* =========================================================
       TOAST
       ========================================================= */

    window.showToast = function (
        message,
        type
    ) {

        var toast =
            document.getElementById("toast");

        var toastMessage =
            document.getElementById(
                "toastMessage"
            );

        var toastIcon =
            document.getElementById(
                "toastIcon"
            );


        if (!toast)
            return;


        if (toastMessage) {

            toastMessage.innerHTML =
                message || "";
        }


        if (toastIcon) {

            if (type === "error") {

                toastIcon.innerHTML = "×";

            }
            else if (type === "warning") {

                toastIcon.innerHTML = "!";

            }
            else {

                toastIcon.innerHTML = "✓";
            }
        }


        toast.classList.remove(
            "toast-success",
            "toast-error",
            "toast-warning"
        );


        if (type === "error") {

            toast.classList.add(
                "toast-error"
            );

        }
        else if (type === "warning") {

            toast.classList.add(
                "toast-warning"
            );

        }
        else {

            toast.classList.add(
                "toast-success"
            );
        }


        toast.classList.add(
            "show"
        );


        window.clearTimeout(
            window.toastTimer
        );


        window.toastTimer =
            window.setTimeout(
                function () {

                    window.hideToast();

                },
                4000
            );
    };


    /* =========================================================
       HIDE TOAST
       ========================================================= */

    window.hideToast = function () {

        var toast =
            document.getElementById("toast");


        if (!toast)
            return;


        toast.classList.remove(
            "show"
        );
    };


    /* =========================================================
       CLOSE SIDEBAR WHEN CLICKING OUTSIDE
       ========================================================= */

    document.addEventListener(
        "click",
        function (event) {

            if (window.innerWidth > 800)
                return;


            var sidebar =
                document.getElementById(
                    "sidebar"
                );

            var menuButton =
                document.querySelector(
                    ".mobile-menu-button"
                );


            if (!sidebar ||
                !sidebar.classList.contains(
                    "mobile-open"
                ))
                return;


            if (sidebar.contains(event.target))
                return;


            if (menuButton &&
                menuButton.contains(event.target))
                return;


            window.closeSidebarOnMobile();

        }
    );


})();