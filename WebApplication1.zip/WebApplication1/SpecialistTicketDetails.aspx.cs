﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web.UI;
using System.Web.UI.WebControls;
using Microsoft.AspNet.Identity;
using WebApplication1.Models;

namespace WebApplication1
{
    public partial class SpecialistTicketDetails : System.Web.UI.Page
    {
        private int TicketId
        {
            get
            {
                int id;

                if (int.TryParse(Request.QueryString["id"], out id))
                    return id;

                return 0;
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Request.IsAuthenticated)
            {
                Response.Redirect("~/Login.aspx");
                return;
            }

            if (!User.IsInRole("Specialist"))
            {
                Response.Redirect("~/Login.aspx");
                return;
            }

            if (TicketId <= 0)
            {
                Response.Redirect("~/SpecialistTickets.aspx");
                return;
            }

            if (!IsPostBack)
            {
                LoadTicket();
                LoadServiceCategories();
                LoadCurrentDiagnosis();
                LoadActions();
                LoadHistory();

                hfActiveTab.Value = "tabInfo";
            }
        }

        private void LoadTicket()
        {
            string currentUserId = User.Identity.GetUserId();

            using (var db = new ApplicationDbContext())
            {
                var ticket = db.Tickets
                    .FirstOrDefault(t =>
                        t.TicketId == TicketId &&
                        t.AssignedTo == currentUserId);

                if (ticket == null)
                {
                    Response.Redirect("~/SpecialistTickets.aspx");
                    return;
                }

                lblTicketId.Text =
                    ticket.TicketId.ToString();

                lblInfoTicketId.Text =
                    ticket.TicketId.ToString();

                lblSubject.Text =
                    ticket.Subject ?? "";

                lblInfoSubject.Text =
                    ticket.Subject ?? "";

                lblDescription.Text =
                    ticket.Description ?? "";

                lblCategory.Text =
                    GetCategoryText(ticket.Category);

                lblInfoCategory.Text =
                    GetCategoryText(ticket.Category);

                lblPriority.Text =
                    GetPriorityText(ticket.Priority);

                lblInfoPriority.Text =
                    GetPriorityText(ticket.Priority);

                lblStatus.Text =
                    GetStatusText(ticket.Status);

                lblInfoStatus.Text =
                    GetStatusText(ticket.Status);

                lblCreatedAt.Text =
                    ticket.CreatedAt.ToString(
                        "yyyy/MM/dd HH:mm");

                var profile =
                    db.UserProfiles
                        .FirstOrDefault(
                            p => p.UserId == ticket.UserId);

                if (profile != null)
                {
                    lblRequester.Text =
                        string.IsNullOrEmpty(profile.FullName)
                            ? "بدون نام"
                            : profile.FullName;

                    if (profile.DepartmentId.HasValue)
                    {
                        var department =
                            db.Departments
                                .FirstOrDefault(
                                    d =>
                                        d.DepartmentId ==
                                        profile.DepartmentId.Value);

                        lblDepartment.Text =
                            department == null
                                ? "بدون بخش"
                                : department.DepartmentName;
                    }
                    else
                    {
                        lblDepartment.Text =
                            "بدون بخش";
                    }
                }
                else
                {
                    lblRequester.Text =
                        "بدون نام";

                    lblDepartment.Text =
                        "بدون بخش";
                }

                if (ticket.Status == "Assigned")
                {
                    pnlStart.Visible = true;
                    pnlWork.Visible = false;
                }
                else if (ticket.Status == "InProgress")
                {
                    pnlStart.Visible = false;
                    pnlWork.Visible = true;
                }
                else
                {
                    pnlStart.Visible = false;
                    pnlWork.Visible = false;
                }
            }
        }

        private void LoadServiceCategories()
        {
            using (var db = new ApplicationDbContext())
            {
                var categories =
                    db.Database
                        .SqlQuery<ServiceCategoryItem>(
                            @"
                            SELECT
                                ServiceCategoryId,
                                CategoryName
                            FROM ServiceCategories
                            WHERE IsActive = 1
                            ORDER BY DisplayOrder, CategoryName")
                        .ToList();

                ddlServiceCategory.Items.Clear();

                ddlServiceCategory.Items.Add(
                    new ListItem(
                        "انتخاب حوزه مشکل",
                        ""));

                foreach (var category in categories)
                {
                    ddlServiceCategory.Items.Add(
                        new ListItem(
                            category.CategoryName,
                            category.ServiceCategoryId.ToString()));
                }
            }
        }

        protected void ddlServiceCategory_SelectedIndexChanged(
            object sender,
            EventArgs e)
        {
            LoadServiceTopics();

            hfActiveTab.Value =
                "tabDiagnosis";
        }

        private void LoadServiceTopics()
        {
            ddlServiceTopic.Items.Clear();

            ddlServiceTopic.Items.Add(
                new ListItem(
                    "ابتدا حوزه مشکل را انتخاب کنید",
                    ""));

            int categoryId;

            if (!int.TryParse(
                ddlServiceCategory.SelectedValue,
                out categoryId))
            {
                return;
            }

            using (var db = new ApplicationDbContext())
            {
                var topics =
                    db.Database
                        .SqlQuery<ServiceTopicItem>(
                            @"
                            SELECT
                                ServiceTopicId,
                                TopicName
                            FROM ServiceTopics
                            WHERE ServiceCategoryId = @CategoryId
                              AND IsActive = 1
                            ORDER BY DisplayOrder, TopicName",
                            new SqlParameter(
                                "@CategoryId",
                                categoryId))
                        .ToList();

                foreach (var topic in topics)
                {
                    ddlServiceTopic.Items.Add(
                        new ListItem(
                            topic.TopicName,
                            topic.ServiceTopicId.ToString()));
                }
            }
        }

        private void LoadCurrentDiagnosis()
        {
            pnlCurrentDiagnosis.Visible = false;
            lblCurrentDiagnosis.Text = "";

            using (var db = new ApplicationDbContext())
            {
                var result =
                    db.Database
                        .SqlQuery<CurrentDiagnosisItem>(
                            @"
                            SELECT
                                T.ServiceTopicId,
                                ST.TopicName,
                                SC.CategoryName
                            FROM Tickets T
                            INNER JOIN ServiceTopics ST
                                ON T.ServiceTopicId =
                                   ST.ServiceTopicId
                            INNER JOIN ServiceCategories SC
                                ON ST.ServiceCategoryId =
                                   SC.ServiceCategoryId
                            WHERE T.TicketId = @TicketId",
                            new SqlParameter(
                                "@TicketId",
                                TicketId))
                        .FirstOrDefault();

                if (result == null)
                    return;

                pnlCurrentDiagnosis.Visible = true;

                lblCurrentDiagnosis.Text =
                    result.CategoryName +
                    " ← " +
                    result.TopicName;

                ddlServiceCategory.ClearSelection();

                ListItem categoryItem =
                    ddlServiceCategory.Items
                        .FindByText(
                            result.CategoryName);

                if (categoryItem != null)
                {
                    categoryItem.Selected = true;

                    LoadServiceTopics();

                    ddlServiceTopic.ClearSelection();

                    ListItem topicItem =
                        ddlServiceTopic.Items
                            .FindByText(
                                result.TopicName);

                    if (topicItem != null)
                    {
                        topicItem.Selected = true;
                    }
                }
            }
        }

        protected void btnSaveDiagnosis_Click(
            object sender,
            EventArgs e)
        {
            hfActiveTab.Value =
                "tabDiagnosis";

            int categoryId;
            int topicId;

            if (!int.TryParse(
                ddlServiceCategory.SelectedValue,
                out categoryId))
            {
                ShowError(
                    "لطفاً حوزه واقعی مشکل را انتخاب کنید.");

                return;
            }

            if (!int.TryParse(
                ddlServiceTopic.SelectedValue,
                out topicId))
            {
                ShowError(
                    "لطفاً موضوع واقعی مشکل را انتخاب کنید.");

                return;
            }

            string currentUserId =
                User.Identity.GetUserId();

            using (var db = new ApplicationDbContext())
            {
                var ticket =
                    db.Tickets
                        .FirstOrDefault(
                            t =>
                                t.TicketId == TicketId &&
                                t.AssignedTo == currentUserId);

                if (ticket == null)
                {
                    ShowError(
                        "درخواست پیدا نشد یا این درخواست به شما ارجاع نشده است.");

                    return;
                }

                if (ticket.Status != "Assigned" &&
                    ticket.Status != "InProgress")
                {
                    ShowError(
                        "در وضعیت فعلی امکان ثبت تشخیص وجود ندارد.");

                    return;
                }

                int validTopicCount =
                    db.Database
                        .SqlQuery<int>(
                            @"
                            SELECT COUNT(*)
                            FROM ServiceTopics
                            WHERE ServiceTopicId = @TopicId
                              AND ServiceCategoryId = @CategoryId
                              AND IsActive = 1",
                            new SqlParameter(
                                "@TopicId",
                                topicId),
                            new SqlParameter(
                                "@CategoryId",
                                categoryId))
                        .FirstOrDefault();

                if (validTopicCount <= 0)
                {
                    ShowError(
                        "موضوع انتخاب‌شده با حوزه مشکل مطابقت ندارد.");

                    return;
                }

                int? oldTopicId =
                    ticket.ServiceTopicId;

                ticket.ServiceTopicId =
                    topicId;

                var history =
                    new TicketHistory
                    {
                        TicketId =
                            ticket.TicketId,

                        UserId =
                            currentUserId,

                        OldStatus =
                            ticket.Status,

                        NewStatus =
                            ticket.Status,

                        Description =
                            oldTopicId.HasValue
                                ? "تشخیص مشکل درخواست توسط متخصص اصلاح شد."
                                : "تشخیص مشکل درخواست توسط متخصص ثبت شد.",

                        HistoryDate =
                            DateTime.Now
                    };

                db.TicketHistory.Add(history);

                db.SaveChanges();
            }

            ShowSuccess(
                "تشخیص مشکل با موفقیت ثبت شد.");

            LoadTicket();
            LoadCurrentDiagnosis();
            LoadHistory();
        }

        protected void btnReturnTicket_Click(
            object sender,
            EventArgs e)
        {
            hfActiveTab.Value =
                "tabDiagnosis";

            string reason =
                txtReturnReason.Text.Trim();

            if (string.IsNullOrEmpty(reason))
            {
                ShowError(
                    "لطفاً علت مرجوع کردن درخواست را وارد کنید.");

                return;
            }

            string currentUserId =
                User.Identity.GetUserId();

            using (var db = new ApplicationDbContext())
            {
                var ticket =
                    db.Tickets
                        .FirstOrDefault(
                            t =>
                                t.TicketId == TicketId &&
                                t.AssignedTo == currentUserId);

                if (ticket == null)
                {
                    ShowError(
                        "درخواست پیدا نشد یا این درخواست به شما ارجاع نشده است.");

                    return;
                }

                if (ticket.Status != "Assigned" &&
                    ticket.Status != "InProgress")
                {
                    ShowError(
                        "این درخواست در وضعیت قابل مرجوع کردن قرار ندارد.");

                    return;
                }

                string oldStatus =
                    ticket.Status;

                ticket.Status =
                    "New";

                ticket.AssignedTo =
                    null;

                ticket.AssignedAt =
                    null;

                ticket.ServiceTopicId =
                    null;

                ticket.ResolvedAt =
                    null;

                ticket.ConfirmationRequestedAt =
                    null;

                ticket.UserConfirmed =
                    false;

                ticket.AutoClosed =
                    false;

                var history =
                    new TicketHistory
                    {
                        TicketId =
                            ticket.TicketId,

                        UserId =
                            currentUserId,

                        OldStatus =
                            oldStatus,

                        NewStatus =
                            "New",

                        Description =
                            "درخواست توسط متخصص به دلیل نادرست بودن حوزه مشکل مرجوع شد. علت: " +
                            reason,

                        HistoryDate =
                            DateTime.Now
                    };

                db.TicketHistory.Add(history);

                db.SaveChanges();
            }

            ShowSuccess(
                "درخواست با موفقیت مرجوع شد و برای بررسی و ارجاع مجدد به مدیر بازگشت.");

            txtReturnReason.Text = "";

            LoadTicket();
            LoadCurrentDiagnosis();
            LoadActions();
            LoadHistory();
        }

        protected void btnStartWork_Click(
            object sender,
            EventArgs e)
        {
            hfActiveTab.Value =
                "tabOperations";

            string currentUserId =
                User.Identity.GetUserId();

            using (var db = new ApplicationDbContext())
            {
                var ticket =
                    db.Tickets
                        .FirstOrDefault(
                            t =>
                                t.TicketId == TicketId &&
                                t.AssignedTo == currentUserId);

                if (ticket == null)
                {
                    ShowError(
                        "درخواست پیدا نشد یا این درخواست به شما ارجاع نشده است.");

                    return;
                }

                if (ticket.Status != "Assigned")
                {
                    ShowError(
                        "این درخواست در وضعیت قابل شروع قرار ندارد.");

                    return;
                }

                string oldStatus =
                    ticket.Status;

                ticket.Status =
                    "InProgress";

                if (!ticket.AssignedAt.HasValue)
                {
                    ticket.AssignedAt =
                        DateTime.Now;
                }

                var history =
                    new TicketHistory
                    {
                        TicketId =
                            ticket.TicketId,

                        UserId =
                            currentUserId,

                        OldStatus =
                            oldStatus,

                        NewStatus =
                            "InProgress",

                        Description =
                            "متخصص رسیدگی به درخواست را آغاز کرد.",

                        HistoryDate =
                            DateTime.Now
                    };

                db.TicketHistory.Add(history);

                db.SaveChanges();
            }

            ShowSuccess(
                "رسیدگی به درخواست آغاز شد.");

            LoadTicket();
            LoadActions();
            LoadHistory();
        }

        protected void btnAddAction_Click(
            object sender,
            EventArgs e)
        {
            hfActiveTab.Value =
                "tabOperations";

            string actionText =
                txtActionText.Text.Trim();

            if (string.IsNullOrEmpty(actionText))
            {
                ShowError(
                    "شرح اقدام را وارد کنید.");

                return;
            }

            string currentUserId =
                User.Identity.GetUserId();

            using (var db = new ApplicationDbContext())
            {
                var ticket =
                    db.Tickets
                        .FirstOrDefault(
                            t =>
                                t.TicketId == TicketId &&
                                t.AssignedTo == currentUserId);

                if (ticket == null)
                {
                    ShowError(
                        "درخواست پیدا نشد یا این درخواست به شما ارجاع نشده است.");

                    return;
                }

                if (ticket.Status != "InProgress")
                {
                    ShowError(
                        "ثبت اقدام فقط در وضعیت «در حال انجام» امکان‌پذیر است.");

                    return;
                }

                var action =
                    new TicketAction
                    {
                        TicketId =
                            ticket.TicketId,

                        UserId =
                            currentUserId,

                        ActionText =
                            actionText,

                        ActionDate =
                            DateTime.Now
                    };

                db.TicketActions.Add(action);

                var history =
                    new TicketHistory
                    {
                        TicketId =
                            ticket.TicketId,

                        UserId =
                            currentUserId,

                        OldStatus =
                            ticket.Status,

                        NewStatus =
                            ticket.Status,

                        Description =
                            "اقدام متخصص ثبت شد: " +
                            actionText,

                        HistoryDate =
                            DateTime.Now
                    };

                db.TicketHistory.Add(history);

                db.SaveChanges();
            }

            txtActionText.Text =
                "";

            ShowSuccess(
                "اقدام با موفقیت ثبت شد.");

            LoadTicket();
            LoadActions();
            LoadHistory();
        }

        protected void btnFinishWork_Click(
            object sender,
            EventArgs e)
        {
            hfActiveTab.Value =
                "tabOperations";

            string currentUserId =
                User.Identity.GetUserId();

            using (var db = new ApplicationDbContext())
            {
                var ticket =
                    db.Tickets
                        .FirstOrDefault(
                            t =>
                                t.TicketId == TicketId &&
                                t.AssignedTo == currentUserId);

                if (ticket == null)
                {
                    ShowError(
                        "درخواست پیدا نشد یا این درخواست به شما ارجاع نشده است.");

                    return;
                }

                if (ticket.Status != "InProgress")
                {
                    ShowError(
                        "این درخواست در وضعیت قابل اتمام قرار ندارد.");

                    return;
                }

                bool hasAction =
                    db.TicketActions
                        .Any(
                            a =>
                                a.TicketId ==
                                ticket.TicketId);

                if (!hasAction)
                {
                    ShowError(
                        "قبل از اتمام کار، حداقل یک اقدام انجام‌شده را ثبت کنید.");

                    return;
                }

                string oldStatus =
                    ticket.Status;

                ticket.Status =
                    "WaitingConfirmation";

                ticket.ResolvedAt =
                    DateTime.Now;

                ticket.ConfirmationRequestedAt =
                    DateTime.Now;

                ticket.UserConfirmed =
                    false;

                ticket.AutoClosed =
                    false;

                var history =
                    new TicketHistory
                    {
                        TicketId =
                            ticket.TicketId,

                        UserId =
                            currentUserId,

                        OldStatus =
                            oldStatus,

                        NewStatus =
                            "WaitingConfirmation",

                        Description =
                            "کار درخواست انجام شد و برای تأیید کاربر ارسال گردید.",

                        HistoryDate =
                            DateTime.Now
                    };

                db.TicketHistory.Add(history);

                db.SaveChanges();
            }

            ShowSuccess(
                "کار با موفقیت ثبت شد و درخواست برای تأیید کاربر ارسال گردید.");

            LoadTicket();
            LoadActions();
            LoadHistory();
        }

        private void LoadActions()
        {
            using (var db = new ApplicationDbContext())
            {
                var actions =
                    db.TicketActions
                        .Where(
                            a =>
                                a.TicketId ==
                                TicketId)
                        .OrderByDescending(
                            a =>
                                a.ActionDate)
                        .ToList()
                        .Select(
                            a =>
                                new
                                {
                                    a.ActionId,

                                    ActionDate =
                                        a.ActionDate
                                            .ToString(
                                                "yyyy/MM/dd HH:mm"),

                                    UserName =
                                        GetUserDisplayName(
                                            db,
                                            a.UserId),

                                    a.ActionText
                                })
                        .ToList();

                gvActions.DataSource =
                    actions;

                gvActions.DataBind();
            }
        }

        private void LoadHistory()
        {
            using (var db = new ApplicationDbContext())
            {
                var history =
                    db.TicketHistory
                        .Where(
                            h =>
                                h.TicketId ==
                                TicketId)
                        .OrderByDescending(
                            h =>
                                h.HistoryDate)
                        .ToList()
                        .Select(
                            h =>
                                new
                                {
                                    h.HistoryId,

                                    HistoryDate =
                                        h.HistoryDate
                                            .ToString(
                                                "yyyy/MM/dd HH:mm"),

                                    UserName =
                                        GetUserDisplayName(
                                            db,
                                            h.UserId),

                                    OldStatus =
                                        GetStatusText(
                                            h.OldStatus),

                                    NewStatus =
                                        GetStatusText(
                                            h.NewStatus),

                                    h.Description
                                })
                        .ToList();

                gvHistory.DataSource =
                    history;

                gvHistory.DataBind();
            }
        }

        private string GetUserDisplayName(
            ApplicationDbContext db,
            string userId)
        {
            var profile =
                db.UserProfiles
                    .FirstOrDefault(
                        p =>
                            p.UserId ==
                            userId);

            if (profile != null &&
                !string.IsNullOrEmpty(
                    profile.FullName))
            {
                return profile.FullName;
            }

            var user =
                db.Users
                    .FirstOrDefault(
                        u =>
                            u.Id ==
                            userId);

            if (user != null &&
                !string.IsNullOrEmpty(
                    user.UserName))
            {
                return user.UserName;
            }

            return "نامشخص";
        }

        private void ShowSuccess(
            string message)
        {
            lblMessage.Text =
                message;

            lblMessage.ForeColor =
                System.Drawing.Color.Green;

            lblMessage.BackColor =
                System.Drawing.Color.Honeydew;

            lblMessage.Visible =
                true;
        }

        private void ShowError(
            string message)
        {
            lblMessage.Text =
                message;

            lblMessage.ForeColor =
                System.Drawing.Color.DarkRed;

            lblMessage.BackColor =
                System.Drawing.Color.MistyRose;

            lblMessage.Visible =
                true;
        }

        private string GetCategoryText(
            string category)
        {
            switch (category)
            {
                case "نرم‌افزار":
                    return "نرم‌افزار";

                case "سخت‌افزار":
                    return "سخت‌افزار";

                case "شبکه":
                    return "شبکه";

                case "امنیت":
                    return "امنیت";

                case "سایر":
                    return "سایر";

                default:
                    return string.IsNullOrEmpty(category)
                        ? "-"
                        : category;
            }
        }

        private string GetPriorityText(
            string priority)
        {
            switch (priority)
            {
                case "Low":
                    return "کم";

                case "Normal":
                    return "عادی";

                case "High":
                    return "زیاد";

                case "Critical":
                    return "بحرانی";

                default:
                    return string.IsNullOrEmpty(priority)
                        ? "-"
                        : priority;
            }
        }

        private string GetStatusText(
            string status)
        {
            switch (status)
            {
                case "New":
                    return "جدید";

                case "Assigned":
                    return "ارجاع شده";

                case "InProgress":
                    return "در حال انجام";

                case "WaitingConfirmation":
                    return "منتظر تأیید کاربر";

                case "Closed":
                    return "خاتمه یافته";

                default:
                    return string.IsNullOrEmpty(status)
                        ? "-"
                        : status;
            }
        }

        private class ServiceCategoryItem
        {
            public int ServiceCategoryId { get; set; }

            public string CategoryName { get; set; }
        }

        private class ServiceTopicItem
        {
            public int ServiceTopicId { get; set; }

            public string TopicName { get; set; }
        }

        private class CurrentDiagnosisItem
        {
            public int ServiceTopicId { get; set; }

            public string TopicName { get; set; }

            public string CategoryName { get; set; }
        }
    }
}